var Po=Object.defineProperty;var To=(s,t,e)=>t in s?Po(s,t,{enumerable:!0,configurable:!0,writable:!0,value:e}):s[t]=e;var G=(s,t,e)=>(To(s,typeof t!="symbol"?t+"":t,e),e);import{_ as Lt}from"./tslib.es6.UDDzLUu6.js";import{d as Oo,m as Ro,b as ko}from"./holochainClient.DKKklgPY.js";/**
 * @license
 * Copyright 2019 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const _e=globalThis,hs=_e.ShadowRoot&&(_e.ShadyCSS===void 0||_e.ShadyCSS.nativeShadow)&&"adoptedStyleSheets"in Document.prototype&&"replace"in CSSStyleSheet.prototype,ds=Symbol(),Ts=new WeakMap;let Ti=class{constructor(t,e,i){if(this._$cssResult$=!0,i!==ds)throw Error("CSSResult is not constructable. Use `unsafeCSS` or `css` instead.");this.cssText=t,this.t=e}get styleSheet(){let t=this.o;const e=this.t;if(hs&&t===void 0){const i=e!==void 0&&e.length===1;i&&(t=Ts.get(e)),t===void 0&&((this.o=t=new CSSStyleSheet).replaceSync(this.cssText),i&&Ts.set(e,t))}return t}toString(){return this.cssText}};const Mo=s=>new Ti(typeof s=="string"?s:s+"",void 0,ds),zo=(s,...t)=>{const e=s.length===1?s[0]:t.reduce((i,o,r)=>i+(n=>{if(n._$cssResult$===!0)return n.cssText;if(typeof n=="number")return n;throw Error("Value passed to 'css' function must be a 'css' function result: "+n+". Use 'unsafeCSS' to pass non-literal values, but take care to ensure page security.")})(o)+s[r+1],s[0]);return new Ti(e,s,ds)},Uo=(s,t)=>{if(hs)s.adoptedStyleSheets=t.map(e=>e instanceof CSSStyleSheet?e:e.styleSheet);else for(const e of t){const i=document.createElement("style"),o=_e.litNonce;o!==void 0&&i.setAttribute("nonce",o),i.textContent=e.cssText,s.appendChild(i)}},Os=hs?s=>s:s=>s instanceof CSSStyleSheet?(t=>{let e="";for(const i of t.cssRules)e+=i.cssText;return Mo(e)})(s):s;/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const{is:Lo,defineProperty:Ho,getOwnPropertyDescriptor:No,getOwnPropertyNames:Bo,getOwnPropertySymbols:Do,getPrototypeOf:Io}=Object,st=globalThis,Rs=st.trustedTypes,jo=Rs?Rs.emptyScript:"",je=st.reactiveElementPolyfillSupport,Zt=(s,t)=>s,Se={toAttribute(s,t){switch(t){case Boolean:s=s?jo:null;break;case Object:case Array:s=s==null?s:JSON.stringify(s)}return s},fromAttribute(s,t){let e=s;switch(t){case Boolean:e=s!==null;break;case Number:e=s===null?null:Number(s);break;case Object:case Array:try{e=JSON.parse(s)}catch{e=null}}return e}},ps=(s,t)=>!Lo(s,t),ks={attribute:!0,type:String,converter:Se,reflect:!1,hasChanged:ps};Symbol.metadata??(Symbol.metadata=Symbol("metadata")),st.litPropertyMetadata??(st.litPropertyMetadata=new WeakMap);let St=class extends HTMLElement{static addInitializer(t){this._$Ei(),(this.l??(this.l=[])).push(t)}static get observedAttributes(){return this.finalize(),this._$Eh&&[...this._$Eh.keys()]}static createProperty(t,e=ks){if(e.state&&(e.attribute=!1),this._$Ei(),this.elementProperties.set(t,e),!e.noAccessor){const i=Symbol(),o=this.getPropertyDescriptor(t,i,e);o!==void 0&&Ho(this.prototype,t,o)}}static getPropertyDescriptor(t,e,i){const{get:o,set:r}=No(this.prototype,t)??{get(){return this[e]},set(n){this[e]=n}};return{get(){return o==null?void 0:o.call(this)},set(n){const l=o==null?void 0:o.call(this);r.call(this,n),this.requestUpdate(t,l,i)},configurable:!0,enumerable:!0}}static getPropertyOptions(t){return this.elementProperties.get(t)??ks}static _$Ei(){if(this.hasOwnProperty(Zt("elementProperties")))return;const t=Io(this);t.finalize(),t.l!==void 0&&(this.l=[...t.l]),this.elementProperties=new Map(t.elementProperties)}static finalize(){if(this.hasOwnProperty(Zt("finalized")))return;if(this.finalized=!0,this._$Ei(),this.hasOwnProperty(Zt("properties"))){const e=this.properties,i=[...Bo(e),...Do(e)];for(const o of i)this.createProperty(o,e[o])}const t=this[Symbol.metadata];if(t!==null){const e=litPropertyMetadata.get(t);if(e!==void 0)for(const[i,o]of e)this.elementProperties.set(i,o)}this._$Eh=new Map;for(const[e,i]of this.elementProperties){const o=this._$Eu(e,i);o!==void 0&&this._$Eh.set(o,e)}this.elementStyles=this.finalizeStyles(this.styles)}static finalizeStyles(t){const e=[];if(Array.isArray(t)){const i=new Set(t.flat(1/0).reverse());for(const o of i)e.unshift(Os(o))}else t!==void 0&&e.push(Os(t));return e}static _$Eu(t,e){const i=e.attribute;return i===!1?void 0:typeof i=="string"?i:typeof t=="string"?t.toLowerCase():void 0}constructor(){super(),this._$Ep=void 0,this.isUpdatePending=!1,this.hasUpdated=!1,this._$Em=null,this._$Ev()}_$Ev(){var t;this._$ES=new Promise(e=>this.enableUpdating=e),this._$AL=new Map,this._$E_(),this.requestUpdate(),(t=this.constructor.l)==null||t.forEach(e=>e(this))}addController(t){var e;(this._$EO??(this._$EO=new Set)).add(t),this.renderRoot!==void 0&&this.isConnected&&((e=t.hostConnected)==null||e.call(t))}removeController(t){var e;(e=this._$EO)==null||e.delete(t)}_$E_(){const t=new Map,e=this.constructor.elementProperties;for(const i of e.keys())this.hasOwnProperty(i)&&(t.set(i,this[i]),delete this[i]);t.size>0&&(this._$Ep=t)}createRenderRoot(){const t=this.shadowRoot??this.attachShadow(this.constructor.shadowRootOptions);return Uo(t,this.constructor.elementStyles),t}connectedCallback(){var t;this.renderRoot??(this.renderRoot=this.createRenderRoot()),this.enableUpdating(!0),(t=this._$EO)==null||t.forEach(e=>{var i;return(i=e.hostConnected)==null?void 0:i.call(e)})}enableUpdating(t){}disconnectedCallback(){var t;(t=this._$EO)==null||t.forEach(e=>{var i;return(i=e.hostDisconnected)==null?void 0:i.call(e)})}attributeChangedCallback(t,e,i){this._$AK(t,i)}_$EC(t,e){var r;const i=this.constructor.elementProperties.get(t),o=this.constructor._$Eu(t,i);if(o!==void 0&&i.reflect===!0){const n=(((r=i.converter)==null?void 0:r.toAttribute)!==void 0?i.converter:Se).toAttribute(e,i.type);this._$Em=t,n==null?this.removeAttribute(o):this.setAttribute(o,n),this._$Em=null}}_$AK(t,e){var r;const i=this.constructor,o=i._$Eh.get(t);if(o!==void 0&&this._$Em!==o){const n=i.getPropertyOptions(o),l=typeof n.converter=="function"?{fromAttribute:n.converter}:((r=n.converter)==null?void 0:r.fromAttribute)!==void 0?n.converter:Se;this._$Em=o,this[o]=l.fromAttribute(e,n.type),this._$Em=null}}requestUpdate(t,e,i){if(t!==void 0){if(i??(i=this.constructor.getPropertyOptions(t)),!(i.hasChanged??ps)(this[t],e))return;this.P(t,e,i)}this.isUpdatePending===!1&&(this._$ES=this._$ET())}P(t,e,i){this._$AL.has(t)||this._$AL.set(t,e),i.reflect===!0&&this._$Em!==t&&(this._$Ej??(this._$Ej=new Set)).add(t)}async _$ET(){this.isUpdatePending=!0;try{await this._$ES}catch(e){Promise.reject(e)}const t=this.scheduleUpdate();return t!=null&&await t,!this.isUpdatePending}scheduleUpdate(){return this.performUpdate()}performUpdate(){var i;if(!this.isUpdatePending)return;if(!this.hasUpdated){if(this.renderRoot??(this.renderRoot=this.createRenderRoot()),this._$Ep){for(const[r,n]of this._$Ep)this[r]=n;this._$Ep=void 0}const o=this.constructor.elementProperties;if(o.size>0)for(const[r,n]of o)n.wrapped!==!0||this._$AL.has(r)||this[r]===void 0||this.P(r,this[r],n)}let t=!1;const e=this._$AL;try{t=this.shouldUpdate(e),t?(this.willUpdate(e),(i=this._$EO)==null||i.forEach(o=>{var r;return(r=o.hostUpdate)==null?void 0:r.call(o)}),this.update(e)):this._$EU()}catch(o){throw t=!1,this._$EU(),o}t&&this._$AE(e)}willUpdate(t){}_$AE(t){var e;(e=this._$EO)==null||e.forEach(i=>{var o;return(o=i.hostUpdated)==null?void 0:o.call(i)}),this.hasUpdated||(this.hasUpdated=!0,this.firstUpdated(t)),this.updated(t)}_$EU(){this._$AL=new Map,this.isUpdatePending=!1}get updateComplete(){return this.getUpdateComplete()}getUpdateComplete(){return this._$ES}shouldUpdate(t){return!0}update(t){this._$Ej&&(this._$Ej=this._$Ej.forEach(e=>this._$EC(e,this[e]))),this._$EU()}updated(t){}firstUpdated(t){}};St.elementStyles=[],St.shadowRootOptions={mode:"open"},St[Zt("elementProperties")]=new Map,St[Zt("finalized")]=new Map,je==null||je({ReactiveElement:St}),(st.reactiveElementVersions??(st.reactiveElementVersions=[])).push("2.0.4");/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const Xt=globalThis,Ce=Xt.trustedTypes,Ms=Ce?Ce.createPolicy("lit-html",{createHTML:s=>s}):void 0,Oi="$lit$",Q=`lit$${(Math.random()+"").slice(9)}$`,Ri="?"+Q,Vo=`<${Ri}>`,yt=document,ie=()=>yt.createComment(""),oe=s=>s===null||typeof s!="object"&&typeof s!="function",ki=Array.isArray,Wo=s=>ki(s)||typeof(s==null?void 0:s[Symbol.iterator])=="function",Ve=`[ 	
\f\r]`,Wt=/<(?:(!--|\/[^a-zA-Z])|(\/?[a-zA-Z][^>\s]*)|(\/?$))/g,zs=/-->/g,Us=/>/g,ht=RegExp(`>|${Ve}(?:([^\\s"'>=/]+)(${Ve}*=${Ve}*(?:[^ 	
\f\r"'\`<>=]|("|')|))|$)`,"g"),Ls=/'/g,Hs=/"/g,Mi=/^(?:script|style|textarea|title)$/i,Fo=s=>(t,...e)=>({_$litType$:s,strings:t,values:e}),Ft=Fo(1),$t=Symbol.for("lit-noChange"),S=Symbol.for("lit-nothing"),Ns=new WeakMap,gt=yt.createTreeWalker(yt,129);function zi(s,t){if(!Array.isArray(s)||!s.hasOwnProperty("raw"))throw Error("invalid template strings array");return Ms!==void 0?Ms.createHTML(t):t}const qo=(s,t)=>{const e=s.length-1,i=[];let o,r=t===2?"<svg>":"",n=Wt;for(let l=0;l<e;l++){const a=s[l];let c,d,h=-1,u=0;for(;u<a.length&&(n.lastIndex=u,d=n.exec(a),d!==null);)u=n.lastIndex,n===Wt?d[1]==="!--"?n=zs:d[1]!==void 0?n=Us:d[2]!==void 0?(Mi.test(d[2])&&(o=RegExp("</"+d[2],"g")),n=ht):d[3]!==void 0&&(n=ht):n===ht?d[0]===">"?(n=o??Wt,h=-1):d[1]===void 0?h=-2:(h=n.lastIndex-d[2].length,c=d[1],n=d[3]===void 0?ht:d[3]==='"'?Hs:Ls):n===Hs||n===Ls?n=ht:n===zs||n===Us?n=Wt:(n=ht,o=void 0);const p=n===ht&&s[l+1].startsWith("/>")?" ":"";r+=n===Wt?a+Vo:h>=0?(i.push(c),a.slice(0,h)+Oi+a.slice(h)+Q+p):a+Q+(h===-2?l:p)}return[zi(s,r+(s[e]||"<?>")+(t===2?"</svg>":"")),i]};let is=class Ui{constructor({strings:t,_$litType$:e},i){let o;this.parts=[];let r=0,n=0;const l=t.length-1,a=this.parts,[c,d]=qo(t,e);if(this.el=Ui.createElement(c,i),gt.currentNode=this.el.content,e===2){const h=this.el.content.firstChild;h.replaceWith(...h.childNodes)}for(;(o=gt.nextNode())!==null&&a.length<l;){if(o.nodeType===1){if(o.hasAttributes())for(const h of o.getAttributeNames())if(h.endsWith(Oi)){const u=d[n++],p=o.getAttribute(h).split(Q),f=/([.?@])?(.*)/.exec(u);a.push({type:1,index:r,name:f[2],strings:p,ctor:f[1]==="."?Yo:f[1]==="?"?Zo:f[1]==="@"?Xo:Le}),o.removeAttribute(h)}else h.startsWith(Q)&&(a.push({type:6,index:r}),o.removeAttribute(h));if(Mi.test(o.tagName)){const h=o.textContent.split(Q),u=h.length-1;if(u>0){o.textContent=Ce?Ce.emptyScript:"";for(let p=0;p<u;p++)o.append(h[p],ie()),gt.nextNode(),a.push({type:2,index:++r});o.append(h[u],ie())}}}else if(o.nodeType===8)if(o.data===Ri)a.push({type:2,index:r});else{let h=-1;for(;(h=o.data.indexOf(Q,h+1))!==-1;)a.push({type:7,index:r}),h+=Q.length-1}r++}}static createElement(t,e){const i=yt.createElement("template");return i.innerHTML=t,i}};function kt(s,t,e=s,i){var n,l;if(t===$t)return t;let o=i!==void 0?(n=e._$Co)==null?void 0:n[i]:e._$Cl;const r=oe(t)?void 0:t._$litDirective$;return(o==null?void 0:o.constructor)!==r&&((l=o==null?void 0:o._$AO)==null||l.call(o,!1),r===void 0?o=void 0:(o=new r(s),o._$AT(s,e,i)),i!==void 0?(e._$Co??(e._$Co=[]))[i]=o:e._$Cl=o),o!==void 0&&(t=kt(s,o._$AS(s,t.values),o,i)),t}let Ko=class{constructor(t,e){this._$AV=[],this._$AN=void 0,this._$AD=t,this._$AM=e}get parentNode(){return this._$AM.parentNode}get _$AU(){return this._$AM._$AU}u(t){const{el:{content:e},parts:i}=this._$AD,o=((t==null?void 0:t.creationScope)??yt).importNode(e,!0);gt.currentNode=o;let r=gt.nextNode(),n=0,l=0,a=i[0];for(;a!==void 0;){if(n===a.index){let c;a.type===2?c=new us(r,r.nextSibling,this,t):a.type===1?c=new a.ctor(r,a.name,a.strings,this,t):a.type===6&&(c=new Jo(r,this,t)),this._$AV.push(c),a=i[++l]}n!==(a==null?void 0:a.index)&&(r=gt.nextNode(),n++)}return gt.currentNode=yt,o}p(t){let e=0;for(const i of this._$AV)i!==void 0&&(i.strings!==void 0?(i._$AI(t,i,e),e+=i.strings.length-2):i._$AI(t[e])),e++}},us=class Li{get _$AU(){var t;return((t=this._$AM)==null?void 0:t._$AU)??this._$Cv}constructor(t,e,i,o){this.type=2,this._$AH=S,this._$AN=void 0,this._$AA=t,this._$AB=e,this._$AM=i,this.options=o,this._$Cv=(o==null?void 0:o.isConnected)??!0}get parentNode(){let t=this._$AA.parentNode;const e=this._$AM;return e!==void 0&&(t==null?void 0:t.nodeType)===11&&(t=e.parentNode),t}get startNode(){return this._$AA}get endNode(){return this._$AB}_$AI(t,e=this){t=kt(this,t,e),oe(t)?t===S||t==null||t===""?(this._$AH!==S&&this._$AR(),this._$AH=S):t!==this._$AH&&t!==$t&&this._(t):t._$litType$!==void 0?this.$(t):t.nodeType!==void 0?this.T(t):Wo(t)?this.k(t):this._(t)}S(t){return this._$AA.parentNode.insertBefore(t,this._$AB)}T(t){this._$AH!==t&&(this._$AR(),this._$AH=this.S(t))}_(t){this._$AH!==S&&oe(this._$AH)?this._$AA.nextSibling.data=t:this.T(yt.createTextNode(t)),this._$AH=t}$(t){var r;const{values:e,_$litType$:i}=t,o=typeof i=="number"?this._$AC(t):(i.el===void 0&&(i.el=is.createElement(zi(i.h,i.h[0]),this.options)),i);if(((r=this._$AH)==null?void 0:r._$AD)===o)this._$AH.p(e);else{const n=new Ko(o,this),l=n.u(this.options);n.p(e),this.T(l),this._$AH=n}}_$AC(t){let e=Ns.get(t.strings);return e===void 0&&Ns.set(t.strings,e=new is(t)),e}k(t){ki(this._$AH)||(this._$AH=[],this._$AR());const e=this._$AH;let i,o=0;for(const r of t)o===e.length?e.push(i=new Li(this.S(ie()),this.S(ie()),this,this.options)):i=e[o],i._$AI(r),o++;o<e.length&&(this._$AR(i&&i._$AB.nextSibling,o),e.length=o)}_$AR(t=this._$AA.nextSibling,e){var i;for((i=this._$AP)==null?void 0:i.call(this,!1,!0,e);t&&t!==this._$AB;){const o=t.nextSibling;t.remove(),t=o}}setConnected(t){var e;this._$AM===void 0&&(this._$Cv=t,(e=this._$AP)==null||e.call(this,t))}},Le=class{get tagName(){return this.element.tagName}get _$AU(){return this._$AM._$AU}constructor(t,e,i,o,r){this.type=1,this._$AH=S,this._$AN=void 0,this.element=t,this.name=e,this._$AM=o,this.options=r,i.length>2||i[0]!==""||i[1]!==""?(this._$AH=Array(i.length-1).fill(new String),this.strings=i):this._$AH=S}_$AI(t,e=this,i,o){const r=this.strings;let n=!1;if(r===void 0)t=kt(this,t,e,0),n=!oe(t)||t!==this._$AH&&t!==$t,n&&(this._$AH=t);else{const l=t;let a,c;for(t=r[0],a=0;a<r.length-1;a++)c=kt(this,l[i+a],e,a),c===$t&&(c=this._$AH[a]),n||(n=!oe(c)||c!==this._$AH[a]),c===S?t=S:t!==S&&(t+=(c??"")+r[a+1]),this._$AH[a]=c}n&&!o&&this.j(t)}j(t){t===S?this.element.removeAttribute(this.name):this.element.setAttribute(this.name,t??"")}},Yo=class extends Le{constructor(){super(...arguments),this.type=3}j(t){this.element[this.name]=t===S?void 0:t}},Zo=class extends Le{constructor(){super(...arguments),this.type=4}j(t){this.element.toggleAttribute(this.name,!!t&&t!==S)}},Xo=class extends Le{constructor(t,e,i,o,r){super(t,e,i,o,r),this.type=5}_$AI(t,e=this){if((t=kt(this,t,e,0)??S)===$t)return;const i=this._$AH,o=t===S&&i!==S||t.capture!==i.capture||t.once!==i.once||t.passive!==i.passive,r=t!==S&&(i===S||o);o&&this.element.removeEventListener(this.name,this,i),r&&this.element.addEventListener(this.name,this,t),this._$AH=t}handleEvent(t){var e;typeof this._$AH=="function"?this._$AH.call(((e=this.options)==null?void 0:e.host)??this.element,t):this._$AH.handleEvent(t)}},Jo=class{constructor(t,e,i){this.element=t,this.type=6,this._$AN=void 0,this._$AM=e,this.options=i}get _$AU(){return this._$AM._$AU}_$AI(t){kt(this,t)}};const We=Xt.litHtmlPolyfillSupport;We==null||We(is,us),(Xt.litHtmlVersions??(Xt.litHtmlVersions=[])).push("3.1.2");const Go=(s,t,e)=>{const i=(e==null?void 0:e.renderBefore)??t;let o=i._$litPart$;if(o===void 0){const r=(e==null?void 0:e.renderBefore)??null;i._$litPart$=o=new us(t.insertBefore(ie(),r),r,void 0,e??{})}return o._$AI(s),o};/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */let Jt=class extends St{constructor(){super(...arguments),this.renderOptions={host:this},this._$Do=void 0}createRenderRoot(){var e;const t=super.createRenderRoot();return(e=this.renderOptions).renderBefore??(e.renderBefore=t.firstChild),t}update(t){const e=this.render();this.hasUpdated||(this.renderOptions.isConnected=this.isConnected),super.update(t),this._$Do=Go(e,this.renderRoot,this.renderOptions)}connectedCallback(){var t;super.connectedCallback(),(t=this._$Do)==null||t.setConnected(!0)}disconnectedCallback(){var t;super.disconnectedCallback(),(t=this._$Do)==null||t.setConnected(!1)}render(){return $t}};var Si;Jt._$litElement$=!0,Jt.finalized=!0,(Si=globalThis.litElementHydrateSupport)==null||Si.call(globalThis,{LitElement:Jt});const Fe=globalThis.litElementPolyfillSupport;Fe==null||Fe({LitElement:Jt});(globalThis.litElementVersions??(globalThis.litElementVersions=[])).push("4.0.4");/**
 * @license
 * Copyright 2021 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */let Qo=class extends Event{constructor(t,e,i){super("context-request",{bubbles:!0,composed:!0}),this.context=t,this.callback=e,this.subscribe=i??!1}};/**
 * @license
 * Copyright 2021 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 *//**
 * @license
 * Copyright 2021 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */let Bs=class{constructor(t,e,i,o){if(this.subscribe=!1,this.provided=!1,this.value=void 0,this.t=(r,n)=>{this.unsubscribe&&(this.unsubscribe!==n&&(this.provided=!1,this.unsubscribe()),this.subscribe||this.unsubscribe()),this.value=r,this.host.requestUpdate(),this.provided&&!this.subscribe||(this.provided=!0,this.callback&&this.callback(r,n)),this.unsubscribe=n},this.host=t,e.context!==void 0){const r=e;this.context=r.context,this.callback=r.callback,this.subscribe=r.subscribe??!1}else this.context=e,this.callback=i,this.subscribe=o??!1;this.host.addController(this)}hostConnected(){this.dispatchRequest()}hostDisconnected(){this.unsubscribe&&(this.unsubscribe(),this.unsubscribe=void 0)}dispatchRequest(){this.host.dispatchEvent(new Qo(this.context,this.t,this.subscribe))}};/**
 * @license
 * Copyright 2022 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */function tr({context:s,subscribe:t}){return(e,i)=>{typeof i=="object"?i.addInitializer(function(){new Bs(this,{context:s,callback:o=>{this[i.name]=o},subscribe:t})}):e.constructor.addInitializer(o=>{new Bs(o,{context:s,callback:r=>{o[i]=r},subscribe:t})})}}/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const er=s=>(t,e)=>{e!==void 0?e.addInitializer(()=>{customElements.define(s,t)}):customElements.define(s,t)};/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const sr={attribute:!0,type:String,converter:Se,reflect:!1,hasChanged:ps},ir=(s=sr,t,e)=>{const{kind:i,metadata:o}=e;let r=globalThis.litPropertyMetadata.get(o);if(r===void 0&&globalThis.litPropertyMetadata.set(o,r=new Map),r.set(e.name,s),i==="accessor"){const{name:n}=e;return{set(l){const a=t.get.call(this);t.set.call(this,l),this.requestUpdate(n,a,s)},init(l){return l!==void 0&&this.P(n,void 0,s),l}}}if(i==="setter"){const{name:n}=e;return function(l){const a=this[n];t.call(this,l),this.requestUpdate(n,a,s)}}throw Error("Unsupported decorator location: "+i)};function pe(s){return(t,e)=>typeof e=="object"?ir(s,t,e):((i,o,r)=>{const n=o.hasOwnProperty(r);return o.constructor.createProperty(r,n?{...i,wrapped:!0}:i),n?Object.getOwnPropertyDescriptor(o,r):void 0})(s,t,e)}const or="hc_zome_profiles/store";/**
 * @license
 * Copyright 2021 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const rr=(s,...t)=>({strTag:!0,strings:s,values:t}),Za=rr,nr=s=>typeof s!="string"&&"strTag"in s,ar=(s,t,e)=>{let i=s[0];for(let o=1;o<s.length;o++)i+=t[e?e[o-1]:o-1],i+=s[o];return i};/**
 * @license
 * Copyright 2021 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const lr=s=>nr(s)?ar(s.strings,s.values):s;/**
 * @license
 * Copyright 2021 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const Ds="lit-localize-status";/**
 * @license
 * Copyright 2021 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */let cr=class{constructor(t){this.__litLocalizeEventHandler=e=>{e.detail.status==="ready"&&this.host.requestUpdate()},this.host=t}hostConnected(){window.addEventListener(Ds,this.__litLocalizeEventHandler)}hostDisconnected(){window.removeEventListener(Ds,this.__litLocalizeEventHandler)}};const hr=s=>s.addController(new cr(s)),dr=hr;/**
 * @license
 * Copyright 2021 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const Hi=()=>(s,t)=>(s.addInitializer(dr),s);/**
 * @license
 * Copyright 2020 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */class pr{constructor(){this.settled=!1,this.promise=new Promise((t,e)=>{this._resolve=t,this._reject=e})}resolve(t){this.settled=!0,this._resolve(t)}reject(t){this.settled=!0,this._reject(t)}}/**
 * @license
 * Copyright 2014 Travis Webb
 * SPDX-License-Identifier: MIT
 */for(let s=0;s<256;s++)(s>>4&15).toString(16)+(s&15).toString(16);/**
 * @license
 * Copyright 2021 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */let ur=new pr;ur.resolve();/**
 * @license
 * Copyright 2020 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */let Ni=lr;/**
 * @license
 * Copyright 2019 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const we=globalThis,fs=we.ShadowRoot&&(we.ShadyCSS===void 0||we.ShadyCSS.nativeShadow)&&"adoptedStyleSheets"in Document.prototype&&"replace"in CSSStyleSheet.prototype,gs=Symbol(),Is=new WeakMap;let Bi=class{constructor(t,e,i){if(this._$cssResult$=!0,i!==gs)throw Error("CSSResult is not constructable. Use `unsafeCSS` or `css` instead.");this.cssText=t,this.t=e}get styleSheet(){let t=this.o;const e=this.t;if(fs&&t===void 0){const i=e!==void 0&&e.length===1;i&&(t=Is.get(e)),t===void 0&&((this.o=t=new CSSStyleSheet).replaceSync(this.cssText),i&&Is.set(e,t))}return t}toString(){return this.cssText}};const fr=s=>new Bi(typeof s=="string"?s:s+"",void 0,gs),ms=(s,...t)=>{const e=s.length===1?s[0]:t.reduce((i,o,r)=>i+(n=>{if(n._$cssResult$===!0)return n.cssText;if(typeof n=="number")return n;throw Error("Value passed to 'css' function must be a 'css' function result: "+n+". Use 'unsafeCSS' to pass non-literal values, but take care to ensure page security.")})(o)+s[r+1],s[0]);return new Bi(e,s,gs)},gr=(s,t)=>{if(fs)s.adoptedStyleSheets=t.map(e=>e instanceof CSSStyleSheet?e:e.styleSheet);else for(const e of t){const i=document.createElement("style"),o=we.litNonce;o!==void 0&&i.setAttribute("nonce",o),i.textContent=e.cssText,s.appendChild(i)}},js=fs?s=>s:s=>s instanceof CSSStyleSheet?(t=>{let e="";for(const i of t.cssRules)e+=i.cssText;return fr(e)})(s):s;/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const{is:mr,defineProperty:vr,getOwnPropertyDescriptor:yr,getOwnPropertyNames:$r,getOwnPropertySymbols:br,getPrototypeOf:_r}=Object,it=globalThis,Vs=it.trustedTypes,wr=Vs?Vs.emptyScript:"",qe=it.reactiveElementPolyfillSupport,Gt=(s,t)=>s,Pe={toAttribute(s,t){switch(t){case Boolean:s=s?wr:null;break;case Object:case Array:s=s==null?s:JSON.stringify(s)}return s},fromAttribute(s,t){let e=s;switch(t){case Boolean:e=s!==null;break;case Number:e=s===null?null:Number(s);break;case Object:case Array:try{e=JSON.parse(s)}catch{e=null}}return e}},vs=(s,t)=>!mr(s,t),Ws={attribute:!0,type:String,converter:Pe,reflect:!1,hasChanged:vs};Symbol.metadata??(Symbol.metadata=Symbol("metadata")),it.litPropertyMetadata??(it.litPropertyMetadata=new WeakMap);let Ct=class extends HTMLElement{static addInitializer(t){this._$Ei(),(this.l??(this.l=[])).push(t)}static get observedAttributes(){return this.finalize(),this._$Eh&&[...this._$Eh.keys()]}static createProperty(t,e=Ws){if(e.state&&(e.attribute=!1),this._$Ei(),this.elementProperties.set(t,e),!e.noAccessor){const i=Symbol(),o=this.getPropertyDescriptor(t,i,e);o!==void 0&&vr(this.prototype,t,o)}}static getPropertyDescriptor(t,e,i){const{get:o,set:r}=yr(this.prototype,t)??{get(){return this[e]},set(n){this[e]=n}};return{get(){return o==null?void 0:o.call(this)},set(n){const l=o==null?void 0:o.call(this);r.call(this,n),this.requestUpdate(t,l,i)},configurable:!0,enumerable:!0}}static getPropertyOptions(t){return this.elementProperties.get(t)??Ws}static _$Ei(){if(this.hasOwnProperty(Gt("elementProperties")))return;const t=_r(this);t.finalize(),t.l!==void 0&&(this.l=[...t.l]),this.elementProperties=new Map(t.elementProperties)}static finalize(){if(this.hasOwnProperty(Gt("finalized")))return;if(this.finalized=!0,this._$Ei(),this.hasOwnProperty(Gt("properties"))){const e=this.properties,i=[...$r(e),...br(e)];for(const o of i)this.createProperty(o,e[o])}const t=this[Symbol.metadata];if(t!==null){const e=litPropertyMetadata.get(t);if(e!==void 0)for(const[i,o]of e)this.elementProperties.set(i,o)}this._$Eh=new Map;for(const[e,i]of this.elementProperties){const o=this._$Eu(e,i);o!==void 0&&this._$Eh.set(o,e)}this.elementStyles=this.finalizeStyles(this.styles)}static finalizeStyles(t){const e=[];if(Array.isArray(t)){const i=new Set(t.flat(1/0).reverse());for(const o of i)e.unshift(js(o))}else t!==void 0&&e.push(js(t));return e}static _$Eu(t,e){const i=e.attribute;return i===!1?void 0:typeof i=="string"?i:typeof t=="string"?t.toLowerCase():void 0}constructor(){super(),this._$Ep=void 0,this.isUpdatePending=!1,this.hasUpdated=!1,this._$Em=null,this._$Ev()}_$Ev(){var t;this._$ES=new Promise(e=>this.enableUpdating=e),this._$AL=new Map,this._$E_(),this.requestUpdate(),(t=this.constructor.l)==null||t.forEach(e=>e(this))}addController(t){var e;(this._$EO??(this._$EO=new Set)).add(t),this.renderRoot!==void 0&&this.isConnected&&((e=t.hostConnected)==null||e.call(t))}removeController(t){var e;(e=this._$EO)==null||e.delete(t)}_$E_(){const t=new Map,e=this.constructor.elementProperties;for(const i of e.keys())this.hasOwnProperty(i)&&(t.set(i,this[i]),delete this[i]);t.size>0&&(this._$Ep=t)}createRenderRoot(){const t=this.shadowRoot??this.attachShadow(this.constructor.shadowRootOptions);return gr(t,this.constructor.elementStyles),t}connectedCallback(){var t;this.renderRoot??(this.renderRoot=this.createRenderRoot()),this.enableUpdating(!0),(t=this._$EO)==null||t.forEach(e=>{var i;return(i=e.hostConnected)==null?void 0:i.call(e)})}enableUpdating(t){}disconnectedCallback(){var t;(t=this._$EO)==null||t.forEach(e=>{var i;return(i=e.hostDisconnected)==null?void 0:i.call(e)})}attributeChangedCallback(t,e,i){this._$AK(t,i)}_$EC(t,e){var r;const i=this.constructor.elementProperties.get(t),o=this.constructor._$Eu(t,i);if(o!==void 0&&i.reflect===!0){const n=(((r=i.converter)==null?void 0:r.toAttribute)!==void 0?i.converter:Pe).toAttribute(e,i.type);this._$Em=t,n==null?this.removeAttribute(o):this.setAttribute(o,n),this._$Em=null}}_$AK(t,e){var r;const i=this.constructor,o=i._$Eh.get(t);if(o!==void 0&&this._$Em!==o){const n=i.getPropertyOptions(o),l=typeof n.converter=="function"?{fromAttribute:n.converter}:((r=n.converter)==null?void 0:r.fromAttribute)!==void 0?n.converter:Pe;this._$Em=o,this[o]=l.fromAttribute(e,n.type),this._$Em=null}}requestUpdate(t,e,i){if(t!==void 0){if(i??(i=this.constructor.getPropertyOptions(t)),!(i.hasChanged??vs)(this[t],e))return;this.P(t,e,i)}this.isUpdatePending===!1&&(this._$ES=this._$ET())}P(t,e,i){this._$AL.has(t)||this._$AL.set(t,e),i.reflect===!0&&this._$Em!==t&&(this._$Ej??(this._$Ej=new Set)).add(t)}async _$ET(){this.isUpdatePending=!0;try{await this._$ES}catch(e){Promise.reject(e)}const t=this.scheduleUpdate();return t!=null&&await t,!this.isUpdatePending}scheduleUpdate(){return this.performUpdate()}performUpdate(){var i;if(!this.isUpdatePending)return;if(!this.hasUpdated){if(this.renderRoot??(this.renderRoot=this.createRenderRoot()),this._$Ep){for(const[r,n]of this._$Ep)this[r]=n;this._$Ep=void 0}const o=this.constructor.elementProperties;if(o.size>0)for(const[r,n]of o)n.wrapped!==!0||this._$AL.has(r)||this[r]===void 0||this.P(r,this[r],n)}let t=!1;const e=this._$AL;try{t=this.shouldUpdate(e),t?(this.willUpdate(e),(i=this._$EO)==null||i.forEach(o=>{var r;return(r=o.hostUpdate)==null?void 0:r.call(o)}),this.update(e)):this._$EU()}catch(o){throw t=!1,this._$EU(),o}t&&this._$AE(e)}willUpdate(t){}_$AE(t){var e;(e=this._$EO)==null||e.forEach(i=>{var o;return(o=i.hostUpdated)==null?void 0:o.call(i)}),this.hasUpdated||(this.hasUpdated=!0,this.firstUpdated(t)),this.updated(t)}_$EU(){this._$AL=new Map,this.isUpdatePending=!1}get updateComplete(){return this.getUpdateComplete()}getUpdateComplete(){return this._$ES}shouldUpdate(t){return!0}update(t){this._$Ej&&(this._$Ej=this._$Ej.forEach(e=>this._$EC(e,this[e]))),this._$EU()}updated(t){}firstUpdated(t){}};Ct.elementStyles=[],Ct.shadowRootOptions={mode:"open"},Ct[Gt("elementProperties")]=new Map,Ct[Gt("finalized")]=new Map,qe==null||qe({ReactiveElement:Ct}),(it.reactiveElementVersions??(it.reactiveElementVersions=[])).push("2.0.4");/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const Qt=globalThis,Te=Qt.trustedTypes,Fs=Te?Te.createPolicy("lit-html",{createHTML:s=>s}):void 0,Di="$lit$",tt=`lit$${(Math.random()+"").slice(9)}$`,Ii="?"+tt,Ar=`<${Ii}>`,bt=document,re=()=>bt.createComment(""),ne=s=>s===null||typeof s!="object"&&typeof s!="function",ji=Array.isArray,xr=s=>ji(s)||typeof(s==null?void 0:s[Symbol.iterator])=="function",Ke=`[ 	
\f\r]`,qt=/<(?:(!--|\/[^a-zA-Z])|(\/?[a-zA-Z][^>\s]*)|(\/?$))/g,qs=/-->/g,Ks=/>/g,dt=RegExp(`>|${Ke}(?:([^\\s"'>=/]+)(${Ke}*=${Ke}*(?:[^ 	
\f\r"'\`<>=]|("|')|))|$)`,"g"),Ys=/'/g,Zs=/"/g,Vi=/^(?:script|style|textarea|title)$/i,Er=s=>(t,...e)=>({_$litType$:s,strings:t,values:e}),ut=Er(1),_t=Symbol.for("lit-noChange"),C=Symbol.for("lit-nothing"),Xs=new WeakMap,mt=bt.createTreeWalker(bt,129);function Wi(s,t){if(!Array.isArray(s)||!s.hasOwnProperty("raw"))throw Error("invalid template strings array");return Fs!==void 0?Fs.createHTML(t):t}const Sr=(s,t)=>{const e=s.length-1,i=[];let o,r=t===2?"<svg>":"",n=qt;for(let l=0;l<e;l++){const a=s[l];let c,d,h=-1,u=0;for(;u<a.length&&(n.lastIndex=u,d=n.exec(a),d!==null);)u=n.lastIndex,n===qt?d[1]==="!--"?n=qs:d[1]!==void 0?n=Ks:d[2]!==void 0?(Vi.test(d[2])&&(o=RegExp("</"+d[2],"g")),n=dt):d[3]!==void 0&&(n=dt):n===dt?d[0]===">"?(n=o??qt,h=-1):d[1]===void 0?h=-2:(h=n.lastIndex-d[2].length,c=d[1],n=d[3]===void 0?dt:d[3]==='"'?Zs:Ys):n===Zs||n===Ys?n=dt:n===qs||n===Ks?n=qt:(n=dt,o=void 0);const p=n===dt&&s[l+1].startsWith("/>")?" ":"";r+=n===qt?a+Ar:h>=0?(i.push(c),a.slice(0,h)+Di+a.slice(h)+tt+p):a+tt+(h===-2?l:p)}return[Wi(s,r+(s[e]||"<?>")+(t===2?"</svg>":"")),i]};let os=class Fi{constructor({strings:t,_$litType$:e},i){let o;this.parts=[];let r=0,n=0;const l=t.length-1,a=this.parts,[c,d]=Sr(t,e);if(this.el=Fi.createElement(c,i),mt.currentNode=this.el.content,e===2){const h=this.el.content.firstChild;h.replaceWith(...h.childNodes)}for(;(o=mt.nextNode())!==null&&a.length<l;){if(o.nodeType===1){if(o.hasAttributes())for(const h of o.getAttributeNames())if(h.endsWith(Di)){const u=d[n++],p=o.getAttribute(h).split(tt),f=/([.?@])?(.*)/.exec(u);a.push({type:1,index:r,name:f[2],strings:p,ctor:f[1]==="."?Pr:f[1]==="?"?Tr:f[1]==="@"?Or:He}),o.removeAttribute(h)}else h.startsWith(tt)&&(a.push({type:6,index:r}),o.removeAttribute(h));if(Vi.test(o.tagName)){const h=o.textContent.split(tt),u=h.length-1;if(u>0){o.textContent=Te?Te.emptyScript:"";for(let p=0;p<u;p++)o.append(h[p],re()),mt.nextNode(),a.push({type:2,index:++r});o.append(h[u],re())}}}else if(o.nodeType===8)if(o.data===Ii)a.push({type:2,index:r});else{let h=-1;for(;(h=o.data.indexOf(tt,h+1))!==-1;)a.push({type:7,index:r}),h+=tt.length-1}r++}}static createElement(t,e){const i=bt.createElement("template");return i.innerHTML=t,i}};function Mt(s,t,e=s,i){var n,l;if(t===_t)return t;let o=i!==void 0?(n=e._$Co)==null?void 0:n[i]:e._$Cl;const r=ne(t)?void 0:t._$litDirective$;return(o==null?void 0:o.constructor)!==r&&((l=o==null?void 0:o._$AO)==null||l.call(o,!1),r===void 0?o=void 0:(o=new r(s),o._$AT(s,e,i)),i!==void 0?(e._$Co??(e._$Co=[]))[i]=o:e._$Cl=o),o!==void 0&&(t=Mt(s,o._$AS(s,t.values),o,i)),t}let Cr=class{constructor(t,e){this._$AV=[],this._$AN=void 0,this._$AD=t,this._$AM=e}get parentNode(){return this._$AM.parentNode}get _$AU(){return this._$AM._$AU}u(t){const{el:{content:e},parts:i}=this._$AD,o=((t==null?void 0:t.creationScope)??bt).importNode(e,!0);mt.currentNode=o;let r=mt.nextNode(),n=0,l=0,a=i[0];for(;a!==void 0;){if(n===a.index){let c;a.type===2?c=new ys(r,r.nextSibling,this,t):a.type===1?c=new a.ctor(r,a.name,a.strings,this,t):a.type===6&&(c=new Rr(r,this,t)),this._$AV.push(c),a=i[++l]}n!==(a==null?void 0:a.index)&&(r=mt.nextNode(),n++)}return mt.currentNode=bt,o}p(t){let e=0;for(const i of this._$AV)i!==void 0&&(i.strings!==void 0?(i._$AI(t,i,e),e+=i.strings.length-2):i._$AI(t[e])),e++}},ys=class qi{get _$AU(){var t;return((t=this._$AM)==null?void 0:t._$AU)??this._$Cv}constructor(t,e,i,o){this.type=2,this._$AH=C,this._$AN=void 0,this._$AA=t,this._$AB=e,this._$AM=i,this.options=o,this._$Cv=(o==null?void 0:o.isConnected)??!0}get parentNode(){let t=this._$AA.parentNode;const e=this._$AM;return e!==void 0&&(t==null?void 0:t.nodeType)===11&&(t=e.parentNode),t}get startNode(){return this._$AA}get endNode(){return this._$AB}_$AI(t,e=this){t=Mt(this,t,e),ne(t)?t===C||t==null||t===""?(this._$AH!==C&&this._$AR(),this._$AH=C):t!==this._$AH&&t!==_t&&this._(t):t._$litType$!==void 0?this.$(t):t.nodeType!==void 0?this.T(t):xr(t)?this.k(t):this._(t)}S(t){return this._$AA.parentNode.insertBefore(t,this._$AB)}T(t){this._$AH!==t&&(this._$AR(),this._$AH=this.S(t))}_(t){this._$AH!==C&&ne(this._$AH)?this._$AA.nextSibling.data=t:this.T(bt.createTextNode(t)),this._$AH=t}$(t){var r;const{values:e,_$litType$:i}=t,o=typeof i=="number"?this._$AC(t):(i.el===void 0&&(i.el=os.createElement(Wi(i.h,i.h[0]),this.options)),i);if(((r=this._$AH)==null?void 0:r._$AD)===o)this._$AH.p(e);else{const n=new Cr(o,this),l=n.u(this.options);n.p(e),this.T(l),this._$AH=n}}_$AC(t){let e=Xs.get(t.strings);return e===void 0&&Xs.set(t.strings,e=new os(t)),e}k(t){ji(this._$AH)||(this._$AH=[],this._$AR());const e=this._$AH;let i,o=0;for(const r of t)o===e.length?e.push(i=new qi(this.S(re()),this.S(re()),this,this.options)):i=e[o],i._$AI(r),o++;o<e.length&&(this._$AR(i&&i._$AB.nextSibling,o),e.length=o)}_$AR(t=this._$AA.nextSibling,e){var i;for((i=this._$AP)==null?void 0:i.call(this,!1,!0,e);t&&t!==this._$AB;){const o=t.nextSibling;t.remove(),t=o}}setConnected(t){var e;this._$AM===void 0&&(this._$Cv=t,(e=this._$AP)==null||e.call(this,t))}},He=class{get tagName(){return this.element.tagName}get _$AU(){return this._$AM._$AU}constructor(t,e,i,o,r){this.type=1,this._$AH=C,this._$AN=void 0,this.element=t,this.name=e,this._$AM=o,this.options=r,i.length>2||i[0]!==""||i[1]!==""?(this._$AH=Array(i.length-1).fill(new String),this.strings=i):this._$AH=C}_$AI(t,e=this,i,o){const r=this.strings;let n=!1;if(r===void 0)t=Mt(this,t,e,0),n=!ne(t)||t!==this._$AH&&t!==_t,n&&(this._$AH=t);else{const l=t;let a,c;for(t=r[0],a=0;a<r.length-1;a++)c=Mt(this,l[i+a],e,a),c===_t&&(c=this._$AH[a]),n||(n=!ne(c)||c!==this._$AH[a]),c===C?t=C:t!==C&&(t+=(c??"")+r[a+1]),this._$AH[a]=c}n&&!o&&this.j(t)}j(t){t===C?this.element.removeAttribute(this.name):this.element.setAttribute(this.name,t??"")}},Pr=class extends He{constructor(){super(...arguments),this.type=3}j(t){this.element[this.name]=t===C?void 0:t}},Tr=class extends He{constructor(){super(...arguments),this.type=4}j(t){this.element.toggleAttribute(this.name,!!t&&t!==C)}},Or=class extends He{constructor(t,e,i,o,r){super(t,e,i,o,r),this.type=5}_$AI(t,e=this){if((t=Mt(this,t,e,0)??C)===_t)return;const i=this._$AH,o=t===C&&i!==C||t.capture!==i.capture||t.once!==i.once||t.passive!==i.passive,r=t!==C&&(i===C||o);o&&this.element.removeEventListener(this.name,this,i),r&&this.element.addEventListener(this.name,this,t),this._$AH=t}handleEvent(t){var e;typeof this._$AH=="function"?this._$AH.call(((e=this.options)==null?void 0:e.host)??this.element,t):this._$AH.handleEvent(t)}},Rr=class{constructor(t,e,i){this.element=t,this.type=6,this._$AN=void 0,this._$AM=e,this.options=i}get _$AU(){return this._$AM._$AU}_$AI(t){Mt(this,t)}};const Ye=Qt.litHtmlPolyfillSupport;Ye==null||Ye(os,ys),(Qt.litHtmlVersions??(Qt.litHtmlVersions=[])).push("3.1.2");const kr=(s,t,e)=>{const i=(e==null?void 0:e.renderBefore)??t;let o=i._$litPart$;if(o===void 0){const r=(e==null?void 0:e.renderBefore)??null;i._$litPart$=o=new ys(t.insertBefore(re(),r),r,void 0,e??{})}return o._$AI(s),o};/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */let Ot=class extends Ct{constructor(){super(...arguments),this.renderOptions={host:this},this._$Do=void 0}createRenderRoot(){var e;const t=super.createRenderRoot();return(e=this.renderOptions).renderBefore??(e.renderBefore=t.firstChild),t}update(t){const e=this.render();this.hasUpdated||(this.renderOptions.isConnected=this.isConnected),super.update(t),this._$Do=kr(e,this.renderRoot,this.renderOptions)}connectedCallback(){var t;super.connectedCallback(),(t=this._$Do)==null||t.setConnected(!0)}disconnectedCallback(){var t;super.disconnectedCallback(),(t=this._$Do)==null||t.setConnected(!1)}render(){return _t}};var Ci;Ot._$litElement$=!0,Ot.finalized=!0,(Ci=globalThis.litElementHydrateSupport)==null||Ci.call(globalThis,{LitElement:Ot});const Ze=globalThis.litElementPolyfillSupport;Ze==null||Ze({LitElement:Ot});(globalThis.litElementVersions??(globalThis.litElementVersions=[])).push("4.0.4");const Ki=[ms`
    .row {
      display: flex;
      flex-direction: row;
    }
    .column {
      display: flex;
      flex-direction: column;
    }
    .small-margin {
      margin-top: 6px;
    }
    .big-margin {
      margin-top: 23px;
    }

    .fill {
      flex: 1;
      height: 100%;
    }

    .title {
      font-size: 20px;
    }

    .center-content {
      align-items: center;
      justify-content: center;
    }

    .placeholder {
      color: var(--sl-color-gray-700);
    }

    .flex-scrollable-parent {
      position: relative;
      display: flex;
      flex: 1;
    }

    .flex-scrollable-container {
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
    }

    .flex-scrollable-x {
      max-width: 100%;
      overflow-x: auto;
    }
    .flex-scrollable-y {
      max-height: 100%;
      overflow-y: auto;
    }
    :host {
      color: var(--sl-color-neutral-1000);
    }

    sl-card {
      display: flex;
    }
    sl-card::part(base) {
      flex: 1;
    }
    sl-card::part(body) {
      display: flex;
      flex: 1;
    }
    sl-drawer::part(body) {
      display: flex;
    }
  `];/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const Mr={ATTRIBUTE:1,CHILD:2,PROPERTY:3,BOOLEAN_ATTRIBUTE:4,EVENT:5,ELEMENT:6},zr=s=>(...t)=>({_$litDirective$:s,values:t});let Ur=class{constructor(t){}get _$AU(){return this._$AM._$AU}_$AT(t,e,i){this._$Ct=t,this._$AM=e,this._$Ci=i}_$AS(t,e){return this.update(t,e)}update(t,e){return this.render(...e)}};function Yi(s){return{attribute:s,type:Object,hasChanged:(t,e)=>(t==null?void 0:t.toString())!==(e==null?void 0:e.toString()),converter:t=>t&&t.length>0&&Oo(t)}}function Lr(s){return`data:image/svg+xml;utf8,${Hr(s)}`}function Hr(s){return`<svg style='fill: currentColor' viewBox='0 0 24 24'><path d='${s}'></path></svg>`}var Nr="M11,15H13V17H11V15M11,7H13V13H11V7M12,2C6.47,2 2,6.5 2,12A10,10 0 0,0 12,22A10,10 0 0,0 22,12A10,10 0 0,0 12,2M12,20A8,8 0 0,1 4,12A8,8 0 0,1 12,4A8,8 0 0,1 20,12A8,8 0 0,1 12,20Z",al="M11,9H13V7H11M12,20C7.59,20 4,16.41 4,12C4,7.59 7.59,4 12,4C16.41,4 20,7.59 20,12C20,16.41 16.41,20 12,20M12,2A10,10 0 0,0 2,12A10,10 0 0,0 12,22A10,10 0 0,0 22,12A10,10 0 0,0 12,2M11,17H13V11H11V17Z",ll="M19,13H13V19H11V13H5V11H11V5H13V11H19V13Z";/**
 * @license
 * Copyright 2019 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const Ae=globalThis,$s=Ae.ShadowRoot&&(Ae.ShadyCSS===void 0||Ae.ShadyCSS.nativeShadow)&&"adoptedStyleSheets"in Document.prototype&&"replace"in CSSStyleSheet.prototype,bs=Symbol(),Js=new WeakMap;let Zi=class{constructor(t,e,i){if(this._$cssResult$=!0,i!==bs)throw Error("CSSResult is not constructable. Use `unsafeCSS` or `css` instead.");this.cssText=t,this.t=e}get styleSheet(){let t=this.o;const e=this.t;if($s&&t===void 0){const i=e!==void 0&&e.length===1;i&&(t=Js.get(e)),t===void 0&&((this.o=t=new CSSStyleSheet).replaceSync(this.cssText),i&&Js.set(e,t))}return t}toString(){return this.cssText}};const Br=s=>new Zi(typeof s=="string"?s:s+"",void 0,bs),Ht=(s,...t)=>{const e=s.length===1?s[0]:t.reduce((i,o,r)=>i+(n=>{if(n._$cssResult$===!0)return n.cssText;if(typeof n=="number")return n;throw Error("Value passed to 'css' function must be a 'css' function result: "+n+". Use 'unsafeCSS' to pass non-literal values, but take care to ensure page security.")})(o)+s[r+1],s[0]);return new Zi(e,s,bs)},Dr=(s,t)=>{if($s)s.adoptedStyleSheets=t.map(e=>e instanceof CSSStyleSheet?e:e.styleSheet);else for(const e of t){const i=document.createElement("style"),o=Ae.litNonce;o!==void 0&&i.setAttribute("nonce",o),i.textContent=e.cssText,s.appendChild(i)}},Gs=$s?s=>s:s=>s instanceof CSSStyleSheet?(t=>{let e="";for(const i of t.cssRules)e+=i.cssText;return Br(e)})(s):s;/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const{is:Ir,defineProperty:jr,getOwnPropertyDescriptor:Vr,getOwnPropertyNames:Wr,getOwnPropertySymbols:Fr,getPrototypeOf:qr}=Object,ot=globalThis,Qs=ot.trustedTypes,Kr=Qs?Qs.emptyScript:"",Xe=ot.reactiveElementPolyfillSupport,te=(s,t)=>s,Oe={toAttribute(s,t){switch(t){case Boolean:s=s?Kr:null;break;case Object:case Array:s=s==null?s:JSON.stringify(s)}return s},fromAttribute(s,t){let e=s;switch(t){case Boolean:e=s!==null;break;case Number:e=s===null?null:Number(s);break;case Object:case Array:try{e=JSON.parse(s)}catch{e=null}}return e}},_s=(s,t)=>!Ir(s,t),ti={attribute:!0,type:String,converter:Oe,reflect:!1,hasChanged:_s};Symbol.metadata??(Symbol.metadata=Symbol("metadata")),ot.litPropertyMetadata??(ot.litPropertyMetadata=new WeakMap);class Pt extends HTMLElement{static addInitializer(t){this._$Ei(),(this.l??(this.l=[])).push(t)}static get observedAttributes(){return this.finalize(),this._$Eh&&[...this._$Eh.keys()]}static createProperty(t,e=ti){if(e.state&&(e.attribute=!1),this._$Ei(),this.elementProperties.set(t,e),!e.noAccessor){const i=Symbol(),o=this.getPropertyDescriptor(t,i,e);o!==void 0&&jr(this.prototype,t,o)}}static getPropertyDescriptor(t,e,i){const{get:o,set:r}=Vr(this.prototype,t)??{get(){return this[e]},set(n){this[e]=n}};return{get(){return o==null?void 0:o.call(this)},set(n){const l=o==null?void 0:o.call(this);r.call(this,n),this.requestUpdate(t,l,i)},configurable:!0,enumerable:!0}}static getPropertyOptions(t){return this.elementProperties.get(t)??ti}static _$Ei(){if(this.hasOwnProperty(te("elementProperties")))return;const t=qr(this);t.finalize(),t.l!==void 0&&(this.l=[...t.l]),this.elementProperties=new Map(t.elementProperties)}static finalize(){if(this.hasOwnProperty(te("finalized")))return;if(this.finalized=!0,this._$Ei(),this.hasOwnProperty(te("properties"))){const e=this.properties,i=[...Wr(e),...Fr(e)];for(const o of i)this.createProperty(o,e[o])}const t=this[Symbol.metadata];if(t!==null){const e=litPropertyMetadata.get(t);if(e!==void 0)for(const[i,o]of e)this.elementProperties.set(i,o)}this._$Eh=new Map;for(const[e,i]of this.elementProperties){const o=this._$Eu(e,i);o!==void 0&&this._$Eh.set(o,e)}this.elementStyles=this.finalizeStyles(this.styles)}static finalizeStyles(t){const e=[];if(Array.isArray(t)){const i=new Set(t.flat(1/0).reverse());for(const o of i)e.unshift(Gs(o))}else t!==void 0&&e.push(Gs(t));return e}static _$Eu(t,e){const i=e.attribute;return i===!1?void 0:typeof i=="string"?i:typeof t=="string"?t.toLowerCase():void 0}constructor(){super(),this._$Ep=void 0,this.isUpdatePending=!1,this.hasUpdated=!1,this._$Em=null,this._$Ev()}_$Ev(){var t;this._$ES=new Promise(e=>this.enableUpdating=e),this._$AL=new Map,this._$E_(),this.requestUpdate(),(t=this.constructor.l)==null||t.forEach(e=>e(this))}addController(t){var e;(this._$EO??(this._$EO=new Set)).add(t),this.renderRoot!==void 0&&this.isConnected&&((e=t.hostConnected)==null||e.call(t))}removeController(t){var e;(e=this._$EO)==null||e.delete(t)}_$E_(){const t=new Map,e=this.constructor.elementProperties;for(const i of e.keys())this.hasOwnProperty(i)&&(t.set(i,this[i]),delete this[i]);t.size>0&&(this._$Ep=t)}createRenderRoot(){const t=this.shadowRoot??this.attachShadow(this.constructor.shadowRootOptions);return Dr(t,this.constructor.elementStyles),t}connectedCallback(){var t;this.renderRoot??(this.renderRoot=this.createRenderRoot()),this.enableUpdating(!0),(t=this._$EO)==null||t.forEach(e=>{var i;return(i=e.hostConnected)==null?void 0:i.call(e)})}enableUpdating(t){}disconnectedCallback(){var t;(t=this._$EO)==null||t.forEach(e=>{var i;return(i=e.hostDisconnected)==null?void 0:i.call(e)})}attributeChangedCallback(t,e,i){this._$AK(t,i)}_$EC(t,e){var r;const i=this.constructor.elementProperties.get(t),o=this.constructor._$Eu(t,i);if(o!==void 0&&i.reflect===!0){const n=(((r=i.converter)==null?void 0:r.toAttribute)!==void 0?i.converter:Oe).toAttribute(e,i.type);this._$Em=t,n==null?this.removeAttribute(o):this.setAttribute(o,n),this._$Em=null}}_$AK(t,e){var r;const i=this.constructor,o=i._$Eh.get(t);if(o!==void 0&&this._$Em!==o){const n=i.getPropertyOptions(o),l=typeof n.converter=="function"?{fromAttribute:n.converter}:((r=n.converter)==null?void 0:r.fromAttribute)!==void 0?n.converter:Oe;this._$Em=o,this[o]=l.fromAttribute(e,n.type),this._$Em=null}}requestUpdate(t,e,i){if(t!==void 0){if(i??(i=this.constructor.getPropertyOptions(t)),!(i.hasChanged??_s)(this[t],e))return;this.P(t,e,i)}this.isUpdatePending===!1&&(this._$ES=this._$ET())}P(t,e,i){this._$AL.has(t)||this._$AL.set(t,e),i.reflect===!0&&this._$Em!==t&&(this._$Ej??(this._$Ej=new Set)).add(t)}async _$ET(){this.isUpdatePending=!0;try{await this._$ES}catch(e){Promise.reject(e)}const t=this.scheduleUpdate();return t!=null&&await t,!this.isUpdatePending}scheduleUpdate(){return this.performUpdate()}performUpdate(){var i;if(!this.isUpdatePending)return;if(!this.hasUpdated){if(this.renderRoot??(this.renderRoot=this.createRenderRoot()),this._$Ep){for(const[r,n]of this._$Ep)this[r]=n;this._$Ep=void 0}const o=this.constructor.elementProperties;if(o.size>0)for(const[r,n]of o)n.wrapped!==!0||this._$AL.has(r)||this[r]===void 0||this.P(r,this[r],n)}let t=!1;const e=this._$AL;try{t=this.shouldUpdate(e),t?(this.willUpdate(e),(i=this._$EO)==null||i.forEach(o=>{var r;return(r=o.hostUpdate)==null?void 0:r.call(o)}),this.update(e)):this._$EU()}catch(o){throw t=!1,this._$EU(),o}t&&this._$AE(e)}willUpdate(t){}_$AE(t){var e;(e=this._$EO)==null||e.forEach(i=>{var o;return(o=i.hostUpdated)==null?void 0:o.call(i)}),this.hasUpdated||(this.hasUpdated=!0,this.firstUpdated(t)),this.updated(t)}_$EU(){this._$AL=new Map,this.isUpdatePending=!1}get updateComplete(){return this.getUpdateComplete()}getUpdateComplete(){return this._$ES}shouldUpdate(t){return!0}update(t){this._$Ej&&(this._$Ej=this._$Ej.forEach(e=>this._$EC(e,this[e]))),this._$EU()}updated(t){}firstUpdated(t){}}Pt.elementStyles=[],Pt.shadowRootOptions={mode:"open"},Pt[te("elementProperties")]=new Map,Pt[te("finalized")]=new Map,Xe==null||Xe({ReactiveElement:Pt}),(ot.reactiveElementVersions??(ot.reactiveElementVersions=[])).push("2.0.4");/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const ee=globalThis,Re=ee.trustedTypes,ei=Re?Re.createPolicy("lit-html",{createHTML:s=>s}):void 0,Xi="$lit$",et=`lit$${(Math.random()+"").slice(9)}$`,Ji="?"+et,Yr=`<${Ji}>`,wt=document,ae=()=>wt.createComment(""),le=s=>s===null||typeof s!="object"&&typeof s!="function",Gi=Array.isArray,Zr=s=>Gi(s)||typeof(s==null?void 0:s[Symbol.iterator])=="function",Je=`[ 	
\f\r]`,Kt=/<(?:(!--|\/[^a-zA-Z])|(\/?[a-zA-Z][^>\s]*)|(\/?$))/g,si=/-->/g,ii=/>/g,pt=RegExp(`>|${Je}(?:([^\\s"'>=/]+)(${Je}*=${Je}*(?:[^ 	
\f\r"'\`<>=]|("|')|))|$)`,"g"),oi=/'/g,ri=/"/g,Qi=/^(?:script|style|textarea|title)$/i,Xr=s=>(t,...e)=>({_$litType$:s,strings:t,values:e}),D=Xr(1),At=Symbol.for("lit-noChange"),P=Symbol.for("lit-nothing"),ni=new WeakMap,vt=wt.createTreeWalker(wt,129);function to(s,t){if(!Array.isArray(s)||!s.hasOwnProperty("raw"))throw Error("invalid template strings array");return ei!==void 0?ei.createHTML(t):t}const Jr=(s,t)=>{const e=s.length-1,i=[];let o,r=t===2?"<svg>":"",n=Kt;for(let l=0;l<e;l++){const a=s[l];let c,d,h=-1,u=0;for(;u<a.length&&(n.lastIndex=u,d=n.exec(a),d!==null);)u=n.lastIndex,n===Kt?d[1]==="!--"?n=si:d[1]!==void 0?n=ii:d[2]!==void 0?(Qi.test(d[2])&&(o=RegExp("</"+d[2],"g")),n=pt):d[3]!==void 0&&(n=pt):n===pt?d[0]===">"?(n=o??Kt,h=-1):d[1]===void 0?h=-2:(h=n.lastIndex-d[2].length,c=d[1],n=d[3]===void 0?pt:d[3]==='"'?ri:oi):n===ri||n===oi?n=pt:n===si||n===ii?n=Kt:(n=pt,o=void 0);const p=n===pt&&s[l+1].startsWith("/>")?" ":"";r+=n===Kt?a+Yr:h>=0?(i.push(c),a.slice(0,h)+Xi+a.slice(h)+et+p):a+et+(h===-2?l:p)}return[to(s,r+(s[e]||"<?>")+(t===2?"</svg>":"")),i]};class ce{constructor({strings:t,_$litType$:e},i){let o;this.parts=[];let r=0,n=0;const l=t.length-1,a=this.parts,[c,d]=Jr(t,e);if(this.el=ce.createElement(c,i),vt.currentNode=this.el.content,e===2){const h=this.el.content.firstChild;h.replaceWith(...h.childNodes)}for(;(o=vt.nextNode())!==null&&a.length<l;){if(o.nodeType===1){if(o.hasAttributes())for(const h of o.getAttributeNames())if(h.endsWith(Xi)){const u=d[n++],p=o.getAttribute(h).split(et),f=/([.?@])?(.*)/.exec(u);a.push({type:1,index:r,name:f[2],strings:p,ctor:f[1]==="."?Qr:f[1]==="?"?tn:f[1]==="@"?en:Ne}),o.removeAttribute(h)}else h.startsWith(et)&&(a.push({type:6,index:r}),o.removeAttribute(h));if(Qi.test(o.tagName)){const h=o.textContent.split(et),u=h.length-1;if(u>0){o.textContent=Re?Re.emptyScript:"";for(let p=0;p<u;p++)o.append(h[p],ae()),vt.nextNode(),a.push({type:2,index:++r});o.append(h[u],ae())}}}else if(o.nodeType===8)if(o.data===Ji)a.push({type:2,index:r});else{let h=-1;for(;(h=o.data.indexOf(et,h+1))!==-1;)a.push({type:7,index:r}),h+=et.length-1}r++}}static createElement(t,e){const i=wt.createElement("template");return i.innerHTML=t,i}}function zt(s,t,e=s,i){var n,l;if(t===At)return t;let o=i!==void 0?(n=e._$Co)==null?void 0:n[i]:e._$Cl;const r=le(t)?void 0:t._$litDirective$;return(o==null?void 0:o.constructor)!==r&&((l=o==null?void 0:o._$AO)==null||l.call(o,!1),r===void 0?o=void 0:(o=new r(s),o._$AT(s,e,i)),i!==void 0?(e._$Co??(e._$Co=[]))[i]=o:e._$Cl=o),o!==void 0&&(t=zt(s,o._$AS(s,t.values),o,i)),t}class Gr{constructor(t,e){this._$AV=[],this._$AN=void 0,this._$AD=t,this._$AM=e}get parentNode(){return this._$AM.parentNode}get _$AU(){return this._$AM._$AU}u(t){const{el:{content:e},parts:i}=this._$AD,o=((t==null?void 0:t.creationScope)??wt).importNode(e,!0);vt.currentNode=o;let r=vt.nextNode(),n=0,l=0,a=i[0];for(;a!==void 0;){if(n===a.index){let c;a.type===2?c=new ue(r,r.nextSibling,this,t):a.type===1?c=new a.ctor(r,a.name,a.strings,this,t):a.type===6&&(c=new sn(r,this,t)),this._$AV.push(c),a=i[++l]}n!==(a==null?void 0:a.index)&&(r=vt.nextNode(),n++)}return vt.currentNode=wt,o}p(t){let e=0;for(const i of this._$AV)i!==void 0&&(i.strings!==void 0?(i._$AI(t,i,e),e+=i.strings.length-2):i._$AI(t[e])),e++}}class ue{get _$AU(){var t;return((t=this._$AM)==null?void 0:t._$AU)??this._$Cv}constructor(t,e,i,o){this.type=2,this._$AH=P,this._$AN=void 0,this._$AA=t,this._$AB=e,this._$AM=i,this.options=o,this._$Cv=(o==null?void 0:o.isConnected)??!0}get parentNode(){let t=this._$AA.parentNode;const e=this._$AM;return e!==void 0&&(t==null?void 0:t.nodeType)===11&&(t=e.parentNode),t}get startNode(){return this._$AA}get endNode(){return this._$AB}_$AI(t,e=this){t=zt(this,t,e),le(t)?t===P||t==null||t===""?(this._$AH!==P&&this._$AR(),this._$AH=P):t!==this._$AH&&t!==At&&this._(t):t._$litType$!==void 0?this.$(t):t.nodeType!==void 0?this.T(t):Zr(t)?this.k(t):this._(t)}S(t){return this._$AA.parentNode.insertBefore(t,this._$AB)}T(t){this._$AH!==t&&(this._$AR(),this._$AH=this.S(t))}_(t){this._$AH!==P&&le(this._$AH)?this._$AA.nextSibling.data=t:this.T(wt.createTextNode(t)),this._$AH=t}$(t){var r;const{values:e,_$litType$:i}=t,o=typeof i=="number"?this._$AC(t):(i.el===void 0&&(i.el=ce.createElement(to(i.h,i.h[0]),this.options)),i);if(((r=this._$AH)==null?void 0:r._$AD)===o)this._$AH.p(e);else{const n=new Gr(o,this),l=n.u(this.options);n.p(e),this.T(l),this._$AH=n}}_$AC(t){let e=ni.get(t.strings);return e===void 0&&ni.set(t.strings,e=new ce(t)),e}k(t){Gi(this._$AH)||(this._$AH=[],this._$AR());const e=this._$AH;let i,o=0;for(const r of t)o===e.length?e.push(i=new ue(this.S(ae()),this.S(ae()),this,this.options)):i=e[o],i._$AI(r),o++;o<e.length&&(this._$AR(i&&i._$AB.nextSibling,o),e.length=o)}_$AR(t=this._$AA.nextSibling,e){var i;for((i=this._$AP)==null?void 0:i.call(this,!1,!0,e);t&&t!==this._$AB;){const o=t.nextSibling;t.remove(),t=o}}setConnected(t){var e;this._$AM===void 0&&(this._$Cv=t,(e=this._$AP)==null||e.call(this,t))}}class Ne{get tagName(){return this.element.tagName}get _$AU(){return this._$AM._$AU}constructor(t,e,i,o,r){this.type=1,this._$AH=P,this._$AN=void 0,this.element=t,this.name=e,this._$AM=o,this.options=r,i.length>2||i[0]!==""||i[1]!==""?(this._$AH=Array(i.length-1).fill(new String),this.strings=i):this._$AH=P}_$AI(t,e=this,i,o){const r=this.strings;let n=!1;if(r===void 0)t=zt(this,t,e,0),n=!le(t)||t!==this._$AH&&t!==At,n&&(this._$AH=t);else{const l=t;let a,c;for(t=r[0],a=0;a<r.length-1;a++)c=zt(this,l[i+a],e,a),c===At&&(c=this._$AH[a]),n||(n=!le(c)||c!==this._$AH[a]),c===P?t=P:t!==P&&(t+=(c??"")+r[a+1]),this._$AH[a]=c}n&&!o&&this.j(t)}j(t){t===P?this.element.removeAttribute(this.name):this.element.setAttribute(this.name,t??"")}}class Qr extends Ne{constructor(){super(...arguments),this.type=3}j(t){this.element[this.name]=t===P?void 0:t}}class tn extends Ne{constructor(){super(...arguments),this.type=4}j(t){this.element.toggleAttribute(this.name,!!t&&t!==P)}}class en extends Ne{constructor(t,e,i,o,r){super(t,e,i,o,r),this.type=5}_$AI(t,e=this){if((t=zt(this,t,e,0)??P)===At)return;const i=this._$AH,o=t===P&&i!==P||t.capture!==i.capture||t.once!==i.once||t.passive!==i.passive,r=t!==P&&(i===P||o);o&&this.element.removeEventListener(this.name,this,i),r&&this.element.addEventListener(this.name,this,t),this._$AH=t}handleEvent(t){var e;typeof this._$AH=="function"?this._$AH.call(((e=this.options)==null?void 0:e.host)??this.element,t):this._$AH.handleEvent(t)}}class sn{constructor(t,e,i){this.element=t,this.type=6,this._$AN=void 0,this._$AM=e,this.options=i}get _$AU(){return this._$AM._$AU}_$AI(t){zt(this,t)}}const Ge=ee.litHtmlPolyfillSupport;Ge==null||Ge(ce,ue),(ee.litHtmlVersions??(ee.litHtmlVersions=[])).push("3.1.2");const on=(s,t,e)=>{const i=(e==null?void 0:e.renderBefore)??t;let o=i._$litPart$;if(o===void 0){const r=(e==null?void 0:e.renderBefore)??null;i._$litPart$=o=new ue(t.insertBefore(ae(),r),r,void 0,e??{})}return o._$AI(s),o};/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */class se extends Pt{constructor(){super(...arguments),this.renderOptions={host:this},this._$Do=void 0}createRenderRoot(){var e;const t=super.createRenderRoot();return(e=this.renderOptions).renderBefore??(e.renderBefore=t.firstChild),t}update(t){const e=this.render();this.hasUpdated||(this.renderOptions.isConnected=this.isConnected),super.update(t),this._$Do=on(e,this.renderRoot,this.renderOptions)}connectedCallback(){var t;super.connectedCallback(),(t=this._$Do)==null||t.setConnected(!0)}disconnectedCallback(){var t;super.disconnectedCallback(),(t=this._$Do)==null||t.setConnected(!1)}render(){return At}}var Pi;se._$litElement$=!0,se.finalized=!0,(Pi=globalThis.litElementHydrateSupport)==null||Pi.call(globalThis,{LitElement:se});const Qe=globalThis.litElementPolyfillSupport;Qe==null||Qe({LitElement:se});(globalThis.litElementVersions??(globalThis.litElementVersions=[])).push("4.0.4");var rs="";function ai(s){rs=s}function rn(s=""){if(!rs){const t=[...document.getElementsByTagName("script")],e=t.find(i=>i.hasAttribute("data-shoelace"));if(e)ai(e.getAttribute("data-shoelace"));else{const i=t.find(r=>/shoelace(\.min)?\.js($|\?)/.test(r.src)||/shoelace-autoloader(\.min)?\.js($|\?)/.test(r.src));let o="";i&&(o=i.getAttribute("src")),ai(o.split("/").slice(0,-1).join("/"))}}return rs.replace(/\/$/,"")+(s?`/${s.replace(/^\//,"")}`:"")}var nn={name:"default",resolver:s=>rn(`assets/icons/${s}.svg`)},an=nn,li={caret:`
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
      <polyline points="6 9 12 15 18 9"></polyline>
    </svg>
  `,check:`
    <svg part="checked-icon" class="checkbox__icon" viewBox="0 0 16 16">
      <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd" stroke-linecap="round">
        <g stroke="currentColor">
          <g transform="translate(3.428571, 3.428571)">
            <path d="M0,5.71428571 L3.42857143,9.14285714"></path>
            <path d="M9.14285714,0 L3.42857143,9.14285714"></path>
          </g>
        </g>
      </g>
    </svg>
  `,"chevron-down":`
    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-chevron-down" viewBox="0 0 16 16">
      <path fill-rule="evenodd" d="M1.646 4.646a.5.5 0 0 1 .708 0L8 10.293l5.646-5.647a.5.5 0 0 1 .708.708l-6 6a.5.5 0 0 1-.708 0l-6-6a.5.5 0 0 1 0-.708z"/>
    </svg>
  `,"chevron-left":`
    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-chevron-left" viewBox="0 0 16 16">
      <path fill-rule="evenodd" d="M11.354 1.646a.5.5 0 0 1 0 .708L5.707 8l5.647 5.646a.5.5 0 0 1-.708.708l-6-6a.5.5 0 0 1 0-.708l6-6a.5.5 0 0 1 .708 0z"/>
    </svg>
  `,"chevron-right":`
    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-chevron-right" viewBox="0 0 16 16">
      <path fill-rule="evenodd" d="M4.646 1.646a.5.5 0 0 1 .708 0l6 6a.5.5 0 0 1 0 .708l-6 6a.5.5 0 0 1-.708-.708L10.293 8 4.646 2.354a.5.5 0 0 1 0-.708z"/>
    </svg>
  `,copy:`
    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-copy" viewBox="0 0 16 16">
      <path fill-rule="evenodd" d="M4 2a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V2Zm2-1a1 1 0 0 0-1 1v8a1 1 0 0 0 1 1h8a1 1 0 0 0 1-1V2a1 1 0 0 0-1-1H6ZM2 5a1 1 0 0 0-1 1v8a1 1 0 0 0 1 1h8a1 1 0 0 0 1-1v-1h1v1a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h1v1H2Z"/>
    </svg>
  `,eye:`
    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-eye" viewBox="0 0 16 16">
      <path d="M16 8s-3-5.5-8-5.5S0 8 0 8s3 5.5 8 5.5S16 8 16 8zM1.173 8a13.133 13.133 0 0 1 1.66-2.043C4.12 4.668 5.88 3.5 8 3.5c2.12 0 3.879 1.168 5.168 2.457A13.133 13.133 0 0 1 14.828 8c-.058.087-.122.183-.195.288-.335.48-.83 1.12-1.465 1.755C11.879 11.332 10.119 12.5 8 12.5c-2.12 0-3.879-1.168-5.168-2.457A13.134 13.134 0 0 1 1.172 8z"/>
      <path d="M8 5.5a2.5 2.5 0 1 0 0 5 2.5 2.5 0 0 0 0-5zM4.5 8a3.5 3.5 0 1 1 7 0 3.5 3.5 0 0 1-7 0z"/>
    </svg>
  `,"eye-slash":`
    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-eye-slash" viewBox="0 0 16 16">
      <path d="M13.359 11.238C15.06 9.72 16 8 16 8s-3-5.5-8-5.5a7.028 7.028 0 0 0-2.79.588l.77.771A5.944 5.944 0 0 1 8 3.5c2.12 0 3.879 1.168 5.168 2.457A13.134 13.134 0 0 1 14.828 8c-.058.087-.122.183-.195.288-.335.48-.83 1.12-1.465 1.755-.165.165-.337.328-.517.486l.708.709z"/>
      <path d="M11.297 9.176a3.5 3.5 0 0 0-4.474-4.474l.823.823a2.5 2.5 0 0 1 2.829 2.829l.822.822zm-2.943 1.299.822.822a3.5 3.5 0 0 1-4.474-4.474l.823.823a2.5 2.5 0 0 0 2.829 2.829z"/>
      <path d="M3.35 5.47c-.18.16-.353.322-.518.487A13.134 13.134 0 0 0 1.172 8l.195.288c.335.48.83 1.12 1.465 1.755C4.121 11.332 5.881 12.5 8 12.5c.716 0 1.39-.133 2.02-.36l.77.772A7.029 7.029 0 0 1 8 13.5C3 13.5 0 8 0 8s.939-1.721 2.641-3.238l.708.709zm10.296 8.884-12-12 .708-.708 12 12-.708.708z"/>
    </svg>
  `,eyedropper:`
    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-eyedropper" viewBox="0 0 16 16">
      <path d="M13.354.646a1.207 1.207 0 0 0-1.708 0L8.5 3.793l-.646-.647a.5.5 0 1 0-.708.708L8.293 5l-7.147 7.146A.5.5 0 0 0 1 12.5v1.793l-.854.853a.5.5 0 1 0 .708.707L1.707 15H3.5a.5.5 0 0 0 .354-.146L11 7.707l1.146 1.147a.5.5 0 0 0 .708-.708l-.647-.646 3.147-3.146a1.207 1.207 0 0 0 0-1.708l-2-2zM2 12.707l7-7L10.293 7l-7 7H2v-1.293z"></path>
    </svg>
  `,"grip-vertical":`
    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-grip-vertical" viewBox="0 0 16 16">
      <path d="M7 2a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm3 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0zM7 5a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm3 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0zM7 8a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm3 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm-3 3a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm3 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm-3 3a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm3 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0z"></path>
    </svg>
  `,indeterminate:`
    <svg part="indeterminate-icon" class="checkbox__icon" viewBox="0 0 16 16">
      <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd" stroke-linecap="round">
        <g stroke="currentColor" stroke-width="2">
          <g transform="translate(2.285714, 6.857143)">
            <path d="M10.2857143,1.14285714 L1.14285714,1.14285714"></path>
          </g>
        </g>
      </g>
    </svg>
  `,"person-fill":`
    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-person-fill" viewBox="0 0 16 16">
      <path d="M3 14s-1 0-1-1 1-4 6-4 6 3 6 4-1 1-1 1H3zm5-6a3 3 0 1 0 0-6 3 3 0 0 0 0 6z"/>
    </svg>
  `,"play-fill":`
    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-play-fill" viewBox="0 0 16 16">
      <path d="m11.596 8.697-6.363 3.692c-.54.313-1.233-.066-1.233-.697V4.308c0-.63.692-1.01 1.233-.696l6.363 3.692a.802.802 0 0 1 0 1.393z"></path>
    </svg>
  `,"pause-fill":`
    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-pause-fill" viewBox="0 0 16 16">
      <path d="M5.5 3.5A1.5 1.5 0 0 1 7 5v6a1.5 1.5 0 0 1-3 0V5a1.5 1.5 0 0 1 1.5-1.5zm5 0A1.5 1.5 0 0 1 12 5v6a1.5 1.5 0 0 1-3 0V5a1.5 1.5 0 0 1 1.5-1.5z"></path>
    </svg>
  `,radio:`
    <svg part="checked-icon" class="radio__icon" viewBox="0 0 16 16">
      <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
        <g fill="currentColor">
          <circle cx="8" cy="8" r="3.42857143"></circle>
        </g>
      </g>
    </svg>
  `,"star-fill":`
    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-star-fill" viewBox="0 0 16 16">
      <path d="M3.612 15.443c-.386.198-.824-.149-.746-.592l.83-4.73L.173 6.765c-.329-.314-.158-.888.283-.95l4.898-.696L7.538.792c.197-.39.73-.39.927 0l2.184 4.327 4.898.696c.441.062.612.636.282.95l-3.522 3.356.83 4.73c.078.443-.36.79-.746.592L8 13.187l-4.389 2.256z"/>
    </svg>
  `,"x-lg":`
    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x-lg" viewBox="0 0 16 16">
      <path d="M2.146 2.854a.5.5 0 1 1 .708-.708L8 7.293l5.146-5.147a.5.5 0 0 1 .708.708L8.707 8l5.147 5.146a.5.5 0 0 1-.708.708L8 8.707l-5.146 5.147a.5.5 0 0 1-.708-.708L7.293 8 2.146 2.854Z"/>
    </svg>
  `,"x-circle-fill":`
    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x-circle-fill" viewBox="0 0 16 16">
      <path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0zM5.354 4.646a.5.5 0 1 0-.708.708L7.293 8l-2.647 2.646a.5.5 0 0 0 .708.708L8 8.707l2.646 2.647a.5.5 0 0 0 .708-.708L8.707 8l2.647-2.646a.5.5 0 0 0-.708-.708L8 7.293 5.354 4.646z"></path>
    </svg>
  `},ln={name:"system",resolver:s=>s in li?`data:image/svg+xml,${encodeURIComponent(li[s])}`:""},cn=ln,hn=[an,cn],ns=[];function dn(s){ns.push(s)}function pn(s){ns=ns.filter(t=>t!==s)}function ci(s){return hn.find(t=>t.name===s)}var un=Ht`
  :host {
    display: inline-block;
    width: 1em;
    height: 1em;
    box-sizing: content-box !important;
  }

  svg {
    display: block;
    height: 100%;
    width: 100%;
  }
`,eo=Object.defineProperty,fn=Object.defineProperties,gn=Object.getOwnPropertyDescriptor,mn=Object.getOwnPropertyDescriptors,hi=Object.getOwnPropertySymbols,vn=Object.prototype.hasOwnProperty,yn=Object.prototype.propertyIsEnumerable,di=(s,t,e)=>t in s?eo(s,t,{enumerable:!0,configurable:!0,writable:!0,value:e}):s[t]=e,Be=(s,t)=>{for(var e in t||(t={}))vn.call(t,e)&&di(s,e,t[e]);if(hi)for(var e of hi(t))yn.call(t,e)&&di(s,e,t[e]);return s},so=(s,t)=>fn(s,mn(t)),g=(s,t,e,i)=>{for(var o=i>1?void 0:i?gn(t,e):t,r=s.length-1,n;r>=0;r--)(n=s[r])&&(o=(i?n(t,e,o):n(o))||o);return i&&o&&eo(t,e,o),o};function Nt(s,t){const e=Be({waitUntilFirstUpdate:!1},t);return(i,o)=>{const{update:r}=i,n=Array.isArray(s)?s:[s];i.update=function(l){n.forEach(a=>{const c=a;if(l.has(c)){const d=l.get(c),h=this[c];d!==h&&(!e.waitUntilFirstUpdate||this.hasUpdated)&&this[o](d,h)}}),r.call(this,l)}}}var fe=Ht`
  :host {
    box-sizing: border-box;
  }

  :host *,
  :host *::before,
  :host *::after {
    box-sizing: inherit;
  }

  [hidden] {
    display: none !important;
  }
`;/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const $n={attribute:!0,type:String,converter:Oe,reflect:!1,hasChanged:_s},bn=(s=$n,t,e)=>{const{kind:i,metadata:o}=e;let r=globalThis.litPropertyMetadata.get(o);if(r===void 0&&globalThis.litPropertyMetadata.set(o,r=new Map),r.set(e.name,s),i==="accessor"){const{name:n}=e;return{set(l){const a=t.get.call(this);t.set.call(this,l),this.requestUpdate(n,a,s)},init(l){return l!==void 0&&this.P(n,void 0,s),l}}}if(i==="setter"){const{name:n}=e;return function(l){const a=this[n];t.call(this,l),this.requestUpdate(n,a,s)}}throw Error("Unsupported decorator location: "+i)};function m(s){return(t,e)=>typeof e=="object"?bn(s,t,e):((i,o,r)=>{const n=o.hasOwnProperty(r);return o.constructor.createProperty(r,n?{...i,wrapped:!0}:i),n?Object.getOwnPropertyDescriptor(o,r):void 0})(s,t,e)}/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */function io(s){return m({...s,state:!0,attribute:!1})}/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const pi=(s,t,e)=>(e.configurable=!0,e.enumerable=!0,Reflect.decorate&&typeof t!="object"&&Object.defineProperty(s,t,e),e);/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */function ge(s,t){return(e,i,o)=>{const r=n=>{var l;return((l=n.renderRoot)==null?void 0:l.querySelector(s))??null};if(t){const{get:n,set:l}=typeof i=="object"?e:o??(()=>{const a=Symbol();return{get(){return this[a]},set(c){this[a]=c}}})();return pi(e,i,{get(){let a=n.call(this);return a===void 0&&(a=r(this),(a!==null||this.hasUpdated)&&l.call(this,a)),a}})}return pi(e,i,{get(){return r(this)}})}}var Y=class extends se{constructor(){super(),Object.entries(this.constructor.dependencies).forEach(([s,t])=>{this.constructor.define(s,t)})}emit(s,t){const e=new CustomEvent(s,Be({bubbles:!0,cancelable:!1,composed:!0,detail:{}},t));return this.dispatchEvent(e),e}static define(s,t=this,e={}){const i=customElements.get(s);if(!i){customElements.define(s,class extends t{},e);return}let o=" (unknown version)",r=o;"version"in t&&t.version&&(o=" v"+t.version),"version"in i&&i.version&&(r=" v"+i.version),!(o&&r&&o===r)&&console.warn(`Attempted to register <${s}>${o}, but <${s}>${r} has already been registered.`)}};Y.version="2.14.0";Y.dependencies={};g([m()],Y.prototype,"dir",2);g([m()],Y.prototype,"lang",2);/**
 * @license
 * Copyright 2020 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const _n=(s,t)=>t===void 0?(s==null?void 0:s._$litType$)!==void 0:(s==null?void 0:s._$litType$)===t,hl=s=>s.strings===void 0,wn={},dl=(s,t=wn)=>s._$AH=t;var Yt=Symbol(),$e=Symbol(),ts,es=new Map,V=class extends Y{constructor(){super(...arguments),this.initialRender=!1,this.svg=null,this.label="",this.library="default"}async resolveIcon(s,t){var e;let i;if(t!=null&&t.spriteSheet)return D`<svg part="svg">
        <use part="use" href="${s}"></use>
      </svg>`;try{if(i=await fetch(s,{mode:"cors"}),!i.ok)return i.status===410?Yt:$e}catch{return $e}try{const o=document.createElement("div");o.innerHTML=await i.text();const r=o.firstElementChild;if(((e=r==null?void 0:r.tagName)==null?void 0:e.toLowerCase())!=="svg")return Yt;ts||(ts=new DOMParser);const l=ts.parseFromString(r.outerHTML,"text/html").body.querySelector("svg");return l?(l.part.add("svg"),document.adoptNode(l)):Yt}catch{return Yt}}connectedCallback(){super.connectedCallback(),dn(this)}firstUpdated(){this.initialRender=!0,this.setIcon()}disconnectedCallback(){super.disconnectedCallback(),pn(this)}getIconSource(){const s=ci(this.library);return this.name&&s?{url:s.resolver(this.name),fromLibrary:!0}:{url:this.src,fromLibrary:!1}}handleLabelChange(){typeof this.label=="string"&&this.label.length>0?(this.setAttribute("role","img"),this.setAttribute("aria-label",this.label),this.removeAttribute("aria-hidden")):(this.removeAttribute("role"),this.removeAttribute("aria-label"),this.setAttribute("aria-hidden","true"))}async setIcon(){var s;const{url:t,fromLibrary:e}=this.getIconSource(),i=e?ci(this.library):void 0;if(!t){this.svg=null;return}let o=es.get(t);if(o||(o=this.resolveIcon(t,i),es.set(t,o)),!this.initialRender)return;const r=await o;if(r===$e&&es.delete(t),t===this.getIconSource().url){if(_n(r)){this.svg=r;return}switch(r){case $e:case Yt:this.svg=null,this.emit("sl-error");break;default:this.svg=r.cloneNode(!0),(s=i==null?void 0:i.mutator)==null||s.call(i,this.svg),this.emit("sl-load")}}}render(){return this.svg}};V.styles=[fe,un];g([io()],V.prototype,"svg",2);g([m({reflect:!0})],V.prototype,"name",2);g([m()],V.prototype,"src",2);g([m()],V.prototype,"label",2);g([m({reflect:!0})],V.prototype,"library",2);g([Nt("label")],V.prototype,"handleLabelChange",1);g([Nt(["name","src","library"])],V.prototype,"setIcon",1);/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const An={ATTRIBUTE:1,CHILD:2,PROPERTY:3,BOOLEAN_ATTRIBUTE:4,EVENT:5,ELEMENT:6},xn=s=>(...t)=>({_$litDirective$:s,values:t});let En=class{constructor(t){}get _$AU(){return this._$AM._$AU}_$AT(t,e,i){this._$Ct=t,this._$AM=e,this._$Ci=i}_$AS(t,e){return this.update(t,e)}update(t,e){return this.render(...e)}};/**
 * @license
 * Copyright 2018 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const he=xn(class extends En{constructor(s){var t;if(super(s),s.type!==An.ATTRIBUTE||s.name!=="class"||((t=s.strings)==null?void 0:t.length)>2)throw Error("`classMap()` can only be used in the `class` attribute and must be the only part in the attribute.")}render(s){return" "+Object.keys(s).filter(t=>s[t]).join(" ")+" "}update(s,[t]){var i,o;if(this.st===void 0){this.st=new Set,s.strings!==void 0&&(this.nt=new Set(s.strings.join(" ").split(/\s/).filter(r=>r!=="")));for(const r in t)t[r]&&!((i=this.nt)!=null&&i.has(r))&&this.st.add(r);return this.render(t)}const e=s.element.classList;for(const r of this.st)r in t||(e.remove(r),this.st.delete(r));for(const r in t){const n=!!t[r];n===this.st.has(r)||(o=this.nt)!=null&&o.has(r)||(n?(e.add(r),this.st.add(r)):(e.remove(r),this.st.delete(r)))}return At}});var oo=new Map,Sn=new WeakMap;function Cn(s){return s??{keyframes:[],options:{duration:0}}}function ui(s,t){return t.toLowerCase()==="rtl"?{keyframes:s.rtlKeyframes||s.keyframes,options:s.options}:s}function ro(s,t){oo.set(s,Cn(t))}function fi(s,t,e){const i=Sn.get(s);if(i!=null&&i[t])return ui(i[t],e.dir);const o=oo.get(t);return o?ui(o,e.dir):{keyframes:[],options:{duration:0}}}function gi(s,t){return new Promise(e=>{function i(o){o.target===s&&(s.removeEventListener(t,i),e())}s.addEventListener(t,i)})}function mi(s,t,e){return new Promise(i=>{if((e==null?void 0:e.duration)===1/0)throw new Error("Promise-based animations must be finite.");const o=s.animate(t,so(Be({},e),{duration:Pn()?0:e.duration}));o.addEventListener("cancel",i,{once:!0}),o.addEventListener("finish",i,{once:!0})})}function vi(s){return s=s.toString().toLowerCase(),s.indexOf("ms")>-1?parseFloat(s):s.indexOf("s")>-1?parseFloat(s)*1e3:parseFloat(s)}function Pn(){return window.matchMedia("(prefers-reduced-motion: reduce)").matches}function yi(s){return Promise.all(s.getAnimations().map(t=>new Promise(e=>{t.cancel(),requestAnimationFrame(e)})))}const as=new Set,Tn=new MutationObserver(co),Tt=new Map;let no=document.documentElement.dir||"ltr",ao=document.documentElement.lang||navigator.language,ft;Tn.observe(document.documentElement,{attributes:!0,attributeFilter:["dir","lang"]});function lo(...s){s.map(t=>{const e=t.$code.toLowerCase();Tt.has(e)?Tt.set(e,Object.assign(Object.assign({},Tt.get(e)),t)):Tt.set(e,t),ft||(ft=t)}),co()}function co(){no=document.documentElement.dir||"ltr",ao=document.documentElement.lang||navigator.language,[...as.keys()].map(s=>{typeof s.requestUpdate=="function"&&s.requestUpdate()})}let On=class{constructor(t){this.host=t,this.host.addController(this)}hostConnected(){as.add(this.host)}hostDisconnected(){as.delete(this.host)}dir(){return`${this.host.dir||no}`.toLowerCase()}lang(){return`${this.host.lang||ao}`.toLowerCase()}getTranslationData(t){var e,i;const o=new Intl.Locale(t.replace(/_/g,"-")),r=o==null?void 0:o.language.toLowerCase(),n=(i=(e=o==null?void 0:o.region)===null||e===void 0?void 0:e.toLowerCase())!==null&&i!==void 0?i:"",l=Tt.get(`${r}-${n}`),a=Tt.get(r);return{locale:o,language:r,region:n,primary:l,secondary:a}}exists(t,e){var i;const{primary:o,secondary:r}=this.getTranslationData((i=e.lang)!==null&&i!==void 0?i:this.lang());return e=Object.assign({includeFallback:!1},e),!!(o&&o[t]||r&&r[t]||e.includeFallback&&ft&&ft[t])}term(t,...e){const{primary:i,secondary:o}=this.getTranslationData(this.lang());let r;if(i&&i[t])r=i[t];else if(o&&o[t])r=o[t];else if(ft&&ft[t])r=ft[t];else return console.error(`No translation found for: ${String(t)}`),String(t);return typeof r=="function"?r(...e):r}date(t,e){return t=new Date(t),new Intl.DateTimeFormat(this.lang(),e).format(t)}number(t,e){return t=Number(t),isNaN(t)?"":new Intl.NumberFormat(this.lang(),e).format(t)}relativeTime(t,e,i){return new Intl.RelativeTimeFormat(this.lang(),i).format(t,e)}};var ho={$code:"en",$name:"English",$dir:"ltr",carousel:"Carousel",clearEntry:"Clear entry",close:"Close",copied:"Copied",copy:"Copy",currentValue:"Current value",error:"Error",goToSlide:(s,t)=>`Go to slide ${s} of ${t}`,hidePassword:"Hide password",loading:"Loading",nextSlide:"Next slide",numOptionsSelected:s=>s===0?"No options selected":s===1?"1 option selected":`${s} options selected`,previousSlide:"Previous slide",progress:"Progress",remove:"Remove",resize:"Resize",scrollToEnd:"Scroll to end",scrollToStart:"Scroll to start",selectAColorFromTheScreen:"Select a color from the screen",showPassword:"Show password",slideNum:s=>`Slide ${s}`,toggleColorFormat:"Toggle color format"};lo(ho);var Rn=ho,kn=class extends On{};lo(Rn);var Mn=Ht`
  :host {
    display: inline-block;

    --size: 3rem;
  }

  .avatar {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    position: relative;
    width: var(--size);
    height: var(--size);
    background-color: var(--sl-color-neutral-400);
    font-family: var(--sl-font-sans);
    font-size: calc(var(--size) * 0.5);
    font-weight: var(--sl-font-weight-normal);
    color: var(--sl-color-neutral-0);
    user-select: none;
    -webkit-user-select: none;
    vertical-align: middle;
  }

  .avatar--circle,
  .avatar--circle .avatar__image {
    border-radius: var(--sl-border-radius-circle);
  }

  .avatar--rounded,
  .avatar--rounded .avatar__image {
    border-radius: var(--sl-border-radius-medium);
  }

  .avatar--square {
    border-radius: 0;
  }

  .avatar__icon {
    display: flex;
    align-items: center;
    justify-content: center;
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
  }

  .avatar__initials {
    line-height: 1;
    text-transform: uppercase;
  }

  .avatar__image {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    object-fit: cover;
    overflow: hidden;
  }
`,W=class extends Y{constructor(){super(...arguments),this.hasError=!1,this.image="",this.label="",this.initials="",this.loading="eager",this.shape="circle"}handleImageChange(){this.hasError=!1}render(){const s=D`
      <img
        part="image"
        class="avatar__image"
        src="${this.image}"
        loading="${this.loading}"
        alt=""
        @error="${()=>this.hasError=!0}"
      />
    `;let t=D``;return this.initials?t=D`<div part="initials" class="avatar__initials">${this.initials}</div>`:t=D`
        <div part="icon" class="avatar__icon" aria-hidden="true">
          <slot name="icon">
            <sl-icon name="person-fill" library="system"></sl-icon>
          </slot>
        </div>
      `,D`
      <div
        part="base"
        class=${he({avatar:!0,"avatar--circle":this.shape==="circle","avatar--rounded":this.shape==="rounded","avatar--square":this.shape==="square"})}
        role="img"
        aria-label=${this.label}
      >
        ${this.image&&!this.hasError?s:t}
      </div>
    `}};W.styles=[fe,Mn];W.dependencies={"sl-icon":V};g([io()],W.prototype,"hasError",2);g([m()],W.prototype,"image",2);g([m()],W.prototype,"label",2);g([m()],W.prototype,"initials",2);g([m()],W.prototype,"loading",2);g([m({reflect:!0})],W.prototype,"shape",2);g([Nt("image")],W.prototype,"handleImageChange",1);W.define("sl-avatar");V.define("sl-icon");/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const po=s=>(t,e)=>{e!==void 0?e.addInitializer(()=>{customElements.define(s,t)}):customElements.define(s,t)};/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const zn={attribute:!0,type:String,converter:Pe,reflect:!1,hasChanged:vs},Un=(s=zn,t,e)=>{const{kind:i,metadata:o}=e;let r=globalThis.litPropertyMetadata.get(o);if(r===void 0&&globalThis.litPropertyMetadata.set(o,r=new Map),r.set(e.name,s),i==="accessor"){const{name:n}=e;return{set(l){const a=t.get.call(this);t.set.call(this,l),this.requestUpdate(n,a,s)},init(l){return l!==void 0&&this.P(n,void 0,s),l}}}if(i==="setter"){const{name:n}=e;return function(l){const a=this[n];t.call(this,l),this.requestUpdate(n,a,s)}}throw Error("Unsupported decorator location: "+i)};function F(s){return(t,e)=>typeof e=="object"?Un(s,t,e):((i,o,r)=>{const n=o.hasOwnProperty(r);return o.constructor.createProperty(r,n?{...i,wrapped:!0}:i),n?Object.getOwnPropertyDescriptor(o,r):void 0})(s,t,e)}/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */function Ln(s){return F({...s,state:!0,attribute:!1})}/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const $i=(s,t,e)=>(e.configurable=!0,e.enumerable=!0,Reflect.decorate&&typeof t!="object"&&Object.defineProperty(s,t,e),e);/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */function uo(s,t){return(e,i,o)=>{const r=n=>{var l;return((l=n.renderRoot)==null?void 0:l.querySelector(s))??null};if(t){const{get:n,set:l}=typeof i=="object"?e:o??(()=>{const a=Symbol();return{get(){return this[a]},set(c){this[a]=c}}})();return $i(e,i,{get(){let a=n.call(this);return a===void 0&&(a=r(this),(a!==null||this.hasUpdated)&&l.call(this,a)),a}})}return $i(e,i,{get(){return r(this)}})}}class Hn{constructor(t,e,i){G(this,"host");G(this,"getStore");G(this,"resubscribeIfChanged");G(this,"value");G(this,"store");G(this,"_unsubscribe");G(this,"_previousArgs");if(this.host=t,this.getStore=e,this.resubscribeIfChanged=i,!this.resubscribeIfChanged){const n=[...this.getStore.toString().matchAll(/[^\_\$a-zA-Z0-9]this\.([\$\_a-zA-Z0-9]+)/gm)].map(l=>l[1]);this.resubscribeIfChanged=()=>n.map(l=>this.host[l])}t.addController(this)}hostUpdate(){this.shouldResubscribe()&&(this.store=this.getStore(),this.unsubscribe(),this.store&&(this._unsubscribe=this.store.subscribe(t=>{this.value=t,this.host.requestUpdate()})))}hostDisconnected(){this.unsubscribe()}unsubscribe(){this._unsubscribe&&(this._unsubscribe(),this._unsubscribe=void 0)}shouldResubscribe(){const t=this.resubscribeIfChanged(),e=this._previousArgs;return this._previousArgs=t,!Ro(t,e)}}var Nn=Ht`
  :host {
    --max-width: 20rem;
    --hide-delay: 0ms;
    --show-delay: 150ms;

    display: contents;
  }

  .tooltip {
    --arrow-size: var(--sl-tooltip-arrow-size);
    --arrow-color: var(--sl-tooltip-background-color);
  }

  .tooltip::part(popup) {
    z-index: var(--sl-z-index-tooltip);
  }

  .tooltip[placement^='top']::part(popup) {
    transform-origin: bottom;
  }

  .tooltip[placement^='bottom']::part(popup) {
    transform-origin: top;
  }

  .tooltip[placement^='left']::part(popup) {
    transform-origin: right;
  }

  .tooltip[placement^='right']::part(popup) {
    transform-origin: left;
  }

  .tooltip__body {
    display: block;
    width: max-content;
    max-width: var(--max-width);
    border-radius: var(--sl-tooltip-border-radius);
    background-color: var(--sl-tooltip-background-color);
    font-family: var(--sl-tooltip-font-family);
    font-size: var(--sl-tooltip-font-size);
    font-weight: var(--sl-tooltip-font-weight);
    line-height: var(--sl-tooltip-line-height);
    color: var(--sl-tooltip-color);
    padding: var(--sl-tooltip-padding);
    pointer-events: none;
    user-select: none;
    -webkit-user-select: none;
  }
`,Bn=Ht`
  :host {
    --arrow-color: var(--sl-color-neutral-1000);
    --arrow-size: 6px;

    /*
     * These properties are computed to account for the arrow's dimensions after being rotated 45º. The constant
     * 0.7071 is derived from sin(45), which is the diagonal size of the arrow's container after rotating.
     */
    --arrow-size-diagonal: calc(var(--arrow-size) * 0.7071);
    --arrow-padding-offset: calc(var(--arrow-size-diagonal) - var(--arrow-size));

    display: contents;
  }

  .popup {
    position: absolute;
    isolation: isolate;
    max-width: var(--auto-size-available-width, none);
    max-height: var(--auto-size-available-height, none);
  }

  .popup--fixed {
    position: fixed;
  }

  .popup:not(.popup--active) {
    display: none;
  }

  .popup__arrow {
    position: absolute;
    width: calc(var(--arrow-size-diagonal) * 2);
    height: calc(var(--arrow-size-diagonal) * 2);
    rotate: 45deg;
    background: var(--arrow-color);
    z-index: -1;
  }

  /* Hover bridge */
  .popup-hover-bridge:not(.popup-hover-bridge--visible) {
    display: none;
  }

  .popup-hover-bridge {
    position: fixed;
    z-index: calc(var(--sl-z-index-dropdown) - 1);
    top: 0;
    right: 0;
    bottom: 0;
    left: 0;
    clip-path: polygon(
      var(--hover-bridge-top-left-x, 0) var(--hover-bridge-top-left-y, 0),
      var(--hover-bridge-top-right-x, 0) var(--hover-bridge-top-right-y, 0),
      var(--hover-bridge-bottom-right-x, 0) var(--hover-bridge-bottom-right-y, 0),
      var(--hover-bridge-bottom-left-x, 0) var(--hover-bridge-bottom-left-y, 0)
    );
  }
`;const rt=Math.min,M=Math.max,ke=Math.round,be=Math.floor,nt=s=>({x:s,y:s}),Dn={left:"right",right:"left",bottom:"top",top:"bottom"},In={start:"end",end:"start"};function ls(s,t,e){return M(s,rt(t,e))}function Bt(s,t){return typeof s=="function"?s(t):s}function at(s){return s.split("-")[0]}function Dt(s){return s.split("-")[1]}function fo(s){return s==="x"?"y":"x"}function ws(s){return s==="y"?"height":"width"}function me(s){return["top","bottom"].includes(at(s))?"y":"x"}function As(s){return fo(me(s))}function jn(s,t,e){e===void 0&&(e=!1);const i=Dt(s),o=As(s),r=ws(o);let n=o==="x"?i===(e?"end":"start")?"right":"left":i==="start"?"bottom":"top";return t.reference[r]>t.floating[r]&&(n=Me(n)),[n,Me(n)]}function Vn(s){const t=Me(s);return[cs(s),t,cs(t)]}function cs(s){return s.replace(/start|end/g,t=>In[t])}function Wn(s,t,e){const i=["left","right"],o=["right","left"],r=["top","bottom"],n=["bottom","top"];switch(s){case"top":case"bottom":return e?t?o:i:t?i:o;case"left":case"right":return t?r:n;default:return[]}}function Fn(s,t,e,i){const o=Dt(s);let r=Wn(at(s),e==="start",i);return o&&(r=r.map(n=>n+"-"+o),t&&(r=r.concat(r.map(cs)))),r}function Me(s){return s.replace(/left|right|bottom|top/g,t=>Dn[t])}function qn(s){return{top:0,right:0,bottom:0,left:0,...s}}function go(s){return typeof s!="number"?qn(s):{top:s,right:s,bottom:s,left:s}}function ze(s){return{...s,top:s.y,left:s.x,right:s.x+s.width,bottom:s.y+s.height}}function bi(s,t,e){let{reference:i,floating:o}=s;const r=me(t),n=As(t),l=ws(n),a=at(t),c=r==="y",d=i.x+i.width/2-o.width/2,h=i.y+i.height/2-o.height/2,u=i[l]/2-o[l]/2;let p;switch(a){case"top":p={x:d,y:i.y-o.height};break;case"bottom":p={x:d,y:i.y+i.height};break;case"right":p={x:i.x+i.width,y:h};break;case"left":p={x:i.x-o.width,y:h};break;default:p={x:i.x,y:i.y}}switch(Dt(t)){case"start":p[n]-=u*(e&&c?-1:1);break;case"end":p[n]+=u*(e&&c?-1:1);break}return p}const Kn=async(s,t,e)=>{const{placement:i="bottom",strategy:o="absolute",middleware:r=[],platform:n}=e,l=r.filter(Boolean),a=await(n.isRTL==null?void 0:n.isRTL(t));let c=await n.getElementRects({reference:s,floating:t,strategy:o}),{x:d,y:h}=bi(c,i,a),u=i,p={},f=0;for(let v=0;v<l.length;v++){const{name:$,fn:y}=l[v],{x:b,y:_,data:x,reset:A}=await y({x:d,y:h,initialPlacement:i,placement:u,strategy:o,middlewareData:p,rects:c,platform:n,elements:{reference:s,floating:t}});d=b??d,h=_??h,p={...p,[$]:{...p[$],...x}},A&&f<=50&&(f++,typeof A=="object"&&(A.placement&&(u=A.placement),A.rects&&(c=A.rects===!0?await n.getElementRects({reference:s,floating:t,strategy:o}):A.rects),{x:d,y:h}=bi(c,u,a)),v=-1)}return{x:d,y:h,placement:u,strategy:o,middlewareData:p}};async function xs(s,t){var e;t===void 0&&(t={});const{x:i,y:o,platform:r,rects:n,elements:l,strategy:a}=s,{boundary:c="clippingAncestors",rootBoundary:d="viewport",elementContext:h="floating",altBoundary:u=!1,padding:p=0}=Bt(t,s),f=go(p),$=l[u?h==="floating"?"reference":"floating":h],y=ze(await r.getClippingRect({element:(e=await(r.isElement==null?void 0:r.isElement($)))==null||e?$:$.contextElement||await(r.getDocumentElement==null?void 0:r.getDocumentElement(l.floating)),boundary:c,rootBoundary:d,strategy:a})),b=h==="floating"?{...n.floating,x:i,y:o}:n.reference,_=await(r.getOffsetParent==null?void 0:r.getOffsetParent(l.floating)),x=await(r.isElement==null?void 0:r.isElement(_))?await(r.getScale==null?void 0:r.getScale(_))||{x:1,y:1}:{x:1,y:1},A=ze(r.convertOffsetParentRelativeRectToViewportRelativeRect?await r.convertOffsetParentRelativeRectToViewportRelativeRect({elements:l,rect:b,offsetParent:_,strategy:a}):b);return{top:(y.top-A.top+f.top)/x.y,bottom:(A.bottom-y.bottom+f.bottom)/x.y,left:(y.left-A.left+f.left)/x.x,right:(A.right-y.right+f.right)/x.x}}const Yn=s=>({name:"arrow",options:s,async fn(t){const{x:e,y:i,placement:o,rects:r,platform:n,elements:l,middlewareData:a}=t,{element:c,padding:d=0}=Bt(s,t)||{};if(c==null)return{};const h=go(d),u={x:e,y:i},p=As(o),f=ws(p),v=await n.getDimensions(c),$=p==="y",y=$?"top":"left",b=$?"bottom":"right",_=$?"clientHeight":"clientWidth",x=r.reference[f]+r.reference[p]-u[p]-r.floating[f],A=u[p]-r.reference[p],E=await(n.getOffsetParent==null?void 0:n.getOffsetParent(c));let R=E?E[_]:0;(!R||!await(n.isElement==null?void 0:n.isElement(E)))&&(R=l.floating[_]||r.floating[f]);const H=x/2-A/2,J=R/2-v[f]/2-1,It=rt(h[y],J),jt=rt(h[b],J),U=It,Vt=R-v[f]-jt,k=R/2-v[f]/2+H,N=ls(U,k,Vt),B=!a.arrow&&Dt(o)!=null&&k!==N&&r.reference[f]/2-(k<U?It:jt)-v[f]/2<0,q=B?k<U?k-U:k-Vt:0;return{[p]:u[p]+q,data:{[p]:N,centerOffset:k-N-q,...B&&{alignmentOffset:q}},reset:B}}}),Zn=function(s){return s===void 0&&(s={}),{name:"flip",options:s,async fn(t){var e,i;const{placement:o,middlewareData:r,rects:n,initialPlacement:l,platform:a,elements:c}=t,{mainAxis:d=!0,crossAxis:h=!0,fallbackPlacements:u,fallbackStrategy:p="bestFit",fallbackAxisSideDirection:f="none",flipAlignment:v=!0,...$}=Bt(s,t);if((e=r.arrow)!=null&&e.alignmentOffset)return{};const y=at(o),b=at(l)===l,_=await(a.isRTL==null?void 0:a.isRTL(c.floating)),x=u||(b||!v?[Me(l)]:Vn(l));!u&&f!=="none"&&x.push(...Fn(l,v,f,_));const A=[l,...x],E=await xs(t,$),R=[];let H=((i=r.flip)==null?void 0:i.overflows)||[];if(d&&R.push(E[y]),h){const U=jn(o,n,_);R.push(E[U[0]],E[U[1]])}if(H=[...H,{placement:o,overflows:R}],!R.every(U=>U<=0)){var J,It;const U=(((J=r.flip)==null?void 0:J.index)||0)+1,Vt=A[U];if(Vt)return{data:{index:U,overflows:H},reset:{placement:Vt}};let k=(It=H.filter(N=>N.overflows[0]<=0).sort((N,B)=>N.overflows[1]-B.overflows[1])[0])==null?void 0:It.placement;if(!k)switch(p){case"bestFit":{var jt;const N=(jt=H.map(B=>[B.placement,B.overflows.filter(q=>q>0).reduce((q,Co)=>q+Co,0)]).sort((B,q)=>B[1]-q[1])[0])==null?void 0:jt[0];N&&(k=N);break}case"initialPlacement":k=l;break}if(o!==k)return{reset:{placement:k}}}return{}}}};async function Xn(s,t){const{placement:e,platform:i,elements:o}=s,r=await(i.isRTL==null?void 0:i.isRTL(o.floating)),n=at(e),l=Dt(e),a=me(e)==="y",c=["left","top"].includes(n)?-1:1,d=r&&a?-1:1,h=Bt(t,s);let{mainAxis:u,crossAxis:p,alignmentAxis:f}=typeof h=="number"?{mainAxis:h,crossAxis:0,alignmentAxis:null}:{mainAxis:0,crossAxis:0,alignmentAxis:null,...h};return l&&typeof f=="number"&&(p=l==="end"?f*-1:f),a?{x:p*d,y:u*c}:{x:u*c,y:p*d}}const Jn=function(s){return s===void 0&&(s=0),{name:"offset",options:s,async fn(t){var e,i;const{x:o,y:r,placement:n,middlewareData:l}=t,a=await Xn(t,s);return n===((e=l.offset)==null?void 0:e.placement)&&(i=l.arrow)!=null&&i.alignmentOffset?{}:{x:o+a.x,y:r+a.y,data:{...a,placement:n}}}}},Gn=function(s){return s===void 0&&(s={}),{name:"shift",options:s,async fn(t){const{x:e,y:i,placement:o}=t,{mainAxis:r=!0,crossAxis:n=!1,limiter:l={fn:$=>{let{x:y,y:b}=$;return{x:y,y:b}}},...a}=Bt(s,t),c={x:e,y:i},d=await xs(t,a),h=me(at(o)),u=fo(h);let p=c[u],f=c[h];if(r){const $=u==="y"?"top":"left",y=u==="y"?"bottom":"right",b=p+d[$],_=p-d[y];p=ls(b,p,_)}if(n){const $=h==="y"?"top":"left",y=h==="y"?"bottom":"right",b=f+d[$],_=f-d[y];f=ls(b,f,_)}const v=l.fn({...t,[u]:p,[h]:f});return{...v,data:{x:v.x-e,y:v.y-i}}}}},Qn=function(s){return s===void 0&&(s={}),{name:"size",options:s,async fn(t){const{placement:e,rects:i,platform:o,elements:r}=t,{apply:n=()=>{},...l}=Bt(s,t),a=await xs(t,l),c=at(e),d=Dt(e),h=me(e)==="y",{width:u,height:p}=i.floating;let f,v;c==="top"||c==="bottom"?(f=c,v=d===(await(o.isRTL==null?void 0:o.isRTL(r.floating))?"start":"end")?"left":"right"):(v=c,f=d==="end"?"top":"bottom");const $=p-a[f],y=u-a[v],b=!t.middlewareData.shift;let _=$,x=y;if(h){const E=u-a.left-a.right;x=d||b?rt(y,E):E}else{const E=p-a.top-a.bottom;_=d||b?rt($,E):E}if(b&&!d){const E=M(a.left,0),R=M(a.right,0),H=M(a.top,0),J=M(a.bottom,0);h?x=u-2*(E!==0||R!==0?E+R:M(a.left,a.right)):_=p-2*(H!==0||J!==0?H+J:M(a.top,a.bottom))}await n({...t,availableWidth:x,availableHeight:_});const A=await o.getDimensions(r.floating);return u!==A.width||p!==A.height?{reset:{rects:!0}}:{}}}};function lt(s){return mo(s)?(s.nodeName||"").toLowerCase():"#document"}function z(s){var t;return(s==null||(t=s.ownerDocument)==null?void 0:t.defaultView)||window}function Z(s){var t;return(t=(mo(s)?s.ownerDocument:s.document)||window.document)==null?void 0:t.documentElement}function mo(s){return s instanceof Node||s instanceof z(s).Node}function K(s){return s instanceof Element||s instanceof z(s).Element}function I(s){return s instanceof HTMLElement||s instanceof z(s).HTMLElement}function _i(s){return typeof ShadowRoot>"u"?!1:s instanceof ShadowRoot||s instanceof z(s).ShadowRoot}function ve(s){const{overflow:t,overflowX:e,overflowY:i,display:o}=L(s);return/auto|scroll|overlay|hidden|clip/.test(t+i+e)&&!["inline","contents"].includes(o)}function ta(s){return["table","td","th"].includes(lt(s))}function Es(s){const t=Ss(),e=L(s);return e.transform!=="none"||e.perspective!=="none"||(e.containerType?e.containerType!=="normal":!1)||!t&&(e.backdropFilter?e.backdropFilter!=="none":!1)||!t&&(e.filter?e.filter!=="none":!1)||["transform","perspective","filter"].some(i=>(e.willChange||"").includes(i))||["paint","layout","strict","content"].some(i=>(e.contain||"").includes(i))}function ea(s){let t=Ut(s);for(;I(t)&&!De(t);){if(Es(t))return t;t=Ut(t)}return null}function Ss(){return typeof CSS>"u"||!CSS.supports?!1:CSS.supports("-webkit-backdrop-filter","none")}function De(s){return["html","body","#document"].includes(lt(s))}function L(s){return z(s).getComputedStyle(s)}function Ie(s){return K(s)?{scrollLeft:s.scrollLeft,scrollTop:s.scrollTop}:{scrollLeft:s.pageXOffset,scrollTop:s.pageYOffset}}function Ut(s){if(lt(s)==="html")return s;const t=s.assignedSlot||s.parentNode||_i(s)&&s.host||Z(s);return _i(t)?t.host:t}function vo(s){const t=Ut(s);return De(t)?s.ownerDocument?s.ownerDocument.body:s.body:I(t)&&ve(t)?t:vo(t)}function de(s,t,e){var i;t===void 0&&(t=[]),e===void 0&&(e=!0);const o=vo(s),r=o===((i=s.ownerDocument)==null?void 0:i.body),n=z(o);return r?t.concat(n,n.visualViewport||[],ve(o)?o:[],n.frameElement&&e?de(n.frameElement):[]):t.concat(o,de(o,[],e))}function yo(s){const t=L(s);let e=parseFloat(t.width)||0,i=parseFloat(t.height)||0;const o=I(s),r=o?s.offsetWidth:e,n=o?s.offsetHeight:i,l=ke(e)!==r||ke(i)!==n;return l&&(e=r,i=n),{width:e,height:i,$:l}}function Cs(s){return K(s)?s:s.contextElement}function Rt(s){const t=Cs(s);if(!I(t))return nt(1);const e=t.getBoundingClientRect(),{width:i,height:o,$:r}=yo(t);let n=(r?ke(e.width):e.width)/i,l=(r?ke(e.height):e.height)/o;return(!n||!Number.isFinite(n))&&(n=1),(!l||!Number.isFinite(l))&&(l=1),{x:n,y:l}}const sa=nt(0);function $o(s){const t=z(s);return!Ss()||!t.visualViewport?sa:{x:t.visualViewport.offsetLeft,y:t.visualViewport.offsetTop}}function ia(s,t,e){return t===void 0&&(t=!1),!e||t&&e!==z(s)?!1:t}function xt(s,t,e,i){t===void 0&&(t=!1),e===void 0&&(e=!1);const o=s.getBoundingClientRect(),r=Cs(s);let n=nt(1);t&&(i?K(i)&&(n=Rt(i)):n=Rt(s));const l=ia(r,e,i)?$o(r):nt(0);let a=(o.left+l.x)/n.x,c=(o.top+l.y)/n.y,d=o.width/n.x,h=o.height/n.y;if(r){const u=z(r),p=i&&K(i)?z(i):i;let f=u,v=f.frameElement;for(;v&&i&&p!==f;){const $=Rt(v),y=v.getBoundingClientRect(),b=L(v),_=y.left+(v.clientLeft+parseFloat(b.paddingLeft))*$.x,x=y.top+(v.clientTop+parseFloat(b.paddingTop))*$.y;a*=$.x,c*=$.y,d*=$.x,h*=$.y,a+=_,c+=x,f=z(v),v=f.frameElement}}return ze({width:d,height:h,x:a,y:c})}const oa=[":popover-open",":modal"];function bo(s){return oa.some(t=>{try{return s.matches(t)}catch{return!1}})}function ra(s){let{elements:t,rect:e,offsetParent:i,strategy:o}=s;const r=o==="fixed",n=Z(i),l=t?bo(t.floating):!1;if(i===n||l&&r)return e;let a={scrollLeft:0,scrollTop:0},c=nt(1);const d=nt(0),h=I(i);if((h||!h&&!r)&&((lt(i)!=="body"||ve(n))&&(a=Ie(i)),I(i))){const u=xt(i);c=Rt(i),d.x=u.x+i.clientLeft,d.y=u.y+i.clientTop}return{width:e.width*c.x,height:e.height*c.y,x:e.x*c.x-a.scrollLeft*c.x+d.x,y:e.y*c.y-a.scrollTop*c.y+d.y}}function na(s){return Array.from(s.getClientRects())}function _o(s){return xt(Z(s)).left+Ie(s).scrollLeft}function aa(s){const t=Z(s),e=Ie(s),i=s.ownerDocument.body,o=M(t.scrollWidth,t.clientWidth,i.scrollWidth,i.clientWidth),r=M(t.scrollHeight,t.clientHeight,i.scrollHeight,i.clientHeight);let n=-e.scrollLeft+_o(s);const l=-e.scrollTop;return L(i).direction==="rtl"&&(n+=M(t.clientWidth,i.clientWidth)-o),{width:o,height:r,x:n,y:l}}function la(s,t){const e=z(s),i=Z(s),o=e.visualViewport;let r=i.clientWidth,n=i.clientHeight,l=0,a=0;if(o){r=o.width,n=o.height;const c=Ss();(!c||c&&t==="fixed")&&(l=o.offsetLeft,a=o.offsetTop)}return{width:r,height:n,x:l,y:a}}function ca(s,t){const e=xt(s,!0,t==="fixed"),i=e.top+s.clientTop,o=e.left+s.clientLeft,r=I(s)?Rt(s):nt(1),n=s.clientWidth*r.x,l=s.clientHeight*r.y,a=o*r.x,c=i*r.y;return{width:n,height:l,x:a,y:c}}function wi(s,t,e){let i;if(t==="viewport")i=la(s,e);else if(t==="document")i=aa(Z(s));else if(K(t))i=ca(t,e);else{const o=$o(s);i={...t,x:t.x-o.x,y:t.y-o.y}}return ze(i)}function wo(s,t){const e=Ut(s);return e===t||!K(e)||De(e)?!1:L(e).position==="fixed"||wo(e,t)}function ha(s,t){const e=t.get(s);if(e)return e;let i=de(s,[],!1).filter(l=>K(l)&&lt(l)!=="body"),o=null;const r=L(s).position==="fixed";let n=r?Ut(s):s;for(;K(n)&&!De(n);){const l=L(n),a=Es(n);!a&&l.position==="fixed"&&(o=null),(r?!a&&!o:!a&&l.position==="static"&&!!o&&["absolute","fixed"].includes(o.position)||ve(n)&&!a&&wo(s,n))?i=i.filter(d=>d!==n):o=l,n=Ut(n)}return t.set(s,i),i}function da(s){let{element:t,boundary:e,rootBoundary:i,strategy:o}=s;const n=[...e==="clippingAncestors"?ha(t,this._c):[].concat(e),i],l=n[0],a=n.reduce((c,d)=>{const h=wi(t,d,o);return c.top=M(h.top,c.top),c.right=rt(h.right,c.right),c.bottom=rt(h.bottom,c.bottom),c.left=M(h.left,c.left),c},wi(t,l,o));return{width:a.right-a.left,height:a.bottom-a.top,x:a.left,y:a.top}}function pa(s){const{width:t,height:e}=yo(s);return{width:t,height:e}}function ua(s,t,e){const i=I(t),o=Z(t),r=e==="fixed",n=xt(s,!0,r,t);let l={scrollLeft:0,scrollTop:0};const a=nt(0);if(i||!i&&!r)if((lt(t)!=="body"||ve(o))&&(l=Ie(t)),i){const h=xt(t,!0,r,t);a.x=h.x+t.clientLeft,a.y=h.y+t.clientTop}else o&&(a.x=_o(o));const c=n.left+l.scrollLeft-a.x,d=n.top+l.scrollTop-a.y;return{x:c,y:d,width:n.width,height:n.height}}function Ai(s,t){return!I(s)||L(s).position==="fixed"?null:t?t(s):s.offsetParent}function Ao(s,t){const e=z(s);if(!I(s)||bo(s))return e;let i=Ai(s,t);for(;i&&ta(i)&&L(i).position==="static";)i=Ai(i,t);return i&&(lt(i)==="html"||lt(i)==="body"&&L(i).position==="static"&&!Es(i))?e:i||ea(s)||e}const fa=async function(s){const t=this.getOffsetParent||Ao,e=this.getDimensions;return{reference:ua(s.reference,await t(s.floating),s.strategy),floating:{x:0,y:0,...await e(s.floating)}}};function ga(s){return L(s).direction==="rtl"}const xe={convertOffsetParentRelativeRectToViewportRelativeRect:ra,getDocumentElement:Z,getClippingRect:da,getOffsetParent:Ao,getElementRects:fa,getClientRects:na,getDimensions:pa,getScale:Rt,isElement:K,isRTL:ga};function ma(s,t){let e=null,i;const o=Z(s);function r(){var l;clearTimeout(i),(l=e)==null||l.disconnect(),e=null}function n(l,a){l===void 0&&(l=!1),a===void 0&&(a=1),r();const{left:c,top:d,width:h,height:u}=s.getBoundingClientRect();if(l||t(),!h||!u)return;const p=be(d),f=be(o.clientWidth-(c+h)),v=be(o.clientHeight-(d+u)),$=be(c),b={rootMargin:-p+"px "+-f+"px "+-v+"px "+-$+"px",threshold:M(0,rt(1,a))||1};let _=!0;function x(A){const E=A[0].intersectionRatio;if(E!==a){if(!_)return n();E?n(!1,E):i=setTimeout(()=>{n(!1,1e-7)},100)}_=!1}try{e=new IntersectionObserver(x,{...b,root:o.ownerDocument})}catch{e=new IntersectionObserver(x,b)}e.observe(s)}return n(!0),r}function va(s,t,e,i){i===void 0&&(i={});const{ancestorScroll:o=!0,ancestorResize:r=!0,elementResize:n=typeof ResizeObserver=="function",layoutShift:l=typeof IntersectionObserver=="function",animationFrame:a=!1}=i,c=Cs(s),d=o||r?[...c?de(c):[],...de(t)]:[];d.forEach(y=>{o&&y.addEventListener("scroll",e,{passive:!0}),r&&y.addEventListener("resize",e)});const h=c&&l?ma(c,e):null;let u=-1,p=null;n&&(p=new ResizeObserver(y=>{let[b]=y;b&&b.target===c&&p&&(p.unobserve(t),cancelAnimationFrame(u),u=requestAnimationFrame(()=>{var _;(_=p)==null||_.observe(t)})),e()}),c&&!a&&p.observe(c),p.observe(t));let f,v=a?xt(s):null;a&&$();function $(){const y=xt(s);v&&(y.x!==v.x||y.y!==v.y||y.width!==v.width||y.height!==v.height)&&e(),v=y,f=requestAnimationFrame($)}return e(),()=>{var y;d.forEach(b=>{o&&b.removeEventListener("scroll",e),r&&b.removeEventListener("resize",e)}),h==null||h(),(y=p)==null||y.disconnect(),p=null,a&&cancelAnimationFrame(f)}}const ya=Gn,$a=Zn,xi=Qn,ba=Yn,_a=(s,t,e)=>{const i=new Map,o={platform:xe,...e},r={...o.platform,_c:i};return Kn(s,t,{...o,platform:r})};function wa(s){return Aa(s)}function ss(s){return s.assignedSlot?s.assignedSlot:s.parentNode instanceof ShadowRoot?s.parentNode.host:s.parentNode}function Aa(s){for(let t=s;t;t=ss(t))if(t instanceof Element&&getComputedStyle(t).display==="none")return null;for(let t=ss(s);t;t=ss(t)){if(!(t instanceof Element))continue;const e=getComputedStyle(t);if(e.display!=="contents"&&(e.position!=="static"||e.filter!=="none"||t.tagName==="BODY"))return t}return null}function xa(s){return s!==null&&typeof s=="object"&&"getBoundingClientRect"in s}var w=class extends Y{constructor(){super(...arguments),this.active=!1,this.placement="top",this.strategy="absolute",this.distance=0,this.skidding=0,this.arrow=!1,this.arrowPlacement="anchor",this.arrowPadding=10,this.flip=!1,this.flipFallbackPlacements="",this.flipFallbackStrategy="best-fit",this.flipPadding=0,this.shift=!1,this.shiftPadding=0,this.autoSizePadding=0,this.hoverBridge=!1,this.updateHoverBridge=()=>{if(this.hoverBridge&&this.anchorEl){const s=this.anchorEl.getBoundingClientRect(),t=this.popup.getBoundingClientRect(),e=this.placement.includes("top")||this.placement.includes("bottom");let i=0,o=0,r=0,n=0,l=0,a=0,c=0,d=0;e?s.top<t.top?(i=s.left,o=s.bottom,r=s.right,n=s.bottom,l=t.left,a=t.top,c=t.right,d=t.top):(i=t.left,o=t.bottom,r=t.right,n=t.bottom,l=s.left,a=s.top,c=s.right,d=s.top):s.left<t.left?(i=s.right,o=s.top,r=t.left,n=t.top,l=s.right,a=s.bottom,c=t.left,d=t.bottom):(i=t.right,o=t.top,r=s.left,n=s.top,l=t.right,a=t.bottom,c=s.left,d=s.bottom),this.style.setProperty("--hover-bridge-top-left-x",`${i}px`),this.style.setProperty("--hover-bridge-top-left-y",`${o}px`),this.style.setProperty("--hover-bridge-top-right-x",`${r}px`),this.style.setProperty("--hover-bridge-top-right-y",`${n}px`),this.style.setProperty("--hover-bridge-bottom-left-x",`${l}px`),this.style.setProperty("--hover-bridge-bottom-left-y",`${a}px`),this.style.setProperty("--hover-bridge-bottom-right-x",`${c}px`),this.style.setProperty("--hover-bridge-bottom-right-y",`${d}px`)}}}async connectedCallback(){super.connectedCallback(),await this.updateComplete,this.start()}disconnectedCallback(){super.disconnectedCallback(),this.stop()}async updated(s){super.updated(s),s.has("active")&&(this.active?this.start():this.stop()),s.has("anchor")&&this.handleAnchorChange(),this.active&&(await this.updateComplete,this.reposition())}async handleAnchorChange(){if(await this.stop(),this.anchor&&typeof this.anchor=="string"){const s=this.getRootNode();this.anchorEl=s.getElementById(this.anchor)}else this.anchor instanceof Element||xa(this.anchor)?this.anchorEl=this.anchor:this.anchorEl=this.querySelector('[slot="anchor"]');this.anchorEl instanceof HTMLSlotElement&&(this.anchorEl=this.anchorEl.assignedElements({flatten:!0})[0]),this.anchorEl&&this.start()}start(){this.anchorEl&&(this.cleanup=va(this.anchorEl,this.popup,()=>{this.reposition()}))}async stop(){return new Promise(s=>{this.cleanup?(this.cleanup(),this.cleanup=void 0,this.removeAttribute("data-current-placement"),this.style.removeProperty("--auto-size-available-width"),this.style.removeProperty("--auto-size-available-height"),requestAnimationFrame(()=>s())):s()})}reposition(){if(!this.active||!this.anchorEl)return;const s=[Jn({mainAxis:this.distance,crossAxis:this.skidding})];this.sync?s.push(xi({apply:({rects:e})=>{const i=this.sync==="width"||this.sync==="both",o=this.sync==="height"||this.sync==="both";this.popup.style.width=i?`${e.reference.width}px`:"",this.popup.style.height=o?`${e.reference.height}px`:""}})):(this.popup.style.width="",this.popup.style.height=""),this.flip&&s.push($a({boundary:this.flipBoundary,fallbackPlacements:this.flipFallbackPlacements,fallbackStrategy:this.flipFallbackStrategy==="best-fit"?"bestFit":"initialPlacement",padding:this.flipPadding})),this.shift&&s.push(ya({boundary:this.shiftBoundary,padding:this.shiftPadding})),this.autoSize?s.push(xi({boundary:this.autoSizeBoundary,padding:this.autoSizePadding,apply:({availableWidth:e,availableHeight:i})=>{this.autoSize==="vertical"||this.autoSize==="both"?this.style.setProperty("--auto-size-available-height",`${i}px`):this.style.removeProperty("--auto-size-available-height"),this.autoSize==="horizontal"||this.autoSize==="both"?this.style.setProperty("--auto-size-available-width",`${e}px`):this.style.removeProperty("--auto-size-available-width")}})):(this.style.removeProperty("--auto-size-available-width"),this.style.removeProperty("--auto-size-available-height")),this.arrow&&s.push(ba({element:this.arrowEl,padding:this.arrowPadding}));const t=this.strategy==="absolute"?e=>xe.getOffsetParent(e,wa):xe.getOffsetParent;_a(this.anchorEl,this.popup,{placement:this.placement,middleware:s,strategy:this.strategy,platform:so(Be({},xe),{getOffsetParent:t})}).then(({x:e,y:i,middlewareData:o,placement:r})=>{const n=getComputedStyle(this).direction==="rtl",l={top:"bottom",right:"left",bottom:"top",left:"right"}[r.split("-")[0]];if(this.setAttribute("data-current-placement",r),Object.assign(this.popup.style,{left:`${e}px`,top:`${i}px`}),this.arrow){const a=o.arrow.x,c=o.arrow.y;let d="",h="",u="",p="";if(this.arrowPlacement==="start"){const f=typeof a=="number"?`calc(${this.arrowPadding}px - var(--arrow-padding-offset))`:"";d=typeof c=="number"?`calc(${this.arrowPadding}px - var(--arrow-padding-offset))`:"",h=n?f:"",p=n?"":f}else if(this.arrowPlacement==="end"){const f=typeof a=="number"?`calc(${this.arrowPadding}px - var(--arrow-padding-offset))`:"";h=n?"":f,p=n?f:"",u=typeof c=="number"?`calc(${this.arrowPadding}px - var(--arrow-padding-offset))`:""}else this.arrowPlacement==="center"?(p=typeof a=="number"?"calc(50% - var(--arrow-size-diagonal))":"",d=typeof c=="number"?"calc(50% - var(--arrow-size-diagonal))":""):(p=typeof a=="number"?`${a}px`:"",d=typeof c=="number"?`${c}px`:"");Object.assign(this.arrowEl.style,{top:d,right:h,bottom:u,left:p,[l]:"calc(var(--arrow-size-diagonal) * -1)"})}}),requestAnimationFrame(()=>this.updateHoverBridge()),this.emit("sl-reposition")}render(){return D`
      <slot name="anchor" @slotchange=${this.handleAnchorChange}></slot>

      <span
        part="hover-bridge"
        class=${he({"popup-hover-bridge":!0,"popup-hover-bridge--visible":this.hoverBridge&&this.active})}
      ></span>

      <div
        part="popup"
        class=${he({popup:!0,"popup--active":this.active,"popup--fixed":this.strategy==="fixed","popup--has-arrow":this.arrow})}
      >
        <slot></slot>
        ${this.arrow?D`<div part="arrow" class="popup__arrow" role="presentation"></div>`:""}
      </div>
    `}};w.styles=[fe,Bn];g([ge(".popup")],w.prototype,"popup",2);g([ge(".popup__arrow")],w.prototype,"arrowEl",2);g([m()],w.prototype,"anchor",2);g([m({type:Boolean,reflect:!0})],w.prototype,"active",2);g([m({reflect:!0})],w.prototype,"placement",2);g([m({reflect:!0})],w.prototype,"strategy",2);g([m({type:Number})],w.prototype,"distance",2);g([m({type:Number})],w.prototype,"skidding",2);g([m({type:Boolean})],w.prototype,"arrow",2);g([m({attribute:"arrow-placement"})],w.prototype,"arrowPlacement",2);g([m({attribute:"arrow-padding",type:Number})],w.prototype,"arrowPadding",2);g([m({type:Boolean})],w.prototype,"flip",2);g([m({attribute:"flip-fallback-placements",converter:{fromAttribute:s=>s.split(" ").map(t=>t.trim()).filter(t=>t!==""),toAttribute:s=>s.join(" ")}})],w.prototype,"flipFallbackPlacements",2);g([m({attribute:"flip-fallback-strategy"})],w.prototype,"flipFallbackStrategy",2);g([m({type:Object})],w.prototype,"flipBoundary",2);g([m({attribute:"flip-padding",type:Number})],w.prototype,"flipPadding",2);g([m({type:Boolean})],w.prototype,"shift",2);g([m({type:Object})],w.prototype,"shiftBoundary",2);g([m({attribute:"shift-padding",type:Number})],w.prototype,"shiftPadding",2);g([m({attribute:"auto-size"})],w.prototype,"autoSize",2);g([m()],w.prototype,"sync",2);g([m({type:Object})],w.prototype,"autoSizeBoundary",2);g([m({attribute:"auto-size-padding",type:Number})],w.prototype,"autoSizePadding",2);g([m({attribute:"hover-bridge",type:Boolean})],w.prototype,"hoverBridge",2);var T=class extends Y{constructor(){super(),this.localize=new kn(this),this.content="",this.placement="top",this.disabled=!1,this.distance=8,this.open=!1,this.skidding=0,this.trigger="hover focus",this.hoist=!1,this.handleBlur=()=>{this.hasTrigger("focus")&&this.hide()},this.handleClick=()=>{this.hasTrigger("click")&&(this.open?this.hide():this.show())},this.handleFocus=()=>{this.hasTrigger("focus")&&this.show()},this.handleDocumentKeyDown=s=>{s.key==="Escape"&&(s.stopPropagation(),this.hide())},this.handleMouseOver=()=>{if(this.hasTrigger("hover")){const s=vi(getComputedStyle(this).getPropertyValue("--show-delay"));clearTimeout(this.hoverTimeout),this.hoverTimeout=window.setTimeout(()=>this.show(),s)}},this.handleMouseOut=()=>{if(this.hasTrigger("hover")){const s=vi(getComputedStyle(this).getPropertyValue("--hide-delay"));clearTimeout(this.hoverTimeout),this.hoverTimeout=window.setTimeout(()=>this.hide(),s)}},this.addEventListener("blur",this.handleBlur,!0),this.addEventListener("focus",this.handleFocus,!0),this.addEventListener("click",this.handleClick),this.addEventListener("mouseover",this.handleMouseOver),this.addEventListener("mouseout",this.handleMouseOut)}disconnectedCallback(){var s;(s=this.closeWatcher)==null||s.destroy(),document.removeEventListener("keydown",this.handleDocumentKeyDown)}firstUpdated(){this.body.hidden=!this.open,this.open&&(this.popup.active=!0,this.popup.reposition())}hasTrigger(s){return this.trigger.split(" ").includes(s)}async handleOpenChange(){var s,t;if(this.open){if(this.disabled)return;this.emit("sl-show"),"CloseWatcher"in window?((s=this.closeWatcher)==null||s.destroy(),this.closeWatcher=new CloseWatcher,this.closeWatcher.onclose=()=>{this.hide()}):document.addEventListener("keydown",this.handleDocumentKeyDown),await yi(this.body),this.body.hidden=!1,this.popup.active=!0;const{keyframes:e,options:i}=fi(this,"tooltip.show",{dir:this.localize.dir()});await mi(this.popup.popup,e,i),this.popup.reposition(),this.emit("sl-after-show")}else{this.emit("sl-hide"),(t=this.closeWatcher)==null||t.destroy(),document.removeEventListener("keydown",this.handleDocumentKeyDown),await yi(this.body);const{keyframes:e,options:i}=fi(this,"tooltip.hide",{dir:this.localize.dir()});await mi(this.popup.popup,e,i),this.popup.active=!1,this.body.hidden=!0,this.emit("sl-after-hide")}}async handleOptionsChange(){this.hasUpdated&&(await this.updateComplete,this.popup.reposition())}handleDisabledChange(){this.disabled&&this.open&&this.hide()}async show(){if(!this.open)return this.open=!0,gi(this,"sl-after-show")}async hide(){if(this.open)return this.open=!1,gi(this,"sl-after-hide")}render(){return D`
      <sl-popup
        part="base"
        exportparts="
          popup:base__popup,
          arrow:base__arrow
        "
        class=${he({tooltip:!0,"tooltip--open":this.open})}
        placement=${this.placement}
        distance=${this.distance}
        skidding=${this.skidding}
        strategy=${this.hoist?"fixed":"absolute"}
        flip
        shift
        arrow
        hover-bridge
      >
        ${""}
        <slot slot="anchor" aria-describedby="tooltip"></slot>

        ${""}
        <div part="body" id="tooltip" class="tooltip__body" role="tooltip" aria-live=${this.open?"polite":"off"}>
          <slot name="content">${this.content}</slot>
        </div>
      </sl-popup>
    `}};T.styles=[fe,Nn];T.dependencies={"sl-popup":w};g([ge("slot:not([name])")],T.prototype,"defaultSlot",2);g([ge(".tooltip__body")],T.prototype,"body",2);g([ge("sl-popup")],T.prototype,"popup",2);g([m()],T.prototype,"content",2);g([m()],T.prototype,"placement",2);g([m({type:Boolean,reflect:!0})],T.prototype,"disabled",2);g([m({type:Number})],T.prototype,"distance",2);g([m({type:Boolean,reflect:!0})],T.prototype,"open",2);g([m({type:Number})],T.prototype,"skidding",2);g([m()],T.prototype,"trigger",2);g([m({type:Boolean})],T.prototype,"hoist",2);g([Nt("open",{waitUntilFirstUpdate:!0})],T.prototype,"handleOpenChange",1);g([Nt(["content","distance","hoist","placement","skidding"])],T.prototype,"handleOptionsChange",1);g([Nt("disabled")],T.prototype,"handleDisabledChange",1);ro("tooltip.show",{keyframes:[{opacity:0,scale:.8},{opacity:1,scale:1}],options:{duration:150,easing:"ease"}});ro("tooltip.hide",{keyframes:[{opacity:1,scale:1},{opacity:0,scale:.8}],options:{duration:150,easing:"ease"}});T.define("sl-tooltip");var ye=function(s,t,e,i){var o=arguments.length,r=o<3?t:i===null?i=Object.getOwnPropertyDescriptor(t,e):i,n;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")r=Reflect.decorate(s,t,e,i);else for(var l=s.length-1;l>=0;l--)(n=s[l])&&(r=(o<3?n(r):o>3?n(t,e,r):n(t,e))||r);return o>3&&r&&Object.defineProperty(t,e,r),r};let Et=class extends Ot{constructor(){super(...arguments),this.tooltip=!1}get _iconSize(){return this.iconSize?this.iconSize:this.tooltip!==!1?"32px":"64px"}renderIcon(){return ut`
      <sl-icon
        style="color: red; height: ${this._iconSize}; width: ${this._iconSize}; margin-bottom: 8px;"
        src="${Lr(Nr)}"
      ></sl-icon>
    `}renderFull(){return ut` <div class="column center-content" style="flex: 1">
      ${this.renderIcon()}
      <div style="width: 500px; text-align: center" class="column">
        ${this.headline?ut` <span style="margin-bottom: 8px">${this.headline} </span>`:ut``}
        <span class="placeholder"
          >${typeof this.error=="object"&&"message"in this.error?this.error.message:this.error}
        </span>
      </div>
    </div>`}renderTooltip(){return ut`
      <sl-tooltip hoist .content=${this.headline?this.headline:this.error}>
        ${this.renderIcon()}</sl-tooltip
      >
    `}render(){return this.tooltip!==!1?this.renderTooltip():this.renderFull()}};Et.styles=[Ki,ms`
      :host {
        display: flex;
        flex: 1;
      }
    `];ye([F({attribute:"tooltip"})],Et.prototype,"tooltip",void 0);ye([F()],Et.prototype,"headline",void 0);ye([F()],Et.prototype,"error",void 0);ye([F({attribute:"icon-size"})],Et.prototype,"iconSize",void 0);Et=ye([po("display-error")],Et);var Ea=Ht`
  :host {
    --border-radius: var(--sl-border-radius-pill);
    --color: var(--sl-color-neutral-200);
    --sheen-color: var(--sl-color-neutral-300);

    display: block;
    position: relative;
  }

  .skeleton {
    display: flex;
    width: 100%;
    height: 100%;
    min-height: 1rem;
  }

  .skeleton__indicator {
    flex: 1 1 auto;
    background: var(--color);
    border-radius: var(--border-radius);
  }

  .skeleton--sheen .skeleton__indicator {
    background: linear-gradient(270deg, var(--sheen-color), var(--color), var(--color), var(--sheen-color));
    background-size: 400% 100%;
    animation: sheen 8s ease-in-out infinite;
  }

  .skeleton--pulse .skeleton__indicator {
    animation: pulse 2s ease-in-out 0.5s infinite;
  }

  /* Forced colors mode */
  @media (forced-colors: active) {
    :host {
      --color: GrayText;
    }
  }

  @keyframes sheen {
    0% {
      background-position: 200% 0;
    }
    to {
      background-position: -200% 0;
    }
  }

  @keyframes pulse {
    0% {
      opacity: 1;
    }
    50% {
      opacity: 0.4;
    }
    100% {
      opacity: 1;
    }
  }
`,Ps=class extends Y{constructor(){super(...arguments),this.effect="none"}render(){return D`
      <div
        part="base"
        class=${he({skeleton:!0,"skeleton--pulse":this.effect==="pulse","skeleton--sheen":this.effect==="sheen"})}
      >
        <div part="indicator" class="skeleton__indicator"></div>
      </div>
    `}};Ps.styles=[fe,Ea];g([m()],Ps.prototype,"effect",2);Ps.define("sl-skeleton");/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const Sa={ATTRIBUTE:1,CHILD:2,PROPERTY:3,BOOLEAN_ATTRIBUTE:4,EVENT:5,ELEMENT:6},Ca=s=>(...t)=>({_$litDirective$:s,values:t});let Pa=class{constructor(t){}get _$AU(){return this._$AM._$AU}_$AT(t,e,i){this._$Ct=t,this._$AM=e,this._$Ci=i}_$AS(t,e){return this.update(t,e)}update(t,e){return this.render(...e)}};/**
 * @license
 * Copyright 2018 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const xo="important",Ta=" !"+xo,Ei=Ca(class extends Pa{constructor(s){var t;if(super(s),s.type!==Sa.ATTRIBUTE||s.name!=="style"||((t=s.strings)==null?void 0:t.length)>2)throw Error("The `styleMap` directive must be used in the `style` attribute and must be the only part in the attribute.")}render(s){return Object.keys(s).reduce((t,e)=>{const i=s[e];return i==null?t:t+`${e=e.includes("-")?e:e.replace(/(?:^(webkit|moz|ms|o)|)(?=[A-Z])/g,"-$&").toLowerCase()}:${i};`},"")}update(s,[t]){const{style:e}=s.element;if(this.ft===void 0)return this.ft=new Set(Object.keys(t)),this.render(t);for(const i of this.ft)t[i]==null&&(this.ft.delete(i),i.includes("-")?e.removeProperty(i):e[i]=null);for(const i in t){const o=t[i];if(o!=null){this.ft.add(i);const r=typeof o=="string"&&o.endsWith(Ta);i.includes("-")||r?e.setProperty(i,r?o.slice(0,-11):o,r?xo:""):e[i]=o}}return $t}});let Ue=[0],Ee=0;function Oa(s){s[0]===132&&s[1]===32&&s[2]===36?Ue=s.slice(3):Ue=s||[],Ee=0}function O(){return(()=>{const t=Ue[Ee];return Ee=(Ee+1)%Ue.length,t})()/256}function Eo(s){const t=Math.floor(O()*360),e=O()*60+40,i=s||(O()*100+(O()+O()+O()+O())*25)/2;return{h:t,s:e,l:i}}function So({h:s,s:t,l:e}){return`hsl(${s}, ${t}%, ${e}%)`}function Ra(s,t,e){const i=O()*2*Math.PI,o=t*Math.cos(i),r=t*Math.sin(i),n=e.x+o,l=e.x+r,a=i+2*Math.PI*.3,c=t*Math.cos(a),d=t*Math.sin(a),h=e.x+c,u=e.x+d,p=a+2*Math.PI*.3,f=t*Math.cos(p),v=t*Math.sin(p),$=e.x+f,y=e.x+v;s.beginPath(),s.moveTo(n,l),s.lineTo(h,u),s.lineTo($,y),s.fill()}function ka(s){const t=s.hash||[0];return Oa(t),{backgroundColor:s.backgroundColor||So(Eo()),hash:t,size:s.size||32}}function Ma(s,t){if(s.hash&&!(s.hash instanceof Uint8Array))throw new Error("invalid type for opts.hash, expecting Uint8Array or null");s=ka(s||{});const{size:e,backgroundColor:i}=s;t.width=t.height=e;const o=t.getContext("2d");if(!o)return;o.fillStyle=i,o.fillRect(0,0,t.width,t.height);const r=O()<.5?3:4,n=Array.apply(null,Array(r)).map((l,a)=>{const c=a===0?5+O()*25:a===1?70+O()*25:null;return{x:O()*e,y:O()*e,radius:5+O()*e*.25,type:Math.floor(O()*3),color:So(Eo(c))}}).sort((l,a)=>l.radius>a.radius?-1:1);for(let l=0;l<r;l++){const a=n[l],{x:c,y:d,radius:h,type:u,color:p}=a;switch(o.fillStyle=p,u){case 0:o.beginPath(),o.arc(c,d,h,0,2*Math.PI),o.fill();break;case 1:o.fillRect(c,d,h*2,h*2);break;case 2:Ra(o,h*2,{x:c,y:d});break;default:throw new Error("shape is greater than 2, this should never happen")}}return t}/**
 * @license
 * Copyright 2018 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const za=zr(class extends Ur{constructor(s){var t;if(super(s),s.type!==Mr.ATTRIBUTE||s.name!=="class"||((t=s.strings)==null?void 0:t.length)>2)throw Error("`classMap()` can only be used in the `class` attribute and must be the only part in the attribute.")}render(s){return" "+Object.keys(s).filter(t=>s[t]).join(" ")+" "}update(s,[t]){var i,o;if(this.st===void 0){this.st=new Set,s.strings!==void 0&&(this.nt=new Set(s.strings.join(" ").split(/\s/).filter(r=>r!=="")));for(const r in t)t[r]&&!((i=this.nt)!=null&&i.has(r))&&this.st.add(r);return this.render(t)}const e=s.element.classList;for(const r of this.st)r in t||(e.remove(r),this.st.delete(r));for(const r in t){const n=!!t[r];n===this.st.has(r)||(o=this.nt)!=null&&o.has(r)||(n?(e.add(r),this.st.add(r)):(e.remove(r),this.st.delete(r)))}return _t}});var X=function(s,t,e,i){var o=arguments.length,r=o<3?t:i===null?i=Object.getOwnPropertyDescriptor(t,e):i,n;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")r=Reflect.decorate(s,t,e,i);else for(var l=s.length-1;l>=0;l--)(n=s[l])&&(r=(o<3?n(r):o>3?n(t,e,r):n(t,e))||r);return o>3&&r&&Object.defineProperty(t,e,r),r};let j=class extends Ot{constructor(){super(...arguments),this.size=32,this.shape="circle",this.disableTooltip=!1,this.disableCopy=!1,this.justCopiedHash=!1}async copyHash(){this.disableCopy||(await navigator.clipboard.writeText(this.strHash),this.timeout&&clearTimeout(this.timeout),this.justCopiedHash=!0,this._tooltip.show(),this.timeout=setTimeout(()=>{this._tooltip.hide(),setTimeout(()=>{this.justCopiedHash=!1},100)},2e3))}get strHash(){return ko(this.hash)}updated(t){var e,i;super.updated(t),(t.has("hash")&&((e=t.get("hash"))==null?void 0:e.toString())!==((i=this.hash)==null?void 0:i.toString())||t.has("size")||t.has("value"))&&Ma({hash:this.hash,size:this.size},this._canvas)}renderCanvas(){return ut` <canvas
      id="canvas"
      width="1"
      height="1"
      class=${za({square:this.shape==="square",circle:this.shape==="circle"})}
    ></canvas>`}render(){return ut`<div
      @click=${()=>this.copyHash()}
      style="${this.disableCopy?"":"cursor: pointer;"} flex-grow: 0"
    >
      <sl-tooltip
        id="tooltip"
        placement="top"
        .content=${this.justCopiedHash?Ni("Copied!"):`${this.strHash.substring(0,6)}...`}
        .trigger=${this.disableTooltip||this.justCopiedHash?"manual":"hover focus"}
        hoist
      >
        ${this.renderCanvas()}
      </sl-tooltip>
    </div>`}static get styles(){return ms`
      :host {
        display: flex;
      }

      .square {
        border-radius: 0%;
      }
      .circle {
        border-radius: 50%;
      }
    `}};X([F(Yi("hash"))],j.prototype,"hash",void 0);X([F({type:Number})],j.prototype,"size",void 0);X([F({type:String})],j.prototype,"shape",void 0);X([F({type:Boolean,attribute:"disable-tooltip"})],j.prototype,"disableTooltip",void 0);X([F({type:Boolean,attribute:"disable-copy"})],j.prototype,"disableCopy",void 0);X([uo("#canvas")],j.prototype,"_canvas",void 0);X([uo("#tooltip")],j.prototype,"_tooltip",void 0);X([Ln()],j.prototype,"justCopiedHash",void 0);j=X([Hi(),po("holo-identicon")],j);let ct=class extends Jt{constructor(){super(...arguments),this.size=32,this.disableTooltip=!1,this.disableCopy=!1,this._agentProfile=new Hn(this,()=>this.store.profiles.get(this.agentPubKey),()=>[this.agentPubKey,this.store])}renderIdenticon(){return Ft` <div
      style=${Ei({position:"relative",height:`${this.size}px`,width:`${this.size}px`})}
    >
      <holo-identicon
        .disableCopy=${this.disableCopy}
        .disableTooltip=${this.disableTooltip}
        .hash=${this.agentPubKey}
        .size=${this.size}
      >
      </holo-identicon>
      <div class="badge"><slot name="badge"></slot></div>
    </div>`}renderProfile(t){if(!t||!t.entry.fields.avatar)return this.renderIdenticon();const e=Ft`
      <div
        style=${Ei({cursor:this.disableCopy?"":"pointer",position:"relative",height:`${this.size}px`,width:`${this.size}px`})}
      >
        <sl-avatar
          .image=${t.entry.fields.avatar}
          style="--size: ${this.size}px;"
          @click=${()=>this.dispatchEvent(new CustomEvent("profile-clicked",{composed:!0,bubbles:!0,detail:{agentPubKey:this.agentPubKey}}))}
        >
        </sl-avatar>
        <div class="badge"><slot name="badge"></slot></div>
      </div>
    `;return Ft`
      <sl-tooltip
        id="tooltip"
        placement="top"
        .trigger=${this.disableTooltip?"manual":"hover focus"}
        hoist
        .content=${t.entry.nickname}
      >
        ${e}
      </sl-tooltip>
    `}render(){if(this.store.config.avatarMode==="identicon")return this.renderIdenticon();switch(this._agentProfile.value.status){case"pending":return Ft`<sl-skeleton
          effect="pulse"
          style="height: ${this.size}px; width: ${this.size}px"
        ></sl-skeleton>`;case"complete":return this.renderProfile(this._agentProfile.value.value);case"error":return Ft`
          <display-error
            tooltip
            .headline=${Ni("Error fetching the agent's avatar")}
            .error=${this._agentProfile.value.error}
          ></display-error>
        `}}};ct.styles=[Ki,zo`
      .badge {
        position: absolute;
        right: 0;
        bottom: 0;
      }
    `];Lt([pe(Yi("agent-pub-key"))],ct.prototype,"agentPubKey",void 0);Lt([pe({type:Number})],ct.prototype,"size",void 0);Lt([pe({type:Boolean,attribute:"disable-tooltip"})],ct.prototype,"disableTooltip",void 0);Lt([pe({type:Boolean,attribute:"disable-copy"})],ct.prototype,"disableCopy",void 0);Lt([tr({context:or,subscribe:!0}),pe()],ct.prototype,"store",void 0);ct=Lt([Hi(),er("agent-avatar")],ct);export{S as $,so as A,Be as B,Oe as C,xn as D,En as E,An as F,hl as G,At as H,dl as I,Ki as J,F as K,kn as L,uo as M,po as N,Ot as O,Ni as P,ut as Q,ll as R,V as S,P as T,tr as U,Za as V,Hi as W,Hn as X,Yi as Y,w as Z,g as _,Jt as a,Ur as b,Nr as c,Ht as d,zr as e,D as f,fe as g,ge as h,zo as i,m as j,Y as k,he as l,al as m,pe as n,Nt as o,or as p,ro as q,io as r,Qo as s,er as t,yi as u,fi as v,Lr as w,Ft as x,mi as y,gi as z};
