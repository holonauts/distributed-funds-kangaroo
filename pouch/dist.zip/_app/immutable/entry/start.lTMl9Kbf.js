import{a as t}from"../chunks/entry.CkXypjhS.js";export{t as start};
