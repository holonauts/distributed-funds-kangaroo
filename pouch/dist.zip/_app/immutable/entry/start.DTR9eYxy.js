import{a as t}from"../chunks/entry.C7OuHK-i.js";export{t as start};
