import{a as t}from"../chunks/entry.C7Y9mYtz.js";export{t as start};
