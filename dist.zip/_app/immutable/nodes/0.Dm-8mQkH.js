import{s as Q,E as at,q as M,e as V,a as et,as as xs,c as F,Y as os,f,g as st,b as P,m as y,L as Et,h as W,i as x,y as S,G as ut,H as ct,I as dt,w as Z,x as X,r as pt,u as mt,k as Ot,ar as ae,A as Bt,M as Fe,z as ve,B as A,F as Nt,a1 as Es,O as Ss,J as As,v as Ut,n as ht,t as St,d as At,j as _e,p as $s,C as Mt,N as Ps}from"../chunks/scheduler.B-whawdI.js";import{S as ot,i as rt,t as k,b as w,c as B,a as N,m as U,d as R,g as Rt,f as Ht,h as Me}from"../chunks/index.DKySoX1N.js";import{_ as z}from"../chunks/tslib.es6.UDDzLUu6.js";import{s as Ls,n as K,i as Qt,a as $t,x as H,p as Dt,t as Pt,e as zs,b as Ts,w as rs,m as Is,c as Ds,d as bt,f as J,T as ue,g as Ct,S as ye,_ as d,h as gt,r as ke,j as p,k as xt,l as wt,o as vt,q as we,L as qt,u as ce,v as de,y as he,z as fe,A as is,B as ze,C as Oe,D as ls,E as ns,F as zt,G as as,H as oe,I as Vs,J as Lt,K as Vt,M as us,N as Fs,O as Ms,P as Y,Q as Kt,R as Os,U as jt,V as Bs,W as Wt,X as Te,Y as cs,Z as ds,$ as Ns}from"../chunks/agent-avatar.azbCN78C.js";import{k as Us,b as Pe,d as Rs,a as G,g as _t,F as Ie,c as hs,e as Be,l as Hs,h as le}from"../chunks/holochainClient.CrmkGE-_.js";import{S as qs}from"../chunks/Spinner.CIdapEpW.js";import{T as js,C as Ws}from"../chunks/CloseButton.Drtt-AcY.js";import{I as Ks}from"../chunks/InfoCircleSolid.CLRZebDa.js";import{B as Ys}from"../chunks/Button.BiIhXYC4.js";import{w as fs}from"../chunks/entry.C7OuHK-i.js";import{q as Xs,s as Ne}from"../chunks/index.Dj2RRtbG.js";import{p as Gs}from"../chunks/stores.Cw97Naka.js";const Zs=typeof window<"u"?window:typeof globalThis<"u"?globalThis:global,Js="auto",Qs=!1,ki=Object.freeze(Object.defineProperty({__proto__:null,prerender:Js,ssr:Qs},Symbol.toStringTag,{value:"Module"}));/**
 * @license
 * Copyright 2021 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */let to=class{get value(){return this.o}set value(t){this.setValue(t)}setValue(t,o=!1){const s=o||!Object.is(t,this.o);this.o=t,s&&this.updateObservers()}constructor(t){this.subscriptions=new Map,this.updateObservers=()=>{for(const[o,{disposer:s}]of this.subscriptions)o(this.o,s)},t!==void 0&&(this.value=t)}addCallback(t,o,s){if(!s)return void t(this.value);this.subscriptions.has(t)||this.subscriptions.set(t,{disposer:()=>{this.subscriptions.delete(t)},consumerHost:o});const{disposer:r}=this.subscriptions.get(t);t(this.value,r)}clearCallbacks(){this.subscriptions.clear()}};/**
 * @license
 * Copyright 2021 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */let eo=class extends Event{constructor(t){super("context-provider",{bubbles:!0,composed:!0}),this.context=t}};class Ue extends to{constructor(t,o,s){var r,i;super(o.context!==void 0?o.initialValue:s),this.onContextRequest=l=>{const u=l.composedPath()[0];l.context===this.context&&u!==this.host&&(l.stopPropagation(),this.addCallback(l.callback,u,l.subscribe))},this.onProviderRequest=l=>{const u=l.composedPath()[0];if(l.context!==this.context||u===this.host)return;const n=new Set;for(const[a,{consumerHost:c}]of this.subscriptions)n.has(a)||(n.add(a),c.dispatchEvent(new Ls(this.context,a,!0)));l.stopPropagation()},this.host=t,o.context!==void 0?this.context=o.context:this.context=o,this.attachListeners(),(i=(r=this.host).addController)==null||i.call(r,this)}attachListeners(){this.host.addEventListener("context-request",this.onContextRequest),this.host.addEventListener("context-provider",this.onProviderRequest)}hostConnected(){this.host.dispatchEvent(new eo(this.context))}}/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */function so({context:e}){return(t,o)=>{const s=new WeakMap;if(typeof o=="object")return o.addInitializer(function(){s.set(this,new Ue(this,{context:e}))}),{get(){return t.get.call(this)},set(r){var i;return(i=s.get(this))==null||i.setValue(r),t.set.call(this,r)},init(r){var i;return(i=s.get(this))==null||i.setValue(r),r}};{t.constructor.addInitializer(l=>{s.set(l,new Ue(l,{context:e}))});const r=Object.getOwnPropertyDescriptor(t,o);let i;if(r===void 0){const l=new WeakMap;i={get:function(){return l.get(this)},set:function(u){s.get(this).setValue(u),l.set(this,u)},configurable:!0,enumerable:!0}}else{const l=r.set;i={...r,set:function(u){s.get(this).setValue(u),l==null||l.call(this,u)}}}return void Object.defineProperty(t,o,i)}}}/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */function ps(e){return K({...e,state:!0,attribute:!1})}/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const Re=(e,t,o)=>(o.configurable=!0,o.enumerable=!0,Reflect.decorate&&typeof t!="object"&&Object.defineProperty(e,t,o),o);/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */function ms(e,t){return(o,s,r)=>{const i=l=>{var u;return((u=l.renderRoot)==null?void 0:u.querySelector(e))??null};if(t){const{get:l,set:u}=typeof s=="object"?o:r??(()=>{const n=Symbol();return{get(){return this[n]},set(a){this[n]=a}}})();return Re(o,s,{get(){let n=l.call(this);return n===void 0&&(n=i(this),(n!==null||this.hasUpdated)&&u.call(this,n)),n}})}return Re(o,s,{get(){return i(this)}})}}let pe=class extends $t{render(){return H`<slot></slot>`}};pe.styles=Qt`
    :host {
      display: contents;
    }
  `;z([so({context:Dt}),K({type:Object})],pe.prototype,"store",void 0);pe=z([Pt("profiles-context")],pe);class bs{constructor(t){this.host=t,this.host.addController(this),this.handleFormData=this.handleFormData.bind(this),this.handleFormSubmit=this.handleFormSubmit.bind(this),this.handleFormReset=this.handleFormReset.bind(this)}closestElement(t){function o(s){if(!s||s===document||s===window)return null;s.assignedSlot&&(s=s.assignedSlot);const r=s.closest(t);return r||o(s.getRootNode().host)}return o(this.host)}hostConnected(){this.form=this.closestElement("form"),this.form&&(this.form.addEventListener("formdata",this.handleFormData),this.form.addEventListener("submit",this.handleFormSubmit),this.form.addEventListener("reset",this.handleFormReset),this.form.dispatchEvent(new CustomEvent("update-form")))}hostDisconnected(){this.form&&(this.form.removeEventListener("formdata",this.handleFormData),this.form.removeEventListener("submit",this.handleFormSubmit),this.form.removeEventListener("reset",this.handleFormReset),this.form=void 0)}handleFormData(t){const o=this.host.disabled,s=this.host.name,r=this.host.value;!o&&s&&r!==void 0&&(Array.isArray(r)?r.map(i=>t.formData.append(s,i)):t.formData.append(s,r))}handleFormSubmit(t){const o=this.form,s=this.host.disabled,r=this.host.reportValidity;o&&!o.noValidate&&!s&&r&&!this.host.reportValidity()&&(t.preventDefault(),t.stopImmediatePropagation())}handleFormReset(t){this.host.reset()}}function Ee(e){return typeof e=="string"&&e.split(",").length===39?new Uint8Array(e.split(",").map(t=>parseInt(t,10))):e}function He(e){const t=new FormData(e),o={};return t.forEach((s,r)=>{if(Reflect.has(o,r)){const i=o[r];Array.isArray(i)?i.push(Ee(s)):o[r]=[o[r],Ee(s)]}else o[r]=Ee(s)}),o}class oo extends Ts{constructor(){super(...arguments),this.initialized=!1}update(t,o){this.initialized||(this.initialized=!0,t.element.addEventListener("update-form",r=>{this.listener&&t.element.removeEventListener("submit",this.listener),this.listener=i=>{i.preventDefault();const l=He(t.element);o[0](l)},t.element.addEventListener("submit",this.listener)})),setTimeout(()=>{this.listener&&t.element.removeEventListener("submit",this.listener),this.listener=s=>{s.preventDefault();const r=He(t.element);o[0](r)},t.element.addEventListener("submit",this.listener)},100)}render(t){return""}}const ro=zs(oo);function io(e){const t=document.createElement("div");return t.textContent=e,t.innerHTML}function lo(e,t="primary",o=Is,s=3e3){const r=Object.assign(document.createElement("sl-alert"),{variant:t,closable:!0,duration:s,innerHTML:`
        <sl-icon src="${rs(o)}" slot="icon"></sl-icon>
        ${io(e)}
      `});return document.body.append(r),r.toast()}function no(e){return lo(e,"danger",Ds)}var ao=bt`
  :host {
    display: inline-block;
    color: var(--sl-color-neutral-600);
  }

  .icon-button {
    flex: 0 0 auto;
    display: flex;
    align-items: center;
    background: none;
    border: none;
    border-radius: var(--sl-border-radius-medium);
    font-size: inherit;
    color: inherit;
    padding: var(--sl-spacing-x-small);
    cursor: pointer;
    transition: var(--sl-transition-x-fast) color;
    -webkit-appearance: none;
  }

  .icon-button:hover:not(.icon-button--disabled),
  .icon-button:focus-visible:not(.icon-button--disabled) {
    color: var(--sl-color-primary-600);
  }

  .icon-button:active:not(.icon-button--disabled) {
    color: var(--sl-color-primary-700);
  }

  .icon-button:focus {
    outline: none;
  }

  .icon-button--disabled {
    opacity: 0.5;
    cursor: not-allowed;
  }

  .icon-button:focus-visible {
    outline: var(--sl-focus-ring);
    outline-offset: var(--sl-focus-ring-offset);
  }

  .icon-button__icon {
    pointer-events: none;
  }
`;/**
 * @license
 * Copyright 2020 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const gs=Symbol.for(""),uo=e=>{if((e==null?void 0:e.r)===gs)return e==null?void 0:e._$litStatic$},me=(e,...t)=>({_$litStatic$:t.reduce((o,s,r)=>o+(i=>{if(i._$litStatic$!==void 0)return i._$litStatic$;throw Error(`Value passed to 'literal' function must be a 'literal' result: ${i}. Use 'unsafeStatic' to pass non-literal values, but
            take care to ensure page security.`)})(s)+e[r+1],e[0]),r:gs}),qe=new Map,co=e=>(t,...o)=>{const s=o.length;let r,i;const l=[],u=[];let n,a=0,c=!1;for(;a<s;){for(n=t[a];a<s&&(i=o[a],(r=uo(i))!==void 0);)n+=r+t[++a],c=!0;a!==s&&u.push(i),l.push(n),a++}if(a===s&&l.push(t[s]),c){const h=l.join("$$lit$$");(t=qe.get(h))===void 0&&(l.raw=l,qe.set(h,t=l)),o=u}return e(t,...o)},ne=co(J);/**
 * @license
 * Copyright 2018 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const I=e=>e??ue;var lt=class extends xt{constructor(){super(...arguments),this.hasFocus=!1,this.label="",this.disabled=!1}handleBlur(){this.hasFocus=!1,this.emit("sl-blur")}handleFocus(){this.hasFocus=!0,this.emit("sl-focus")}handleClick(e){this.disabled&&(e.preventDefault(),e.stopPropagation())}click(){this.button.click()}focus(e){this.button.focus(e)}blur(){this.button.blur()}render(){const e=!!this.href,t=e?me`a`:me`button`;return ne`
      <${t}
        part="base"
        class=${wt({"icon-button":!0,"icon-button--disabled":!e&&this.disabled,"icon-button--focused":this.hasFocus})}
        ?disabled=${I(e?void 0:this.disabled)}
        type=${I(e?void 0:"button")}
        href=${I(e?this.href:void 0)}
        target=${I(e?this.target:void 0)}
        download=${I(e?this.download:void 0)}
        rel=${I(e&&this.target?"noreferrer noopener":void 0)}
        role=${I(e?void 0:"button")}
        aria-disabled=${this.disabled?"true":"false"}
        aria-label="${this.label}"
        tabindex=${this.disabled?"-1":"0"}
        @blur=${this.handleBlur}
        @focus=${this.handleFocus}
        @click=${this.handleClick}
      >
        <sl-icon
          class="icon-button__icon"
          name=${I(this.name)}
          library=${I(this.library)}
          src=${I(this.src)}
          aria-hidden="true"
        ></sl-icon>
      </${t}>
    `}};lt.styles=[Ct,ao];lt.dependencies={"sl-icon":ye};d([gt(".icon-button")],lt.prototype,"button",2);d([ke()],lt.prototype,"hasFocus",2);d([p()],lt.prototype,"name",2);d([p()],lt.prototype,"library",2);d([p()],lt.prototype,"src",2);d([p()],lt.prototype,"href",2);d([p()],lt.prototype,"target",2);d([p()],lt.prototype,"download",2);d([p()],lt.prototype,"label",2);d([p({type:Boolean,reflect:!0})],lt.prototype,"disabled",2);var te=class{constructor(e,...t){this.slotNames=[],this.handleSlotChange=o=>{const s=o.target;(this.slotNames.includes("[default]")&&!s.name||s.name&&this.slotNames.includes(s.name))&&this.host.requestUpdate()},(this.host=e).addController(this),this.slotNames=t}hasDefaultSlot(){return[...this.host.childNodes].some(e=>{if(e.nodeType===e.TEXT_NODE&&e.textContent.trim()!=="")return!0;if(e.nodeType===e.ELEMENT_NODE){const t=e;if(t.tagName.toLowerCase()==="sl-visually-hidden")return!1;if(!t.hasAttribute("slot"))return!0}return!1})}hasNamedSlot(e){return this.host.querySelector(`:scope > [slot="${e}"]`)!==null}test(e){return e==="[default]"?this.hasDefaultSlot():this.hasNamedSlot(e)}hostConnected(){this.host.shadowRoot.addEventListener("slotchange",this.handleSlotChange)}hostDisconnected(){this.host.shadowRoot.removeEventListener("slotchange",this.handleSlotChange)}};function ho(e){if(!e)return"";const t=e.assignedNodes({flatten:!0});let o="";return[...t].forEach(s=>{s.nodeType===Node.TEXT_NODE&&(o+=s.textContent)}),o}var fo=bt`
  :host {
    display: contents;

    /* For better DX, we'll reset the margin here so the base part can inherit it */
    margin: 0;
  }

  .alert {
    position: relative;
    display: flex;
    align-items: stretch;
    background-color: var(--sl-panel-background-color);
    border: solid var(--sl-panel-border-width) var(--sl-panel-border-color);
    border-top-width: calc(var(--sl-panel-border-width) * 3);
    border-radius: var(--sl-border-radius-medium);
    font-family: var(--sl-font-sans);
    font-size: var(--sl-font-size-small);
    font-weight: var(--sl-font-weight-normal);
    line-height: 1.6;
    color: var(--sl-color-neutral-700);
    margin: inherit;
  }

  .alert:not(.alert--has-icon) .alert__icon,
  .alert:not(.alert--closable) .alert__close-button {
    display: none;
  }

  .alert__icon {
    flex: 0 0 auto;
    display: flex;
    align-items: center;
    font-size: var(--sl-font-size-large);
    padding-inline-start: var(--sl-spacing-large);
  }

  .alert--primary {
    border-top-color: var(--sl-color-primary-600);
  }

  .alert--primary .alert__icon {
    color: var(--sl-color-primary-600);
  }

  .alert--success {
    border-top-color: var(--sl-color-success-600);
  }

  .alert--success .alert__icon {
    color: var(--sl-color-success-600);
  }

  .alert--neutral {
    border-top-color: var(--sl-color-neutral-600);
  }

  .alert--neutral .alert__icon {
    color: var(--sl-color-neutral-600);
  }

  .alert--warning {
    border-top-color: var(--sl-color-warning-600);
  }

  .alert--warning .alert__icon {
    color: var(--sl-color-warning-600);
  }

  .alert--danger {
    border-top-color: var(--sl-color-danger-600);
  }

  .alert--danger .alert__icon {
    color: var(--sl-color-danger-600);
  }

  .alert__message {
    flex: 1 1 auto;
    display: block;
    padding: var(--sl-spacing-large);
    overflow: hidden;
  }

  .alert__close-button {
    flex: 0 0 auto;
    display: flex;
    align-items: center;
    font-size: var(--sl-font-size-medium);
    padding-inline-end: var(--sl-spacing-medium);
  }
`,Ft=Object.assign(document.createElement("div"),{className:"sl-toast-stack"}),yt=class extends xt{constructor(){super(...arguments),this.hasSlotController=new te(this,"icon","suffix"),this.localize=new qt(this),this.open=!1,this.closable=!1,this.variant="primary",this.duration=1/0}firstUpdated(){this.base.hidden=!this.open}restartAutoHide(){clearTimeout(this.autoHideTimeout),this.open&&this.duration<1/0&&(this.autoHideTimeout=window.setTimeout(()=>this.hide(),this.duration))}handleCloseClick(){this.hide()}handleMouseMove(){this.restartAutoHide()}async handleOpenChange(){if(this.open){this.emit("sl-show"),this.duration<1/0&&this.restartAutoHide(),await ce(this.base),this.base.hidden=!1;const{keyframes:e,options:t}=de(this,"alert.show",{dir:this.localize.dir()});await he(this.base,e,t),this.emit("sl-after-show")}else{this.emit("sl-hide"),clearTimeout(this.autoHideTimeout),await ce(this.base);const{keyframes:e,options:t}=de(this,"alert.hide",{dir:this.localize.dir()});await he(this.base,e,t),this.base.hidden=!0,this.emit("sl-after-hide")}}handleDurationChange(){this.restartAutoHide()}async show(){if(!this.open)return this.open=!0,fe(this,"sl-after-show")}async hide(){if(this.open)return this.open=!1,fe(this,"sl-after-hide")}async toast(){return new Promise(e=>{Ft.parentElement===null&&document.body.append(Ft),Ft.appendChild(this),requestAnimationFrame(()=>{this.clientWidth,this.show()}),this.addEventListener("sl-after-hide",()=>{Ft.removeChild(this),e(),Ft.querySelector("sl-alert")===null&&Ft.remove()},{once:!0})})}render(){return J`
      <div
        part="base"
        class=${wt({alert:!0,"alert--open":this.open,"alert--closable":this.closable,"alert--has-icon":this.hasSlotController.test("icon"),"alert--primary":this.variant==="primary","alert--success":this.variant==="success","alert--neutral":this.variant==="neutral","alert--warning":this.variant==="warning","alert--danger":this.variant==="danger"})}
        role="alert"
        aria-hidden=${this.open?"false":"true"}
        @mousemove=${this.handleMouseMove}
      >
        <div part="icon" class="alert__icon">
          <slot name="icon"></slot>
        </div>

        <div part="message" class="alert__message" aria-live="polite">
          <slot></slot>
        </div>

        ${this.closable?J`
              <sl-icon-button
                part="close-button"
                exportparts="base:close-button__base"
                class="alert__close-button"
                name="x-lg"
                library="system"
                label=${this.localize.term("close")}
                @click=${this.handleCloseClick}
              ></sl-icon-button>
            `:""}
      </div>
    `}};yt.styles=[Ct,fo];yt.dependencies={"sl-icon-button":lt};d([gt('[part~="base"]')],yt.prototype,"base",2);d([p({type:Boolean,reflect:!0})],yt.prototype,"open",2);d([p({type:Boolean,reflect:!0})],yt.prototype,"closable",2);d([p({reflect:!0})],yt.prototype,"variant",2);d([p({type:Number})],yt.prototype,"duration",2);d([vt("open",{waitUntilFirstUpdate:!0})],yt.prototype,"handleOpenChange",1);d([vt("duration")],yt.prototype,"handleDurationChange",1);we("alert.show",{keyframes:[{opacity:0,scale:.8},{opacity:1,scale:1}],options:{duration:250,easing:"ease"}});we("alert.hide",{keyframes:[{opacity:1,scale:1},{opacity:0,scale:.8}],options:{duration:250,easing:"ease"}});yt.define("sl-alert");var po=bt`
  :host {
    --border-color: var(--sl-color-neutral-200);
    --border-radius: var(--sl-border-radius-medium);
    --border-width: 1px;
    --padding: var(--sl-spacing-large);

    display: inline-block;
  }

  .card {
    display: flex;
    flex-direction: column;
    background-color: var(--sl-panel-background-color);
    box-shadow: var(--sl-shadow-x-small);
    border: solid var(--border-width) var(--border-color);
    border-radius: var(--border-radius);
  }

  .card__image {
    display: flex;
    border-top-left-radius: var(--border-radius);
    border-top-right-radius: var(--border-radius);
    margin: calc(-1 * var(--border-width));
    overflow: hidden;
  }

  .card__image::slotted(img) {
    display: block;
    width: 100%;
  }

  .card:not(.card--has-image) .card__image {
    display: none;
  }

  .card__header {
    display: block;
    border-bottom: solid var(--border-width) var(--border-color);
    padding: calc(var(--padding) / 2) var(--padding);
  }

  .card:not(.card--has-header) .card__header {
    display: none;
  }

  .card:not(.card--has-image) .card__header {
    border-top-left-radius: var(--border-radius);
    border-top-right-radius: var(--border-radius);
  }

  .card__body {
    display: block;
    padding: var(--padding);
  }

  .card--has-footer .card__footer {
    display: block;
    border-top: solid var(--border-width) var(--border-color);
    padding: var(--padding);
  }

  .card:not(.card--has-footer) .card__footer {
    display: none;
  }
`,vs=class extends xt{constructor(){super(...arguments),this.hasSlotController=new te(this,"footer","header","image")}render(){return J`
      <div
        part="base"
        class=${wt({card:!0,"card--has-footer":this.hasSlotController.test("footer"),"card--has-image":this.hasSlotController.test("image"),"card--has-header":this.hasSlotController.test("header")})}
      >
        <slot name="image" part="image" class="card__image"></slot>
        <slot name="header" part="header" class="card__header"></slot>
        <slot part="body" class="card__body"></slot>
        <slot name="footer" part="footer" class="card__footer"></slot>
      </div>
    `}};vs.styles=[Ct,po];vs.define("sl-card");var mo=bt`
  :host {
    --track-width: 2px;
    --track-color: rgb(128 128 128 / 25%);
    --indicator-color: var(--sl-color-primary-600);
    --speed: 2s;

    display: inline-flex;
    width: 1em;
    height: 1em;
    flex: none;
  }

  .spinner {
    flex: 1 1 auto;
    height: 100%;
    width: 100%;
  }

  .spinner__track,
  .spinner__indicator {
    fill: none;
    stroke-width: var(--track-width);
    r: calc(0.5em - var(--track-width) / 2);
    cx: 0.5em;
    cy: 0.5em;
    transform-origin: 50% 50%;
  }

  .spinner__track {
    stroke: var(--track-color);
    transform-origin: 0% 0%;
  }

  .spinner__indicator {
    stroke: var(--indicator-color);
    stroke-linecap: round;
    stroke-dasharray: 150% 75%;
    animation: spin var(--speed) linear infinite;
  }

  @keyframes spin {
    0% {
      transform: rotate(0deg);
      stroke-dasharray: 0.05em, 3em;
    }

    50% {
      transform: rotate(450deg);
      stroke-dasharray: 1.375em, 1.375em;
    }

    100% {
      transform: rotate(1080deg);
      stroke-dasharray: 0.05em, 3em;
    }
  }
`,Ce=class extends xt{constructor(){super(...arguments),this.localize=new qt(this)}render(){return J`
      <svg part="base" class="spinner" role="progressbar" aria-label=${this.localize.term("loading")}>
        <circle class="spinner__track"></circle>
        <circle class="spinner__indicator"></circle>
      </svg>
    `}};Ce.styles=[Ct,mo];var Yt=new WeakMap,Xt=new WeakMap,Gt=new WeakMap,Se=new WeakSet,re=new WeakMap,_s=class{constructor(e,t){this.handleFormData=o=>{const s=this.options.disabled(this.host),r=this.options.name(this.host),i=this.options.value(this.host),l=this.host.tagName.toLowerCase()==="sl-button";this.host.isConnected&&!s&&!l&&typeof r=="string"&&r.length>0&&typeof i<"u"&&(Array.isArray(i)?i.forEach(u=>{o.formData.append(r,u.toString())}):o.formData.append(r,i.toString()))},this.handleFormSubmit=o=>{var s;const r=this.options.disabled(this.host),i=this.options.reportValidity;this.form&&!this.form.noValidate&&((s=Yt.get(this.form))==null||s.forEach(l=>{this.setUserInteracted(l,!0)})),this.form&&!this.form.noValidate&&!r&&!i(this.host)&&(o.preventDefault(),o.stopImmediatePropagation())},this.handleFormReset=()=>{this.options.setValue(this.host,this.options.defaultValue(this.host)),this.setUserInteracted(this.host,!1),re.set(this.host,[])},this.handleInteraction=o=>{const s=re.get(this.host);s.includes(o.type)||s.push(o.type),s.length===this.options.assumeInteractionOn.length&&this.setUserInteracted(this.host,!0)},this.checkFormValidity=()=>{if(this.form&&!this.form.noValidate){const o=this.form.querySelectorAll("*");for(const s of o)if(typeof s.checkValidity=="function"&&!s.checkValidity())return!1}return!0},this.reportFormValidity=()=>{if(this.form&&!this.form.noValidate){const o=this.form.querySelectorAll("*");for(const s of o)if(typeof s.reportValidity=="function"&&!s.reportValidity())return!1}return!0},(this.host=e).addController(this),this.options=ze({form:o=>{const s=o.form;if(s){const i=o.getRootNode().getElementById(s);if(i)return i}return o.closest("form")},name:o=>o.name,value:o=>o.value,defaultValue:o=>o.defaultValue,disabled:o=>{var s;return(s=o.disabled)!=null?s:!1},reportValidity:o=>typeof o.reportValidity=="function"?o.reportValidity():!0,checkValidity:o=>typeof o.checkValidity=="function"?o.checkValidity():!0,setValue:(o,s)=>o.value=s,assumeInteractionOn:["sl-input"]},t)}hostConnected(){const e=this.options.form(this.host);e&&this.attachForm(e),re.set(this.host,[]),this.options.assumeInteractionOn.forEach(t=>{this.host.addEventListener(t,this.handleInteraction)})}hostDisconnected(){this.detachForm(),re.delete(this.host),this.options.assumeInteractionOn.forEach(e=>{this.host.removeEventListener(e,this.handleInteraction)})}hostUpdated(){const e=this.options.form(this.host);e||this.detachForm(),e&&this.form!==e&&(this.detachForm(),this.attachForm(e)),this.host.hasUpdated&&this.setValidity(this.host.validity.valid)}attachForm(e){e?(this.form=e,Yt.has(this.form)?Yt.get(this.form).add(this.host):Yt.set(this.form,new Set([this.host])),this.form.addEventListener("formdata",this.handleFormData),this.form.addEventListener("submit",this.handleFormSubmit),this.form.addEventListener("reset",this.handleFormReset),Xt.has(this.form)||(Xt.set(this.form,this.form.reportValidity),this.form.reportValidity=()=>this.reportFormValidity()),Gt.has(this.form)||(Gt.set(this.form,this.form.checkValidity),this.form.checkValidity=()=>this.checkFormValidity())):this.form=void 0}detachForm(){if(!this.form)return;const e=Yt.get(this.form);e&&(e.delete(this.host),e.size<=0&&(this.form.removeEventListener("formdata",this.handleFormData),this.form.removeEventListener("submit",this.handleFormSubmit),this.form.removeEventListener("reset",this.handleFormReset),Xt.has(this.form)&&(this.form.reportValidity=Xt.get(this.form),Xt.delete(this.form)),Gt.has(this.form)&&(this.form.checkValidity=Gt.get(this.form),Gt.delete(this.form)),this.form=void 0))}setUserInteracted(e,t){t?Se.add(e):Se.delete(e),e.requestUpdate()}doAction(e,t){if(this.form){const o=document.createElement("button");o.type=e,o.style.position="absolute",o.style.width="0",o.style.height="0",o.style.clipPath="inset(50%)",o.style.overflow="hidden",o.style.whiteSpace="nowrap",t&&(o.name=t.name,o.value=t.value,["formaction","formenctype","formmethod","formnovalidate","formtarget"].forEach(s=>{t.hasAttribute(s)&&o.setAttribute(s,t.getAttribute(s))})),this.form.append(o),o.click(),o.remove()}}getForm(){var e;return(e=this.form)!=null?e:null}reset(e){this.doAction("reset",e)}submit(e){this.doAction("submit",e)}setValidity(e){const t=this.host,o=!!Se.has(t),s=!!t.required;t.toggleAttribute("data-required",s),t.toggleAttribute("data-optional",!s),t.toggleAttribute("data-invalid",!e),t.toggleAttribute("data-valid",e),t.toggleAttribute("data-user-invalid",!e&&o),t.toggleAttribute("data-user-valid",e&&o)}updateValidity(){const e=this.host;this.setValidity(e.validity.valid)}emitInvalidEvent(e){const t=new CustomEvent("sl-invalid",{bubbles:!1,composed:!1,cancelable:!0,detail:{}});e||t.preventDefault(),this.host.dispatchEvent(t)||e==null||e.preventDefault()}},De=Object.freeze({badInput:!1,customError:!1,patternMismatch:!1,rangeOverflow:!1,rangeUnderflow:!1,stepMismatch:!1,tooLong:!1,tooShort:!1,typeMismatch:!1,valid:!0,valueMissing:!1});Object.freeze(is(ze({},De),{valid:!1,valueMissing:!0}));Object.freeze(is(ze({},De),{valid:!1,customError:!0}));var bo=bt`
  :host {
    display: inline-block;
    position: relative;
    width: auto;
    cursor: pointer;
  }

  .button {
    display: inline-flex;
    align-items: stretch;
    justify-content: center;
    width: 100%;
    border-style: solid;
    border-width: var(--sl-input-border-width);
    font-family: var(--sl-input-font-family);
    font-weight: var(--sl-font-weight-semibold);
    text-decoration: none;
    user-select: none;
    -webkit-user-select: none;
    white-space: nowrap;
    vertical-align: middle;
    padding: 0;
    transition:
      var(--sl-transition-x-fast) background-color,
      var(--sl-transition-x-fast) color,
      var(--sl-transition-x-fast) border,
      var(--sl-transition-x-fast) box-shadow;
    cursor: inherit;
  }

  .button::-moz-focus-inner {
    border: 0;
  }

  .button:focus {
    outline: none;
  }

  .button:focus-visible {
    outline: var(--sl-focus-ring);
    outline-offset: var(--sl-focus-ring-offset);
  }

  .button--disabled {
    opacity: 0.5;
    cursor: not-allowed;
  }

  /* When disabled, prevent mouse events from bubbling up from children */
  .button--disabled * {
    pointer-events: none;
  }

  .button__prefix,
  .button__suffix {
    flex: 0 0 auto;
    display: flex;
    align-items: center;
    pointer-events: none;
  }

  .button__label {
    display: inline-block;
  }

  .button__label::slotted(sl-icon) {
    vertical-align: -2px;
  }

  /*
   * Standard buttons
   */

  /* Default */
  .button--standard.button--default {
    background-color: var(--sl-color-neutral-0);
    border-color: var(--sl-color-neutral-300);
    color: var(--sl-color-neutral-700);
  }

  .button--standard.button--default:hover:not(.button--disabled) {
    background-color: var(--sl-color-primary-50);
    border-color: var(--sl-color-primary-300);
    color: var(--sl-color-primary-700);
  }

  .button--standard.button--default:active:not(.button--disabled) {
    background-color: var(--sl-color-primary-100);
    border-color: var(--sl-color-primary-400);
    color: var(--sl-color-primary-700);
  }

  /* Primary */
  .button--standard.button--primary {
    background-color: var(--sl-color-primary-600);
    border-color: var(--sl-color-primary-600);
    color: var(--sl-color-neutral-0);
  }

  .button--standard.button--primary:hover:not(.button--disabled) {
    background-color: var(--sl-color-primary-500);
    border-color: var(--sl-color-primary-500);
    color: var(--sl-color-neutral-0);
  }

  .button--standard.button--primary:active:not(.button--disabled) {
    background-color: var(--sl-color-primary-600);
    border-color: var(--sl-color-primary-600);
    color: var(--sl-color-neutral-0);
  }

  /* Success */
  .button--standard.button--success {
    background-color: var(--sl-color-success-600);
    border-color: var(--sl-color-success-600);
    color: var(--sl-color-neutral-0);
  }

  .button--standard.button--success:hover:not(.button--disabled) {
    background-color: var(--sl-color-success-500);
    border-color: var(--sl-color-success-500);
    color: var(--sl-color-neutral-0);
  }

  .button--standard.button--success:active:not(.button--disabled) {
    background-color: var(--sl-color-success-600);
    border-color: var(--sl-color-success-600);
    color: var(--sl-color-neutral-0);
  }

  /* Neutral */
  .button--standard.button--neutral {
    background-color: var(--sl-color-neutral-600);
    border-color: var(--sl-color-neutral-600);
    color: var(--sl-color-neutral-0);
  }

  .button--standard.button--neutral:hover:not(.button--disabled) {
    background-color: var(--sl-color-neutral-500);
    border-color: var(--sl-color-neutral-500);
    color: var(--sl-color-neutral-0);
  }

  .button--standard.button--neutral:active:not(.button--disabled) {
    background-color: var(--sl-color-neutral-600);
    border-color: var(--sl-color-neutral-600);
    color: var(--sl-color-neutral-0);
  }

  /* Warning */
  .button--standard.button--warning {
    background-color: var(--sl-color-warning-600);
    border-color: var(--sl-color-warning-600);
    color: var(--sl-color-neutral-0);
  }
  .button--standard.button--warning:hover:not(.button--disabled) {
    background-color: var(--sl-color-warning-500);
    border-color: var(--sl-color-warning-500);
    color: var(--sl-color-neutral-0);
  }

  .button--standard.button--warning:active:not(.button--disabled) {
    background-color: var(--sl-color-warning-600);
    border-color: var(--sl-color-warning-600);
    color: var(--sl-color-neutral-0);
  }

  /* Danger */
  .button--standard.button--danger {
    background-color: var(--sl-color-danger-600);
    border-color: var(--sl-color-danger-600);
    color: var(--sl-color-neutral-0);
  }

  .button--standard.button--danger:hover:not(.button--disabled) {
    background-color: var(--sl-color-danger-500);
    border-color: var(--sl-color-danger-500);
    color: var(--sl-color-neutral-0);
  }

  .button--standard.button--danger:active:not(.button--disabled) {
    background-color: var(--sl-color-danger-600);
    border-color: var(--sl-color-danger-600);
    color: var(--sl-color-neutral-0);
  }

  /*
   * Outline buttons
   */

  .button--outline {
    background: none;
    border: solid 1px;
  }

  /* Default */
  .button--outline.button--default {
    border-color: var(--sl-color-neutral-300);
    color: var(--sl-color-neutral-700);
  }

  .button--outline.button--default:hover:not(.button--disabled),
  .button--outline.button--default.button--checked:not(.button--disabled) {
    border-color: var(--sl-color-primary-600);
    background-color: var(--sl-color-primary-600);
    color: var(--sl-color-neutral-0);
  }

  .button--outline.button--default:active:not(.button--disabled) {
    border-color: var(--sl-color-primary-700);
    background-color: var(--sl-color-primary-700);
    color: var(--sl-color-neutral-0);
  }

  /* Primary */
  .button--outline.button--primary {
    border-color: var(--sl-color-primary-600);
    color: var(--sl-color-primary-600);
  }

  .button--outline.button--primary:hover:not(.button--disabled),
  .button--outline.button--primary.button--checked:not(.button--disabled) {
    background-color: var(--sl-color-primary-600);
    color: var(--sl-color-neutral-0);
  }

  .button--outline.button--primary:active:not(.button--disabled) {
    border-color: var(--sl-color-primary-700);
    background-color: var(--sl-color-primary-700);
    color: var(--sl-color-neutral-0);
  }

  /* Success */
  .button--outline.button--success {
    border-color: var(--sl-color-success-600);
    color: var(--sl-color-success-600);
  }

  .button--outline.button--success:hover:not(.button--disabled),
  .button--outline.button--success.button--checked:not(.button--disabled) {
    background-color: var(--sl-color-success-600);
    color: var(--sl-color-neutral-0);
  }

  .button--outline.button--success:active:not(.button--disabled) {
    border-color: var(--sl-color-success-700);
    background-color: var(--sl-color-success-700);
    color: var(--sl-color-neutral-0);
  }

  /* Neutral */
  .button--outline.button--neutral {
    border-color: var(--sl-color-neutral-600);
    color: var(--sl-color-neutral-600);
  }

  .button--outline.button--neutral:hover:not(.button--disabled),
  .button--outline.button--neutral.button--checked:not(.button--disabled) {
    background-color: var(--sl-color-neutral-600);
    color: var(--sl-color-neutral-0);
  }

  .button--outline.button--neutral:active:not(.button--disabled) {
    border-color: var(--sl-color-neutral-700);
    background-color: var(--sl-color-neutral-700);
    color: var(--sl-color-neutral-0);
  }

  /* Warning */
  .button--outline.button--warning {
    border-color: var(--sl-color-warning-600);
    color: var(--sl-color-warning-600);
  }

  .button--outline.button--warning:hover:not(.button--disabled),
  .button--outline.button--warning.button--checked:not(.button--disabled) {
    background-color: var(--sl-color-warning-600);
    color: var(--sl-color-neutral-0);
  }

  .button--outline.button--warning:active:not(.button--disabled) {
    border-color: var(--sl-color-warning-700);
    background-color: var(--sl-color-warning-700);
    color: var(--sl-color-neutral-0);
  }

  /* Danger */
  .button--outline.button--danger {
    border-color: var(--sl-color-danger-600);
    color: var(--sl-color-danger-600);
  }

  .button--outline.button--danger:hover:not(.button--disabled),
  .button--outline.button--danger.button--checked:not(.button--disabled) {
    background-color: var(--sl-color-danger-600);
    color: var(--sl-color-neutral-0);
  }

  .button--outline.button--danger:active:not(.button--disabled) {
    border-color: var(--sl-color-danger-700);
    background-color: var(--sl-color-danger-700);
    color: var(--sl-color-neutral-0);
  }

  @media (forced-colors: active) {
    .button.button--outline.button--checked:not(.button--disabled) {
      outline: solid 2px transparent;
    }
  }

  /*
   * Text buttons
   */

  .button--text {
    background-color: transparent;
    border-color: transparent;
    color: var(--sl-color-primary-600);
  }

  .button--text:hover:not(.button--disabled) {
    background-color: transparent;
    border-color: transparent;
    color: var(--sl-color-primary-500);
  }

  .button--text:focus-visible:not(.button--disabled) {
    background-color: transparent;
    border-color: transparent;
    color: var(--sl-color-primary-500);
  }

  .button--text:active:not(.button--disabled) {
    background-color: transparent;
    border-color: transparent;
    color: var(--sl-color-primary-700);
  }

  /*
   * Size modifiers
   */

  .button--small {
    height: auto;
    min-height: var(--sl-input-height-small);
    font-size: var(--sl-button-font-size-small);
    line-height: calc(var(--sl-input-height-small) - var(--sl-input-border-width) * 2);
    border-radius: var(--sl-input-border-radius-small);
  }

  .button--medium {
    height: auto;
    min-height: var(--sl-input-height-medium);
    font-size: var(--sl-button-font-size-medium);
    line-height: calc(var(--sl-input-height-medium) - var(--sl-input-border-width) * 2);
    border-radius: var(--sl-input-border-radius-medium);
  }

  .button--large {
    height: auto;
    min-height: var(--sl-input-height-large);
    font-size: var(--sl-button-font-size-large);
    line-height: calc(var(--sl-input-height-large) - var(--sl-input-border-width) * 2);
    border-radius: var(--sl-input-border-radius-large);
  }

  /*
   * Pill modifier
   */

  .button--pill.button--small {
    border-radius: var(--sl-input-height-small);
  }

  .button--pill.button--medium {
    border-radius: var(--sl-input-height-medium);
  }

  .button--pill.button--large {
    border-radius: var(--sl-input-height-large);
  }

  /*
   * Circle modifier
   */

  .button--circle {
    padding-left: 0;
    padding-right: 0;
  }

  .button--circle.button--small {
    width: var(--sl-input-height-small);
    border-radius: 50%;
  }

  .button--circle.button--medium {
    width: var(--sl-input-height-medium);
    border-radius: 50%;
  }

  .button--circle.button--large {
    width: var(--sl-input-height-large);
    border-radius: 50%;
  }

  .button--circle .button__prefix,
  .button--circle .button__suffix,
  .button--circle .button__caret {
    display: none;
  }

  /*
   * Caret modifier
   */

  .button--caret .button__suffix {
    display: none;
  }

  .button--caret .button__caret {
    height: auto;
  }

  /*
   * Loading modifier
   */

  .button--loading {
    position: relative;
    cursor: wait;
  }

  .button--loading .button__prefix,
  .button--loading .button__label,
  .button--loading .button__suffix,
  .button--loading .button__caret {
    visibility: hidden;
  }

  .button--loading sl-spinner {
    --indicator-color: currentColor;
    position: absolute;
    font-size: 1em;
    height: 1em;
    width: 1em;
    top: calc(50% - 0.5em);
    left: calc(50% - 0.5em);
  }

  /*
   * Badges
   */

  .button ::slotted(sl-badge) {
    position: absolute;
    top: 0;
    right: 0;
    translate: 50% -50%;
    pointer-events: none;
  }

  .button--rtl ::slotted(sl-badge) {
    right: auto;
    left: 0;
    translate: -50% -50%;
  }

  /*
   * Button spacing
   */

  .button--has-label.button--small .button__label {
    padding: 0 var(--sl-spacing-small);
  }

  .button--has-label.button--medium .button__label {
    padding: 0 var(--sl-spacing-medium);
  }

  .button--has-label.button--large .button__label {
    padding: 0 var(--sl-spacing-large);
  }

  .button--has-prefix.button--small {
    padding-inline-start: var(--sl-spacing-x-small);
  }

  .button--has-prefix.button--small .button__label {
    padding-inline-start: var(--sl-spacing-x-small);
  }

  .button--has-prefix.button--medium {
    padding-inline-start: var(--sl-spacing-small);
  }

  .button--has-prefix.button--medium .button__label {
    padding-inline-start: var(--sl-spacing-small);
  }

  .button--has-prefix.button--large {
    padding-inline-start: var(--sl-spacing-small);
  }

  .button--has-prefix.button--large .button__label {
    padding-inline-start: var(--sl-spacing-small);
  }

  .button--has-suffix.button--small,
  .button--caret.button--small {
    padding-inline-end: var(--sl-spacing-x-small);
  }

  .button--has-suffix.button--small .button__label,
  .button--caret.button--small .button__label {
    padding-inline-end: var(--sl-spacing-x-small);
  }

  .button--has-suffix.button--medium,
  .button--caret.button--medium {
    padding-inline-end: var(--sl-spacing-small);
  }

  .button--has-suffix.button--medium .button__label,
  .button--caret.button--medium .button__label {
    padding-inline-end: var(--sl-spacing-small);
  }

  .button--has-suffix.button--large,
  .button--caret.button--large {
    padding-inline-end: var(--sl-spacing-small);
  }

  .button--has-suffix.button--large .button__label,
  .button--caret.button--large .button__label {
    padding-inline-end: var(--sl-spacing-small);
  }

  /*
   * Button groups support a variety of button types (e.g. buttons with tooltips, buttons as dropdown triggers, etc.).
   * This means buttons aren't always direct descendants of the button group, thus we can't target them with the
   * ::slotted selector. To work around this, the button group component does some magic to add these special classes to
   * buttons and we style them here instead.
   */

  :host(.sl-button-group__button--first:not(.sl-button-group__button--last)) .button {
    border-start-end-radius: 0;
    border-end-end-radius: 0;
  }

  :host(.sl-button-group__button--inner) .button {
    border-radius: 0;
  }

  :host(.sl-button-group__button--last:not(.sl-button-group__button--first)) .button {
    border-start-start-radius: 0;
    border-end-start-radius: 0;
  }

  /* All except the first */
  :host(.sl-button-group__button:not(.sl-button-group__button--first)) {
    margin-inline-start: calc(-1 * var(--sl-input-border-width));
  }

  /* Add a visual separator between solid buttons */
  :host(
      .sl-button-group__button:not(
          .sl-button-group__button--first,
          .sl-button-group__button--radio,
          [variant='default']
        ):not(:hover)
    )
    .button:after {
    content: '';
    position: absolute;
    top: 0;
    inset-inline-start: 0;
    bottom: 0;
    border-left: solid 1px rgb(128 128 128 / 33%);
    mix-blend-mode: multiply;
  }

  /* Bump hovered, focused, and checked buttons up so their focus ring isn't clipped */
  :host(.sl-button-group__button--hover) {
    z-index: 1;
  }

  /* Focus and checked are always on top */
  :host(.sl-button-group__button--focus),
  :host(.sl-button-group__button[checked]) {
    z-index: 2;
  }
`,O=class extends xt{constructor(){super(...arguments),this.formControlController=new _s(this,{assumeInteractionOn:["click"]}),this.hasSlotController=new te(this,"[default]","prefix","suffix"),this.localize=new qt(this),this.hasFocus=!1,this.invalid=!1,this.title="",this.variant="default",this.size="medium",this.caret=!1,this.disabled=!1,this.loading=!1,this.outline=!1,this.pill=!1,this.circle=!1,this.type="button",this.name="",this.value="",this.href="",this.rel="noreferrer noopener"}get validity(){return this.isButton()?this.button.validity:De}get validationMessage(){return this.isButton()?this.button.validationMessage:""}firstUpdated(){this.isButton()&&this.formControlController.updateValidity()}handleBlur(){this.hasFocus=!1,this.emit("sl-blur")}handleFocus(){this.hasFocus=!0,this.emit("sl-focus")}handleClick(){this.type==="submit"&&this.formControlController.submit(this),this.type==="reset"&&this.formControlController.reset(this)}handleInvalid(e){this.formControlController.setValidity(!1),this.formControlController.emitInvalidEvent(e)}isButton(){return!this.href}isLink(){return!!this.href}handleDisabledChange(){this.isButton()&&this.formControlController.setValidity(this.disabled)}click(){this.button.click()}focus(e){this.button.focus(e)}blur(){this.button.blur()}checkValidity(){return this.isButton()?this.button.checkValidity():!0}getForm(){return this.formControlController.getForm()}reportValidity(){return this.isButton()?this.button.reportValidity():!0}setCustomValidity(e){this.isButton()&&(this.button.setCustomValidity(e),this.formControlController.updateValidity())}render(){const e=this.isLink(),t=e?me`a`:me`button`;return ne`
      <${t}
        part="base"
        class=${wt({button:!0,"button--default":this.variant==="default","button--primary":this.variant==="primary","button--success":this.variant==="success","button--neutral":this.variant==="neutral","button--warning":this.variant==="warning","button--danger":this.variant==="danger","button--text":this.variant==="text","button--small":this.size==="small","button--medium":this.size==="medium","button--large":this.size==="large","button--caret":this.caret,"button--circle":this.circle,"button--disabled":this.disabled,"button--focused":this.hasFocus,"button--loading":this.loading,"button--standard":!this.outline,"button--outline":this.outline,"button--pill":this.pill,"button--rtl":this.localize.dir()==="rtl","button--has-label":this.hasSlotController.test("[default]"),"button--has-prefix":this.hasSlotController.test("prefix"),"button--has-suffix":this.hasSlotController.test("suffix")})}
        ?disabled=${I(e?void 0:this.disabled)}
        type=${I(e?void 0:this.type)}
        title=${this.title}
        name=${I(e?void 0:this.name)}
        value=${I(e?void 0:this.value)}
        href=${I(e?this.href:void 0)}
        target=${I(e?this.target:void 0)}
        download=${I(e?this.download:void 0)}
        rel=${I(e?this.rel:void 0)}
        role=${I(e?void 0:"button")}
        aria-disabled=${this.disabled?"true":"false"}
        tabindex=${this.disabled?"-1":"0"}
        @blur=${this.handleBlur}
        @focus=${this.handleFocus}
        @invalid=${this.isButton()?this.handleInvalid:null}
        @click=${this.handleClick}
      >
        <slot name="prefix" part="prefix" class="button__prefix"></slot>
        <slot part="label" class="button__label"></slot>
        <slot name="suffix" part="suffix" class="button__suffix"></slot>
        ${this.caret?ne` <sl-icon part="caret" class="button__caret" library="system" name="caret"></sl-icon> `:""}
        ${this.loading?ne`<sl-spinner part="spinner"></sl-spinner>`:""}
      </${t}>
    `}};O.styles=[Ct,bo];O.dependencies={"sl-icon":ye,"sl-spinner":Ce};d([gt(".button")],O.prototype,"button",2);d([ke()],O.prototype,"hasFocus",2);d([ke()],O.prototype,"invalid",2);d([p()],O.prototype,"title",2);d([p({reflect:!0})],O.prototype,"variant",2);d([p({reflect:!0})],O.prototype,"size",2);d([p({type:Boolean,reflect:!0})],O.prototype,"caret",2);d([p({type:Boolean,reflect:!0})],O.prototype,"disabled",2);d([p({type:Boolean,reflect:!0})],O.prototype,"loading",2);d([p({type:Boolean,reflect:!0})],O.prototype,"outline",2);d([p({type:Boolean,reflect:!0})],O.prototype,"pill",2);d([p({type:Boolean,reflect:!0})],O.prototype,"circle",2);d([p()],O.prototype,"type",2);d([p()],O.prototype,"name",2);d([p()],O.prototype,"value",2);d([p()],O.prototype,"href",2);d([p()],O.prototype,"target",2);d([p()],O.prototype,"rel",2);d([p()],O.prototype,"download",2);d([p()],O.prototype,"form",2);d([p({attribute:"formaction"})],O.prototype,"formAction",2);d([p({attribute:"formenctype"})],O.prototype,"formEnctype",2);d([p({attribute:"formmethod"})],O.prototype,"formMethod",2);d([p({attribute:"formnovalidate",type:Boolean})],O.prototype,"formNoValidate",2);d([p({attribute:"formtarget"})],O.prototype,"formTarget",2);d([vt("disabled",{waitUntilFirstUpdate:!0})],O.prototype,"handleDisabledChange",1);O.define("sl-button");var go=bt`
  .form-control .form-control__label {
    display: none;
  }

  .form-control .form-control__help-text {
    display: none;
  }

  /* Label */
  .form-control--has-label .form-control__label {
    display: inline-block;
    color: var(--sl-input-label-color);
    margin-bottom: var(--sl-spacing-3x-small);
  }

  .form-control--has-label.form-control--small .form-control__label {
    font-size: var(--sl-input-label-font-size-small);
  }

  .form-control--has-label.form-control--medium .form-control__label {
    font-size: var(--sl-input-label-font-size-medium);
  }

  .form-control--has-label.form-control--large .form-control__label {
    font-size: var(--sl-input-label-font-size-large);
  }

  :host([required]) .form-control--has-label .form-control__label::after {
    content: var(--sl-input-required-content);
    margin-inline-start: var(--sl-input-required-content-offset);
    color: var(--sl-input-required-content-color);
  }

  /* Help text */
  .form-control--has-help-text .form-control__help-text {
    display: block;
    color: var(--sl-input-help-text-color);
    margin-top: var(--sl-spacing-3x-small);
  }

  .form-control--has-help-text.form-control--small .form-control__help-text {
    font-size: var(--sl-input-help-text-font-size-small);
  }

  .form-control--has-help-text.form-control--medium .form-control__help-text {
    font-size: var(--sl-input-help-text-font-size-medium);
  }

  .form-control--has-help-text.form-control--large .form-control__help-text {
    font-size: var(--sl-input-help-text-font-size-large);
  }

  .form-control--has-help-text.form-control--radio-group .form-control__help-text {
    margin-top: var(--sl-spacing-2x-small);
  }
`,vo=bt`
  :host {
    display: block;
  }

  .input {
    flex: 1 1 auto;
    display: inline-flex;
    align-items: stretch;
    justify-content: start;
    position: relative;
    width: 100%;
    font-family: var(--sl-input-font-family);
    font-weight: var(--sl-input-font-weight);
    letter-spacing: var(--sl-input-letter-spacing);
    vertical-align: middle;
    overflow: hidden;
    cursor: text;
    transition:
      var(--sl-transition-fast) color,
      var(--sl-transition-fast) border,
      var(--sl-transition-fast) box-shadow,
      var(--sl-transition-fast) background-color;
  }

  /* Standard inputs */
  .input--standard {
    background-color: var(--sl-input-background-color);
    border: solid var(--sl-input-border-width) var(--sl-input-border-color);
  }

  .input--standard:hover:not(.input--disabled) {
    background-color: var(--sl-input-background-color-hover);
    border-color: var(--sl-input-border-color-hover);
  }

  .input--standard.input--focused:not(.input--disabled) {
    background-color: var(--sl-input-background-color-focus);
    border-color: var(--sl-input-border-color-focus);
    box-shadow: 0 0 0 var(--sl-focus-ring-width) var(--sl-input-focus-ring-color);
  }

  .input--standard.input--focused:not(.input--disabled) .input__control {
    color: var(--sl-input-color-focus);
  }

  .input--standard.input--disabled {
    background-color: var(--sl-input-background-color-disabled);
    border-color: var(--sl-input-border-color-disabled);
    opacity: 0.5;
    cursor: not-allowed;
  }

  .input--standard.input--disabled .input__control {
    color: var(--sl-input-color-disabled);
  }

  .input--standard.input--disabled .input__control::placeholder {
    color: var(--sl-input-placeholder-color-disabled);
  }

  /* Filled inputs */
  .input--filled {
    border: none;
    background-color: var(--sl-input-filled-background-color);
    color: var(--sl-input-color);
  }

  .input--filled:hover:not(.input--disabled) {
    background-color: var(--sl-input-filled-background-color-hover);
  }

  .input--filled.input--focused:not(.input--disabled) {
    background-color: var(--sl-input-filled-background-color-focus);
    outline: var(--sl-focus-ring);
    outline-offset: var(--sl-focus-ring-offset);
  }

  .input--filled.input--disabled {
    background-color: var(--sl-input-filled-background-color-disabled);
    opacity: 0.5;
    cursor: not-allowed;
  }

  .input__control {
    flex: 1 1 auto;
    font-family: inherit;
    font-size: inherit;
    font-weight: inherit;
    min-width: 0;
    height: 100%;
    color: var(--sl-input-color);
    border: none;
    background: inherit;
    box-shadow: none;
    padding: 0;
    margin: 0;
    cursor: inherit;
    -webkit-appearance: none;
  }

  .input__control::-webkit-search-decoration,
  .input__control::-webkit-search-cancel-button,
  .input__control::-webkit-search-results-button,
  .input__control::-webkit-search-results-decoration {
    -webkit-appearance: none;
  }

  .input__control:-webkit-autofill,
  .input__control:-webkit-autofill:hover,
  .input__control:-webkit-autofill:focus,
  .input__control:-webkit-autofill:active {
    box-shadow: 0 0 0 var(--sl-input-height-large) var(--sl-input-background-color-hover) inset !important;
    -webkit-text-fill-color: var(--sl-color-primary-500);
    caret-color: var(--sl-input-color);
  }

  .input--filled .input__control:-webkit-autofill,
  .input--filled .input__control:-webkit-autofill:hover,
  .input--filled .input__control:-webkit-autofill:focus,
  .input--filled .input__control:-webkit-autofill:active {
    box-shadow: 0 0 0 var(--sl-input-height-large) var(--sl-input-filled-background-color) inset !important;
  }

  .input__control::placeholder {
    color: var(--sl-input-placeholder-color);
    user-select: none;
    -webkit-user-select: none;
  }

  .input:hover:not(.input--disabled) .input__control {
    color: var(--sl-input-color-hover);
  }

  .input__control:focus {
    outline: none;
  }

  .input__prefix,
  .input__suffix {
    display: inline-flex;
    flex: 0 0 auto;
    align-items: center;
    cursor: default;
  }

  .input__prefix ::slotted(sl-icon),
  .input__suffix ::slotted(sl-icon) {
    color: var(--sl-input-icon-color);
  }

  /*
   * Size modifiers
   */

  .input--small {
    border-radius: var(--sl-input-border-radius-small);
    font-size: var(--sl-input-font-size-small);
    height: var(--sl-input-height-small);
  }

  .input--small .input__control {
    height: calc(var(--sl-input-height-small) - var(--sl-input-border-width) * 2);
    padding: 0 var(--sl-input-spacing-small);
  }

  .input--small .input__clear,
  .input--small .input__password-toggle {
    width: calc(1em + var(--sl-input-spacing-small) * 2);
  }

  .input--small .input__prefix ::slotted(*) {
    margin-inline-start: var(--sl-input-spacing-small);
  }

  .input--small .input__suffix ::slotted(*) {
    margin-inline-end: var(--sl-input-spacing-small);
  }

  .input--medium {
    border-radius: var(--sl-input-border-radius-medium);
    font-size: var(--sl-input-font-size-medium);
    height: var(--sl-input-height-medium);
  }

  .input--medium .input__control {
    height: calc(var(--sl-input-height-medium) - var(--sl-input-border-width) * 2);
    padding: 0 var(--sl-input-spacing-medium);
  }

  .input--medium .input__clear,
  .input--medium .input__password-toggle {
    width: calc(1em + var(--sl-input-spacing-medium) * 2);
  }

  .input--medium .input__prefix ::slotted(*) {
    margin-inline-start: var(--sl-input-spacing-medium);
  }

  .input--medium .input__suffix ::slotted(*) {
    margin-inline-end: var(--sl-input-spacing-medium);
  }

  .input--large {
    border-radius: var(--sl-input-border-radius-large);
    font-size: var(--sl-input-font-size-large);
    height: var(--sl-input-height-large);
  }

  .input--large .input__control {
    height: calc(var(--sl-input-height-large) - var(--sl-input-border-width) * 2);
    padding: 0 var(--sl-input-spacing-large);
  }

  .input--large .input__clear,
  .input--large .input__password-toggle {
    width: calc(1em + var(--sl-input-spacing-large) * 2);
  }

  .input--large .input__prefix ::slotted(*) {
    margin-inline-start: var(--sl-input-spacing-large);
  }

  .input--large .input__suffix ::slotted(*) {
    margin-inline-end: var(--sl-input-spacing-large);
  }

  /*
   * Pill modifier
   */

  .input--pill.input--small {
    border-radius: var(--sl-input-height-small);
  }

  .input--pill.input--medium {
    border-radius: var(--sl-input-height-medium);
  }

  .input--pill.input--large {
    border-radius: var(--sl-input-height-large);
  }

  /*
   * Clearable + Password Toggle
   */

  .input__clear:not(.input__clear--visible) {
    visibility: hidden;
  }

  .input__clear,
  .input__password-toggle {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    font-size: inherit;
    color: var(--sl-input-icon-color);
    border: none;
    background: none;
    padding: 0;
    transition: var(--sl-transition-fast) color;
    cursor: pointer;
  }

  .input__clear:hover,
  .input__password-toggle:hover {
    color: var(--sl-input-icon-color-hover);
  }

  .input__clear:focus,
  .input__password-toggle:focus {
    outline: none;
  }

  .input--empty .input__clear {
    visibility: hidden;
  }

  /* Don't show the browser's password toggle in Edge */
  ::-ms-reveal {
    display: none;
  }

  /* Hide the built-in number spinner */
  .input--no-spin-buttons input[type='number']::-webkit-outer-spin-button,
  .input--no-spin-buttons input[type='number']::-webkit-inner-spin-button {
    -webkit-appearance: none;
    display: none;
  }

  .input--no-spin-buttons input[type='number'] {
    -moz-appearance: textfield;
  }
`,_o=(e="value")=>(t,o)=>{const s=t.constructor,r=s.prototype.attributeChangedCallback;s.prototype.attributeChangedCallback=function(i,l,u){var n;const a=s.getPropertyOptions(e),c=typeof a.attribute=="string"?a.attribute:e;if(i===c){const h=a.converter||Oe,v=(typeof h=="function"?h:(n=h==null?void 0:h.fromAttribute)!=null?n:Oe.fromAttribute)(u,a.type);this[e]!==v&&(this[o]=v)}r.call(this,i,l,u)}};/**
 * @license
 * Copyright 2020 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const yo=ls(class extends ns{constructor(e){if(super(e),e.type!==zt.PROPERTY&&e.type!==zt.ATTRIBUTE&&e.type!==zt.BOOLEAN_ATTRIBUTE)throw Error("The `live` directive is not allowed on child or event bindings");if(!as(e))throw Error("`live` bindings can only contain a single expression")}render(e){return e}update(e,[t]){if(t===oe||t===ue)return t;const o=e.element,s=e.name;if(e.type===zt.PROPERTY){if(t===o[s])return oe}else if(e.type===zt.BOOLEAN_ATTRIBUTE){if(!!t===o.hasAttribute(s))return oe}else if(e.type===zt.ATTRIBUTE&&o.getAttribute(s)===t+"")return oe;return Vs(e),t}});var E=class extends xt{constructor(){super(...arguments),this.formControlController=new _s(this,{assumeInteractionOn:["sl-blur","sl-input"]}),this.hasSlotController=new te(this,"help-text","label"),this.localize=new qt(this),this.hasFocus=!1,this.title="",this.__numberInput=Object.assign(document.createElement("input"),{type:"number"}),this.__dateInput=Object.assign(document.createElement("input"),{type:"date"}),this.type="text",this.name="",this.value="",this.defaultValue="",this.size="medium",this.filled=!1,this.pill=!1,this.label="",this.helpText="",this.clearable=!1,this.disabled=!1,this.placeholder="",this.readonly=!1,this.passwordToggle=!1,this.passwordVisible=!1,this.noSpinButtons=!1,this.form="",this.required=!1,this.spellcheck=!0}get valueAsDate(){var e;return this.__dateInput.type=this.type,this.__dateInput.value=this.value,((e=this.input)==null?void 0:e.valueAsDate)||this.__dateInput.valueAsDate}set valueAsDate(e){this.__dateInput.type=this.type,this.__dateInput.valueAsDate=e,this.value=this.__dateInput.value}get valueAsNumber(){var e;return this.__numberInput.value=this.value,((e=this.input)==null?void 0:e.valueAsNumber)||this.__numberInput.valueAsNumber}set valueAsNumber(e){this.__numberInput.valueAsNumber=e,this.value=this.__numberInput.value}get validity(){return this.input.validity}get validationMessage(){return this.input.validationMessage}firstUpdated(){this.formControlController.updateValidity()}handleBlur(){this.hasFocus=!1,this.emit("sl-blur")}handleChange(){this.value=this.input.value,this.emit("sl-change")}handleClearClick(e){this.value="",this.emit("sl-clear"),this.emit("sl-input"),this.emit("sl-change"),this.input.focus(),e.stopPropagation()}handleFocus(){this.hasFocus=!0,this.emit("sl-focus")}handleInput(){this.value=this.input.value,this.formControlController.updateValidity(),this.emit("sl-input")}handleInvalid(e){this.formControlController.setValidity(!1),this.formControlController.emitInvalidEvent(e)}handleKeyDown(e){const t=e.metaKey||e.ctrlKey||e.shiftKey||e.altKey;e.key==="Enter"&&!t&&setTimeout(()=>{!e.defaultPrevented&&!e.isComposing&&this.formControlController.submit()})}handlePasswordToggle(){this.passwordVisible=!this.passwordVisible}handleDisabledChange(){this.formControlController.setValidity(this.disabled)}handleStepChange(){this.input.step=String(this.step),this.formControlController.updateValidity()}async handleValueChange(){await this.updateComplete,this.formControlController.updateValidity()}focus(e){this.input.focus(e)}blur(){this.input.blur()}select(){this.input.select()}setSelectionRange(e,t,o="none"){this.input.setSelectionRange(e,t,o)}setRangeText(e,t,o,s="preserve"){const r=t??this.input.selectionStart,i=o??this.input.selectionEnd;this.input.setRangeText(e,r,i,s),this.value!==this.input.value&&(this.value=this.input.value)}showPicker(){"showPicker"in HTMLInputElement.prototype&&this.input.showPicker()}stepUp(){this.input.stepUp(),this.value!==this.input.value&&(this.value=this.input.value)}stepDown(){this.input.stepDown(),this.value!==this.input.value&&(this.value=this.input.value)}checkValidity(){return this.input.checkValidity()}getForm(){return this.formControlController.getForm()}reportValidity(){return this.input.reportValidity()}setCustomValidity(e){this.input.setCustomValidity(e),this.formControlController.updateValidity()}render(){const e=this.hasSlotController.test("label"),t=this.hasSlotController.test("help-text"),o=this.label?!0:!!e,s=this.helpText?!0:!!t,r=this.clearable&&!this.disabled&&!this.readonly,i=r&&(typeof this.value=="number"||this.value.length>0);return J`
      <div
        part="form-control"
        class=${wt({"form-control":!0,"form-control--small":this.size==="small","form-control--medium":this.size==="medium","form-control--large":this.size==="large","form-control--has-label":o,"form-control--has-help-text":s})}
      >
        <label
          part="form-control-label"
          class="form-control__label"
          for="input"
          aria-hidden=${o?"false":"true"}
        >
          <slot name="label">${this.label}</slot>
        </label>

        <div part="form-control-input" class="form-control-input">
          <div
            part="base"
            class=${wt({input:!0,"input--small":this.size==="small","input--medium":this.size==="medium","input--large":this.size==="large","input--pill":this.pill,"input--standard":!this.filled,"input--filled":this.filled,"input--disabled":this.disabled,"input--focused":this.hasFocus,"input--empty":!this.value,"input--no-spin-buttons":this.noSpinButtons})}
          >
            <span part="prefix" class="input__prefix">
              <slot name="prefix"></slot>
            </span>

            <input
              part="input"
              id="input"
              class="input__control"
              type=${this.type==="password"&&this.passwordVisible?"text":this.type}
              title=${this.title}
              name=${I(this.name)}
              ?disabled=${this.disabled}
              ?readonly=${this.readonly}
              ?required=${this.required}
              placeholder=${I(this.placeholder)}
              minlength=${I(this.minlength)}
              maxlength=${I(this.maxlength)}
              min=${I(this.min)}
              max=${I(this.max)}
              step=${I(this.step)}
              .value=${yo(this.value)}
              autocapitalize=${I(this.autocapitalize)}
              autocomplete=${I(this.autocomplete)}
              autocorrect=${I(this.autocorrect)}
              ?autofocus=${this.autofocus}
              spellcheck=${this.spellcheck}
              pattern=${I(this.pattern)}
              enterkeyhint=${I(this.enterkeyhint)}
              inputmode=${I(this.inputmode)}
              aria-describedby="help-text"
              @change=${this.handleChange}
              @input=${this.handleInput}
              @invalid=${this.handleInvalid}
              @keydown=${this.handleKeyDown}
              @focus=${this.handleFocus}
              @blur=${this.handleBlur}
            />

            ${r?J`
                  <button
                    part="clear-button"
                    class=${wt({input__clear:!0,"input__clear--visible":i})}
                    type="button"
                    aria-label=${this.localize.term("clearEntry")}
                    @click=${this.handleClearClick}
                    tabindex="-1"
                  >
                    <slot name="clear-icon">
                      <sl-icon name="x-circle-fill" library="system"></sl-icon>
                    </slot>
                  </button>
                `:""}
            ${this.passwordToggle&&!this.disabled?J`
                  <button
                    part="password-toggle-button"
                    class="input__password-toggle"
                    type="button"
                    aria-label=${this.localize.term(this.passwordVisible?"hidePassword":"showPassword")}
                    @click=${this.handlePasswordToggle}
                    tabindex="-1"
                  >
                    ${this.passwordVisible?J`
                          <slot name="show-password-icon">
                            <sl-icon name="eye-slash" library="system"></sl-icon>
                          </slot>
                        `:J`
                          <slot name="hide-password-icon">
                            <sl-icon name="eye" library="system"></sl-icon>
                          </slot>
                        `}
                  </button>
                `:""}

            <span part="suffix" class="input__suffix">
              <slot name="suffix"></slot>
            </span>
          </div>
        </div>

        <div
          part="form-control-help-text"
          id="help-text"
          class="form-control__help-text"
          aria-hidden=${s?"false":"true"}
        >
          <slot name="help-text">${this.helpText}</slot>
        </div>
      </div>
    `}};E.styles=[Ct,go,vo];E.dependencies={"sl-icon":ye};d([gt(".input__control")],E.prototype,"input",2);d([ke()],E.prototype,"hasFocus",2);d([p()],E.prototype,"title",2);d([p({reflect:!0})],E.prototype,"type",2);d([p()],E.prototype,"name",2);d([p()],E.prototype,"value",2);d([_o()],E.prototype,"defaultValue",2);d([p({reflect:!0})],E.prototype,"size",2);d([p({type:Boolean,reflect:!0})],E.prototype,"filled",2);d([p({type:Boolean,reflect:!0})],E.prototype,"pill",2);d([p()],E.prototype,"label",2);d([p({attribute:"help-text"})],E.prototype,"helpText",2);d([p({type:Boolean})],E.prototype,"clearable",2);d([p({type:Boolean,reflect:!0})],E.prototype,"disabled",2);d([p()],E.prototype,"placeholder",2);d([p({type:Boolean,reflect:!0})],E.prototype,"readonly",2);d([p({attribute:"password-toggle",type:Boolean})],E.prototype,"passwordToggle",2);d([p({attribute:"password-visible",type:Boolean})],E.prototype,"passwordVisible",2);d([p({attribute:"no-spin-buttons",type:Boolean})],E.prototype,"noSpinButtons",2);d([p({reflect:!0})],E.prototype,"form",2);d([p({type:Boolean,reflect:!0})],E.prototype,"required",2);d([p()],E.prototype,"pattern",2);d([p({type:Number})],E.prototype,"minlength",2);d([p({type:Number})],E.prototype,"maxlength",2);d([p()],E.prototype,"min",2);d([p()],E.prototype,"max",2);d([p()],E.prototype,"step",2);d([p()],E.prototype,"autocapitalize",2);d([p()],E.prototype,"autocorrect",2);d([p()],E.prototype,"autocomplete",2);d([p({type:Boolean})],E.prototype,"autofocus",2);d([p()],E.prototype,"enterkeyhint",2);d([p({type:Boolean,converter:{fromAttribute:e=>!(!e||e==="false"),toAttribute:e=>e?"true":"false"}})],E.prototype,"spellcheck",2);d([p()],E.prototype,"inputmode",2);d([vt("disabled",{waitUntilFirstUpdate:!0})],E.prototype,"handleDisabledChange",1);d([vt("step",{waitUntilFirstUpdate:!0})],E.prototype,"handleStepChange",1);d([vt("value",{waitUntilFirstUpdate:!0})],E.prototype,"handleValueChange",1);E.define("sl-input");function ko(e){let s=e.width,r=e.height;s>r?s>300&&(r=r*(300/s),s=300):r>300&&(s=s*(300/r),r=300);const i=document.createElement("canvas");return i.width=s,i.height=r,i.getContext("2d").drawImage(e,0,0,s,r),i.toDataURL()}var kt=function(e,t,o,s){var r=arguments.length,i=r<3?t:s===null?s=Object.getOwnPropertyDescriptor(t,o):s,l;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")i=Reflect.decorate(e,t,o,s);else for(var u=e.length-1;u>=0;u--)(l=e[u])&&(i=(r<3?l(i):r>3?l(t,o,i):l(t,o))||i);return r>3&&i&&Object.defineProperty(t,o,i),i};let ft=class extends Ms{constructor(){super(...arguments),this.name="avatar",this.required=!1,this.shape="circle",this.disabled=!1,this.label=Y("Avatar"),this._controller=new bs(this)}reportValidity(){const t=this.required!==!1&&!this.value;return t&&(this._errorInput.setCustomValidity("Avatar is required"),this._errorInput.reportValidity()),!t}reset(){this.value=this.defaultValue}onAvatarUploaded(){if(this._avatarFilePicker.files&&this._avatarFilePicker.files[0]){const t=new FileReader;t.onload=o=>{var r;const s=new Image;s.crossOrigin="anonymous",s.onload=()=>{this.value=ko(s),this._avatarFilePicker.value=""},s.src=(r=o.target)==null?void 0:r.result,this.dispatchEvent(new CustomEvent("avatar-selected",{composed:!0,bubbles:!0,detail:{avatar:s.src}}))},t.readAsDataURL(this._avatarFilePicker.files[0])}}renderAvatar(){return this.value?Kt`
        <div
          class="column"
          style="align-items: center; height: 50px"
          @click=${()=>{this.value=void 0}}
        >
          <sl-tooltip .content=${Y("Clear")}>
            <sl-avatar
              image="${this.value}"
              alt="Avatar"
              .shape=${this.shape}
              initials=""
            ></sl-avatar
          ></sl-tooltip>
        </div>
      `:Kt` <div class="column" style="align-items: center;">
        <sl-button
          .disabled=${this.disabled}
          variant="default"
          size="large"
          circle
          @click=${()=>this._avatarFilePicker.click()}
        >
          <sl-icon
            src="${rs(Os)}"
            .label=${Y("Add avatar image")}
          ></sl-icon>
        </sl-button>
      </div>`}render(){return Kt`<input
        type="file"
        id="avatar-file-picker"
        style="display: none"
        @change=${this.onAvatarUploaded}
      />
      <div class="column" style="position: relative; align-items: center">
        <input
          id="error-input"
          style="position: absolute; z-index: -1; left: 50%; top: 30px; height: 0; width: 0"
        />
        ${this.label!==""?Kt`
              <span
                style="font-size: var(--sl-input-label-font-size-medium); margin-bottom: 4px"
                >${this.label}${this.required!==!1?" *":""}</span
              >
            `:Kt``}
        ${this.renderAvatar()}
      </div>`}};ft.styles=Lt;kt([Vt({attribute:"name"})],ft.prototype,"name",void 0);kt([Vt()],ft.prototype,"required",void 0);kt([Vt()],ft.prototype,"shape",void 0);kt([Vt()],ft.prototype,"value",void 0);kt([Vt()],ft.prototype,"disabled",void 0);kt([Vt()],ft.prototype,"defaultValue",void 0);kt([Vt()],ft.prototype,"label",void 0);kt([us("#avatar-file-picker")],ft.prototype,"_avatarFilePicker",void 0);kt([us("#error-input")],ft.prototype,"_errorInput",void 0);ft=kt([Fs("select-avatar")],ft);let Tt=class extends $t{constructor(){super(...arguments),this.allowCancel=!1}avatarMode(){return this.store.config.avatarMode==="avatar-required"||this.store.config.avatarMode==="avatar-optional"}fireSaveProfile(t){const o=t.nickname;delete t.nickname;const s={fields:t,nickname:o};this.dispatchEvent(new CustomEvent("save-profile",{detail:{profile:s},bubbles:!0,composed:!0}))}fireCancel(){this.dispatchEvent(new CustomEvent("cancel-edit-profile",{bubbles:!0,composed:!0}))}renderField(t){var o;return H`
      <sl-input
        name="${t.name}"
        .required=${t.required}
        .label=${t.label}
        .value=${((o=this.profile)===null||o===void 0?void 0:o.entry.fields[t.name])||""}
        style="margin-bottom: 16px;"
      ></sl-input>
    `}render(){var t,o,s;return H`
      <form
        id="profile-form"
        class="column"
        ${ro(r=>this.fireSaveProfile(r))}
      >
        <div
          class="row"
          style="justify-content: center; align-self: start; margin-bottom: 16px"
        >
          ${this.avatarMode()?H` <select-avatar
                name="avatar"
                .value=${((t=this.profile)===null||t===void 0?void 0:t.entry.fields.avatar)||void 0}
                .required=${this.store.config.avatarMode==="avatar-required"}
              ></select-avatar>`:H``}

          <sl-input
            name="nickname"
            .label=${Y("Nickname")}
            required
            minLength="${this.store.config.minNicknameLength}"
            .value=${((o=this.profile)===null||o===void 0?void 0:o.entry.nickname)||""}
            .helpText=${Y(Bs`Min. ${this.store.config.minNicknameLength} characters`)}
            style="margin-left: 16px;"
          ></sl-input>
        </div>

        ${this.store.config.additionalFields.map(r=>this.renderField(r))}

        <div class="row" style="margin-top: 8px;">
          ${this.allowCancel?H`
                <sl-button
                  style="flex: 1; margin-right: 6px;"
                  @click=${()=>this.fireCancel()}
                >
                  ${Y("Cancel")}
                </sl-button>
              `:H``}

          <sl-button style="flex: 1;" variant="primary" type="submit"
            >${(s=this.saveProfileLabel)!==null&&s!==void 0?s:Y("Save Profile")}
          </sl-button>
        </div>
      </form>
    `}};Tt.styles=[Lt];z([K({type:Object})],Tt.prototype,"profile",void 0);z([K({type:String,attribute:"save-profile-label"})],Tt.prototype,"saveProfileLabel",void 0);z([jt({context:Dt,subscribe:!0}),K()],Tt.prototype,"store",void 0);z([K({type:Boolean,attribute:"allow-cancel"})],Tt.prototype,"allowCancel",void 0);Tt=z([Wt(),Pt("edit-profile")],Tt);let be=class extends $t{async createProfile(t){try{await this.store.client.createProfile(t),this.dispatchEvent(new CustomEvent("profile-created",{detail:{profile:t},bubbles:!0,composed:!0}))}catch(o){console.error(o),no(Y("Error creating the profile"))}}render(){return H`
      <sl-card>
        <div class="column">
          <span
            class="title"
            style="margin-bottom: 16px; align-self: flex-start"
            >${Y("Create Profile")}</span
          >
          <edit-profile
            .saveProfileLabel=${Y("Create Profile")}
            .store=${this.store}
            @save-profile=${t=>this.createProfile(t.detail.profile)}
          ></edit-profile></div
      ></sl-card>
    `}};be.styles=Lt;z([jt({context:Dt,subscribe:!0}),K()],be.prototype,"store",void 0);be=z([Wt(),Pt("create-profile")],be);async function wo(e){return new Promise((t,o)=>{const s=e.subscribe(r=>{r.status==="complete"&&setTimeout(()=>{s(),t(r.value)}),r.status==="error"&&setTimeout(()=>{s(),o(r.error)})})})}Ce.define("sl-spinner");let Le=class extends $t{constructor(){super(...arguments),this._myProfile=new Te(this,()=>this.store.myProfile,()=>[this.store])}async updateProfile(t){await this.store.client.updateProfile(t),this.dispatchEvent(new CustomEvent("profile-updated",{detail:{profile:t},bubbles:!0,composed:!0}))}render(){switch(this._myProfile.value.status){case"pending":return H`<div
          class="column"
          style="align-items: center; justify-content: center; flex: 1;"
        >
          <sl-spinner></sl-spinner>
        </div>`;case"complete":return H` <edit-profile
          .allowCancel=${!0}
          style="margin-top: 16px; flex: 1"
          .profile=${this._myProfile.value.value}
          .saveProfileLabel=${Y("Update Profile")}
          @save-profile=${t=>this.updateProfile(t.detail.profile)}
        ></edit-profile>`;case"error":return H`<display-error
          .headline=${Y("Error fetching your profile")}
          .error=${this._myProfile.value.error}
        ></display-error>`}}static get styles(){return[Lt,Qt`
        :host {
          display: flex;
        }
      `]}};z([jt({context:Dt,subscribe:!0}),K()],Le.prototype,"store",void 0);Le=z([Wt(),Pt("update-profile")],Le);let Jt=class extends $t{constructor(){super(...arguments),this._agentProfile=new Te(this,()=>this.store.profiles.get(this.agentPubKey),()=>[this.agentPubKey,this.store])}getAdditionalFields(t){const o={};for(const[s,r]of Object.entries(t.fields))s!=="avatar"&&(o[s]=r);return o}renderAdditionalField(t,o){return H`
      <div class="column" style="margin-top: 16px">
        <span style="margin-bottom: 8px; ">
          <strong
            >${t.substring(0,1).toUpperCase()}${t.substring(1)}</strong
          ></span
        >
        <span>${o}</span>
      </div>
    `}renderProfile(t){return t?H`
      <div class="column">
        <div class="row" style="align-items: center">
          <agent-avatar .agentPubKey=${this.agentPubKey}></agent-avatar>
          <span style="font-size: 16px; margin-left: 8px;"
            >${t.entry.nickname}</span
          >

          <span style="flex: 1"></span>

          <slot name="action"></slot>
        </div>

        ${Object.entries(this.getAdditionalFields(t.entry)).filter(([,o])=>o!=="").map(([o,s])=>this.renderAdditionalField(o,s))}
      </div>
    `:H`<div
        class="column"
        style="align-items: center; justify-content: center; flex: 1;"
      >
        <span class="placeholder"
          >${Y("This agent hasn't created a profile yet")}</span
        >
      </div>`}render(){switch(this._agentProfile.value.status){case"pending":return H`
          <div class="column">
            <div class="row" style="align-items: center">
              <sl-skeleton
                effect="pulse"
                style="height: 32px; width: 32px; border-radius: 50%;"
              ></sl-skeleton>
              <div>
                <sl-skeleton
                  effect="pulse"
                  style="width: 122px; margin-left: 8px;"
                ></sl-skeleton>
              </div>
            </div>

            ${this.store.config.additionalFields.map(()=>H`
                <sl-skeleton
                  effect="pulse"
                  style="width: 200px; margin-top: 16px;"
                ></sl-skeleton>
              `)}
          </div>
        `;case"complete":return this.renderProfile(this._agentProfile.value.value);case"error":return H`<display-error
          .headline=${Y("Error fetching the profile")}
          .error=${this._agentProfile.value.error}
        ></display-error>`}}};Jt.styles=[Lt];z([K(cs("agent-pub-key"))],Jt.prototype,"agentPubKey",void 0);z([jt({context:Dt,subscribe:!0}),K()],Jt.prototype,"store",void 0);Jt=z([Wt(),Pt("profile-detail")],Jt);var Co=bt`
  :host {
    display: block;
    position: relative;
    background: var(--sl-panel-background-color);
    border: solid var(--sl-panel-border-width) var(--sl-panel-border-color);
    border-radius: var(--sl-border-radius-medium);
    padding: var(--sl-spacing-x-small) 0;
    overflow: auto;
    overscroll-behavior: none;
  }

  ::slotted(sl-divider) {
    --spacing: var(--sl-spacing-x-small);
  }
`,Ve=class extends xt{connectedCallback(){super.connectedCallback(),this.setAttribute("role","menu")}handleClick(e){const t=["menuitem","menuitemcheckbox"],o=e.composedPath().find(r=>{var i;return t.includes(((i=r==null?void 0:r.getAttribute)==null?void 0:i.call(r,"role"))||"")});if(!o)return;const s=o;s.type==="checkbox"&&(s.checked=!s.checked),this.emit("sl-select",{detail:{item:s}})}handleKeyDown(e){if(e.key==="Enter"||e.key===" "){const t=this.getCurrentItem();e.preventDefault(),e.stopPropagation(),t==null||t.click()}else if(["ArrowDown","ArrowUp","Home","End"].includes(e.key)){const t=this.getAllItems(),o=this.getCurrentItem();let s=o?t.indexOf(o):0;t.length>0&&(e.preventDefault(),e.stopPropagation(),e.key==="ArrowDown"?s++:e.key==="ArrowUp"?s--:e.key==="Home"?s=0:e.key==="End"&&(s=t.length-1),s<0&&(s=t.length-1),s>t.length-1&&(s=0),this.setCurrentItem(t[s]),t[s].focus())}}handleMouseDown(e){const t=e.target;this.isMenuItem(t)&&this.setCurrentItem(t)}handleSlotChange(){const e=this.getAllItems();e.length>0&&this.setCurrentItem(e[0])}isMenuItem(e){var t;return e.tagName.toLowerCase()==="sl-menu-item"||["menuitem","menuitemcheckbox","menuitemradio"].includes((t=e.getAttribute("role"))!=null?t:"")}getAllItems(){return[...this.defaultSlot.assignedElements({flatten:!0})].filter(e=>!(e.inert||!this.isMenuItem(e)))}getCurrentItem(){return this.getAllItems().find(e=>e.getAttribute("tabindex")==="0")}setCurrentItem(e){this.getAllItems().forEach(o=>{o.setAttribute("tabindex",o===e?"0":"-1")})}render(){return J`
      <slot
        @slotchange=${this.handleSlotChange}
        @click=${this.handleClick}
        @keydown=${this.handleKeyDown}
        @mousedown=${this.handleMouseDown}
      ></slot>
    `}};Ve.styles=[Ct,Co];d([gt("slot")],Ve.prototype,"defaultSlot",2);Ve.define("sl-menu");var xo=bt`
  :host {
    --submenu-offset: -2px;

    display: block;
  }

  :host([inert]) {
    display: none;
  }

  .menu-item {
    position: relative;
    display: flex;
    align-items: stretch;
    font-family: var(--sl-font-sans);
    font-size: var(--sl-font-size-medium);
    font-weight: var(--sl-font-weight-normal);
    line-height: var(--sl-line-height-normal);
    letter-spacing: var(--sl-letter-spacing-normal);
    color: var(--sl-color-neutral-700);
    padding: var(--sl-spacing-2x-small) var(--sl-spacing-2x-small);
    transition: var(--sl-transition-fast) fill;
    user-select: none;
    -webkit-user-select: none;
    white-space: nowrap;
    cursor: pointer;
  }

  .menu-item.menu-item--disabled {
    outline: none;
    opacity: 0.5;
    cursor: not-allowed;
  }

  .menu-item.menu-item--loading {
    outline: none;
    cursor: wait;
  }

  .menu-item.menu-item--loading *:not(sl-spinner) {
    opacity: 0.5;
  }

  .menu-item--loading sl-spinner {
    --indicator-color: currentColor;
    --track-width: 1px;
    position: absolute;
    font-size: 0.75em;
    top: calc(50% - 0.5em);
    left: 0.65rem;
    opacity: 1;
  }

  .menu-item .menu-item__label {
    flex: 1 1 auto;
    display: inline-block;
    text-overflow: ellipsis;
    overflow: hidden;
  }

  .menu-item .menu-item__prefix {
    flex: 0 0 auto;
    display: flex;
    align-items: center;
  }

  .menu-item .menu-item__prefix::slotted(*) {
    margin-inline-end: var(--sl-spacing-x-small);
  }

  .menu-item .menu-item__suffix {
    flex: 0 0 auto;
    display: flex;
    align-items: center;
  }

  .menu-item .menu-item__suffix::slotted(*) {
    margin-inline-start: var(--sl-spacing-x-small);
  }

  /* Safe triangle */
  .menu-item--submenu-expanded::after {
    content: '';
    position: fixed;
    z-index: calc(var(--sl-z-index-dropdown) - 1);
    top: 0;
    right: 0;
    bottom: 0;
    left: 0;
    clip-path: polygon(
      var(--safe-triangle-cursor-x, 0) var(--safe-triangle-cursor-y, 0),
      var(--safe-triangle-submenu-start-x, 0) var(--safe-triangle-submenu-start-y, 0),
      var(--safe-triangle-submenu-end-x, 0) var(--safe-triangle-submenu-end-y, 0)
    );
  }

  :host(:focus-visible) {
    outline: none;
  }

  :host(:hover:not([aria-disabled='true'], :focus-visible)) .menu-item,
  .menu-item--submenu-expanded {
    background-color: var(--sl-color-neutral-100);
    color: var(--sl-color-neutral-1000);
  }

  :host(:focus-visible) .menu-item {
    outline: none;
    background-color: var(--sl-color-primary-600);
    color: var(--sl-color-neutral-0);
    opacity: 1;
  }

  .menu-item .menu-item__check,
  .menu-item .menu-item__chevron {
    flex: 0 0 auto;
    display: flex;
    align-items: center;
    justify-content: center;
    width: 1.5em;
    visibility: hidden;
  }

  .menu-item--checked .menu-item__check,
  .menu-item--has-submenu .menu-item__chevron {
    visibility: visible;
  }

  /* Add elevation and z-index to submenus */
  sl-popup::part(popup) {
    box-shadow: var(--sl-shadow-large);
    z-index: var(--sl-z-index-dropdown);
    margin-left: var(--submenu-offset);
  }

  .menu-item--rtl sl-popup::part(popup) {
    margin-left: calc(-1 * var(--submenu-offset));
  }

  @media (forced-colors: active) {
    :host(:hover:not([aria-disabled='true'])) .menu-item,
    :host(:focus-visible) .menu-item {
      outline: dashed 1px SelectedItem;
      outline-offset: -1px;
    }
  }
`;/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const Zt=(e,t)=>{var s;const o=e._$AN;if(o===void 0)return!1;for(const r of o)(s=r._$AO)==null||s.call(r,t,!1),Zt(r,t);return!0},ge=e=>{let t,o;do{if((t=e._$AM)===void 0)break;o=t._$AN,o.delete(e),e=t}while((o==null?void 0:o.size)===0)},ys=e=>{for(let t;t=e._$AM;e=t){let o=t._$AN;if(o===void 0)t._$AN=o=new Set;else if(o.has(e))break;o.add(e),Ao(t)}};function Eo(e){this._$AN!==void 0?(ge(this),this._$AM=e,ys(this)):this._$AM=e}function So(e,t=!1,o=0){const s=this._$AH,r=this._$AN;if(r!==void 0&&r.size!==0)if(t)if(Array.isArray(s))for(let i=o;i<s.length;i++)Zt(s[i],!1),ge(s[i]);else s!=null&&(Zt(s,!1),ge(s));else Zt(this,e)}const Ao=e=>{e.type==zt.CHILD&&(e._$AP??(e._$AP=So),e._$AQ??(e._$AQ=Eo))};class $o extends ns{constructor(){super(...arguments),this._$AN=void 0}_$AT(t,o,s){super._$AT(t,o,s),ys(this),this.isConnected=t._$AU}_$AO(t,o=!0){var s,r;t!==this.isConnected&&(this.isConnected=t,t?(s=this.reconnected)==null||s.call(this):(r=this.disconnected)==null||r.call(this)),o&&(Zt(this,t),ge(this))}setValue(t){if(as(this._$Ct))this._$Ct._$AI(t,this);else{const o=[...this._$Ct._$AH];o[this._$Ci]=t,this._$Ct._$AI(o,this,0)}}disconnected(){}reconnected(){}}/**
 * @license
 * Copyright 2020 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const Po=()=>new Lo;class Lo{}const Ae=new WeakMap,zo=ls(class extends $o{render(e){return ue}update(e,[t]){var s;const o=t!==this.Y;return o&&this.Y!==void 0&&this.rt(void 0),(o||this.lt!==this.ct)&&(this.Y=t,this.ht=(s=e.options)==null?void 0:s.host,this.rt(this.ct=e.element)),ue}rt(e){if(typeof this.Y=="function"){const t=this.ht??globalThis;let o=Ae.get(t);o===void 0&&(o=new WeakMap,Ae.set(t,o)),o.get(this.Y)!==void 0&&this.Y.call(this.ht,void 0),o.set(this.Y,e),e!==void 0&&this.Y.call(this.ht,e)}else this.Y.value=e}get lt(){var e,t;return typeof this.Y=="function"?(e=Ae.get(this.ht??globalThis))==null?void 0:e.get(this.Y):(t=this.Y)==null?void 0:t.value}disconnected(){this.lt===this.ct&&this.rt(void 0)}reconnected(){this.rt(this.ct)}});var To=class{constructor(e,t,o){this.popupRef=Po(),this.enableSubmenuTimer=-1,this.isConnected=!1,this.isPopupConnected=!1,this.skidding=0,this.submenuOpenDelay=100,this.handleMouseMove=s=>{this.host.style.setProperty("--safe-triangle-cursor-x",`${s.clientX}px`),this.host.style.setProperty("--safe-triangle-cursor-y",`${s.clientY}px`)},this.handleMouseOver=()=>{this.hasSlotController.test("submenu")&&this.enableSubmenu()},this.handleKeyDown=s=>{switch(s.key){case"Escape":case"Tab":this.disableSubmenu();break;case"ArrowLeft":s.target!==this.host&&(s.preventDefault(),s.stopPropagation(),this.host.focus(),this.disableSubmenu());break;case"ArrowRight":case"Enter":case" ":this.handleSubmenuEntry(s);break}},this.handleClick=s=>{var r;s.target===this.host?(s.preventDefault(),s.stopPropagation()):s.target instanceof Element&&(s.target.tagName==="sl-menu-item"||(r=s.target.role)!=null&&r.startsWith("menuitem"))&&this.disableSubmenu()},this.handleFocusOut=s=>{s.relatedTarget&&s.relatedTarget instanceof Element&&this.host.contains(s.relatedTarget)||this.disableSubmenu()},this.handlePopupMouseover=s=>{s.stopPropagation()},this.handlePopupReposition=()=>{const s=this.host.renderRoot.querySelector("slot[name='submenu']"),r=s==null?void 0:s.assignedElements({flatten:!0}).filter(c=>c.localName==="sl-menu")[0],i=this.localize.dir()==="rtl";if(!r)return;const{left:l,top:u,width:n,height:a}=r.getBoundingClientRect();this.host.style.setProperty("--safe-triangle-submenu-start-x",`${i?l+n:l}px`),this.host.style.setProperty("--safe-triangle-submenu-start-y",`${u}px`),this.host.style.setProperty("--safe-triangle-submenu-end-x",`${i?l+n:l}px`),this.host.style.setProperty("--safe-triangle-submenu-end-y",`${u+a}px`)},(this.host=e).addController(this),this.hasSlotController=t,this.localize=o}hostConnected(){this.hasSlotController.test("submenu")&&!this.host.disabled&&this.addListeners()}hostDisconnected(){this.removeListeners()}hostUpdated(){this.hasSlotController.test("submenu")&&!this.host.disabled?(this.addListeners(),this.updateSkidding()):this.removeListeners()}addListeners(){this.isConnected||(this.host.addEventListener("mousemove",this.handleMouseMove),this.host.addEventListener("mouseover",this.handleMouseOver),this.host.addEventListener("keydown",this.handleKeyDown),this.host.addEventListener("click",this.handleClick),this.host.addEventListener("focusout",this.handleFocusOut),this.isConnected=!0),this.isPopupConnected||this.popupRef.value&&(this.popupRef.value.addEventListener("mouseover",this.handlePopupMouseover),this.popupRef.value.addEventListener("sl-reposition",this.handlePopupReposition),this.isPopupConnected=!0)}removeListeners(){this.isConnected&&(this.host.removeEventListener("mousemove",this.handleMouseMove),this.host.removeEventListener("mouseover",this.handleMouseOver),this.host.removeEventListener("keydown",this.handleKeyDown),this.host.removeEventListener("click",this.handleClick),this.host.removeEventListener("focusout",this.handleFocusOut),this.isConnected=!1),this.isPopupConnected&&this.popupRef.value&&(this.popupRef.value.removeEventListener("mouseover",this.handlePopupMouseover),this.popupRef.value.removeEventListener("sl-reposition",this.handlePopupReposition),this.isPopupConnected=!1)}handleSubmenuEntry(e){const t=this.host.renderRoot.querySelector("slot[name='submenu']");if(!t){console.error("Cannot activate a submenu if no corresponding menuitem can be found.",this);return}let o=null;for(const s of t.assignedElements())if(o=s.querySelectorAll("sl-menu-item, [role^='menuitem']"),o.length!==0)break;if(!(!o||o.length===0)){o[0].setAttribute("tabindex","0");for(let s=1;s!==o.length;++s)o[s].setAttribute("tabindex","-1");this.popupRef.value&&(e.preventDefault(),e.stopPropagation(),this.popupRef.value.active?o[0]instanceof HTMLElement&&o[0].focus():(this.enableSubmenu(!1),this.host.updateComplete.then(()=>{o[0]instanceof HTMLElement&&o[0].focus()}),this.host.requestUpdate()))}}setSubmenuState(e){this.popupRef.value&&this.popupRef.value.active!==e&&(this.popupRef.value.active=e,this.host.requestUpdate())}enableSubmenu(e=!0){e?this.enableSubmenuTimer=window.setTimeout(()=>{this.setSubmenuState(!0)},this.submenuOpenDelay):this.setSubmenuState(!0)}disableSubmenu(){clearTimeout(this.enableSubmenuTimer),this.setSubmenuState(!1)}updateSkidding(){var e;if(!((e=this.host.parentElement)!=null&&e.computedStyleMap))return;const t=this.host.parentElement.computedStyleMap(),s=["padding-top","border-top-width","margin-top"].reduce((r,i)=>{var l;const u=(l=t.get(i))!=null?l:new CSSUnitValue(0,"px"),a=(u instanceof CSSUnitValue?u:new CSSUnitValue(0,"px")).to("px");return r-a.value},0);this.skidding=s}isExpanded(){return this.popupRef.value?this.popupRef.value.active:!1}renderSubmenu(){const e=this.localize.dir()==="ltr";return this.isConnected?J`
      <sl-popup
        ${zo(this.popupRef)}
        placement=${e?"right-start":"left-start"}
        anchor="anchor"
        flip
        flip-fallback-strategy="best-fit"
        skidding="${this.skidding}"
        strategy="fixed"
      >
        <slot name="submenu"></slot>
      </sl-popup>
    `:J` <slot name="submenu" hidden></slot> `}},nt=class extends xt{constructor(){super(...arguments),this.type="normal",this.checked=!1,this.value="",this.loading=!1,this.disabled=!1,this.localize=new qt(this),this.hasSlotController=new te(this,"submenu"),this.submenuController=new To(this,this.hasSlotController,this.localize),this.handleHostClick=e=>{this.disabled&&(e.preventDefault(),e.stopImmediatePropagation())},this.handleMouseOver=e=>{this.focus(),e.stopPropagation()}}connectedCallback(){super.connectedCallback(),this.addEventListener("click",this.handleHostClick),this.addEventListener("mouseover",this.handleMouseOver)}disconnectedCallback(){super.disconnectedCallback(),this.removeEventListener("click",this.handleHostClick),this.removeEventListener("mouseover",this.handleMouseOver)}handleDefaultSlotChange(){const e=this.getTextLabel();if(typeof this.cachedTextLabel>"u"){this.cachedTextLabel=e;return}e!==this.cachedTextLabel&&(this.cachedTextLabel=e,this.emit("slotchange",{bubbles:!0,composed:!1,cancelable:!1}))}handleCheckedChange(){if(this.checked&&this.type!=="checkbox"){this.checked=!1,console.error('The checked attribute can only be used on menu items with type="checkbox"',this);return}this.type==="checkbox"?this.setAttribute("aria-checked",this.checked?"true":"false"):this.removeAttribute("aria-checked")}handleDisabledChange(){this.setAttribute("aria-disabled",this.disabled?"true":"false")}handleTypeChange(){this.type==="checkbox"?(this.setAttribute("role","menuitemcheckbox"),this.setAttribute("aria-checked",this.checked?"true":"false")):(this.setAttribute("role","menuitem"),this.removeAttribute("aria-checked"))}getTextLabel(){return ho(this.defaultSlot)}isSubmenu(){return this.hasSlotController.test("submenu")}render(){const e=this.localize.dir()==="rtl",t=this.submenuController.isExpanded();return J`
      <div
        id="anchor"
        part="base"
        class=${wt({"menu-item":!0,"menu-item--rtl":e,"menu-item--checked":this.checked,"menu-item--disabled":this.disabled,"menu-item--loading":this.loading,"menu-item--has-submenu":this.isSubmenu(),"menu-item--submenu-expanded":t})}
        ?aria-haspopup="${this.isSubmenu()}"
        ?aria-expanded="${!!t}"
      >
        <span part="checked-icon" class="menu-item__check">
          <sl-icon name="check" library="system" aria-hidden="true"></sl-icon>
        </span>

        <slot name="prefix" part="prefix" class="menu-item__prefix"></slot>

        <slot part="label" class="menu-item__label" @slotchange=${this.handleDefaultSlotChange}></slot>

        <slot name="suffix" part="suffix" class="menu-item__suffix"></slot>

        <span part="submenu-icon" class="menu-item__chevron">
          <sl-icon name=${e?"chevron-left":"chevron-right"} library="system" aria-hidden="true"></sl-icon>
        </span>

        ${this.submenuController.renderSubmenu()}
        ${this.loading?J` <sl-spinner part="spinner" exportparts="base:spinner__base"></sl-spinner> `:""}
      </div>
    `}};nt.styles=[Ct,xo];nt.dependencies={"sl-icon":ye,"sl-popup":ds,"sl-spinner":Ce};d([gt("slot:not([name])")],nt.prototype,"defaultSlot",2);d([gt(".menu-item")],nt.prototype,"menuItem",2);d([p()],nt.prototype,"type",2);d([p({type:Boolean,reflect:!0})],nt.prototype,"checked",2);d([p()],nt.prototype,"value",2);d([p({type:Boolean,reflect:!0})],nt.prototype,"loading",2);d([p({type:Boolean,reflect:!0})],nt.prototype,"disabled",2);d([vt("checked")],nt.prototype,"handleCheckedChange",1);d([vt("disabled")],nt.prototype,"handleDisabledChange",1);d([vt("type")],nt.prototype,"handleTypeChange",1);nt.define("sl-menu-item");var Io=bt`
  :host {
    display: inline-block;
  }

  .dropdown::part(popup) {
    z-index: var(--sl-z-index-dropdown);
  }

  .dropdown[data-current-placement^='top']::part(popup) {
    transform-origin: bottom;
  }

  .dropdown[data-current-placement^='bottom']::part(popup) {
    transform-origin: top;
  }

  .dropdown[data-current-placement^='left']::part(popup) {
    transform-origin: right;
  }

  .dropdown[data-current-placement^='right']::part(popup) {
    transform-origin: left;
  }

  .dropdown__trigger {
    display: block;
  }

  .dropdown__panel {
    font-family: var(--sl-font-sans);
    font-size: var(--sl-font-size-medium);
    font-weight: var(--sl-font-weight-normal);
    box-shadow: var(--sl-shadow-large);
    border-radius: var(--sl-border-radius-medium);
    pointer-events: none;
  }

  .dropdown--open .dropdown__panel {
    display: block;
    pointer-events: all;
  }

  /* When users slot a menu, make sure it conforms to the popup's auto-size */
  ::slotted(sl-menu) {
    max-width: var(--auto-size-available-width) !important;
    max-height: var(--auto-size-available-height) !important;
  }
`,je=new WeakMap;function ks(e){let t=je.get(e);return t||(t=window.getComputedStyle(e,null),je.set(e,t)),t}function Do(e){if(typeof e.checkVisibility=="function")return e.checkVisibility({checkOpacity:!1,checkVisibilityCSS:!0});const t=ks(e);return t.visibility!=="hidden"&&t.display!=="none"}function Vo(e){const t=ks(e),{overflowY:o,overflowX:s}=t;return o==="scroll"||s==="scroll"?!0:o!=="auto"||s!=="auto"?!1:e.scrollHeight>e.clientHeight&&o==="auto"||e.scrollWidth>e.clientWidth&&s==="auto"}function Fo(e){const t=e.tagName.toLowerCase(),o=Number(e.getAttribute("tabindex"));return e.hasAttribute("tabindex")&&(isNaN(o)||o<=-1)||e.hasAttribute("disabled")||e.closest("[inert]")||t==="input"&&e.getAttribute("type")==="radio"&&!e.hasAttribute("checked")||!Do(e)?!1:(t==="audio"||t==="video")&&e.hasAttribute("controls")||e.hasAttribute("tabindex")||e.hasAttribute("contenteditable")&&e.getAttribute("contenteditable")!=="false"||["button","input","select","textarea","a","audio","video","summary","iframe"].includes(t)?!0:Vo(e)}function Mo(e){var t,o;const s=Bo(e),r=(t=s[0])!=null?t:null,i=(o=s[s.length-1])!=null?o:null;return{start:r,end:i}}function Oo(e,t){var o;return((o=e.getRootNode({composed:!0}))==null?void 0:o.host)!==t}function Bo(e){const t=new WeakMap,o=[];function s(r){if(r instanceof Element){if(r.hasAttribute("inert")||r.closest("[inert]")||t.has(r))return;t.set(r,!0),!o.includes(r)&&Fo(r)&&o.push(r),r instanceof HTMLSlotElement&&Oo(r,e)&&r.assignedElements({flatten:!0}).forEach(i=>{s(i)}),r.shadowRoot!==null&&r.shadowRoot.mode==="open"&&s(r.shadowRoot)}for(const i of r.children)s(i)}return s(e),o.sort((r,i)=>{const l=Number(r.getAttribute("tabindex"))||0;return(Number(i.getAttribute("tabindex"))||0)-l})}var tt=class extends xt{constructor(){super(...arguments),this.localize=new qt(this),this.open=!1,this.placement="bottom-start",this.disabled=!1,this.stayOpenOnSelect=!1,this.distance=0,this.skidding=0,this.hoist=!1,this.handleKeyDown=e=>{this.open&&e.key==="Escape"&&(e.stopPropagation(),this.hide(),this.focusOnTrigger())},this.handleDocumentKeyDown=e=>{var t;if(e.key==="Escape"&&this.open&&!this.closeWatcher){e.stopPropagation(),this.focusOnTrigger(),this.hide();return}if(e.key==="Tab"){if(this.open&&((t=document.activeElement)==null?void 0:t.tagName.toLowerCase())==="sl-menu-item"){e.preventDefault(),this.hide(),this.focusOnTrigger();return}setTimeout(()=>{var o,s,r;const i=((o=this.containingElement)==null?void 0:o.getRootNode())instanceof ShadowRoot?(r=(s=document.activeElement)==null?void 0:s.shadowRoot)==null?void 0:r.activeElement:document.activeElement;(!this.containingElement||(i==null?void 0:i.closest(this.containingElement.tagName.toLowerCase()))!==this.containingElement)&&this.hide()})}},this.handleDocumentMouseDown=e=>{const t=e.composedPath();this.containingElement&&!t.includes(this.containingElement)&&this.hide()},this.handlePanelSelect=e=>{const t=e.target;!this.stayOpenOnSelect&&t.tagName.toLowerCase()==="sl-menu"&&(this.hide(),this.focusOnTrigger())}}connectedCallback(){super.connectedCallback(),this.containingElement||(this.containingElement=this)}firstUpdated(){this.panel.hidden=!this.open,this.open&&(this.addOpenListeners(),this.popup.active=!0)}disconnectedCallback(){super.disconnectedCallback(),this.removeOpenListeners(),this.hide()}focusOnTrigger(){const e=this.trigger.assignedElements({flatten:!0})[0];typeof(e==null?void 0:e.focus)=="function"&&e.focus()}getMenu(){return this.panel.assignedElements({flatten:!0}).find(e=>e.tagName.toLowerCase()==="sl-menu")}handleTriggerClick(){this.open?this.hide():(this.show(),this.focusOnTrigger())}async handleTriggerKeyDown(e){if([" ","Enter"].includes(e.key)){e.preventDefault(),this.handleTriggerClick();return}const t=this.getMenu();if(t){const o=t.getAllItems(),s=o[0],r=o[o.length-1];["ArrowDown","ArrowUp","Home","End"].includes(e.key)&&(e.preventDefault(),this.open||(this.show(),await this.updateComplete),o.length>0&&this.updateComplete.then(()=>{(e.key==="ArrowDown"||e.key==="Home")&&(t.setCurrentItem(s),s.focus()),(e.key==="ArrowUp"||e.key==="End")&&(t.setCurrentItem(r),r.focus())}))}}handleTriggerKeyUp(e){e.key===" "&&e.preventDefault()}handleTriggerSlotChange(){this.updateAccessibleTrigger()}updateAccessibleTrigger(){const t=this.trigger.assignedElements({flatten:!0}).find(s=>Mo(s).start);let o;if(t){switch(t.tagName.toLowerCase()){case"sl-button":case"sl-icon-button":o=t.button;break;default:o=t}o.setAttribute("aria-haspopup","true"),o.setAttribute("aria-expanded",this.open?"true":"false")}}async show(){if(!this.open)return this.open=!0,fe(this,"sl-after-show")}async hide(){if(this.open)return this.open=!1,fe(this,"sl-after-hide")}reposition(){this.popup.reposition()}addOpenListeners(){var e;this.panel.addEventListener("sl-select",this.handlePanelSelect),"CloseWatcher"in window?((e=this.closeWatcher)==null||e.destroy(),this.closeWatcher=new CloseWatcher,this.closeWatcher.onclose=()=>{this.hide(),this.focusOnTrigger()}):this.panel.addEventListener("keydown",this.handleKeyDown),document.addEventListener("keydown",this.handleDocumentKeyDown),document.addEventListener("mousedown",this.handleDocumentMouseDown)}removeOpenListeners(){var e;this.panel&&(this.panel.removeEventListener("sl-select",this.handlePanelSelect),this.panel.removeEventListener("keydown",this.handleKeyDown)),document.removeEventListener("keydown",this.handleDocumentKeyDown),document.removeEventListener("mousedown",this.handleDocumentMouseDown),(e=this.closeWatcher)==null||e.destroy()}async handleOpenChange(){if(this.disabled){this.open=!1;return}if(this.updateAccessibleTrigger(),this.open){this.emit("sl-show"),this.addOpenListeners(),await ce(this),this.panel.hidden=!1,this.popup.active=!0;const{keyframes:e,options:t}=de(this,"dropdown.show",{dir:this.localize.dir()});await he(this.popup.popup,e,t),this.emit("sl-after-show")}else{this.emit("sl-hide"),this.removeOpenListeners(),await ce(this);const{keyframes:e,options:t}=de(this,"dropdown.hide",{dir:this.localize.dir()});await he(this.popup.popup,e,t),this.panel.hidden=!0,this.popup.active=!1,this.emit("sl-after-hide")}}render(){return J`
      <sl-popup
        part="base"
        id="dropdown"
        placement=${this.placement}
        distance=${this.distance}
        skidding=${this.skidding}
        strategy=${this.hoist?"fixed":"absolute"}
        flip
        shift
        auto-size="vertical"
        auto-size-padding="10"
        class=${wt({dropdown:!0,"dropdown--open":this.open})}
      >
        <slot
          name="trigger"
          slot="anchor"
          part="trigger"
          class="dropdown__trigger"
          @click=${this.handleTriggerClick}
          @keydown=${this.handleTriggerKeyDown}
          @keyup=${this.handleTriggerKeyUp}
          @slotchange=${this.handleTriggerSlotChange}
        ></slot>

        <div aria-hidden=${this.open?"false":"true"} aria-labelledby="dropdown">
          <slot part="panel" class="dropdown__panel"></slot>
        </div>
      </sl-popup>
    `}};tt.styles=[Ct,Io];tt.dependencies={"sl-popup":ds};d([gt(".dropdown")],tt.prototype,"popup",2);d([gt(".dropdown__trigger")],tt.prototype,"trigger",2);d([gt(".dropdown__panel")],tt.prototype,"panel",2);d([p({type:Boolean,reflect:!0})],tt.prototype,"open",2);d([p({reflect:!0})],tt.prototype,"placement",2);d([p({type:Boolean,reflect:!0})],tt.prototype,"disabled",2);d([p({attribute:"stay-open-on-select",type:Boolean,reflect:!0})],tt.prototype,"stayOpenOnSelect",2);d([p({attribute:!1})],tt.prototype,"containingElement",2);d([p({type:Number})],tt.prototype,"distance",2);d([p({type:Number})],tt.prototype,"skidding",2);d([p({type:Boolean})],tt.prototype,"hoist",2);d([vt("open",{waitUntilFirstUpdate:!0})],tt.prototype,"handleOpenChange",1);we("dropdown.show",{keyframes:[{opacity:0,scale:.9},{opacity:1,scale:1}],options:{duration:100,easing:"ease"}});we("dropdown.hide",{keyframes:[{opacity:1,scale:1},{opacity:0,scale:.9}],options:{duration:100,easing:"ease"}});tt.define("sl-dropdown");let We=class extends $t{render(){return H`<div class="row" style="align-items: center; width: 150px">
      <sl-skeleton
        effect="sheen"
        style="height: 32px; width: 32px; border-radius: 50%; margin: 8px"
      ></sl-skeleton
      ><sl-skeleton
        effect="sheen"
        style="flex: 1; margin: 8px; border-radius: 12px"
      >
      </sl-skeleton>
    </div>`}static get styles(){return[Lt,Qt`
        :host {
          display: flex;
        }
      `]}};We=z([Pt("profile-list-item-skeleton")],We);/**
 * @license
 * Copyright 2018 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const No=e=>e??Ns;let It=class extends $t{constructor(){super(...arguments),this.includeMyself=!1,this._searchProfiles=new Te(this,()=>this.searchFilter&&this.searchFilter.length>=3?this.store.searchProfiles(this.searchFilter):Us(void 0),()=>[this.searchFilter])}async onUsernameSelected(t){const o=await wo(this.store.profiles.get(t));this.dispatchEvent(new CustomEvent("agent-selected",{detail:{agentPubKey:t,profile:o},bubbles:!0,composed:!0}))}renderAgentList(){if(!this._searchProfiles.value)return H`<sl-menu-item disabled
        >${Y("Enter at least 3 chars to search...")}</sl-menu-item
      >`;switch(this._searchProfiles.value.status){case"pending":return Array(3).map(()=>H`
            <sl-menu-item>
              <sl-skeleton
                effect="sheen"
                slot="prefix"
                style="height: 32px; width: 32px; border-radius: 50%; margin: 8px"
              ></sl-skeleton>
              <sl-skeleton
                effect="sheen"
                style="width: 100px; margin: 8px; border-radius: 12px"
              ></sl-skeleton>
            </sl-menu-item>
          `);case"error":return H`
          <display-error
            style="flex: 1; display:flex"
            tooltip
            .headline=${Y("Error searching agents")}
            .error=${this._searchProfiles.value.error}
          ></display-error>
        `;case"complete":{if(!this._searchProfiles.value.value)return H`<sl-menu-item disabled
            >${Y("Enter at least 3 chars to search...")}</sl-menu-item
          >`;let t=Array.from(this._searchProfiles.value.value.entries());return this.includeMyself||(t=t.filter(([o,s])=>o.toString()!==this.store.client.client.myPubKey.toString())),t.length===0?H`<sl-menu-item disabled>
            ${Y("No agents match the filter")}
          </sl-menu-item>`:H`
          ${t.map(([o,s])=>H`
              <sl-menu-item .value=${Pe(o)}>
                <agent-avatar
                  slot="prefix"
                  .agentPubKey=${o}
                  style="margin-right: 16px"
                ></agent-avatar>
                ${s.entry.nickname}
              </sl-menu-item>
            `)}
        `}}}render(){return H`
      <sl-dropdown id="dropdown" style="flex: 1" .open=${No(this.open)}>
        <slot slot="trigger"></slot>
        <sl-menu
          @sl-select=${t=>{this.onUsernameSelected(Rs(t.detail.item.value))}}
        >
          ${this.renderAgentList()}
        </sl-menu>
      </sl-dropdown>
    `}static get styles(){return[Lt,Qt`
        :host {
          display: flex;
        }
      `]}};z([K()],It.prototype,"searchFilter",void 0);z([K()],It.prototype,"open",void 0);z([K({type:Boolean,attribute:"include-myself"})],It.prototype,"includeMyself",void 0);z([jt({context:Dt,subscribe:!0}),K()],It.prototype,"store",void 0);z([ms("#dropdown")],It.prototype,"dropdown",void 0);It=z([Wt(),Pt("search-agent-dropdown")],It);let it=class extends $t{constructor(){super(...arguments),this.required=!1,this.disabled=!1,this.clearOnSelect=!1,this.includeMyself=!1,this._controller=new bs(this),this.searchFilter=""}reportValidity(){const t=this.required!==!1&&this.value===void 0;return t&&(this._textField.setCustomValidity("This field is required"),this._textField.reportValidity()),!t}async reset(){if(this.value=this.defaultValue,this.defaultValue){const t=await this.store.client.getAgentProfile(this.defaultValue);this._textField.value=(t==null?void 0:t.entry.nickname)||""}else this._textField.value=""}onUsernameSelected(t,o){this.value=t,this.clearOnSelect?this._textField.value="":this._textField.value=o.entry.nickname,this.searchFilter=""}get _label(){let t=this.fieldLabel?this.fieldLabel:Y("Search Agent");return this.required!==!1&&(t=`${t} *`),t}render(){return H`
      <div style="flex: 1; display: flex;">
        <search-agent-dropdown
          id="dropdown"
          .open=${this.searchFilter.length>=3}
          style="flex: 1"
          .includeMyself=${this.includeMyself}
          .searchFilter=${this.searchFilter}
          @agent-selected=${t=>this.onUsernameSelected(t.detail.agentPubKey,t.detail.profile)}
        >
          <sl-input
            id="textfield"
            .label=${this._label}
            .placeholder=${Y("At least 3 chars...")}
            @input=${t=>{this.searchFilter=t.target.value}}
          ></sl-input>
        </search-agent-dropdown>
      </div>
    `}static get styles(){return[Lt,Qt`
        :host {
          display: flex;
        }
      `]}};z([K()],it.prototype,"name",void 0);z([K(cs("default-value"))],it.prototype,"defaultValue",void 0);z([K()],it.prototype,"required",void 0);z([K()],it.prototype,"disabled",void 0);z([ps()],it.prototype,"value",void 0);z([K({type:Boolean,attribute:"clear-on-select"})],it.prototype,"clearOnSelect",void 0);z([K({type:Boolean,attribute:"include-myself"})],it.prototype,"includeMyself",void 0);z([K({type:String,attribute:"field-label"})],it.prototype,"fieldLabel",void 0);z([jt({context:Dt,subscribe:!0}),K()],it.prototype,"store",void 0);z([ms("#textfield")],it.prototype,"_textField",void 0);z([ps()],it.prototype,"searchFilter",void 0);it=z([Wt(),Pt("search-agent")],it);const{document:Ke}=Zs,Uo=e=>({}),Ye=e=>({}),Ro=e=>({}),Xe=e=>({});function Ho(e){let t,o,s;return{c(){t=pt("svg"),o=pt("path"),this.h()},l(r){t=mt(r,"svg",{class:!0,fill:!0,viewBox:!0,xmlns:!0});var i=P(t);o=mt(i,"path",{d:!0,"fill-rule":!0,"clip-rule":!0}),P(o).forEach(f),i.forEach(f),this.h()},h(){y(o,"d",`M10 2a1 1 0 011 1v1a1 1 0 11-2 0V3a1 1 0 011-1zm4 8a4 4 0 11-8 0 4 4 0 018 0zm-.464 4.95l.707.707a1 1 0 001.414-1.414l-.707-.707a1 1 0 00-1.414 1.414zm2.12-10.607a1 1 0 010 1.414l-.706.707a1 1 0 11-1.414-1.414l.707-.707a1 1 0 011.414 0zM17 11a1 1 0 100-2h-1a1 1 0 100 2h1zm-7 4a1 1 0 011 1v1a1 1 0 11-2 0v-1a1 1 0 011-1zM5.05 6.464A1 1 0 106.465 5.05l-.708-.707a1 1 0 00-1.414 1.414l.707.707zm1.414 8.486l-.707.707a1 1 0 01-1.414-1.414l.707-.707a1 1 0 011.414 1.414zM4 11a1 1
  0 100-2H3a1 1 0 000 2h1z`),y(o,"fill-rule","evenodd"),y(o,"clip-rule","evenodd"),y(t,"class",s=e[3][e[1]]),y(t,"fill","currentColor"),y(t,"viewBox","0 0 20 20"),y(t,"xmlns","http://www.w3.org/2000/svg")},m(r,i){x(r,t,i),W(t,o)},p(r,i){i&2&&s!==(s=r[3][r[1]])&&y(t,"class",s)},d(r){r&&f(t)}}}function qo(e){let t,o,s;return{c(){t=pt("svg"),o=pt("path"),this.h()},l(r){t=mt(r,"svg",{class:!0,fill:!0,viewBox:!0,xmlns:!0});var i=P(t);o=mt(i,"path",{d:!0}),P(o).forEach(f),i.forEach(f),this.h()},h(){y(o,"d","M17.293 13.293A8 8 0 016.707 2.707a8.001 8.001 0 1010.586 10.586z"),y(t,"class",s=e[3][e[1]]),y(t,"fill","currentColor"),y(t,"viewBox","0 0 20 20"),y(t,"xmlns","http://www.w3.org/2000/svg")},m(r,i){x(r,t,i),W(t,o)},p(r,i){i&2&&s!==(s=r[3][r[1]])&&y(t,"class",s)},d(r){r&&f(t)}}}function jo(e){let t,o=`if ('color-theme' in localStorage) {
      // explicit preference - overrides author's choice
      localStorage.getItem('color-theme') === 'dark' ? window.document.documentElement.classList.add('dark') : window.document.documentElement.classList.remove('dark');
    } else {
      // browser preference - does not overrides
      if (window.matchMedia('(prefers-color-scheme: dark)').matches) window.document.documentElement.classList.add('dark');
    }`,s,r,i,l,u,n,a,c,h;const b=e[8].lightIcon,v=at(b,e,e[7],Xe),m=v||Ho(e),L=e[8].darkIcon,q=at(L,e,e[7],Ye),T=q||qo(e);let j=[{"aria-label":e[2]},{type:"button"},e[5],{class:n=G(e[0],e[6].class)}],g={};for(let _=0;_<j.length;_+=1)g=M(g,j[_]);return{c(){t=V("script"),t.textContent=o,s=et(),r=V("button"),i=V("span"),m&&m.c(),l=et(),u=V("span"),T&&T.c(),this.h()},l(_){const C=xs("svelte-1pa505f",Ke.head);t=F(C,"SCRIPT",{"data-svelte-h":!0}),os(t)!=="svelte-mp99qu"&&(t.textContent=o),C.forEach(f),s=st(_),r=F(_,"BUTTON",{"aria-label":!0,type:!0,class:!0});var $=P(r);i=F($,"SPAN",{class:!0});var ee=P(i);m&&m.l(ee),ee.forEach(f),l=st($),u=F($,"SPAN",{class:!0});var se=P(u);T&&T.l(se),se.forEach(f),$.forEach(f),this.h()},h(){y(i,"class","hidden dark:block"),y(u,"class","block dark:hidden"),Et(r,g)},m(_,C){W(Ke.head,t),x(_,s,C),x(_,r,C),W(r,i),m&&m.m(i,null),W(r,l),W(r,u),T&&T.m(u,null),r.autofocus&&r.focus(),a=!0,c||(h=S(r,"click",e[4]),c=!0)},p(_,[C]){v?v.p&&(!a||C&128)&&ut(v,b,_,_[7],a?dt(b,_[7],C,Ro):ct(_[7]),Xe):m&&m.p&&(!a||C&2)&&m.p(_,a?C:-1),q?q.p&&(!a||C&128)&&ut(q,L,_,_[7],a?dt(L,_[7],C,Uo):ct(_[7]),Ye):T&&T.p&&(!a||C&2)&&T.p(_,a?C:-1),Et(r,g=_t(j,[(!a||C&4)&&{"aria-label":_[2]},{type:"button"},C&32&&_[5],(!a||C&65&&n!==(n=G(_[0],_[6].class)))&&{class:n}]))},i(_){a||(k(m,_),k(T,_),a=!0)},o(_){w(m,_),w(T,_),a=!1},d(_){_&&(f(s),f(r)),f(t),m&&m.d(_),T&&T.d(_),c=!1,h()}}}function Wo(e,t,o){const s=["btnClass","size","ariaLabel"];let r=Z(t,s),{$$slots:i={},$$scope:l}=t,{btnClass:u="text-gray-500 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-700 focus:outline-none rounded-lg text-sm p-2.5"}=t,{size:n="md"}=t,{ariaLabel:a="Dark mode"}=t;const c={sm:"w-4 h-4",md:"w-5 h-5",lg:"w-6 h-6"},h=b=>{const v=b.target,m=v.ownerDocument.documentElement.classList.toggle("dark");v.ownerDocument===document&&localStorage.setItem("color-theme",m?"dark":"light")};return e.$$set=b=>{o(6,t=M(M({},t),X(b))),o(5,r=Z(t,s)),"btnClass"in b&&o(0,u=b.btnClass),"size"in b&&o(1,n=b.size),"ariaLabel"in b&&o(2,a=b.ariaLabel),"$$scope"in b&&o(7,l=b.$$scope)},t=X(t),[u,n,a,c,h,r,t,l,i]}class ws extends ot{constructor(t){super(),rt(this,t,Wo,jo,Q,{btnClass:0,size:1,ariaLabel:2})}}function Ko(e){let t,o,s;const r=e[3].default,i=at(r,e,e[2],null);return{c(){t=V("div"),i&&i.c(),this.h()},l(l){t=F(l,"DIV",{class:!0});var u=P(t);i&&i.l(u),u.forEach(f),this.h()},h(){y(t,"class",o=G("mx-auto flex flex-wrap justify-between items-center ",e[0]?"w-full":"container",e[1].class))},m(l,u){x(l,t,u),i&&i.m(t,null),s=!0},p(l,[u]){i&&i.p&&(!s||u&4)&&ut(i,r,l,l[2],s?dt(r,l[2],u,null):ct(l[2]),null),(!s||u&3&&o!==(o=G("mx-auto flex flex-wrap justify-between items-center ",l[0]?"w-full":"container",l[1].class)))&&y(t,"class",o)},i(l){s||(k(i,l),s=!0)},o(l){w(i,l),s=!1},d(l){l&&f(t),i&&i.d(l)}}}function Yo(e,t,o){let{$$slots:s={},$$scope:r}=t,{fluid:i=!1}=t;return e.$$set=l=>{o(1,t=M(M({},t),X(l))),"fluid"in l&&o(0,i=l.fluid),"$$scope"in l&&o(2,r=l.$$scope)},t=X(t),[i,t,r,s]}class Cs extends ot{constructor(t){super(),rt(this,t,Yo,Ko,Q,{fluid:0})}}const Xo=e=>({hidden:e&2}),Ge=e=>({hidden:e[1],toggle:e[3],NavContainer:Cs});function Go(e){let t;const o=e[6].default,s=at(o,e,e[7],Ge);return{c(){s&&s.c()},l(r){s&&s.l(r)},m(r,i){s&&s.m(r,i),t=!0},p(r,i){s&&s.p&&(!t||i&130)&&ut(s,o,r,r[7],t?dt(o,r[7],i,Xo):ct(r[7]),Ge)},i(r){t||(k(s,r),t=!0)},o(r){w(s,r),t=!1},d(r){s&&s.d(r)}}}function Zo(e){let t,o;return t=new Cs({props:{fluid:e[0],$$slots:{default:[Go]},$$scope:{ctx:e}}}),{c(){B(t.$$.fragment)},l(s){N(t.$$.fragment,s)},m(s,r){U(t,s,r),o=!0},p(s,r){const i={};r&1&&(i.fluid=s[0]),r&130&&(i.$$scope={dirty:r,ctx:s}),t.$set(i)},i(s){o||(k(t.$$.fragment,s),o=!0)},o(s){w(t.$$.fragment,s),o=!1},d(s){R(t,s)}}}function Jo(e){let t,o;const s=[{tag:"nav"},e[4],{class:G("px-2 sm:px-4 py-2.5 w-full",e[5].class)}];let r={$$slots:{default:[Zo]},$$scope:{ctx:e}};for(let i=0;i<s.length;i+=1)r=M(r,s[i]);return t=new Ie({props:r}),{c(){B(t.$$.fragment)},l(i){N(t.$$.fragment,i)},m(i,l){U(t,i,l),o=!0},p(i,[l]){const u=l&48?_t(s,[s[0],l&16&&hs(i[4]),l&32&&{class:G("px-2 sm:px-4 py-2.5 w-full",i[5].class)}]):{};l&131&&(u.$$scope={dirty:l,ctx:i}),t.$set(u)},i(i){o||(k(t.$$.fragment,i),o=!0)},o(i){w(t.$$.fragment,i),o=!1},d(i){R(t,i)}}}function Qo(e,t,o){const s=["fluid"];let r=Z(t,s),i,{$$slots:l={},$$scope:u}=t,{fluid:n=!1}=t,a=fs(!0);Ot(e,a,h=>o(1,i=h)),ae("navHidden",a);let c=()=>a.update(h=>!h);return e.$$set=h=>{o(5,t=M(M({},t),X(h))),o(4,r=Z(t,s)),"fluid"in h&&o(0,n=h.fluid),"$$scope"in h&&o(7,u=h.$$scope)},e.$$.update=()=>{o(4,r.color=r.color??"navbar",r)},t=X(t),[n,i,a,c,r,t,l,u]}class tr extends ot{constructor(t){super(),rt(this,t,Qo,Jo,Q,{fluid:0})}}function er(e){let t,o,s;const r=e[4].default,i=at(r,e,e[3],null);let l=[{href:e[0]},e[1],{class:o=G("flex items-center",e[2].class)}],u={};for(let n=0;n<l.length;n+=1)u=M(u,l[n]);return{c(){t=V("a"),i&&i.c(),this.h()},l(n){t=F(n,"A",{href:!0,class:!0});var a=P(t);i&&i.l(a),a.forEach(f),this.h()},h(){Et(t,u)},m(n,a){x(n,t,a),i&&i.m(t,null),s=!0},p(n,[a]){i&&i.p&&(!s||a&8)&&ut(i,r,n,n[3],s?dt(r,n[3],a,null):ct(n[3]),null),Et(t,u=_t(l,[(!s||a&1)&&{href:n[0]},a&2&&n[1],(!s||a&4&&o!==(o=G("flex items-center",n[2].class)))&&{class:o}]))},i(n){s||(k(i,n),s=!0)},o(n){w(i,n),s=!1},d(n){n&&f(t),i&&i.d(n)}}}function sr(e,t,o){const s=["href"];let r=Z(t,s),{$$slots:i={},$$scope:l}=t,{href:u=""}=t;return e.$$set=n=>{o(2,t=M(M({},t),X(n))),o(1,r=Z(t,s)),"href"in n&&o(0,u=n.href),"$$scope"in n&&o(3,l=n.$$scope)},t=X(t),[u,r,t,l,i]}class or extends ot{constructor(t){super(),rt(this,t,sr,er,Q,{href:0})}}function $e(e){let t,o,s,r,i;const l=e[8].default,u=at(l,e,e[7],null);let n=[{role:o=e[0]?void 0:"link"},{href:e[0]},e[2],{class:e[1]}],a={};for(let c=0;c<n.length;c+=1)a=M(a,n[c]);return{c(){t=V(e[0]?"a":"div"),u&&u.c(),this.h()},l(c){t=F(c,((e[0]?"a":"div")||"null").toUpperCase(),{role:!0,href:!0,class:!0});var h=P(t);u&&u.l(h),h.forEach(f),this.h()},h(){Fe(e[0]?"a":"div")(t,a)},m(c,h){x(c,t,h),u&&u.m(t,null),s=!0,r||(i=[S(t,"blur",e[9]),S(t,"change",e[10]),S(t,"click",e[11]),S(t,"focus",e[12]),S(t,"keydown",e[13]),S(t,"keypress",e[14]),S(t,"keyup",e[15]),S(t,"mouseenter",e[16]),S(t,"mouseleave",e[17]),S(t,"mouseover",e[18])],r=!0)},p(c,h){u&&u.p&&(!s||h&128)&&ut(u,l,c,c[7],s?dt(l,c[7],h,null):ct(c[7]),null),Fe(c[0]?"a":"div")(t,a=_t(n,[(!s||h&1&&o!==(o=c[0]?void 0:"link"))&&{role:o},(!s||h&1)&&{href:c[0]},h&4&&c[2],(!s||h&2)&&{class:c[1]}]))},i(c){s||(k(u,c),s=!0)},o(c){w(u,c),s=!1},d(c){c&&f(t),u&&u.d(c),r=!1,ve(i)}}}function rr(e){let t,o=e[0]?"a":"div",s,r=(e[0]?"a":"div")&&$e(e);return{c(){t=V("li"),r&&r.c()},l(i){t=F(i,"LI",{});var l=P(t);r&&r.l(l),l.forEach(f)},m(i,l){x(i,t,l),r&&r.m(t,null),s=!0},p(i,[l]){i[0],o?Q(o,i[0]?"a":"div")?(r.d(1),r=$e(i),o=i[0]?"a":"div",r.c(),r.m(t,null)):r.p(i,l):(r=$e(i),o=i[0]?"a":"div",r.c(),r.m(t,null))},i(i){s||(k(r,i),s=!0)},o(i){w(r,i),s=!1},d(i){i&&f(t),r&&r.d(i)}}}function ir(e,t,o){let s,r;const i=["href","activeClass","nonActiveClass"];let l=Z(t,i),{$$slots:u={},$$scope:n}=t,{href:a=""}=t,{activeClass:c=void 0}=t,{nonActiveClass:h=void 0}=t;const b=Bt("navbarContext")??{},v=Bt("activeUrl");let m="";v.subscribe(D=>{o(5,m=D)});function L(D){A.call(this,e,D)}function q(D){A.call(this,e,D)}function T(D){A.call(this,e,D)}function j(D){A.call(this,e,D)}function g(D){A.call(this,e,D)}function _(D){A.call(this,e,D)}function C(D){A.call(this,e,D)}function $(D){A.call(this,e,D)}function ee(D){A.call(this,e,D)}function se(D){A.call(this,e,D)}return e.$$set=D=>{o(21,t=M(M({},t),X(D))),o(2,l=Z(t,i)),"href"in D&&o(0,a=D.href),"activeClass"in D&&o(3,c=D.activeClass),"nonActiveClass"in D&&o(4,h=D.nonActiveClass),"$$scope"in D&&o(7,n=D.$$scope)},e.$$.update=()=>{e.$$.dirty&33&&o(6,s=m?a===m:!1),o(1,r=G("block py-2 pe-4 ps-3 md:p-0 rounded md:border-0",s?c??b.activeClass:h??b.nonActiveClass,t.class))},t=X(t),[a,r,l,c,h,m,s,n,u,L,q,T,j,g,_,C,$,ee,se]}class ie extends ot{constructor(t){super(),rt(this,t,ir,rr,Q,{href:0,activeClass:3,nonActiveClass:4})}}function lr(e){let t,o,s;const r=e[13].default,i=at(r,e,e[15],null);let l=[e[5],{class:e[2]},{hidden:e[1]}],u={};for(let n=0;n<l.length;n+=1)u=M(u,l[n]);return{c(){t=V("div"),o=V("ul"),i&&i.c(),this.h()},l(n){t=F(n,"DIV",{class:!0});var a=P(t);o=F(a,"UL",{class:!0});var c=P(o);i&&i.l(c),c.forEach(f),a.forEach(f),this.h()},h(){y(o,"class",e[3]),Et(t,u)},m(n,a){x(n,t,a),W(t,o),i&&i.m(o,null),s=!0},p(n,a){i&&i.p&&(!s||a&32768)&&ut(i,r,n,n[15],s?dt(r,n[15],a,null):ct(n[15]),null),(!s||a&8)&&y(o,"class",n[3]),Et(t,u=_t(l,[a&32&&n[5],(!s||a&4)&&{class:n[2]},(!s||a&2)&&{hidden:n[1]}]))},i(n){s||(k(i,n),s=!0)},o(n){w(i,n),s=!1},d(n){n&&f(t),i&&i.d(n)}}}function nr(e){let t,o,s,r,i,l;o=new Ie({props:{tag:"ul",border:!0,rounded:!0,color:"navbarUl",class:e[3],$$slots:{default:[ar]},$$scope:{ctx:e}}});let u=[e[5],{class:e[2]},{role:"button"},{tabindex:"0"}],n={};for(let a=0;a<u.length;a+=1)n=M(n,u[a]);return{c(){t=V("div"),B(o.$$.fragment),this.h()},l(a){t=F(a,"DIV",{class:!0,role:!0,tabindex:!0});var c=P(t);N(o.$$.fragment,c),c.forEach(f),this.h()},h(){Et(t,n)},m(a,c){x(a,t,c),U(o,t,null),r=!0,i||(l=S(t,"click",e[14]),i=!0)},p(a,c){e=a;const h={};c&8&&(h.class=e[3]),c&32768&&(h.$$scope={dirty:c,ctx:e}),o.$set(h),Et(t,n=_t(u,[c&32&&e[5],(!r||c&4)&&{class:e[2]},{role:"button"},{tabindex:"0"}]))},i(a){r||(k(o.$$.fragment,a),a&&Es(()=>{r&&(s||(s=Me(t,Ne,e[0],!0)),s.run(1))}),r=!0)},o(a){w(o.$$.fragment,a),a&&(s||(s=Me(t,Ne,e[0],!1)),s.run(0)),r=!1},d(a){a&&f(t),R(o),a&&s&&s.end(),i=!1,l()}}}function ar(e){let t;const o=e[13].default,s=at(o,e,e[15],null);return{c(){s&&s.c()},l(r){s&&s.l(r)},m(r,i){s&&s.m(r,i),t=!0},p(r,i){s&&s.p&&(!t||i&32768)&&ut(s,o,r,r[15],t?dt(o,r[15],i,null):ct(r[15]),null)},i(r){t||(k(s,r),t=!0)},o(r){w(s,r),t=!1},d(r){s&&s.d(r)}}}function ur(e){let t,o,s,r;const i=[nr,lr],l=[];function u(n,a){return n[1]?1:0}return t=u(e),o=l[t]=i[t](e),{c(){o.c(),s=Nt()},l(n){o.l(n),s=Nt()},m(n,a){l[t].m(n,a),x(n,s,a),r=!0},p(n,[a]){let c=t;t=u(n),t===c?l[t].p(n,a):(Rt(),w(l[c],1,1,()=>{l[c]=null}),Ht(),o=l[t],o?o.p(n,a):(o=l[t]=i[t](n),o.c()),k(o,1),o.m(s.parentNode,s))},i(n){r||(k(o),r=!0)},o(n){w(o),r=!1},d(n){n&&f(s),l[t].d(n)}}}function cr(e,t,o){const s=["activeUrl","divClass","ulClass","hidden","slideParams","activeClass","nonActiveClass"];let r=Z(t,s),i,{$$slots:l={},$$scope:u}=t;const n=fs("");let{activeUrl:a=""}=t,{divClass:c="w-full md:block md:w-auto"}=t,{ulClass:h="flex flex-col p-4 mt-4 md:flex-row md:space-x-8 rtl:space-x-reverse md:mt-0 md:text-sm md:font-medium"}=t,{hidden:b=void 0}=t,{slideParams:v={delay:250,duration:500,easing:Xs}}=t,{activeClass:m="text-white bg-primary-700 md:bg-transparent md:text-primary-700 md:dark:text-white dark:bg-primary-600 md:dark:bg-transparent"}=t,{nonActiveClass:L="text-gray-700 hover:bg-gray-100 md:hover:bg-transparent md:border-0 md:hover:text-primary-700 dark:text-gray-400 md:dark:hover:text-white dark:hover:bg-gray-700 dark:hover:text-white md:dark:hover:bg-transparent"}=t;ae("navbarContext",{activeClass:m,nonActiveClass:L}),ae("activeUrl",n);let q=Bt("navHidden");Ot(e,q,C=>o(12,i=C));let T,j,g;function _(C){A.call(this,e,C)}return e.$$set=C=>{o(17,t=M(M({},t),X(C))),o(5,r=Z(t,s)),"activeUrl"in C&&o(6,a=C.activeUrl),"divClass"in C&&o(7,c=C.divClass),"ulClass"in C&&o(8,h=C.ulClass),"hidden"in C&&o(9,b=C.hidden),"slideParams"in C&&o(0,v=C.slideParams),"activeClass"in C&&o(10,m=C.activeClass),"nonActiveClass"in C&&o(11,L=C.nonActiveClass),"$$scope"in C&&o(15,u=C.$$scope)},e.$$.update=()=>{e.$$.dirty&64&&n.set(a),e.$$.dirty&4608&&o(1,T=b??i??!0),o(2,j=G(c,t.class)),o(3,g=G(h,t.classUl))},t=X(t),[v,T,j,g,q,r,a,c,h,b,m,L,i,l,_,u]}class dr extends ot{constructor(t){super(),rt(this,t,cr,ur,Q,{activeUrl:6,divClass:7,ulClass:8,hidden:9,slideParams:0,activeClass:10,nonActiveClass:11})}}const hr=e=>({close:e&131072}),Ze=e=>({close:e[17]}),fr=e=>({}),Je=e=>({});function Qe(e){let t,o;return t=new Ie({props:{rounded:!0,color:"none",class:e[3],$$slots:{default:[pr]},$$scope:{ctx:e}}}),{c(){B(t.$$.fragment)},l(s){N(t.$$.fragment,s)},m(s,r){U(t,s,r),o=!0},p(s,r){const i={};r&8&&(i.class=s[3]),r&8192&&(i.$$scope={dirty:r,ctx:s}),t.$set(i)},i(s){o||(k(t.$$.fragment,s),o=!0)},o(s){w(t.$$.fragment,s),o=!1},d(s){R(t,s)}}}function pr(e){let t;const o=e[11].icon,s=at(o,e,e[13],Je);return{c(){s&&s.c()},l(r){s&&s.l(r)},m(r,i){s&&s.m(r,i),t=!0},p(r,i){s&&s.p&&(!t||i&8192)&&ut(s,o,r,r[13],t?dt(o,r[13],i,fr):ct(r[13]),Je)},i(r){t||(k(s,r),t=!0)},o(r){w(s,r),t=!1},d(r){s&&s.d(r)}}}function ts(e){let t;const o=e[11]["close-button"],s=at(o,e,e[13],Ze),r=s||mr(e);return{c(){r&&r.c()},l(i){r&&r.l(i)},m(i,l){r&&r.m(i,l),t=!0},p(i,l){s?s.p&&(!t||l&139264)&&ut(s,o,i,i[13],t?dt(o,i[13],l,hr):ct(i[13]),Ze):r&&r.p&&(!t||l&131072)&&r.p(i,t?l:-1)},i(i){t||(k(r,i),t=!0)},o(i){w(r,i),t=!1},d(i){r&&r.d(i)}}}function mr(e){let t,o;return t=new Ws({props:{class:vr}}),t.$on("click",function(){As(e[17])&&e[17].apply(this,arguments)}),{c(){B(t.$$.fragment)},l(s){N(t.$$.fragment,s)},m(s,r){U(t,s,r),o=!0},p(s,r){e=s},i(s){o||(k(t.$$.fragment,s),o=!0)},o(s){w(t.$$.fragment,s),o=!1},d(s){R(t,s)}}}function br(e){let t,o,s,r,i,l=e[5].icon&&Qe(e);const u=e[11].default,n=at(u,e,e[13],null);let a=e[0]&&ts(e);return{c(){l&&l.c(),t=et(),o=V("div"),n&&n.c(),s=et(),a&&a.c(),r=Nt(),this.h()},l(c){l&&l.l(c),t=st(c),o=F(c,"DIV",{class:!0});var h=P(o);n&&n.l(h),h.forEach(f),s=st(c),a&&a.l(c),r=Nt(),this.h()},h(){y(o,"class",e[1])},m(c,h){l&&l.m(c,h),x(c,t,h),x(c,o,h),n&&n.m(o,null),x(c,s,h),a&&a.m(c,h),x(c,r,h),i=!0},p(c,h){c[5].icon?l?(l.p(c,h),h&32&&k(l,1)):(l=Qe(c),l.c(),k(l,1),l.m(t.parentNode,t)):l&&(Rt(),w(l,1,1,()=>{l=null}),Ht()),n&&n.p&&(!i||h&8192)&&ut(n,u,c,c[13],i?dt(u,c[13],h,null):ct(c[13]),null),(!i||h&2)&&y(o,"class",c[1]),c[0]?a?(a.p(c,h),h&1&&k(a,1)):(a=ts(c),a.c(),k(a,1),a.m(r.parentNode,r)):a&&(Rt(),w(a,1,1,()=>{a=null}),Ht())},i(c){i||(k(l),k(n,c),k(a),i=!0)},o(c){w(l),w(n,c),w(a),i=!1},d(c){c&&(f(t),f(o),f(s),f(r)),l&&l.d(c),n&&n.d(c),a&&a.d(c)}}}function gr(e){let t,o;const s=[{rounded:!0},{dismissable:e[0]},{color:"none"},{role:"alert"},e[4],{class:e[2]}];let r={$$slots:{default:[br,({close:i})=>({17:i}),({close:i})=>i?131072:0]},$$scope:{ctx:e}};for(let i=0;i<s.length;i+=1)r=M(r,s[i]);return t=new js({props:r}),t.$on("close",e[12]),{c(){B(t.$$.fragment)},l(i){N(t.$$.fragment,i)},m(i,l){U(t,i,l),o=!0},p(i,[l]){const u=l&21?_t(s,[s[0],l&1&&{dismissable:i[0]},s[2],s[3],l&16&&hs(i[4]),l&4&&{class:i[2]}]):{};l&139307&&(u.$$scope={dirty:l,ctx:i}),t.$set(u)},i(i){o||(k(t.$$.fragment,i),o=!0)},o(i){w(t.$$.fragment,i),o=!1},d(i){R(t,i)}}}const vr="-mx-1.5 -my-1.5 text-gray-400 hover:text-gray-900 focus:!ring-gray-300 hover:bg-gray-100 dark:text-gray-500 dark:hover:text-white dark:hover:bg-gray-700";function _r(e,t,o){const s=["dismissable","color","position","divClass","defaultIconClass","contentClass","align"];let r=Z(t,s),{$$slots:i={},$$scope:l}=t;const u=Ss(i);let{dismissable:n=!0}=t,{color:a="primary"}=t,{position:c="none"}=t,{divClass:h="w-full max-w-xs p-4 text-gray-500 bg-white shadow dark:text-gray-400 dark:bg-gray-800 gap-3"}=t,{defaultIconClass:b="w-8 h-8"}=t,{contentClass:v="w-full text-sm font-normal"}=t,{align:m=!0}=t;const L={"top-left":"absolute top-5 start-5","top-right":"absolute top-5 end-5","bottom-left":"absolute bottom-5 start-5","bottom-right":"absolute bottom-5 end-5",none:""};let q;const T={primary:"text-primary-500 bg-primary-100 dark:bg-primary-800 dark:text-primary-200",gray:"text-gray-500 bg-gray-100 dark:bg-gray-700 dark:text-gray-200",red:"text-red-500 bg-red-100 dark:bg-red-800 dark:text-red-200",yellow:"text-yellow-500 bg-yellow-100 dark:bg-yellow-800 dark:text-yellow-200",green:"text-green-500 bg-green-100 dark:bg-green-800 dark:text-green-200",blue:"text-blue-500 bg-blue-100 dark:bg-blue-800 dark:text-blue-200",indigo:"text-indigo-500 bg-indigo-100 dark:bg-indigo-800 dark:text-indigo-200",purple:"text-purple-500 bg-purple-100 dark:bg-purple-800 dark:text-purple-200",orange:"text-orange-500 bg-orange-100 dark:bg-orange-700 dark:text-orange-200",none:""};let j;function g(_){A.call(this,e,_)}return e.$$set=_=>{o(16,t=M(M({},t),X(_))),o(4,r=Z(t,s)),"dismissable"in _&&o(0,n=_.dismissable),"color"in _&&o(6,a=_.color),"position"in _&&o(7,c=_.position),"divClass"in _&&o(8,h=_.divClass),"defaultIconClass"in _&&o(9,b=_.defaultIconClass),"contentClass"in _&&o(1,v=_.contentClass),"align"in _&&o(10,m=_.align),"$$scope"in _&&o(13,l=_.$$scope)},e.$$.update=()=>{o(2,q=G("flex",m?"items-center":"items-start",h,L[c],t.class)),e.$$.dirty&576&&o(3,j=G("inline-flex items-center justify-center shrink-0",T[a],b))},t=X(t),[n,v,q,j,r,u,a,c,h,b,m,i,g,l]}class xe extends ot{constructor(t){super(),rt(this,t,_r,gr,Q,{dismissable:0,color:6,position:7,divClass:8,defaultIconClass:9,contentClass:1,align:10})}}const yr="appAgentClient";function kr(e){let t,o,s,r,i,l=[{xmlns:"http://www.w3.org/2000/svg"},{fill:"currentColor"},e[4],{class:s=G("shrink-0",e[3][e[0]],e[5].class)},{role:e[1]},{"aria-label":e[2]},{viewBox:"0 0 24 24"}],u={};for(let n=0;n<l.length;n+=1)u=M(u,l[n]);return{c(){t=pt("svg"),o=pt("path"),this.h()},l(n){t=mt(n,"svg",{xmlns:!0,fill:!0,class:!0,role:!0,"aria-label":!0,viewBox:!0});var a=P(t);o=mt(a,"path",{fill:!0,"fill-rule":!0,d:!0,"clip-rule":!0}),P(o).forEach(f),a.forEach(f),this.h()},h(){y(o,"fill","currentColor"),y(o,"fill-rule","evenodd"),y(o,"d","M2 12a10 10 0 1 1 20 0 10 10 0 0 1-20 0Zm13.7-1.3a1 1 0 0 0-1.4-1.4L11 12.6l-1.8-1.8a1 1 0 0 0-1.4 1.4l2.5 2.5c.4.4 1 .4 1.4 0l4-4Z"),y(o,"clip-rule","evenodd"),Ut(t,u)},m(n,a){x(n,t,a),W(t,o),r||(i=[S(t,"click",e[6]),S(t,"keydown",e[7]),S(t,"keyup",e[8]),S(t,"focus",e[9]),S(t,"blur",e[10]),S(t,"mouseenter",e[11]),S(t,"mouseleave",e[12]),S(t,"mouseover",e[13]),S(t,"mouseout",e[14])],r=!0)},p(n,[a]){Ut(t,u=_t(l,[{xmlns:"http://www.w3.org/2000/svg"},{fill:"currentColor"},a&16&&n[4],a&33&&s!==(s=G("shrink-0",n[3][n[0]],n[5].class))&&{class:s},a&2&&{role:n[1]},a&4&&{"aria-label":n[2]},{viewBox:"0 0 24 24"}]))},i:ht,o:ht,d(n){n&&f(t),r=!1,ve(i)}}}function wr(e,t,o){const s=["size","role","ariaLabel"];let r=Z(t,s);const i=Bt("iconCtx")??{},l={xs:"w-3 h-3",sm:"w-4 h-4",md:"w-5 h-5",lg:"w-6 h-6",xl:"w-8 h-8"};let{size:u=i.size||"md"}=t,{role:n=i.role||"img"}=t,{ariaLabel:a="check circle solid"}=t;function c(g){A.call(this,e,g)}function h(g){A.call(this,e,g)}function b(g){A.call(this,e,g)}function v(g){A.call(this,e,g)}function m(g){A.call(this,e,g)}function L(g){A.call(this,e,g)}function q(g){A.call(this,e,g)}function T(g){A.call(this,e,g)}function j(g){A.call(this,e,g)}return e.$$set=g=>{o(5,t=M(M({},t),X(g))),o(4,r=Z(t,s)),"size"in g&&o(0,u=g.size),"role"in g&&o(1,n=g.role),"ariaLabel"in g&&o(2,a=g.ariaLabel)},t=X(t),[u,n,a,l,r,t,c,h,b,v,m,L,q,T,j]}class Cr extends ot{constructor(t){super(),rt(this,t,wr,kr,Q,{size:0,role:1,ariaLabel:2})}}function xr(e){let t,o,s,r,i,l=[{xmlns:"http://www.w3.org/2000/svg"},{fill:"currentColor"},e[7],{class:s=G("shrink-0",e[6][e[0]],e[8].class)},{role:e[1]},{"aria-label":e[5]},{viewBox:"0 0 24 24"}],u={};for(let n=0;n<l.length;n+=1)u=M(u,l[n]);return{c(){t=pt("svg"),o=pt("path"),this.h()},l(n){t=mt(n,"svg",{xmlns:!0,fill:!0,class:!0,role:!0,"aria-label":!0,viewBox:!0});var a=P(t);o=mt(a,"path",{stroke:!0,"stroke-linecap":!0,"stroke-linejoin":!0,"stroke-width":!0,d:!0}),P(o).forEach(f),a.forEach(f),this.h()},h(){y(o,"stroke","currentColor"),y(o,"stroke-linecap",e[2]),y(o,"stroke-linejoin",e[3]),y(o,"stroke-width",e[4]),y(o,"d","M6 18 18 6m0 12L6 6"),Ut(t,u)},m(n,a){x(n,t,a),W(t,o),r||(i=[S(t,"click",e[9]),S(t,"keydown",e[10]),S(t,"keyup",e[11]),S(t,"focus",e[12]),S(t,"blur",e[13]),S(t,"mouseenter",e[14]),S(t,"mouseleave",e[15]),S(t,"mouseover",e[16]),S(t,"mouseout",e[17])],r=!0)},p(n,[a]){a&4&&y(o,"stroke-linecap",n[2]),a&8&&y(o,"stroke-linejoin",n[3]),a&16&&y(o,"stroke-width",n[4]),Ut(t,u=_t(l,[{xmlns:"http://www.w3.org/2000/svg"},{fill:"currentColor"},a&128&&n[7],a&257&&s!==(s=G("shrink-0",n[6][n[0]],n[8].class))&&{class:s},a&2&&{role:n[1]},a&32&&{"aria-label":n[5]},{viewBox:"0 0 24 24"}]))},i:ht,o:ht,d(n){n&&f(t),r=!1,ve(i)}}}function Er(e,t,o){const s=["size","role","strokeLinecap","strokeLinejoin","strokeWidth","ariaLabel"];let r=Z(t,s);const i=Bt("iconCtx")??{},l={xs:"w-3 h-3",sm:"w-4 h-4",md:"w-5 h-5",lg:"w-6 h-6",xl:"w-8 h-8"};let{size:u=i.size||"md"}=t,{role:n=i.role||"img"}=t,{strokeLinecap:a=i.strokeLinecap||"round"}=t,{strokeLinejoin:c=i.strokeLinejoin||"round"}=t,{strokeWidth:h=i.strokeWidth||"2"}=t,{ariaLabel:b="close solid"}=t;function v($){A.call(this,e,$)}function m($){A.call(this,e,$)}function L($){A.call(this,e,$)}function q($){A.call(this,e,$)}function T($){A.call(this,e,$)}function j($){A.call(this,e,$)}function g($){A.call(this,e,$)}function _($){A.call(this,e,$)}function C($){A.call(this,e,$)}return e.$$set=$=>{o(8,t=M(M({},t),X($))),o(7,r=Z(t,s)),"size"in $&&o(0,u=$.size),"role"in $&&o(1,n=$.role),"strokeLinecap"in $&&o(2,a=$.strokeLinecap),"strokeLinejoin"in $&&o(3,c=$.strokeLinejoin),"strokeWidth"in $&&o(4,h=$.strokeWidth),"ariaLabel"in $&&o(5,b=$.ariaLabel)},t=X(t),[u,n,a,c,h,b,l,r,t,v,m,L,q,T,j,g,_,C]}class Sr extends ot{constructor(t){super(),rt(this,t,Er,xr,Q,{size:0,role:1,strokeLinecap:2,strokeLinejoin:3,strokeWidth:4,ariaLabel:5})}}function Ar(e){let t,o,s,r,i,l=[{xmlns:"http://www.w3.org/2000/svg"},{fill:"currentColor"},e[4],{class:s=G("shrink-0",e[3][e[0]],e[5].class)},{role:e[1]},{"aria-label":e[2]},{viewBox:"0 0 24 24"}],u={};for(let n=0;n<l.length;n+=1)u=M(u,l[n]);return{c(){t=pt("svg"),o=pt("path"),this.h()},l(n){t=mt(n,"svg",{xmlns:!0,fill:!0,class:!0,role:!0,"aria-label":!0,viewBox:!0});var a=P(t);o=mt(a,"path",{fill:!0,"fill-rule":!0,d:!0,"clip-rule":!0}),P(o).forEach(f),a.forEach(f),this.h()},h(){y(o,"fill","currentColor"),y(o,"fill-rule","evenodd"),y(o,"d","M2 12a10 10 0 1 1 20 0 10 10 0 0 1-20 0Zm11-4a1 1 0 1 0-2 0v5a1 1 0 1 0 2 0V8Zm-1 7a1 1 0 1 0 0 2 1 1 0 1 0 0-2Z"),y(o,"clip-rule","evenodd"),Ut(t,u)},m(n,a){x(n,t,a),W(t,o),r||(i=[S(t,"click",e[6]),S(t,"keydown",e[7]),S(t,"keyup",e[8]),S(t,"focus",e[9]),S(t,"blur",e[10]),S(t,"mouseenter",e[11]),S(t,"mouseleave",e[12]),S(t,"mouseover",e[13]),S(t,"mouseout",e[14])],r=!0)},p(n,[a]){Ut(t,u=_t(l,[{xmlns:"http://www.w3.org/2000/svg"},{fill:"currentColor"},a&16&&n[4],a&33&&s!==(s=G("shrink-0",n[3][n[0]],n[5].class))&&{class:s},a&2&&{role:n[1]},a&4&&{"aria-label":n[2]},{viewBox:"0 0 24 24"}]))},i:ht,o:ht,d(n){n&&f(t),r=!1,ve(i)}}}function $r(e,t,o){const s=["size","role","ariaLabel"];let r=Z(t,s);const i=Bt("iconCtx")??{},l={xs:"w-3 h-3",sm:"w-4 h-4",md:"w-5 h-5",lg:"w-6 h-6",xl:"w-8 h-8"};let{size:u=i.size||"md"}=t,{role:n=i.role||"img"}=t,{ariaLabel:a="exclamation circle solid"}=t;function c(g){A.call(this,e,g)}function h(g){A.call(this,e,g)}function b(g){A.call(this,e,g)}function v(g){A.call(this,e,g)}function m(g){A.call(this,e,g)}function L(g){A.call(this,e,g)}function q(g){A.call(this,e,g)}function T(g){A.call(this,e,g)}function j(g){A.call(this,e,g)}return e.$$set=g=>{o(5,t=M(M({},t),X(g))),o(4,r=Z(t,s)),"size"in g&&o(0,u=g.size),"role"in g&&o(1,n=g.role),"ariaLabel"in g&&o(2,a=g.ariaLabel)},t=X(t),[u,n,a,l,r,t,c,h,b,v,m,L,q,T,j]}class Pr extends ot{constructor(t){super(),rt(this,t,$r,Ar,Q,{size:0,role:1,ariaLabel:2})}}function Lr(e){let t,o;return t=new xe({props:{color:"blue",$$slots:{icon:[Vr],default:[Dr]},$$scope:{ctx:e}}}),{c(){B(t.$$.fragment)},l(s){N(t.$$.fragment,s)},m(s,r){U(t,s,r),o=!0},p(s,r){const i={};r&3&&(i.$$scope={dirty:r,ctx:s}),t.$set(i)},i(s){o||(k(t.$$.fragment,s),o=!0)},o(s){w(t.$$.fragment,s),o=!1},d(s){R(t,s)}}}function zr(e){let t,o;return t=new xe({props:{color:"yellow",$$slots:{icon:[Mr],default:[Fr]},$$scope:{ctx:e}}}),{c(){B(t.$$.fragment)},l(s){N(t.$$.fragment,s)},m(s,r){U(t,s,r),o=!0},p(s,r){const i={};r&3&&(i.$$scope={dirty:r,ctx:s}),t.$set(i)},i(s){o||(k(t.$$.fragment,s),o=!0)},o(s){w(t.$$.fragment,s),o=!1},d(s){R(t,s)}}}function Tr(e){let t,o;return t=new xe({props:{color:"red",$$slots:{icon:[Br],default:[Or]},$$scope:{ctx:e}}}),{c(){B(t.$$.fragment)},l(s){N(t.$$.fragment,s)},m(s,r){U(t,s,r),o=!0},p(s,r){const i={};r&3&&(i.$$scope={dirty:r,ctx:s}),t.$set(i)},i(s){o||(k(t.$$.fragment,s),o=!0)},o(s){w(t.$$.fragment,s),o=!1},d(s){R(t,s)}}}function Ir(e){let t,o;return t=new xe({props:{color:"green",$$slots:{icon:[Ur],default:[Nr]},$$scope:{ctx:e}}}),{c(){B(t.$$.fragment)},l(s){N(t.$$.fragment,s)},m(s,r){U(t,s,r),o=!0},p(s,r){const i={};r&3&&(i.$$scope={dirty:r,ctx:s}),t.$set(i)},i(s){o||(k(t.$$.fragment,s),o=!0)},o(s){w(t.$$.fragment,s),o=!1},d(s){R(t,s)}}}function Dr(e){let t,o=e[0].text+"",s,r;return{c(){t=V("span"),s=St(o),this.h()},l(i){t=F(i,"SPAN",{class:!0});var l=P(t);s=At(l,o),l.forEach(f),this.h()},h(){y(t,"class",r=e[0].break_text?"break-all":"")},m(i,l){x(i,t,l),W(t,s)},p(i,l){l&1&&o!==(o=i[0].text+"")&&_e(s,o),l&1&&r!==(r=i[0].break_text?"break-all":"")&&y(t,"class",r)},d(i){i&&f(t)}}}function Vr(e){let t,o;return t=new Ks({props:{slot:"icon",class:"h-5 w-5"}}),{c(){B(t.$$.fragment)},l(s){N(t.$$.fragment,s)},m(s,r){U(t,s,r),o=!0},p:ht,i(s){o||(k(t.$$.fragment,s),o=!0)},o(s){w(t.$$.fragment,s),o=!1},d(s){R(t,s)}}}function Fr(e){let t,o=e[0].text+"",s,r;return{c(){t=V("span"),s=St(o),this.h()},l(i){t=F(i,"SPAN",{class:!0});var l=P(t);s=At(l,o),l.forEach(f),this.h()},h(){y(t,"class",r=e[0].break_text?"break-all":"")},m(i,l){x(i,t,l),W(t,s)},p(i,l){l&1&&o!==(o=i[0].text+"")&&_e(s,o),l&1&&r!==(r=i[0].break_text?"break-all":"")&&y(t,"class",r)},d(i){i&&f(t)}}}function Mr(e){let t,o;return t=new Pr({props:{slot:"icon",class:"h-5 w-5"}}),{c(){B(t.$$.fragment)},l(s){N(t.$$.fragment,s)},m(s,r){U(t,s,r),o=!0},p:ht,i(s){o||(k(t.$$.fragment,s),o=!0)},o(s){w(t.$$.fragment,s),o=!1},d(s){R(t,s)}}}function Or(e){let t,o=e[0].text+"",s,r;return{c(){t=V("span"),s=St(o),this.h()},l(i){t=F(i,"SPAN",{class:!0});var l=P(t);s=At(l,o),l.forEach(f),this.h()},h(){y(t,"class",r=e[0].break_text?"break-all":"")},m(i,l){x(i,t,l),W(t,s)},p(i,l){l&1&&o!==(o=i[0].text+"")&&_e(s,o),l&1&&r!==(r=i[0].break_text?"break-all":"")&&y(t,"class",r)},d(i){i&&f(t)}}}function Br(e){let t,o;return t=new Sr({props:{slot:"icon",class:"h-5 w-5"}}),{c(){B(t.$$.fragment)},l(s){N(t.$$.fragment,s)},m(s,r){U(t,s,r),o=!0},p:ht,i(s){o||(k(t.$$.fragment,s),o=!0)},o(s){w(t.$$.fragment,s),o=!1},d(s){R(t,s)}}}function Nr(e){let t,o=e[0].text+"",s,r;return{c(){t=V("span"),s=St(o),this.h()},l(i){t=F(i,"SPAN",{class:!0});var l=P(t);s=At(l,o),l.forEach(f),this.h()},h(){y(t,"class",r=e[0].break_text?"break-all":"")},m(i,l){x(i,t,l),W(t,s)},p(i,l){l&1&&o!==(o=i[0].text+"")&&_e(s,o),l&1&&r!==(r=i[0].break_text?"break-all":"")&&y(t,"class",r)},d(i){i&&f(t)}}}function Ur(e){let t,o;return t=new Cr({props:{slot:"icon",class:"h-5 w-5"}}),{c(){B(t.$$.fragment)},l(s){N(t.$$.fragment,s)},m(s,r){U(t,s,r),o=!0},p:ht,i(s){o||(k(t.$$.fragment,s),o=!0)},o(s){w(t.$$.fragment,s),o=!1},d(s){R(t,s)}}}function Rr(e){let t,o,s,r;const i=[Ir,Tr,zr,Lr],l=[];function u(n,a){return n[0].message_type==="Success"?0:n[0].message_type==="Error"?1:n[0].message_type==="Warning"?2:3}return o=u(e),s=l[o]=i[o](e),{c(){t=V("div"),s.c(),this.h()},l(n){t=F(n,"DIV",{class:!0});var a=P(t);s.l(a),a.forEach(f),this.h()},h(){y(t,"class","mt-2")},m(n,a){x(n,t,a),l[o].m(t,null),r=!0},p(n,[a]){let c=o;o=u(n),o===c?l[o].p(n,a):(Rt(),w(l[c],1,1,()=>{l[c]=null}),Ht(),s=l[o],s?s.p(n,a):(s=l[o]=i[o](n),s.c()),k(s,1),s.m(t,null))},i(n){r||(k(s),r=!0)},o(n){w(s),r=!1},d(n){n&&f(t),l[o].d()}}}function Hr(e,t,o){let{toast:s}=t;return e.$$set=r=>{"toast"in r&&o(0,s=r.toast)},[s]}class qr extends ot{constructor(t){super(),rt(this,t,Hr,Rr,Q,{toast:0})}}function es(e,t,o){const s=e.slice();return s[1]=t[o],s}function ss(e){let t,o,s,r;return o=new qr({props:{toast:e[1]}}),{c(){t=V("div"),B(o.$$.fragment),s=et(),this.h()},l(i){t=F(i,"DIV",{class:!0});var l=P(t);N(o.$$.fragment,l),s=st(l),l.forEach(f),this.h()},h(){y(t,"class","flex justify-end")},m(i,l){x(i,t,l),U(o,t,null),W(t,s),r=!0},p(i,l){const u={};l&1&&(u.toast=i[1]),o.$set(u)},i(i){r||(k(o.$$.fragment,i),r=!0)},o(i){w(o.$$.fragment,i),r=!1},d(i){i&&f(t),R(o)}}}function jr(e){let t,o,s=Be(e[0]),r=[];for(let l=0;l<s.length;l+=1)r[l]=ss(es(e,s,l));const i=l=>w(r[l],1,1,()=>{r[l]=null});return{c(){for(let l=0;l<r.length;l+=1)r[l].c();t=Nt()},l(l){for(let u=0;u<r.length;u+=1)r[u].l(l);t=Nt()},m(l,u){for(let n=0;n<r.length;n+=1)r[n]&&r[n].m(l,u);x(l,t,u),o=!0},p(l,[u]){if(u&1){s=Be(l[0]);let n;for(n=0;n<s.length;n+=1){const a=es(l,s,n);r[n]?(r[n].p(a,u),k(r[n],1)):(r[n]=ss(a),r[n].c(),k(r[n],1),r[n].m(t.parentNode,t))}for(Rt(),n=s.length;n<r.length;n+=1)i(n);Ht()}},i(l){if(!o){for(let u=0;u<s.length;u+=1)k(r[u]);o=!0}},o(l){r=r.filter(Boolean);for(let u=0;u<r.length;u+=1)w(r[u]);o=!1},d(l){l&&f(t),$s(r,l)}}}function Wr(e,t,o){let s;return Ot(e,Hs,r=>o(0,s=r)),[s]}class Kr extends ot{constructor(t){super(),rt(this,t,Wr,jr,Q,{})}}function Yr(e){let t,o="Distributed Funds";return{c(){t=V("span"),t.textContent=o,this.h()},l(s){t=F(s,"SPAN",{class:!0,"data-svelte-h":!0}),os(t)!=="svelte-htp48q"&&(t.textContent=o),this.h()},h(){y(t,"class","font-stencil self-center whitespace-nowrap text-4xl font-semibold text-black dark:text-slate-300")},m(s,r){x(s,t,r)},p:ht,d(s){s&&f(t)}}}function Xr(e){let t;return{c(){t=St("Time Periods")},l(o){t=At(o,"Time Periods")},m(o,s){x(o,t,s)},d(o){o&&f(t)}}}function Gr(e){let t;return{c(){t=St("Grant Pools")},l(o){t=At(o,"Grant Pools")},m(o,s){x(o,t,s)},d(o){o&&f(t)}}}function Zr(e){let t;return{c(){t=St("My Applications")},l(o){t=At(o,"My Applications")},m(o,s){x(o,t,s)},d(o){o&&f(t)}}}function Jr(e){let t;return{c(){t=St("My Evaluations")},l(o){t=At(o,"My Evaluations")},m(o,s){x(o,t,s)},d(o){o&&f(t)}}}function Qr(e){let t,o;return{c(){t=V("agent-avatar"),this.h()},l(s){t=F(s,"AGENT-AVATAR",{"disable-copy":!0,"disable-tooltip":!0,agentPubKey:!0}),P(t).forEach(f),this.h()},h(){Mt(t,"disable-copy",""),Mt(t,"disable-tooltip",""),Mt(t,"agentPubKey",o=e[1].client.myPubKey)},m(s,r){x(s,t,r)},p(s,r){r&2&&o!==(o=s[1].client.myPubKey)&&Mt(t,"agentPubKey",o)},d(s){s&&f(t)}}}function ti(e){let t,o,s,r,i,l,u,n,a,c,h;return o=new ie({props:{href:"/time-periods",$$slots:{default:[Xr]},$$scope:{ctx:e}}}),r=new ie({props:{href:"/grant-pools",$$slots:{default:[Gr]},$$scope:{ctx:e}}}),l=new ie({props:{href:"/my-applications",$$slots:{default:[Zr]},$$scope:{ctx:e}}}),n=new ie({props:{href:"/my-assigned-evaluations",$$slots:{default:[Jr]},$$scope:{ctx:e}}}),c=new Ys({props:{color:"alternative",size:"xs",href:`/profiles/${Pe(e[1].client.myPubKey)}`,$$slots:{default:[Qr]},$$scope:{ctx:e}}}),{c(){t=V("div"),B(o.$$.fragment),s=et(),B(r.$$.fragment),i=et(),B(l.$$.fragment),u=et(),B(n.$$.fragment),a=et(),B(c.$$.fragment),this.h()},l(b){t=F(b,"DIV",{class:!0});var v=P(t);N(o.$$.fragment,v),s=st(v),N(r.$$.fragment,v),i=st(v),N(l.$$.fragment,v),u=st(v),N(n.$$.fragment,v),a=st(v),N(c.$$.fragment,v),v.forEach(f),this.h()},h(){y(t,"class","flex items-center space-x-8")},m(b,v){x(b,t,v),U(o,t,null),W(t,s),U(r,t,null),W(t,i),U(l,t,null),W(t,u),U(n,t,null),W(t,a),U(c,t,null),h=!0},p(b,v){const m={};v&16&&(m.$$scope={dirty:v,ctx:b}),o.$set(m);const L={};v&16&&(L.$$scope={dirty:v,ctx:b}),r.$set(L);const q={};v&16&&(q.$$scope={dirty:v,ctx:b}),l.$set(q);const T={};v&16&&(T.$$scope={dirty:v,ctx:b}),n.$set(T);const j={};v&2&&(j.href=`/profiles/${Pe(b[1].client.myPubKey)}`),v&18&&(j.$$scope={dirty:v,ctx:b}),c.$set(j)},i(b){h||(k(o.$$.fragment,b),k(r.$$.fragment,b),k(l.$$.fragment,b),k(n.$$.fragment,b),k(c.$$.fragment,b),h=!0)},o(b){w(o.$$.fragment,b),w(r.$$.fragment,b),w(l.$$.fragment,b),w(n.$$.fragment,b),w(c.$$.fragment,b),h=!1},d(b){b&&f(t),R(o),R(r),R(l),R(n),R(c)}}}function ei(e){let t,o,s,r;return t=new or({props:{href:"/",$$slots:{default:[Yr]},$$scope:{ctx:e}}}),s=new dr({props:{hidden:e[3],activeUrl:e[0],class:"flex items-center",$$slots:{default:[ti]},$$scope:{ctx:e}}}),{c(){B(t.$$.fragment),o=et(),B(s.$$.fragment)},l(i){N(t.$$.fragment,i),o=st(i),N(s.$$.fragment,i)},m(i,l){U(t,i,l),x(i,o,l),U(s,i,l),r=!0},p(i,l){const u={};l&16&&(u.$$scope={dirty:l,ctx:i}),t.$set(u);const n={};l&8&&(n.hidden=i[3]),l&1&&(n.activeUrl=i[0]),l&18&&(n.$$scope={dirty:l,ctx:i}),s.$set(n)},i(i){r||(k(t.$$.fragment,i),k(s.$$.fragment,i),r=!0)},o(i){w(t.$$.fragment,i),w(s.$$.fragment,i),r=!1},d(i){i&&f(o),R(t,i),R(s,i)}}}function si(e){let t,o,s;return o=new tr({props:{$$slots:{default:[ei,({hidden:r})=>({3:r}),({hidden:r})=>r?8:0]},$$scope:{ctx:e}}}),{c(){t=V("div"),B(o.$$.fragment),this.h()},l(r){t=F(r,"DIV",{class:!0});var i=P(t);N(o.$$.fragment,i),i.forEach(f),this.h()},h(){y(t,"class","relative flex items-start justify-center")},m(r,i){x(r,t,i),U(o,t,null),s=!0},p(r,[i]){const l={};i&27&&(l.$$scope={dirty:i,ctx:r}),o.$set(l)},i(r){s||(k(o.$$.fragment,r),s=!0)},o(r){w(o.$$.fragment,r),s=!1},d(r){r&&f(t),R(o)}}}function oi(e,t,o){let s,r,i;return Ot(e,Gs,l=>o(2,r=l)),Ot(e,le,l=>o(1,i=l)),e.$$.update=()=>{e.$$.dirty&4&&o(0,s=r.url.pathname)},[s,i,r]}class ri extends ot{constructor(t){super(),rt(this,t,oi,si,Q,{})}}function ii(e){let t,o,s,r,i,l,u,n,a,c,h;t=new ri({});const b=e[2].default,v=at(b,e,e[1],null);return u=new Kr({}),c=new ws({props:{btnClass:"rounded text-gray-700 hover:bg-gray-100 md:hover:bg-transparent md:border-0 md:hover:text-primary-700 dark:text-gray-400 md:dark:hover:text-white dark:hover:bg-gray-700 dark:hover:text-white md:dark:hover:bg-transparent"}}),{c(){B(t.$$.fragment),o=et(),s=V("main"),r=V("div"),v&&v.c(),i=et(),l=V("div"),B(u.$$.fragment),n=et(),a=V("div"),B(c.$$.fragment),this.h()},l(m){N(t.$$.fragment,m),o=st(m),s=F(m,"MAIN",{class:!0});var L=P(s);r=F(L,"DIV",{class:!0});var q=P(r);v&&v.l(q),q.forEach(f),L.forEach(f),i=st(m),l=F(m,"DIV",{class:!0});var T=P(l);N(u.$$.fragment,T),T.forEach(f),n=st(m),a=F(m,"DIV",{class:!0});var j=P(a);N(c.$$.fragment,j),j.forEach(f),this.h()},h(){y(r,"class","h-full w-full max-w-screen-md pb-16"),y(s,"class","flex w-full flex-grow grow justify-center overflow-x-auto"),y(l,"class","fixed right-5 top-5 z-50 w-full max-w-md"),y(a,"class","fixed bottom-1 right-1")},m(m,L){U(t,m,L),x(m,o,L),x(m,s,L),W(s,r),v&&v.m(r,null),x(m,i,L),x(m,l,L),U(u,l,null),x(m,n,L),x(m,a,L),U(c,a,null),h=!0},p(m,L){v&&v.p&&(!h||L&2)&&ut(v,b,m,m[1],h?dt(b,m[1],L,null):ct(m[1]),null)},i(m){h||(k(t.$$.fragment,m),k(v,m),k(u.$$.fragment,m),k(c.$$.fragment,m),h=!0)},o(m){w(t.$$.fragment,m),w(v,m),w(u.$$.fragment,m),w(c.$$.fragment,m),h=!1},d(m){m&&(f(o),f(s),f(i),f(l),f(n),f(a)),R(t,m),v&&v.d(m),R(u),R(c)}}}function li(e){let t,o,s,r,i,l;return o=new qs({props:{class:"h-14 w-14"}}),i=new ws({}),{c(){t=V("div"),B(o.$$.fragment),s=et(),r=V("div"),B(i.$$.fragment),this.h()},l(u){t=F(u,"DIV",{class:!0});var n=P(t);N(o.$$.fragment,n),s=st(n),r=F(n,"DIV",{class:!0});var a=P(r);N(i.$$.fragment,a),a.forEach(f),n.forEach(f),this.h()},h(){y(r,"class","hidden"),y(t,"class","flex h-screen w-full items-center justify-center")},m(u,n){x(u,t,n),U(o,t,null),W(t,s),W(t,r),U(i,r,null),l=!0},p:ht,i(u){l||(k(o.$$.fragment,u),k(i.$$.fragment,u),l=!0)},o(u){w(o.$$.fragment,u),w(i.$$.fragment,u),l=!1},d(u){u&&f(t),R(o),R(i)}}}function ni(e){let t,o,s,r,i,l;const u=[li,ii],n=[];function a(c,h){return c[0].isConnecting?0:1}return s=a(e),r=n[s]=u[s](e),{c(){t=V("profiles-context"),o=V("div"),r.c(),this.h()},l(c){t=F(c,"PROFILES-CONTEXT",{store:!0});var h=P(t);o=F(h,"DIV",{class:!0});var b=P(o);r.l(b),b.forEach(f),h.forEach(f),this.h()},h(){y(o,"class","flex min-h-screen w-full flex-col bg-white dark:bg-gray-900"),Mt(t,"store",i=e[0].profilesStore)},m(c,h){x(c,t,h),W(t,o),n[s].m(o,null),l=!0},p(c,[h]){let b=s;s=a(c),s===b?n[s].p(c,h):(Rt(),w(n[b],1,1,()=>{n[b]=null}),Ht(),r=n[s],r?r.p(c,h):(r=n[s]=u[s](c),r.c()),k(r,1),r.m(o,null)),(!l||h&1&&i!==(i=c[0].profilesStore))&&Mt(t,"store",i)},i(c){l||(k(r),l=!0)},o(c){w(r),l=!1},d(c){c&&f(t),n[s].d()}}}function ai(e,t,o){let s;Ot(e,le,l=>o(0,s=l));let{$$slots:r={},$$scope:i}=t;return Ps(async()=>{await le.connect(new URL("ws://unused"),"distributed-funds")}),ae(yr,{getClient:()=>le}),e.$$set=l=>{"$$scope"in l&&o(1,i=l.$$scope)},[s,i,r]}class Ii extends ot{constructor(t){super(),rt(this,t,ai,ni,Q,{})}}export{Ii as component,ki as universal};
