import{a as t}from"../chunks/entry.B2_ArKaw.js";export{t as start};
