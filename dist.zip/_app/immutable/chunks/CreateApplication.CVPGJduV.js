import{s as _1,k as E1,l as Qd,a as Ji,e as Pc,g as Qi,c as Oc,b as kc,f as ht,m as vu,i as Gt,h as $1,o as Xd,E as A1,G as S1,H as I1,I as R1,n as T1,t as e0,d as t0}from"./scheduler.B-whawdI.js";import{S as P1,i as O1,c as Yt,a as Kt,m as Jt,t as Tt,b as Pt,d as Qt,e as n0}from"./index.DKySoX1N.js";import{B as k1}from"./BaseBreadcrumbs.Cr645FsL.js";import{B as N1}from"./BaseHeading.D02hu5zT.js";import{B as M1}from"./BaseFormBuilder.D6Mq5rIo.js";import{R as i0}from"./RecordDetail.yaTjB-DJ.js";import{j as r0,f as L1,h as B1,b as nc,t as yu}from"./holochainClient.jrRPnoXI.js";import{b as G,s as ot,i as ba,t as bl,e as va,h as sr,S as o0,n as Ne,p as pi,j as j1,k as s0,l as D1,m as wi,o as yn,q as U1,r as W1,v as z1,w as a0,f as ya,x as F1,g as vl,I as xu,y as H1,z as V1,C as Z1,W as c0,d as Cu,B as _u,A as q1,a as G1,u as Eu}from"./u256.B5SpBLfz.js";import{I as Y1}from"./InputTokenAmount.FnWgCbfy.js";import{B as $u}from"./Button.CzIbOgsp.js";import{g as Au}from"./entry.B2_ArKaw.js";import{S as Su}from"./types.wUYqzdJS.js";import{d as ar,r as K1}from"./relativeTime.CRcQu9SG.js";import{_ as ho}from"./preload-helper.BQ24v_F8.js";function J1(n,e){const t=n.exec(e);return t==null?void 0:t.groups}const Iu=/^tuple(?<array>(\[(\d*)\])*)$/;function Nc(n){let e=n.type;if(Iu.test(n.type)&&"components"in n){e="(";const t=n.components.length;for(let o=0;o<t;o++){const r=n.components[o];e+=Nc(r),o<t-1&&(e+=", ")}const i=J1(Iu,n.type);return e+=`)${(i==null?void 0:i.array)??""}`,Nc({...n,type:e})}return"indexed"in n&&n.indexed&&(e=`${e} indexed`),n.name?`${e} ${n.name}`:e}function qr(n){let e="";const t=n.length;for(let i=0;i<t;i++){const o=n[i];e+=Nc(o),i!==t-1&&(e+=", ")}return e}function Q1(n){return n.type==="function"?`function ${n.name}(${qr(n.inputs)})${n.stateMutability&&n.stateMutability!=="nonpayable"?` ${n.stateMutability}`:""}${n.outputs.length?` returns (${qr(n.outputs)})`:""}`:n.type==="event"?`event ${n.name}(${qr(n.inputs)})`:n.type==="error"?`error ${n.name}(${qr(n.inputs)})`:n.type==="constructor"?`constructor(${qr(n.inputs)})${n.stateMutability==="payable"?" payable":""}`:n.type==="fallback"?"fallback()":"receive() external payable"}function ss(n,e,t){return i=>{var o;return((o=n[e.name||t])==null?void 0:o.call(n,i))??e(n,i)}}function dr(n,{includeName:e=!1}={}){if(n.type!=="function"&&n.type!=="event"&&n.type!=="error")throw new lp(n.type);return`${n.name}(${yl(n.inputs,{includeName:e})})`}function yl(n,{includeName:e=!1}={}){return n?n.map(t=>X1(t,{includeName:e})).join(e?", ":","):""}function X1(n,{includeName:e}){return n.type.startsWith("tuple")?`(${yl(n.components,{includeName:e})})${n.type.slice(5)}`:n.type+(e&&n.name?` ${n.name}`:"")}class ep extends G{constructor({data:e,params:t,size:i}){super([`Data size of ${i} bytes is too small for given parameters.`].join(`
`),{metaMessages:[`Params: (${yl(t,{includeName:!0})})`,`Data:   ${e} (${i} bytes)`]}),Object.defineProperty(this,"name",{enumerable:!0,configurable:!0,writable:!0,value:"AbiDecodingDataSizeTooSmallError"}),Object.defineProperty(this,"data",{enumerable:!0,configurable:!0,writable:!0,value:void 0}),Object.defineProperty(this,"params",{enumerable:!0,configurable:!0,writable:!0,value:void 0}),Object.defineProperty(this,"size",{enumerable:!0,configurable:!0,writable:!0,value:void 0}),this.data=e,this.params=t,this.size=i}}class xa extends G{constructor(){super('Cannot decode zero data ("0x") with ABI parameters.'),Object.defineProperty(this,"name",{enumerable:!0,configurable:!0,writable:!0,value:"AbiDecodingZeroDataError"})}}class tp extends G{constructor({expectedLength:e,givenLength:t,type:i}){super([`ABI encoding array length mismatch for type ${i}.`,`Expected length: ${e}`,`Given length: ${t}`].join(`
`)),Object.defineProperty(this,"name",{enumerable:!0,configurable:!0,writable:!0,value:"AbiEncodingArrayLengthMismatchError"})}}class np extends G{constructor({expectedSize:e,value:t}){super(`Size of bytes "${t}" (bytes${ot(t)}) does not match expected size (bytes${e}).`),Object.defineProperty(this,"name",{enumerable:!0,configurable:!0,writable:!0,value:"AbiEncodingBytesSizeMismatchError"})}}class ip extends G{constructor({expectedLength:e,givenLength:t}){super(["ABI encoding params/values length mismatch.",`Expected length (params): ${e}`,`Given length (values): ${t}`].join(`
`)),Object.defineProperty(this,"name",{enumerable:!0,configurable:!0,writable:!0,value:"AbiEncodingLengthMismatchError"})}}class l0 extends G{constructor(e,{docsPath:t}){super([`Encoded error signature "${e}" not found on ABI.`,"Make sure you are using the correct ABI and that the error exists on it.",`You can look up the decoded signature here: https://openchain.xyz/signatures?query=${e}.`].join(`
`),{docsPath:t}),Object.defineProperty(this,"name",{enumerable:!0,configurable:!0,writable:!0,value:"AbiErrorSignatureNotFoundError"}),Object.defineProperty(this,"signature",{enumerable:!0,configurable:!0,writable:!0,value:void 0}),this.signature=e}}class Ns extends G{constructor(e,{docsPath:t}={}){super([`Function ${e?`"${e}" `:""}not found on ABI.`,"Make sure you are using the correct ABI and that the function exists on it."].join(`
`),{docsPath:t}),Object.defineProperty(this,"name",{enumerable:!0,configurable:!0,writable:!0,value:"AbiFunctionNotFoundError"})}}class rp extends G{constructor(e,{docsPath:t}){super([`Function "${e}" does not contain any \`outputs\` on ABI.`,"Cannot decode function result without knowing what the parameter types are.","Make sure you are using the correct ABI and that the function exists on it."].join(`
`),{docsPath:t}),Object.defineProperty(this,"name",{enumerable:!0,configurable:!0,writable:!0,value:"AbiFunctionOutputsNotFoundError"})}}class op extends G{constructor(e,t){super("Found ambiguous types in overloaded ABI items.",{metaMessages:[`\`${e.type}\` in \`${dr(e.abiItem)}\`, and`,`\`${t.type}\` in \`${dr(t.abiItem)}\``,"","These types encode differently and cannot be distinguished at runtime.","Remove one of the ambiguous items in the ABI."]}),Object.defineProperty(this,"name",{enumerable:!0,configurable:!0,writable:!0,value:"AbiItemAmbiguityError"})}}class sp extends G{constructor(e,{docsPath:t}){super([`Type "${e}" is not a valid encoding type.`,"Please provide a valid ABI type."].join(`
`),{docsPath:t}),Object.defineProperty(this,"name",{enumerable:!0,configurable:!0,writable:!0,value:"InvalidAbiEncodingType"})}}class ap extends G{constructor(e,{docsPath:t}){super([`Type "${e}" is not a valid decoding type.`,"Please provide a valid ABI type."].join(`
`),{docsPath:t}),Object.defineProperty(this,"name",{enumerable:!0,configurable:!0,writable:!0,value:"InvalidAbiDecodingType"})}}class cp extends G{constructor(e){super([`Value "${e}" is not a valid array.`].join(`
`)),Object.defineProperty(this,"name",{enumerable:!0,configurable:!0,writable:!0,value:"InvalidArrayError"})}}class lp extends G{constructor(e){super([`"${e}" is not a valid definition type.`,'Valid types: "function", "event", "error"'].join(`
`)),Object.defineProperty(this,"name",{enumerable:!0,configurable:!0,writable:!0,value:"InvalidDefinitionTypeError"})}}function Ru(n){if(!Number.isSafeInteger(n)||n<0)throw new Error(`Wrong positive integer: ${n}`)}function u0(n,...e){if(!(n instanceof Uint8Array))throw new Error("Expected Uint8Array");if(e.length>0&&!e.includes(n.length))throw new Error(`Expected Uint8Array of length ${e}, not of length=${n.length}`)}function Tu(n,e=!0){if(n.destroyed)throw new Error("Hash instance has been destroyed");if(e&&n.finished)throw new Error("Hash#digest() has already been called")}function up(n,e){u0(n);const t=e.outputLen;if(n.length<t)throw new Error(`digestInto() expects output buffer of length at least ${t}`)}const bs=BigInt(2**32-1),Pu=BigInt(32);function dp(n,e=!1){return e?{h:Number(n&bs),l:Number(n>>Pu&bs)}:{h:Number(n>>Pu&bs)|0,l:Number(n&bs)|0}}function hp(n,e=!1){let t=new Uint32Array(n.length),i=new Uint32Array(n.length);for(let o=0;o<n.length;o++){const{h:r,l:s}=dp(n[o],e);[t[o],i[o]]=[r,s]}return[t,i]}const pp=(n,e,t)=>n<<t|e>>>32-t,fp=(n,e,t)=>e<<t|n>>>32-t,gp=(n,e,t)=>e<<t-32|n>>>64-t,mp=(n,e,t)=>n<<t-32|e>>>64-t;/*! noble-hashes - MIT License (c) 2022 Paul Miller (paulmillr.com) */const wp=n=>n instanceof Uint8Array,bp=n=>new Uint32Array(n.buffer,n.byteOffset,Math.floor(n.byteLength/4)),vp=new Uint8Array(new Uint32Array([287454020]).buffer)[0]===68;if(!vp)throw new Error("Non little-endian hardware is not supported");function yp(n){if(typeof n!="string")throw new Error(`utf8ToBytes expected string, got ${typeof n}`);return new Uint8Array(new TextEncoder().encode(n))}function d0(n){if(typeof n=="string"&&(n=yp(n)),!wp(n))throw new Error(`expected Uint8Array, got ${typeof n}`);return n}class xp{clone(){return this._cloneInto()}}function Cp(n){const e=i=>n().update(d0(i)).digest(),t=n();return e.outputLen=t.outputLen,e.blockLen=t.blockLen,e.create=()=>n(),e}const[h0,p0,f0]=[[],[],[]],_p=BigInt(0),Gr=BigInt(1),Ep=BigInt(2),$p=BigInt(7),Ap=BigInt(256),Sp=BigInt(113);for(let n=0,e=Gr,t=1,i=0;n<24;n++){[t,i]=[i,(2*t+3*i)%5],h0.push(2*(5*i+t)),p0.push((n+1)*(n+2)/2%64);let o=_p;for(let r=0;r<7;r++)e=(e<<Gr^(e>>$p)*Sp)%Ap,e&Ep&&(o^=Gr<<(Gr<<BigInt(r))-Gr);f0.push(o)}const[Ip,Rp]=hp(f0,!0),Ou=(n,e,t)=>t>32?gp(n,e,t):pp(n,e,t),ku=(n,e,t)=>t>32?mp(n,e,t):fp(n,e,t);function Tp(n,e=24){const t=new Uint32Array(10);for(let i=24-e;i<24;i++){for(let s=0;s<10;s++)t[s]=n[s]^n[s+10]^n[s+20]^n[s+30]^n[s+40];for(let s=0;s<10;s+=2){const a=(s+8)%10,c=(s+2)%10,u=t[c],h=t[c+1],p=Ou(u,h,1)^t[a],g=ku(u,h,1)^t[a+1];for(let b=0;b<50;b+=10)n[s+b]^=p,n[s+b+1]^=g}let o=n[2],r=n[3];for(let s=0;s<24;s++){const a=p0[s],c=Ou(o,r,a),u=ku(o,r,a),h=h0[s];o=n[h],r=n[h+1],n[h]=c,n[h+1]=u}for(let s=0;s<50;s+=10){for(let a=0;a<10;a++)t[a]=n[s+a];for(let a=0;a<10;a++)n[s+a]^=~t[(a+2)%10]&t[(a+4)%10]}n[0]^=Ip[i],n[1]^=Rp[i]}t.fill(0)}class xl extends xp{constructor(e,t,i,o=!1,r=24){if(super(),this.blockLen=e,this.suffix=t,this.outputLen=i,this.enableXOF=o,this.rounds=r,this.pos=0,this.posOut=0,this.finished=!1,this.destroyed=!1,Ru(i),0>=this.blockLen||this.blockLen>=200)throw new Error("Sha3 supports only keccak-f1600 function");this.state=new Uint8Array(200),this.state32=bp(this.state)}keccak(){Tp(this.state32,this.rounds),this.posOut=0,this.pos=0}update(e){Tu(this);const{blockLen:t,state:i}=this;e=d0(e);const o=e.length;for(let r=0;r<o;){const s=Math.min(t-this.pos,o-r);for(let a=0;a<s;a++)i[this.pos++]^=e[r++];this.pos===t&&this.keccak()}return this}finish(){if(this.finished)return;this.finished=!0;const{state:e,suffix:t,pos:i,blockLen:o}=this;e[i]^=t,t&128&&i===o-1&&this.keccak(),e[o-1]^=128,this.keccak()}writeInto(e){Tu(this,!1),u0(e),this.finish();const t=this.state,{blockLen:i}=this;for(let o=0,r=e.length;o<r;){this.posOut>=i&&this.keccak();const s=Math.min(i-this.posOut,r-o);e.set(t.subarray(this.posOut,this.posOut+s),o),this.posOut+=s,o+=s}return e}xofInto(e){if(!this.enableXOF)throw new Error("XOF is not possible for this instance");return this.writeInto(e)}xof(e){return Ru(e),this.xofInto(new Uint8Array(e))}digestInto(e){if(up(e,this),this.finished)throw new Error("digest() was already called");return this.writeInto(e),this.destroy(),e}digest(){return this.digestInto(new Uint8Array(this.outputLen))}destroy(){this.destroyed=!0,this.state.fill(0)}_cloneInto(e){const{blockLen:t,suffix:i,outputLen:o,rounds:r,enableXOF:s}=this;return e||(e=new xl(t,i,o,s,r)),e.state32.set(this.state32),e.pos=this.pos,e.posOut=this.posOut,e.finished=this.finished,e.rounds=r,e.suffix=i,e.outputLen=o,e.enableXOF=s,e.destroyed=this.destroyed,e}}const Pp=(n,e,t)=>Cp(()=>new xl(e,n,t)),Op=Pp(1,136,256/8);function po(n,e){const t=e||"hex",i=Op(ba(n,{strict:!1})?bl(n):n);return t==="bytes"?i:va(i)}const kp=n=>po(bl(n));function Np(n){return kp(n)}function Mp(n){let e=!0,t="",i=0,o="",r=!1;for(let s=0;s<n.length;s++){const a=n[s];if(["(",")",","].includes(a)&&(e=!0),a==="("&&i++,a===")"&&i--,!!e){if(i===0){if(a===" "&&["event","function",""].includes(o))o="";else if(o+=a,a===")"){r=!0;break}continue}if(a===" "){n[s-1]!==","&&t!==","&&t!==",("&&(t="",e=!1);continue}o+=a,t+=a}}if(!r)throw new G("Unable to normalize signature.");return o}const Lp=n=>{const e=typeof n=="string"?n:Q1(n);return Mp(e)};function g0(n){return Np(Lp(n))}const Bp=g0;class fo extends G{constructor({address:e}){super(`Address "${e}" is invalid.`,{metaMessages:["- Address must be a hex value of 20 bytes (40 hex characters).","- Address must match its checksum counterpart."]}),Object.defineProperty(this,"name",{enumerable:!0,configurable:!0,writable:!0,value:"InvalidAddressError"})}}class jp extends Map{constructor(e){super(),Object.defineProperty(this,"maxSize",{enumerable:!0,configurable:!0,writable:!0,value:void 0}),this.maxSize=e}set(e,t){return super.set(e,t),this.maxSize&&this.size>this.maxSize&&this.delete(this.keys().next().value),this}}function Cl(n,e){const t=e?`${e}${n.toLowerCase()}`:n.substring(2).toLowerCase(),i=po(sr(t),"bytes"),o=(e?t.substring(`${e}0x`.length):t).split("");for(let r=0;r<40;r+=2)i[r>>1]>>4>=8&&o[r]&&(o[r]=o[r].toUpperCase()),(i[r>>1]&15)>=8&&o[r+1]&&(o[r+1]=o[r+1].toUpperCase());return`0x${o.join("")}`}function Ot(n,e){if(!zn(n))throw new fo({address:n});return Cl(n,e)}const Dp=/^0x[a-fA-F0-9]{40}$/,ic=new jp(8192);function zn(n,{strict:e=!0}={}){if(ic.has(n))return ic.get(n);const t=Dp.test(n)?n.toLowerCase()===n?!0:e?Cl(n)===n:!0:!1;return ic.set(n,t),t}function bi(n){return typeof n[0]=="string"?m0(n):Up(n)}function Up(n){let e=0;for(const o of n)e+=o.length;const t=new Uint8Array(e);let i=0;for(const o of n)t.set(o,i),i+=o.length;return t}function m0(n){return`0x${n.reduce((e,t)=>e+t.replace("0x",""),"")}`}function Ms(n,e,t,{strict:i}={}){return ba(n,{strict:!1})?Wp(n,e,t,{strict:i}):v0(n,e,t,{strict:i})}function w0(n,e){if(typeof e=="number"&&e>0&&e>ot(n)-1)throw new o0({offset:e,position:"start",size:ot(n)})}function b0(n,e,t){if(typeof e=="number"&&typeof t=="number"&&ot(n)!==t-e)throw new o0({offset:t,position:"end",size:ot(n)})}function v0(n,e,t,{strict:i}={}){w0(n,e);const o=n.slice(e,t);return i&&b0(o,e,t),o}function Wp(n,e,t,{strict:i}={}){w0(n,e);const o=`0x${n.replace("0x","").slice((e??0)*2,(t??n.length)*2)}`;return i&&b0(o,e,t),o}function zp(n,e){if(n.length!==e.length)throw new ip({expectedLength:n.length,givenLength:e.length});const t=Fp({params:n,values:e}),i=El(t);return i.length===0?"0x":i}function Fp({params:n,values:e}){const t=[];for(let i=0;i<n.length;i++)t.push(_l({param:n[i],value:e[i]}));return t}function _l({param:n,value:e}){const t=$l(n.type);if(t){const[i,o]=t;return Vp(e,{length:i,param:{...n,type:o}})}if(n.type==="tuple")return Kp(e,{param:n});if(n.type==="address")return Hp(e);if(n.type==="bool")return qp(e);if(n.type.startsWith("uint")||n.type.startsWith("int")){const i=n.type.startsWith("int");return Gp(e,{signed:i})}if(n.type.startsWith("bytes"))return Zp(e,{param:n});if(n.type==="string")return Yp(e);throw new sp(n.type,{docsPath:"/docs/contract/encodeAbiParameters"})}function El(n){let e=0;for(let r=0;r<n.length;r++){const{dynamic:s,encoded:a}=n[r];s?e+=32:e+=ot(a)}const t=[],i=[];let o=0;for(let r=0;r<n.length;r++){const{dynamic:s,encoded:a}=n[r];s?(t.push(Ne(e+o,{size:32})),i.push(a),o+=ot(a)):t.push(a)}return bi([...t,...i])}function Hp(n){if(!zn(n))throw new fo({address:n});return{dynamic:!1,encoded:pi(n.toLowerCase())}}function Vp(n,{length:e,param:t}){const i=e===null;if(!Array.isArray(n))throw new cp(n);if(!i&&n.length!==e)throw new tp({expectedLength:e,givenLength:n.length,type:`${t.type}[${e}]`});let o=!1;const r=[];for(let s=0;s<n.length;s++){const a=_l({param:t,value:n[s]});a.dynamic&&(o=!0),r.push(a)}if(i||o){const s=El(r);if(i){const a=Ne(r.length,{size:32});return{dynamic:!0,encoded:r.length>0?bi([a,s]):a}}if(o)return{dynamic:!0,encoded:s}}return{dynamic:!1,encoded:bi(r.map(({encoded:s})=>s))}}function Zp(n,{param:e}){const[,t]=e.type.split("bytes"),i=ot(n);if(!t){let o=n;return i%32!==0&&(o=pi(o,{dir:"right",size:Math.ceil((n.length-2)/2/32)*32})),{dynamic:!0,encoded:bi([pi(Ne(i,{size:32})),o])}}if(i!==parseInt(t))throw new np({expectedSize:parseInt(t),value:n});return{dynamic:!1,encoded:pi(n,{dir:"right"})}}function qp(n){return{dynamic:!1,encoded:pi(j1(n))}}function Gp(n,{signed:e}){return{dynamic:!1,encoded:Ne(n,{size:32,signed:e})}}function Yp(n){const e=s0(n),t=Math.ceil(ot(e)/32),i=[];for(let o=0;o<t;o++)i.push(pi(Ms(e,o*32,(o+1)*32),{dir:"right"}));return{dynamic:!0,encoded:bi([pi(Ne(ot(e),{size:32})),...i])}}function Kp(n,{param:e}){let t=!1;const i=[];for(let o=0;o<e.components.length;o++){const r=e.components[o],s=Array.isArray(n)?o:r.name,a=_l({param:r,value:n[s]});i.push(a),a.dynamic&&(t=!0)}return{dynamic:t,encoded:t?El(i):bi(i.map(({encoded:o})=>o))}}function $l(n){const e=n.match(/^(.*)\[(\d+)?\]$/);return e?[e[2]?Number(e[2]):null,e[1]]:void 0}const Al=n=>Ms(g0(n),0,4);function Sl(n){const{abi:e,args:t=[],name:i}=n,o=ba(i,{strict:!1}),r=e.filter(a=>o?a.type==="function"?Al(a)===i:a.type==="event"?Bp(a)===i:!1:"name"in a&&a.name===i);if(r.length===0)return;if(r.length===1)return r[0];let s;for(const a of r){if(!("inputs"in a))continue;if(!t||t.length===0){if(!a.inputs||a.inputs.length===0)return a;continue}if(!a.inputs||a.inputs.length===0||a.inputs.length!==t.length)continue;if(t.every((u,h)=>{const p="inputs"in a&&a.inputs[h];return p?Mc(u,p):!1})){if(s&&"inputs"in s&&s.inputs){const u=y0(a.inputs,s.inputs,t);if(u)throw new op({abiItem:a,type:u[0]},{abiItem:s,type:u[1]})}s=a}}return s||r[0]}function Mc(n,e){const t=typeof n,i=e.type;switch(i){case"address":return zn(n,{strict:!1});case"bool":return t==="boolean";case"function":return t==="string";case"string":return t==="string";default:return i==="tuple"&&"components"in e?Object.values(e.components).every((o,r)=>Mc(Object.values(n)[r],o)):/^u?int(8|16|24|32|40|48|56|64|72|80|88|96|104|112|120|128|136|144|152|160|168|176|184|192|200|208|216|224|232|240|248|256)?$/.test(i)?t==="number"||t==="bigint":/^bytes([1-9]|1[0-9]|2[0-9]|3[0-2])?$/.test(i)?t==="string"||n instanceof Uint8Array:/[a-z]+[1-9]{0,3}(\[[0-9]{0,}\])+$/.test(i)?Array.isArray(n)&&n.every(o=>Mc(o,{...e,type:i.replace(/(\[[0-9]{0,}\])$/,"")})):!1}}function y0(n,e,t){for(const i in n){const o=n[i],r=e[i];if(o.type==="tuple"&&r.type==="tuple"&&"components"in o&&"components"in r)return y0(o.components,r.components,t[i]);const s=[o.type,r.type];if(s.includes("address")&&s.includes("bytes20")?!0:s.includes("address")&&s.includes("string")?zn(t[i],{strict:!1}):s.includes("address")&&s.includes("bytes")?zn(t[i],{strict:!1}):!1)return s}}function jr(n){return typeof n=="string"?{address:n,type:"json-rpc"}:n}const Nu="/docs/contract/encodeFunctionData";function Ca(n){const{abi:e,args:t,functionName:i}=n;let o=e[0];if(i){const c=Sl({abi:e,args:t,name:i});if(!c)throw new Ns(i,{docsPath:Nu});o=c}if(o.type!=="function")throw new Ns(void 0,{docsPath:Nu});const r=dr(o),s=Al(r),a="inputs"in o&&o.inputs?zp(o.inputs,t??[]):void 0;return m0([s,a??"0x"])}const x0={1:"An `assert` condition failed.",17:"Arithmetic operation resulted in underflow or overflow.",18:"Division or modulo by zero (e.g. `5 / 0` or `23 % 0`).",33:"Attempted to convert to an invalid type.",34:"Attempted to access a storage byte array that is incorrectly encoded.",49:"Performed `.pop()` on an empty array",50:"Array index is out of bounds.",65:"Allocated too much memory or created an array which is too large.",81:"Attempted to call a zero-initialized variable of internal function type."},Jp={inputs:[{name:"message",type:"string"}],name:"Error",type:"error"},Qp={inputs:[{name:"reason",type:"uint256"}],name:"Panic",type:"error"};class Mu extends G{constructor({offset:e}){super(`Offset \`${e}\` cannot be negative.`),Object.defineProperty(this,"name",{enumerable:!0,configurable:!0,writable:!0,value:"NegativeOffsetError"})}}class Xp extends G{constructor({length:e,position:t}){super(`Position \`${t}\` is out of bounds (\`0 < position < ${e}\`).`),Object.defineProperty(this,"name",{enumerable:!0,configurable:!0,writable:!0,value:"PositionOutOfBoundsError"})}}class ef extends G{constructor({count:e,limit:t}){super(`Recursive read limit of \`${t}\` exceeded (recursive read count: \`${e}\`).`),Object.defineProperty(this,"name",{enumerable:!0,configurable:!0,writable:!0,value:"RecursiveReadLimitExceededError"})}}const tf={bytes:new Uint8Array,dataView:new DataView(new ArrayBuffer(0)),position:0,positionReadCount:new Map,recursiveReadCount:0,recursiveReadLimit:1/0,assertReadLimit(){if(this.recursiveReadCount>=this.recursiveReadLimit)throw new ef({count:this.recursiveReadCount+1,limit:this.recursiveReadLimit})},assertPosition(n){if(n<0||n>this.bytes.length-1)throw new Xp({length:this.bytes.length,position:n})},decrementPosition(n){if(n<0)throw new Mu({offset:n});const e=this.position-n;this.assertPosition(e),this.position=e},getReadCount(n){return this.positionReadCount.get(n||this.position)||0},incrementPosition(n){if(n<0)throw new Mu({offset:n});const e=this.position+n;this.assertPosition(e),this.position=e},inspectByte(n){const e=n??this.position;return this.assertPosition(e),this.bytes[e]},inspectBytes(n,e){const t=e??this.position;return this.assertPosition(t+n-1),this.bytes.subarray(t,t+n)},inspectUint8(n){const e=n??this.position;return this.assertPosition(e),this.bytes[e]},inspectUint16(n){const e=n??this.position;return this.assertPosition(e+1),this.dataView.getUint16(e)},inspectUint24(n){const e=n??this.position;return this.assertPosition(e+2),(this.dataView.getUint16(e)<<8)+this.dataView.getUint8(e+2)},inspectUint32(n){const e=n??this.position;return this.assertPosition(e+3),this.dataView.getUint32(e)},pushByte(n){this.assertPosition(this.position),this.bytes[this.position]=n,this.position++},pushBytes(n){this.assertPosition(this.position+n.length-1),this.bytes.set(n,this.position),this.position+=n.length},pushUint8(n){this.assertPosition(this.position),this.bytes[this.position]=n,this.position++},pushUint16(n){this.assertPosition(this.position+1),this.dataView.setUint16(this.position,n),this.position+=2},pushUint24(n){this.assertPosition(this.position+2),this.dataView.setUint16(this.position,n>>8),this.dataView.setUint8(this.position+2,n&255),this.position+=3},pushUint32(n){this.assertPosition(this.position+3),this.dataView.setUint32(this.position,n),this.position+=4},readByte(){this.assertReadLimit(),this._touch();const n=this.inspectByte();return this.position++,n},readBytes(n,e){this.assertReadLimit(),this._touch();const t=this.inspectBytes(n);return this.position+=e??n,t},readUint8(){this.assertReadLimit(),this._touch();const n=this.inspectUint8();return this.position+=1,n},readUint16(){this.assertReadLimit(),this._touch();const n=this.inspectUint16();return this.position+=2,n},readUint24(){this.assertReadLimit(),this._touch();const n=this.inspectUint24();return this.position+=3,n},readUint32(){this.assertReadLimit(),this._touch();const n=this.inspectUint32();return this.position+=4,n},setPosition(n){const e=this.position;return this.assertPosition(n),this.position=n,()=>this.position=e},_touch(){if(this.recursiveReadLimit===1/0)return;const n=this.getReadCount();this.positionReadCount.set(this.position,n+1),n>0&&this.recursiveReadCount++}};function nf(n,{recursiveReadLimit:e=8192}={}){const t=Object.create(tf);return t.bytes=n,t.dataView=new DataView(n.buffer,n.byteOffset,n.byteLength),t.positionReadCount=new Map,t.recursiveReadLimit=e,t}function C0(n,e){const t=typeof e=="string"?D1(e):e,i=nf(t);if(ot(t)===0&&n.length>0)throw new xa;if(ot(e)&&ot(e)<32)throw new ep({data:typeof e=="string"?e:wi(e),params:n,size:ot(e)});let o=0;const r=[];for(let s=0;s<n.length;++s){const a=n[s];i.setPosition(o);const[c,u]=cr(i,a,{staticPosition:0});o+=u,r.push(c)}return r}function cr(n,e,{staticPosition:t}){const i=$l(e.type);if(i){const[o,r]=i;return of(n,{...e,type:r},{length:o,staticPosition:t})}if(e.type==="tuple")return lf(n,e,{staticPosition:t});if(e.type==="address")return rf(n);if(e.type==="bool")return sf(n);if(e.type.startsWith("bytes"))return af(n,e,{staticPosition:t});if(e.type.startsWith("uint")||e.type.startsWith("int"))return cf(n,e);if(e.type==="string")return uf(n,{staticPosition:t});throw new ap(e.type,{docsPath:"/docs/contract/decodeAbiParameters"})}const Lu=32,Lc=32;function rf(n){const e=n.readBytes(32);return[Cl(wi(v0(e,-20))),32]}function of(n,e,{length:t,staticPosition:i}){if(!t){const s=yn(n.readBytes(Lc)),a=i+s,c=a+Lu;n.setPosition(a);const u=yn(n.readBytes(Lu)),h=go(e);let p=0;const g=[];for(let b=0;b<u;++b){n.setPosition(c+(h?b*32:p));const[_,x]=cr(n,e,{staticPosition:c});p+=x,g.push(_)}return n.setPosition(i+32),[g,32]}if(go(e)){const s=yn(n.readBytes(Lc)),a=i+s,c=[];for(let u=0;u<t;++u){n.setPosition(a+u*32);const[h]=cr(n,e,{staticPosition:a});c.push(h)}return n.setPosition(i+32),[c,32]}let o=0;const r=[];for(let s=0;s<t;++s){const[a,c]=cr(n,e,{staticPosition:i+o});o+=c,r.push(a)}return[r,o]}function sf(n){return[U1(n.readBytes(32),{size:32}),32]}function af(n,e,{staticPosition:t}){const[i,o]=e.type.split("bytes");if(!o){const s=yn(n.readBytes(32));n.setPosition(t+s);const a=yn(n.readBytes(32));if(a===0)return n.setPosition(t+32),["0x",32];const c=n.readBytes(a);return n.setPosition(t+32),[wi(c),32]}return[wi(n.readBytes(parseInt(o),32)),32]}function cf(n,e){const t=e.type.startsWith("int"),i=parseInt(e.type.split("int")[1]||"256"),o=n.readBytes(32);return[i>48?W1(o,{signed:t}):yn(o,{signed:t}),32]}function lf(n,e,{staticPosition:t}){const i=e.components.length===0||e.components.some(({name:s})=>!s),o=i?[]:{};let r=0;if(go(e)){const s=yn(n.readBytes(Lc)),a=t+s;for(let c=0;c<e.components.length;++c){const u=e.components[c];n.setPosition(a+r);const[h,p]=cr(n,u,{staticPosition:a});r+=p,o[i?c:u==null?void 0:u.name]=h}return n.setPosition(t+32),[o,32]}for(let s=0;s<e.components.length;++s){const a=e.components[s],[c,u]=cr(n,a,{staticPosition:t});o[i?s:a==null?void 0:a.name]=c,r+=u}return[o,r]}function uf(n,{staticPosition:e}){const t=yn(n.readBytes(32)),i=e+t;n.setPosition(i);const o=yn(n.readBytes(32));if(o===0)return n.setPosition(e+32),["",32];const r=n.readBytes(o,32),s=z1(a0(r));return n.setPosition(e+32),[s,32]}function go(n){var i;const{type:e}=n;if(e==="string"||e==="bytes"||e.endsWith("[]"))return!0;if(e==="tuple")return(i=n.components)==null?void 0:i.some(go);const t=$l(n.type);return!!(t&&go({...n,type:t[1]}))}function df(n){const{abi:e,data:t}=n,i=Ms(t,0,4);if(i==="0x")throw new xa;const r=[...e||[],Jp,Qp].find(s=>s.type==="error"&&i===Al(dr(s)));if(!r)throw new l0(i,{docsPath:"/docs/contract/decodeErrorResult"});return{abiItem:r,args:"inputs"in r&&r.inputs&&r.inputs.length>0?C0(r.inputs,Ms(t,4)):void 0,errorName:r.name}}const fi=(n,e,t)=>JSON.stringify(n,(i,o)=>{const r=typeof o=="bigint"?o.toString():o;return typeof e=="function"?e(i,r):r},t);function _0({abiItem:n,args:e,includeFunctionName:t=!0,includeName:i=!1}){if("name"in n&&"inputs"in n&&n.inputs)return`${t?n.name:""}(${n.inputs.map((o,r)=>`${i&&o.name?`${o.name}: `:""}${typeof e[r]=="object"?fi(e[r]):e[r]}`).join(", ")})`}const hf={gwei:9,wei:18},pf={ether:-9,wei:9},ff={ether:-18,gwei:-9};function gf(n,e="wei"){return ya(n,hf[e])}function gi(n,e="wei"){return ya(n,pf[e])}class mf extends G{constructor({address:e}){super(`State for account "${e}" is set multiple times.`),Object.defineProperty(this,"name",{enumerable:!0,configurable:!0,writable:!0,value:"AccountStateConflictError"})}}class wf extends G{constructor(){super("state and stateDiff are set on the same account."),Object.defineProperty(this,"name",{enumerable:!0,configurable:!0,writable:!0,value:"StateAssignmentConflictError"})}}function Bu(n){return n.reduce((e,{slot:t,value:i})=>`${e}        ${t}: ${i}
`,"")}function bf(n){return n.reduce((e,{address:t,...i})=>{let o=`${e}    ${t}:
`;return i.nonce&&(o+=`      nonce: ${i.nonce}
`),i.balance&&(o+=`      balance: ${i.balance}
`),i.code&&(o+=`      code: ${i.code}
`),i.state&&(o+=`      state:
`,o+=Bu(i.state)),i.stateDiff&&(o+=`      stateDiff:
`,o+=Bu(i.stateDiff)),o},`  State Override:
`).slice(0,-1)}function E0(n){const e=Object.entries(n).map(([i,o])=>o===void 0||o===!1?null:[i,o]).filter(Boolean),t=e.reduce((i,[o])=>Math.max(i,o.length),0);return e.map(([i,o])=>`  ${`${i}:`.padEnd(t+1)}  ${o}`).join(`
`)}class vf extends G{constructor(){super(["Cannot specify both a `gasPrice` and a `maxFeePerGas`/`maxPriorityFeePerGas`.","Use `maxFeePerGas`/`maxPriorityFeePerGas` for EIP-1559 compatible networks, and `gasPrice` for others."].join(`
`)),Object.defineProperty(this,"name",{enumerable:!0,configurable:!0,writable:!0,value:"FeeConflictError"})}}class yf extends G{constructor(e,{account:t,docsPath:i,chain:o,data:r,gas:s,gasPrice:a,maxFeePerGas:c,maxPriorityFeePerGas:u,nonce:h,to:p,value:g,stateOverride:b}){var C;const _=t?jr(t):void 0;let x=E0({from:_==null?void 0:_.address,to:p,value:typeof g<"u"&&`${gf(g)} ${((C=o==null?void 0:o.nativeCurrency)==null?void 0:C.symbol)||"ETH"}`,data:r,gas:s,gasPrice:typeof a<"u"&&`${gi(a)} gwei`,maxFeePerGas:typeof c<"u"&&`${gi(c)} gwei`,maxPriorityFeePerGas:typeof u<"u"&&`${gi(u)} gwei`,nonce:h});b&&(x+=`
${bf(b)}`),super(e.shortMessage,{cause:e,docsPath:i,metaMessages:[...e.metaMessages?[...e.metaMessages," "]:[],"Raw Call Arguments:",x].filter(Boolean)}),Object.defineProperty(this,"cause",{enumerable:!0,configurable:!0,writable:!0,value:void 0}),Object.defineProperty(this,"name",{enumerable:!0,configurable:!0,writable:!0,value:"CallExecutionError"}),this.cause=e}}class Il extends G{constructor(e,{abi:t,args:i,contractAddress:o,docsPath:r,functionName:s,sender:a}){const c=Sl({abi:t,args:i,name:s}),u=c?_0({abiItem:c,args:i,includeFunctionName:!1,includeName:!1}):void 0,h=c?dr(c,{includeName:!0}):void 0,p=E0({address:o&&F1(o),function:h,args:u&&u!=="()"&&`${[...Array((s==null?void 0:s.length)??0).keys()].map(()=>" ").join("")}${u}`,sender:a});super(e.shortMessage||`An unknown error occurred while executing the contract function "${s}".`,{cause:e,docsPath:r,metaMessages:[...e.metaMessages?[...e.metaMessages," "]:[],"Contract Call:",p].filter(Boolean)}),Object.defineProperty(this,"abi",{enumerable:!0,configurable:!0,writable:!0,value:void 0}),Object.defineProperty(this,"args",{enumerable:!0,configurable:!0,writable:!0,value:void 0}),Object.defineProperty(this,"cause",{enumerable:!0,configurable:!0,writable:!0,value:void 0}),Object.defineProperty(this,"contractAddress",{enumerable:!0,configurable:!0,writable:!0,value:void 0}),Object.defineProperty(this,"formattedArgs",{enumerable:!0,configurable:!0,writable:!0,value:void 0}),Object.defineProperty(this,"functionName",{enumerable:!0,configurable:!0,writable:!0,value:void 0}),Object.defineProperty(this,"sender",{enumerable:!0,configurable:!0,writable:!0,value:void 0}),Object.defineProperty(this,"name",{enumerable:!0,configurable:!0,writable:!0,value:"ContractFunctionExecutionError"}),this.abi=t,this.args=i,this.cause=e,this.contractAddress=o,this.functionName=s,this.sender=a}}class Bc extends G{constructor({abi:e,data:t,functionName:i,message:o}){let r,s,a,c;if(t&&t!=="0x")try{s=df({abi:e,data:t});const{abiItem:h,errorName:p,args:g}=s;if(p==="Error")c=g[0];else if(p==="Panic"){const[b]=g;c=x0[b]}else{const b=h?dr(h,{includeName:!0}):void 0,_=h&&g?_0({abiItem:h,args:g,includeFunctionName:!1,includeName:!1}):void 0;a=[b?`Error: ${b}`:"",_&&_!=="()"?`       ${[...Array((p==null?void 0:p.length)??0).keys()].map(()=>" ").join("")}${_}`:""]}}catch(h){r=h}else o&&(c=o);let u;r instanceof l0&&(u=r.signature,a=[`Unable to decode signature "${u}" as it was not found on the provided ABI.`,"Make sure you are using the correct ABI and that the error exists on it.",`You can look up the decoded signature here: https://openchain.xyz/signatures?query=${u}.`]),super(c&&c!=="execution reverted"||u?[`The contract function "${i}" reverted with the following ${u?"signature":"reason"}:`,c||u].join(`
`):`The contract function "${i}" reverted.`,{cause:r,metaMessages:a}),Object.defineProperty(this,"name",{enumerable:!0,configurable:!0,writable:!0,value:"ContractFunctionRevertedError"}),Object.defineProperty(this,"data",{enumerable:!0,configurable:!0,writable:!0,value:void 0}),Object.defineProperty(this,"reason",{enumerable:!0,configurable:!0,writable:!0,value:void 0}),Object.defineProperty(this,"signature",{enumerable:!0,configurable:!0,writable:!0,value:void 0}),this.data=s,this.reason=c,this.signature=u}}class xf extends G{constructor({functionName:e}){super(`The contract function "${e}" returned no data ("0x").`,{metaMessages:["This could be due to any of the following:",`  - The contract does not have the function "${e}",`,"  - The parameters passed to the contract function may be invalid, or","  - The address is not a contract."]}),Object.defineProperty(this,"name",{enumerable:!0,configurable:!0,writable:!0,value:"ContractFunctionZeroDataError"})}}class Rl extends G{constructor({data:e,message:t}){super(t||""),Object.defineProperty(this,"code",{enumerable:!0,configurable:!0,writable:!0,value:3}),Object.defineProperty(this,"name",{enumerable:!0,configurable:!0,writable:!0,value:"RawContractError"}),Object.defineProperty(this,"data",{enumerable:!0,configurable:!0,writable:!0,value:void 0}),this.data=e}}class no extends G{constructor({body:e,details:t,headers:i,status:o,url:r}){super("HTTP request failed.",{details:t,metaMessages:[o&&`Status: ${o}`,`URL: ${vl(r)}`,e&&`Request body: ${fi(e)}`].filter(Boolean)}),Object.defineProperty(this,"name",{enumerable:!0,configurable:!0,writable:!0,value:"HttpRequestError"}),Object.defineProperty(this,"body",{enumerable:!0,configurable:!0,writable:!0,value:void 0}),Object.defineProperty(this,"headers",{enumerable:!0,configurable:!0,writable:!0,value:void 0}),Object.defineProperty(this,"status",{enumerable:!0,configurable:!0,writable:!0,value:void 0}),Object.defineProperty(this,"url",{enumerable:!0,configurable:!0,writable:!0,value:void 0}),this.body=e,this.headers=i,this.status=o,this.url=r}}class $0 extends G{constructor({body:e,error:t,url:i}){super("RPC Request failed.",{cause:t,details:t.message,metaMessages:[`URL: ${vl(i)}`,`Request body: ${fi(e)}`]}),Object.defineProperty(this,"name",{enumerable:!0,configurable:!0,writable:!0,value:"RpcRequestError"}),Object.defineProperty(this,"code",{enumerable:!0,configurable:!0,writable:!0,value:void 0}),this.code=t.code}}class ju extends G{constructor({body:e,url:t}){super("The request took too long to respond.",{details:"The request timed out.",metaMessages:[`URL: ${vl(t)}`,`Request body: ${fi(e)}`]}),Object.defineProperty(this,"name",{enumerable:!0,configurable:!0,writable:!0,value:"TimeoutError"})}}const Cf=-1;class ct extends G{constructor(e,{code:t,docsPath:i,metaMessages:o,shortMessage:r}){super(r,{cause:e,docsPath:i,metaMessages:o||(e==null?void 0:e.metaMessages)}),Object.defineProperty(this,"name",{enumerable:!0,configurable:!0,writable:!0,value:"RpcError"}),Object.defineProperty(this,"code",{enumerable:!0,configurable:!0,writable:!0,value:void 0}),this.name=e.name,this.code=e instanceof $0?e.code:t??Cf}}class Dr extends ct{constructor(e,t){super(e,t),Object.defineProperty(this,"name",{enumerable:!0,configurable:!0,writable:!0,value:"ProviderRpcError"}),Object.defineProperty(this,"data",{enumerable:!0,configurable:!0,writable:!0,value:void 0}),this.data=t.data}}class mo extends ct{constructor(e){super(e,{code:mo.code,shortMessage:"Invalid JSON was received by the server. An error occurred on the server while parsing the JSON text."}),Object.defineProperty(this,"name",{enumerable:!0,configurable:!0,writable:!0,value:"ParseRpcError"})}}Object.defineProperty(mo,"code",{enumerable:!0,configurable:!0,writable:!0,value:-32700});class wo extends ct{constructor(e){super(e,{code:wo.code,shortMessage:"JSON is not a valid request object."}),Object.defineProperty(this,"name",{enumerable:!0,configurable:!0,writable:!0,value:"InvalidRequestRpcError"})}}Object.defineProperty(wo,"code",{enumerable:!0,configurable:!0,writable:!0,value:-32600});class bo extends ct{constructor(e){super(e,{code:bo.code,shortMessage:"The method does not exist / is not available."}),Object.defineProperty(this,"name",{enumerable:!0,configurable:!0,writable:!0,value:"MethodNotFoundRpcError"})}}Object.defineProperty(bo,"code",{enumerable:!0,configurable:!0,writable:!0,value:-32601});class vo extends ct{constructor(e){super(e,{code:vo.code,shortMessage:["Invalid parameters were provided to the RPC method.","Double check you have provided the correct parameters."].join(`
`)}),Object.defineProperty(this,"name",{enumerable:!0,configurable:!0,writable:!0,value:"InvalidParamsRpcError"})}}Object.defineProperty(vo,"code",{enumerable:!0,configurable:!0,writable:!0,value:-32602});class vi extends ct{constructor(e){super(e,{code:vi.code,shortMessage:"An internal error was received."}),Object.defineProperty(this,"name",{enumerable:!0,configurable:!0,writable:!0,value:"InternalRpcError"})}}Object.defineProperty(vi,"code",{enumerable:!0,configurable:!0,writable:!0,value:-32603});class yo extends ct{constructor(e){super(e,{code:yo.code,shortMessage:["Missing or invalid parameters.","Double check you have provided the correct parameters."].join(`
`)}),Object.defineProperty(this,"name",{enumerable:!0,configurable:!0,writable:!0,value:"InvalidInputRpcError"})}}Object.defineProperty(yo,"code",{enumerable:!0,configurable:!0,writable:!0,value:-32e3});class xo extends ct{constructor(e){super(e,{code:xo.code,shortMessage:"Requested resource not found."}),Object.defineProperty(this,"name",{enumerable:!0,configurable:!0,writable:!0,value:"ResourceNotFoundRpcError"})}}Object.defineProperty(xo,"code",{enumerable:!0,configurable:!0,writable:!0,value:-32001});class Bn extends ct{constructor(e){super(e,{code:Bn.code,shortMessage:"Requested resource not available."}),Object.defineProperty(this,"name",{enumerable:!0,configurable:!0,writable:!0,value:"ResourceUnavailableRpcError"})}}Object.defineProperty(Bn,"code",{enumerable:!0,configurable:!0,writable:!0,value:-32002});class Co extends ct{constructor(e){super(e,{code:Co.code,shortMessage:"Transaction creation failed."}),Object.defineProperty(this,"name",{enumerable:!0,configurable:!0,writable:!0,value:"TransactionRejectedRpcError"})}}Object.defineProperty(Co,"code",{enumerable:!0,configurable:!0,writable:!0,value:-32003});class _o extends ct{constructor(e){super(e,{code:_o.code,shortMessage:"Method is not implemented."}),Object.defineProperty(this,"name",{enumerable:!0,configurable:!0,writable:!0,value:"MethodNotSupportedRpcError"})}}Object.defineProperty(_o,"code",{enumerable:!0,configurable:!0,writable:!0,value:-32004});class hr extends ct{constructor(e){super(e,{code:hr.code,shortMessage:"Request exceeds defined limit."}),Object.defineProperty(this,"name",{enumerable:!0,configurable:!0,writable:!0,value:"LimitExceededRpcError"})}}Object.defineProperty(hr,"code",{enumerable:!0,configurable:!0,writable:!0,value:-32005});class Eo extends ct{constructor(e){super(e,{code:Eo.code,shortMessage:"Version of JSON-RPC protocol is not supported."}),Object.defineProperty(this,"name",{enumerable:!0,configurable:!0,writable:!0,value:"JsonRpcVersionUnsupportedError"})}}Object.defineProperty(Eo,"code",{enumerable:!0,configurable:!0,writable:!0,value:-32006});class De extends Dr{constructor(e){super(e,{code:De.code,shortMessage:"User rejected the request."}),Object.defineProperty(this,"name",{enumerable:!0,configurable:!0,writable:!0,value:"UserRejectedRequestError"})}}Object.defineProperty(De,"code",{enumerable:!0,configurable:!0,writable:!0,value:4001});class $o extends Dr{constructor(e){super(e,{code:$o.code,shortMessage:"The requested method and/or account has not been authorized by the user."}),Object.defineProperty(this,"name",{enumerable:!0,configurable:!0,writable:!0,value:"UnauthorizedProviderError"})}}Object.defineProperty($o,"code",{enumerable:!0,configurable:!0,writable:!0,value:4100});class Ao extends Dr{constructor(e){super(e,{code:Ao.code,shortMessage:"The Provider does not support the requested method."}),Object.defineProperty(this,"name",{enumerable:!0,configurable:!0,writable:!0,value:"UnsupportedProviderMethodError"})}}Object.defineProperty(Ao,"code",{enumerable:!0,configurable:!0,writable:!0,value:4200});class So extends Dr{constructor(e){super(e,{code:So.code,shortMessage:"The Provider is disconnected from all chains."}),Object.defineProperty(this,"name",{enumerable:!0,configurable:!0,writable:!0,value:"ProviderDisconnectedError"})}}Object.defineProperty(So,"code",{enumerable:!0,configurable:!0,writable:!0,value:4900});class Io extends Dr{constructor(e){super(e,{code:Io.code,shortMessage:"The Provider is not connected to the requested chain."}),Object.defineProperty(this,"name",{enumerable:!0,configurable:!0,writable:!0,value:"ChainDisconnectedError"})}}Object.defineProperty(Io,"code",{enumerable:!0,configurable:!0,writable:!0,value:4901});class ft extends Dr{constructor(e){super(e,{code:ft.code,shortMessage:"An error occurred when attempting to switch chain."}),Object.defineProperty(this,"name",{enumerable:!0,configurable:!0,writable:!0,value:"SwitchChainError"})}}Object.defineProperty(ft,"code",{enumerable:!0,configurable:!0,writable:!0,value:4902});class _f extends ct{constructor(e){super(e,{shortMessage:"An unknown RPC error occurred."}),Object.defineProperty(this,"name",{enumerable:!0,configurable:!0,writable:!0,value:"UnknownRpcError"})}}const Ef=3;function jc(n,{abi:e,address:t,args:i,docsPath:o,functionName:r,sender:s}){const{code:a,data:c,message:u,shortMessage:h}=n instanceof Rl?n:n instanceof G?n.walk(g=>"data"in g)||n.walk():{},p=n instanceof xa?new xf({functionName:r}):[Ef,vi.code].includes(a)&&(c||u||h)?new Bc({abi:e,data:typeof c=="object"?c.data:c,functionName:r,message:h??u}):n;return new Il(p,{abi:e,args:i,contractAddress:t,docsPath:o,functionName:r,sender:s})}class or extends G{constructor({cause:e,message:t}={}){var o;const i=(o=t==null?void 0:t.replace("execution reverted: ",""))==null?void 0:o.replace("execution reverted","");super(`Execution reverted ${i?`with reason: ${i}`:"for an unknown reason"}.`,{cause:e}),Object.defineProperty(this,"name",{enumerable:!0,configurable:!0,writable:!0,value:"ExecutionRevertedError"})}}Object.defineProperty(or,"code",{enumerable:!0,configurable:!0,writable:!0,value:3});Object.defineProperty(or,"nodeMessage",{enumerable:!0,configurable:!0,writable:!0,value:/execution reverted/});class Ls extends G{constructor({cause:e,maxFeePerGas:t}={}){super(`The fee cap (\`maxFeePerGas\`${t?` = ${gi(t)} gwei`:""}) cannot be higher than the maximum allowed value (2^256-1).`,{cause:e}),Object.defineProperty(this,"name",{enumerable:!0,configurable:!0,writable:!0,value:"FeeCapTooHigh"})}}Object.defineProperty(Ls,"nodeMessage",{enumerable:!0,configurable:!0,writable:!0,value:/max fee per gas higher than 2\^256-1|fee cap higher than 2\^256-1/});class Dc extends G{constructor({cause:e,maxFeePerGas:t}={}){super(`The fee cap (\`maxFeePerGas\`${t?` = ${gi(t)}`:""} gwei) cannot be lower than the block base fee.`,{cause:e}),Object.defineProperty(this,"name",{enumerable:!0,configurable:!0,writable:!0,value:"FeeCapTooLow"})}}Object.defineProperty(Dc,"nodeMessage",{enumerable:!0,configurable:!0,writable:!0,value:/max fee per gas less than block base fee|fee cap less than block base fee|transaction is outdated/});class Uc extends G{constructor({cause:e,nonce:t}={}){super(`Nonce provided for the transaction ${t?`(${t}) `:""}is higher than the next one expected.`,{cause:e}),Object.defineProperty(this,"name",{enumerable:!0,configurable:!0,writable:!0,value:"NonceTooHighError"})}}Object.defineProperty(Uc,"nodeMessage",{enumerable:!0,configurable:!0,writable:!0,value:/nonce too high/});class Wc extends G{constructor({cause:e,nonce:t}={}){super([`Nonce provided for the transaction ${t?`(${t}) `:""}is lower than the current nonce of the account.`,"Try increasing the nonce or find the latest nonce with `getTransactionCount`."].join(`
`),{cause:e}),Object.defineProperty(this,"name",{enumerable:!0,configurable:!0,writable:!0,value:"NonceTooLowError"})}}Object.defineProperty(Wc,"nodeMessage",{enumerable:!0,configurable:!0,writable:!0,value:/nonce too low|transaction already imported|already known/});class zc extends G{constructor({cause:e,nonce:t}={}){super(`Nonce provided for the transaction ${t?`(${t}) `:""}exceeds the maximum allowed nonce.`,{cause:e}),Object.defineProperty(this,"name",{enumerable:!0,configurable:!0,writable:!0,value:"NonceMaxValueError"})}}Object.defineProperty(zc,"nodeMessage",{enumerable:!0,configurable:!0,writable:!0,value:/nonce has max value/});class Fc extends G{constructor({cause:e}={}){super(["The total cost (gas * gas fee + value) of executing this transaction exceeds the balance of the account."].join(`
`),{cause:e,metaMessages:["This error could arise when the account does not have enough funds to:"," - pay for the total gas fee,"," - pay for the value to send."," ","The cost of the transaction is calculated as `gas * gas fee + value`, where:"," - `gas` is the amount of gas needed for transaction to execute,"," - `gas fee` is the gas fee,"," - `value` is the amount of ether to send to the recipient."]}),Object.defineProperty(this,"name",{enumerable:!0,configurable:!0,writable:!0,value:"InsufficientFundsError"})}}Object.defineProperty(Fc,"nodeMessage",{enumerable:!0,configurable:!0,writable:!0,value:/insufficient funds/});class Hc extends G{constructor({cause:e,gas:t}={}){super(`The amount of gas ${t?`(${t}) `:""}provided for the transaction exceeds the limit allowed for the block.`,{cause:e}),Object.defineProperty(this,"name",{enumerable:!0,configurable:!0,writable:!0,value:"IntrinsicGasTooHighError"})}}Object.defineProperty(Hc,"nodeMessage",{enumerable:!0,configurable:!0,writable:!0,value:/intrinsic gas too high|gas limit reached/});class Vc extends G{constructor({cause:e,gas:t}={}){super(`The amount of gas ${t?`(${t}) `:""}provided for the transaction is too low.`,{cause:e}),Object.defineProperty(this,"name",{enumerable:!0,configurable:!0,writable:!0,value:"IntrinsicGasTooLowError"})}}Object.defineProperty(Vc,"nodeMessage",{enumerable:!0,configurable:!0,writable:!0,value:/intrinsic gas too low/});class Zc extends G{constructor({cause:e}){super("The transaction type is not supported for this chain.",{cause:e}),Object.defineProperty(this,"name",{enumerable:!0,configurable:!0,writable:!0,value:"TransactionTypeNotSupportedError"})}}Object.defineProperty(Zc,"nodeMessage",{enumerable:!0,configurable:!0,writable:!0,value:/transaction type not valid/});class Bs extends G{constructor({cause:e,maxPriorityFeePerGas:t,maxFeePerGas:i}={}){super([`The provided tip (\`maxPriorityFeePerGas\`${t?` = ${gi(t)} gwei`:""}) cannot be higher than the fee cap (\`maxFeePerGas\`${i?` = ${gi(i)} gwei`:""}).`].join(`
`),{cause:e}),Object.defineProperty(this,"name",{enumerable:!0,configurable:!0,writable:!0,value:"TipAboveFeeCapError"})}}Object.defineProperty(Bs,"nodeMessage",{enumerable:!0,configurable:!0,writable:!0,value:/max priority fee per gas higher than max fee per gas|tip higher than fee cap/});class A0 extends G{constructor({cause:e}){super(`An error occurred while executing: ${e==null?void 0:e.shortMessage}`,{cause:e}),Object.defineProperty(this,"name",{enumerable:!0,configurable:!0,writable:!0,value:"UnknownNodeError"})}}function $f(n,e){const t=(n.details||"").toLowerCase(),i=n instanceof G?n.walk(o=>o.code===or.code):n;return i instanceof G?new or({cause:n,message:i.details}):or.nodeMessage.test(t)?new or({cause:n,message:n.details}):Ls.nodeMessage.test(t)?new Ls({cause:n,maxFeePerGas:e==null?void 0:e.maxFeePerGas}):Dc.nodeMessage.test(t)?new Dc({cause:n,maxFeePerGas:e==null?void 0:e.maxFeePerGas}):Uc.nodeMessage.test(t)?new Uc({cause:n,nonce:e==null?void 0:e.nonce}):Wc.nodeMessage.test(t)?new Wc({cause:n,nonce:e==null?void 0:e.nonce}):zc.nodeMessage.test(t)?new zc({cause:n,nonce:e==null?void 0:e.nonce}):Fc.nodeMessage.test(t)?new Fc({cause:n}):Hc.nodeMessage.test(t)?new Hc({cause:n,gas:e==null?void 0:e.gas}):Vc.nodeMessage.test(t)?new Vc({cause:n,gas:e==null?void 0:e.gas}):Zc.nodeMessage.test(t)?new Zc({cause:n}):Bs.nodeMessage.test(t)?new Bs({cause:n,maxFeePerGas:e==null?void 0:e.maxFeePerGas,maxPriorityFeePerGas:e==null?void 0:e.maxPriorityFeePerGas}):new A0({cause:n})}function Af(n,{format:e}){if(!e)return{};const t={};function i(r){const s=Object.keys(r);for(const a of s)a in n&&(t[a]=n[a]),r[a]&&typeof r[a]=="object"&&!Array.isArray(r[a])&&i(r[a])}const o=e(n||{});return i(o),t}const Sf={legacy:"0x0",eip2930:"0x1",eip1559:"0x2",eip4844:"0x3"};function If(n){return{...n,gas:typeof n.gas<"u"?Ne(n.gas):void 0,gasPrice:typeof n.gasPrice<"u"?Ne(n.gasPrice):void 0,maxFeePerGas:typeof n.maxFeePerGas<"u"?Ne(n.maxFeePerGas):void 0,maxPriorityFeePerGas:typeof n.maxPriorityFeePerGas<"u"?Ne(n.maxPriorityFeePerGas):void 0,nonce:typeof n.nonce<"u"?Ne(n.nonce):void 0,type:typeof n.type<"u"?Sf[n.type]:void 0,value:typeof n.value<"u"?Ne(n.value):void 0}}function Rf(n){const{account:e,gasPrice:t,maxFeePerGas:i,maxPriorityFeePerGas:o,to:r}=n,s=e?jr(e):void 0;if(s&&!zn(s.address))throw new fo({address:s.address});if(r&&!zn(r))throw new fo({address:r});if(typeof t<"u"&&(typeof i<"u"||typeof o<"u"))throw new vf;if(i&&i>2n**256n-1n)throw new Ls({maxFeePerGas:i});if(o&&i&&o>i)throw new Bs({maxFeePerGas:i,maxPriorityFeePerGas:o})}class Tf extends G{constructor({docsPath:e}={}){super(["Could not find an Account to execute with this Action.","Please provide an Account with the `account` argument on the Action, or by supplying an `account` to the WalletClient."].join(`
`),{docsPath:e,docsSlug:"account"}),Object.defineProperty(this,"name",{enumerable:!0,configurable:!0,writable:!0,value:"AccountNotFoundError"})}}const rc="/docs/contract/decodeFunctionResult";function _a(n){const{abi:e,args:t,functionName:i,data:o}=n;let r=e[0];if(i){const a=Sl({abi:e,args:t,name:i});if(!a)throw new Ns(i,{docsPath:rc});r=a}if(r.type!=="function")throw new Ns(void 0,{docsPath:rc});if(!r.outputs)throw new rp(r.name,{docsPath:rc});const s=C0(r.outputs,o);if(s&&s.length>1)return s;if(s&&s.length===1)return s[0]}const qc=[{inputs:[{components:[{name:"target",type:"address"},{name:"allowFailure",type:"bool"},{name:"callData",type:"bytes"}],name:"calls",type:"tuple[]"}],name:"aggregate3",outputs:[{components:[{name:"success",type:"bool"},{name:"returnData",type:"bytes"}],name:"returnData",type:"tuple[]"}],stateMutability:"view",type:"function"}],S0=[{inputs:[],name:"ResolverNotFound",type:"error"},{inputs:[],name:"ResolverWildcardNotSupported",type:"error"},{inputs:[],name:"ResolverNotContract",type:"error"},{inputs:[{name:"returnData",type:"bytes"}],name:"ResolverError",type:"error"},{inputs:[{components:[{name:"status",type:"uint16"},{name:"message",type:"string"}],name:"errors",type:"tuple[]"}],name:"HttpError",type:"error"}],Pf=[...S0,{name:"resolve",type:"function",stateMutability:"view",inputs:[{name:"name",type:"bytes"},{name:"data",type:"bytes"}],outputs:[{name:"",type:"bytes"},{name:"address",type:"address"}]},{name:"resolve",type:"function",stateMutability:"view",inputs:[{name:"name",type:"bytes"},{name:"data",type:"bytes"},{name:"gateways",type:"string[]"}],outputs:[{name:"",type:"bytes"},{name:"address",type:"address"}]}],Of=[...S0,{name:"reverse",type:"function",stateMutability:"view",inputs:[{type:"bytes",name:"reverseName"}],outputs:[{type:"string",name:"resolvedName"},{type:"address",name:"resolvedAddress"},{type:"address",name:"reverseResolver"},{type:"address",name:"resolver"}]},{name:"reverse",type:"function",stateMutability:"view",inputs:[{type:"bytes",name:"reverseName"},{type:"string[]",name:"gateways"}],outputs:[{type:"string",name:"resolvedName"},{type:"address",name:"resolvedAddress"},{type:"address",name:"reverseResolver"},{type:"address",name:"resolver"}]}],Du=[{name:"text",type:"function",stateMutability:"view",inputs:[{name:"name",type:"bytes32"},{name:"key",type:"string"}],outputs:[{name:"",type:"string"}]}],kf="0x82ad56cb";class Gc extends G{constructor({blockNumber:e,chain:t,contract:i}){super(`Chain "${t.name}" does not support contract "${i.name}".`,{metaMessages:["This could be due to any of the following:",...e&&i.blockCreated&&i.blockCreated>e?[`- The contract "${i.name}" was not deployed until block ${i.blockCreated} (current block ${e}).`]:[`- The chain does not have the contract "${i.name}" configured.`]]}),Object.defineProperty(this,"name",{enumerable:!0,configurable:!0,writable:!0,value:"ChainDoesNotSupportContract"})}}class I0 extends G{constructor(){super("No chain was provided to the Client."),Object.defineProperty(this,"name",{enumerable:!0,configurable:!0,writable:!0,value:"ClientChainNotConfiguredError"})}}function Ea({blockNumber:n,chain:e,contract:t}){var o;const i=(o=e==null?void 0:e.contracts)==null?void 0:o[t];if(!i)throw new Gc({chain:e,contract:{name:t}});if(n&&i.blockCreated&&i.blockCreated>n)throw new Gc({blockNumber:n,chain:e,contract:{name:t,blockCreated:i.blockCreated}});return i.address}function Nf(n,{docsPath:e,...t}){const i=(()=>{const o=$f(n,t);return o instanceof A0?n:o})();return new yf(i,{docsPath:e,...t})}const oc=new Map;function R0({fn:n,id:e,shouldSplitBatch:t,wait:i=0,sort:o}){const r=async()=>{const h=c();s();const p=h.map(({args:g})=>g);p.length!==0&&n(p).then(g=>{var b;o&&Array.isArray(g)&&g.sort(o);for(let _=0;_<h.length;_++){const{pendingPromise:x}=h[_];(b=x.resolve)==null||b.call(x,[g[_],g])}}).catch(g=>{var b;for(let _=0;_<h.length;_++){const{pendingPromise:x}=h[_];(b=x.reject)==null||b.call(x,g)}})},s=()=>oc.delete(e),a=()=>c().map(({args:h})=>h),c=()=>oc.get(e)||[],u=h=>oc.set(e,[...c(),h]);return{flush:s,async schedule(h){const p={},g=new Promise((x,C)=>{p.resolve=x,p.reject=C});return(t==null?void 0:t([...a(),h]))&&r(),c().length>0?(u({args:h,pendingPromise:p}),g):(u({args:h,pendingPromise:p}),setTimeout(r,i),g)}}}async function Mf(n,e){var R,T,y,S;const{account:t=n.account,batch:i=!!((R=n.batch)!=null&&R.multicall),blockNumber:o,blockTag:r="latest",accessList:s,data:a,gas:c,gasPrice:u,maxFeePerGas:h,maxPriorityFeePerGas:p,nonce:g,to:b,value:_,stateOverride:x,...C}=e,$=t?jr(t):void 0;try{Rf(e);const D=(o?Ne(o):void 0)||r,ee=Uf(x),K=(S=(y=(T=n.chain)==null?void 0:T.formatters)==null?void 0:y.transactionRequest)==null?void 0:S.format,V=(K||If)({...Af(C,{format:K}),from:$==null?void 0:$.address,accessList:s,data:a,gas:c,gasPrice:u,maxFeePerGas:h,maxPriorityFeePerGas:p,nonce:g,to:b,value:_});if(i&&Lf({request:V})&&!ee)try{return await Bf(n,{...V,blockNumber:o,blockTag:r})}catch(me){if(!(me instanceof I0)&&!(me instanceof Gc))throw me}const re=await n.request({method:"eth_call",params:ee?[V,D,ee]:[V,D]});return re==="0x"?{data:void 0}:{data:re}}catch(M){const D=jf(M),{offchainLookup:ee,offchainLookupSignature:K}=await ho(()=>import("./ccip.BDCkY7fA.js"),__vite__mapDeps([0,1,2,3,4,5,6]),import.meta.url);if((D==null?void 0:D.slice(0,10))===K&&b)return{data:await ee(n,{data:D,to:b})};throw Nf(M,{...e,account:$,chain:n.chain})}}function Lf({request:n}){const{data:e,to:t,...i}=n;return!(!e||e.startsWith(kf)||!t||Object.values(i).filter(o=>typeof o<"u").length>0)}async function Bf(n,e){var x;const{batchSize:t=1024,wait:i=0}=typeof((x=n.batch)==null?void 0:x.multicall)=="object"?n.batch.multicall:{},{blockNumber:o,blockTag:r="latest",data:s,multicallAddress:a,to:c}=e;let u=a;if(!u){if(!n.chain)throw new I0;u=Ea({blockNumber:o,chain:n.chain,contract:"multicall3"})}const p=(o?Ne(o):void 0)||r,{schedule:g}=R0({id:`${n.uid}.${p}`,wait:i,shouldSplitBatch(C){return C.reduce((R,{data:T})=>R+(T.length-2),0)>t*2},fn:async C=>{const $=C.map(y=>({allowFailure:!0,callData:y.data,target:y.to})),R=Ca({abi:qc,args:[$],functionName:"aggregate3"}),T=await n.request({method:"eth_call",params:[{data:R,to:u},p]});return _a({abi:qc,args:[$],functionName:"aggregate3",data:T||"0x"})}}),[{returnData:b,success:_}]=await g({data:s,to:c});if(!_)throw new Rl({data:b});return b==="0x"?{data:void 0}:{data:b}}function jf(n){if(!(n instanceof G))return;const e=n.walk();return typeof e.data=="object"?e.data.data:e.data}function Uu(n){if(!(!n||n.length===0))return n.reduce((e,{slot:t,value:i})=>{if(t.length!==66)throw new xu({size:t.length,targetSize:66,type:"hex"});if(i.length!==66)throw new xu({size:i.length,targetSize:66,type:"hex"});return e[t]=i,e},{})}function Df(n){const{balance:e,nonce:t,state:i,stateDiff:o,code:r}=n,s={};if(r!==void 0&&(s.code=r),e!==void 0&&(s.balance=Ne(e,{size:32})),t!==void 0&&(s.nonce=Ne(t,{size:8})),i!==void 0&&(s.state=Uu(i)),o!==void 0){if(s.state)throw new wf;s.stateDiff=Uu(o)}return s}function Uf(n){if(!n)return;const e={};for(const{address:t,...i}of n){if(!zn(t,{strict:!1}))throw new fo({address:t});if(e[t])throw new mf({address:t});e[t]=Df(i)}return e}async function pr(n,e){const{abi:t,address:i,args:o,functionName:r,...s}=e,a=Ca({abi:t,args:o,functionName:r});try{const{data:c}=await ss(n,Mf,"call")({...s,data:a,to:i});return _a({abi:t,args:o,functionName:r,data:c||"0x"})}catch(c){throw jc(c,{abi:t,address:i,args:o,docsPath:"/docs/contract/readContract",functionName:r})}}async function Wf(n){return new Promise(e=>setTimeout(e,n))}const Yc=256;let vs=Yc,ys;function zf(n=11){if(!ys||vs+n>Yc*2){ys="",vs=0;for(let e=0;e<Yc;e++)ys+=(256+Math.random()*256|0).toString(16).substring(1)}return ys.substring(vs,vs+++n)}function T0(n){const{batch:e,cacheTime:t=n.pollingInterval??4e3,key:i="base",name:o="Base Client",pollingInterval:r=4e3,type:s="base"}=n,a=n.chain,c=n.account?jr(n.account):void 0,{config:u,request:h,value:p}=n.transport({chain:a,pollingInterval:r}),g={...u,...p},b={account:c,batch:e,cacheTime:t,chain:a,key:i,name:o,pollingInterval:r,request:h,transport:g,type:s,uid:zf()};function _(x){return C=>{const $=C(x);for(const T in b)delete $[T];const R={...x,...$};return Object.assign(R,{extend:_(R)})}}return Object.assign(b,{extend:_(b)})}function P0(n,{delay:e=100,retryCount:t=2,shouldRetry:i=()=>!0}={}){return new Promise((o,r)=>{const s=async({count:a=0}={})=>{const c=async({error:u})=>{const h=typeof e=="function"?e({count:a,error:u}):e;h&&await Wf(h),s({count:a+1})};try{const u=await n();o(u)}catch(u){if(a<t&&await i({count:a,error:u}))return c({error:u});r(u)}};s()})}function Ff(n,e={}){return async(t,i={})=>{const{retryDelay:o=150,retryCount:r=3}={...e,...i};return P0(async()=>{try{return await n(t)}catch(s){const a=s;switch(a.code){case mo.code:throw new mo(a);case wo.code:throw new wo(a);case bo.code:throw new bo(a);case vo.code:throw new vo(a);case vi.code:throw new vi(a);case yo.code:throw new yo(a);case xo.code:throw new xo(a);case Bn.code:throw new Bn(a);case Co.code:throw new Co(a);case _o.code:throw new _o(a);case hr.code:throw new hr(a);case Eo.code:throw new Eo(a);case De.code:throw new De(a);case $o.code:throw new $o(a);case Ao.code:throw new Ao(a);case So.code:throw new So(a);case Io.code:throw new Io(a);case ft.code:throw new ft(a);case 5e3:throw new De(a);default:throw s instanceof G?s:new _f(a)}}},{delay:({count:s,error:a})=>{var c;if(a&&a instanceof no){const u=(c=a==null?void 0:a.headers)==null?void 0:c.get("Retry-After");if(u!=null&&u.match(/\d/))return parseInt(u)*1e3}return~~(1<<s)*o},retryCount:r,shouldRetry:({error:s})=>Hf(s)})}}function Hf(n){return"code"in n&&typeof n.code=="number"?n.code===-1||n.code===hr.code||n.code===vi.code:n instanceof no&&n.status?n.status===403||n.status===408||n.status===413||n.status===429||n.status===500||n.status===502||n.status===503||n.status===504:!0}function O0({key:n,name:e,request:t,retryCount:i=3,retryDelay:o=150,timeout:r,type:s},a){return{config:{key:n,name:e,request:t,retryCount:i,retryDelay:o,timeout:r,type:s},request:Ff(t,{retryCount:i,retryDelay:o}),value:a}}function Vf(n,e={}){const{key:t="custom",name:i="Custom Provider",retryDelay:o}=e;return({retryCount:r})=>O0({key:t,name:i,request:n.request.bind(n),retryCount:e.retryCount??r,retryDelay:o,type:"custom"})}class Zf extends G{constructor(){super("No URL was provided to the Transport. Please provide a valid RPC URL to the Transport.",{docsPath:"/docs/clients/intro"})}}function k0(n,{errorInstance:e=new Error("timed out"),timeout:t,signal:i}){return new Promise((o,r)=>{(async()=>{let s;try{const a=new AbortController;t>0&&(s=setTimeout(()=>{i?a.abort():r(e)},t)),o(await n({signal:a==null?void 0:a.signal}))}catch(a){a.name==="AbortError"&&r(e),r(a)}finally{clearTimeout(s)}})()})}function qf(){return{current:0,take(){return this.current++},reset(){this.current=0}}}const Wu=qf();function Gf(n,e={}){return{async request(t){var u;const{body:i,fetchOptions:o={},timeout:r=e.timeout??1e4}=t,{headers:s,method:a,signal:c}={...e.fetchOptions,...o};try{const h=await k0(async({signal:g})=>await fetch(n,{...o,body:Array.isArray(i)?fi(i.map(_=>({jsonrpc:"2.0",id:_.id??Wu.take(),..._}))):fi({jsonrpc:"2.0",id:i.id??Wu.take(),...i}),headers:{...s,"Content-Type":"application/json"},method:a||"POST",signal:c||(r>0?g:void 0)}),{errorInstance:new ju({body:i,url:n}),timeout:r,signal:!0});let p;if((u=h.headers.get("Content-Type"))!=null&&u.startsWith("application/json")?p=await h.json():p=await h.text(),!h.ok)throw new no({body:i,details:fi(p.error)||h.statusText,headers:h.headers,status:h.status,url:n});return p}catch(h){throw h instanceof no||h instanceof ju?h:new no({body:i,details:h.message,url:n})}}}}function zu(n,e={}){const{batch:t,fetchOptions:i,key:o="http",name:r="HTTP JSON-RPC",retryDelay:s}=e;return({chain:a,retryCount:c,timeout:u})=>{const{batchSize:h=1e3,wait:p=0}=typeof t=="object"?t:{},g=e.retryCount??c,b=u??e.timeout??1e4,_=n||(a==null?void 0:a.rpcUrls.default.http[0]);if(!_)throw new Zf;const x=Gf(_,{fetchOptions:i,timeout:b});return O0({key:o,name:r,async request({method:C,params:$}){const R={method:C,params:$},{schedule:T}=R0({id:`${n}`,wait:p,shouldSplitBatch(D){return D.length>h},fn:D=>x.request({body:D}),sort:(D,ee)=>D.id-ee.id}),y=async D=>t?T(D):[await x.request({body:D})],[{error:S,result:M}]=await y(R);if(S)throw new $0({body:R,error:S,url:_});return M},retryCount:g,retryDelay:s,timeout:b,type:"http"},{fetchOptions:i,url:_})}}function N0(n,e){var i,o,r,s,a,c;if(!(n instanceof G))return!1;const t=n.walk(u=>u instanceof Bc);return t instanceof Bc?!!(((i=t.data)==null?void 0:i.errorName)==="ResolverNotFound"||((o=t.data)==null?void 0:o.errorName)==="ResolverWildcardNotSupported"||((r=t.data)==null?void 0:r.errorName)==="ResolverNotContract"||((s=t.data)==null?void 0:s.errorName)==="ResolverError"||((a=t.data)==null?void 0:a.errorName)==="HttpError"||(c=t.reason)!=null&&c.includes("Wildcard on non-extended resolvers is not supported")||e==="reverse"&&t.reason===x0[50]):!1}function M0(n){if(n.length!==66||n.indexOf("[")!==0||n.indexOf("]")!==65)return null;const e=`0x${n.slice(1,65)}`;return ba(e)?e:null}function Yf(n){let e=new Uint8Array(32).fill(0);if(!n)return wi(e);const t=n.split(".");for(let i=t.length-1;i>=0;i-=1){const o=M0(t[i]),r=o?bl(o):po(sr(t[i]),"bytes");e=po(bi([e,r]),"bytes")}return wi(e)}function Kf(n){return`[${n.slice(2)}]`}function Jf(n){const e=new Uint8Array(32).fill(0);return n?M0(n)||po(sr(n)):wi(e)}function L0(n){const e=n.replace(/^\.|\.$/gm,"");if(e.length===0)return new Uint8Array(1);const t=new Uint8Array(sr(e).byteLength+2);let i=0;const o=e.split(".");for(let r=0;r<o.length;r++){let s=sr(o[r]);s.byteLength>255&&(s=sr(Kf(Jf(o[r])))),t[i]=s.length,t.set(s,i+1),i+=s.length+1}return t.byteLength!==i+1?t.slice(0,i+1):t}class Qf extends G{constructor({data:e}){super("Unable to extract image from metadata. The metadata may be malformed or invalid.",{metaMessages:["- Metadata must be a JSON object with at least an `image`, `image_url` or `image_data` property.","",`Provided data: ${JSON.stringify(e)}`]}),Object.defineProperty(this,"name",{enumerable:!0,configurable:!0,writable:!0,value:"EnsAvatarInvalidMetadataError"})}}class Yr extends G{constructor({reason:e}){super(`ENS NFT avatar URI is invalid. ${e}`),Object.defineProperty(this,"name",{enumerable:!0,configurable:!0,writable:!0,value:"EnsAvatarInvalidNftUriError"})}}class Tl extends G{constructor({uri:e}){super(`Unable to resolve ENS avatar URI "${e}". The URI may be malformed, invalid, or does not respond with a valid image.`),Object.defineProperty(this,"name",{enumerable:!0,configurable:!0,writable:!0,value:"EnsAvatarUriResolutionError"})}}class Xf extends G{constructor({namespace:e}){super(`ENS NFT avatar namespace "${e}" is not supported. Must be "erc721" or "erc1155".`),Object.defineProperty(this,"name",{enumerable:!0,configurable:!0,writable:!0,value:"EnsAvatarUnsupportedNamespaceError"})}}const eg=/(?<protocol>https?:\/\/[^\/]*|ipfs:\/|ipns:\/|ar:\/)?(?<root>\/)?(?<subpath>ipfs\/|ipns\/)?(?<target>[\w\-.]+)(?<subtarget>\/.*)?/,tg=/^(Qm[1-9A-HJ-NP-Za-km-z]{44,}|b[A-Za-z2-7]{58,}|B[A-Z2-7]{58,}|z[1-9A-HJ-NP-Za-km-z]{48,}|F[0-9A-F]{50,})(\/(?<target>[\w\-.]+))?(?<subtarget>\/.*)?$/,ng=/^data:([a-zA-Z\-/+]*);base64,([^"].*)/,ig=/^data:([a-zA-Z\-/+]*)?(;[a-zA-Z0-9].*?)?(,)/;async function rg(n){try{const e=await fetch(n,{method:"HEAD"});if(e.status===200){const t=e.headers.get("content-type");return t==null?void 0:t.startsWith("image/")}return!1}catch(e){return typeof e=="object"&&typeof e.response<"u"||!globalThis.hasOwnProperty("Image")?!1:new Promise(t=>{const i=new Image;i.onload=()=>{t(!0)},i.onerror=()=>{t(!1)},i.src=n})}}function Fu(n,e){return n?n.endsWith("/")?n.slice(0,-1):n:e}function B0({uri:n,gatewayUrls:e}){const t=ng.test(n);if(t)return{uri:n,isOnChain:!0,isEncoded:t};const i=Fu(e==null?void 0:e.ipfs,"https://ipfs.io"),o=Fu(e==null?void 0:e.arweave,"https://arweave.net"),r=n.match(eg),{protocol:s,subpath:a,target:c,subtarget:u=""}=(r==null?void 0:r.groups)||{},h=s==="ipns:/"||a==="ipns/",p=s==="ipfs:/"||a==="ipfs/"||tg.test(n);if(n.startsWith("http")&&!h&&!p){let b=n;return e!=null&&e.arweave&&(b=n.replace(/https:\/\/arweave.net/g,e==null?void 0:e.arweave)),{uri:b,isOnChain:!1,isEncoded:!1}}if((h||p)&&c)return{uri:`${i}/${h?"ipns":"ipfs"}/${c}${u}`,isOnChain:!1,isEncoded:!1};if(s==="ar:/"&&c)return{uri:`${o}/${c}${u||""}`,isOnChain:!1,isEncoded:!1};let g=n.replace(ig,"");if(g.startsWith("<svg")&&(g=`data:image/svg+xml;base64,${btoa(g)}`),g.startsWith("data:")||g.startsWith("{"))return{uri:g,isOnChain:!0,isEncoded:!1};throw new Tl({uri:n})}function j0(n){if(typeof n!="object"||!("image"in n)&&!("image_url"in n)&&!("image_data"in n))throw new Qf({data:n});return n.image||n.image_url||n.image_data}async function og({gatewayUrls:n,uri:e}){try{const t=await fetch(e).then(o=>o.json());return await Pl({gatewayUrls:n,uri:j0(t)})}catch{throw new Tl({uri:e})}}async function Pl({gatewayUrls:n,uri:e}){const{uri:t,isOnChain:i}=B0({uri:e,gatewayUrls:n});if(i||await rg(t))return t;throw new Tl({uri:e})}function sg(n){let e=n;e.startsWith("did:nft:")&&(e=e.replace("did:nft:","").replace(/_/g,"/"));const[t,i,o]=e.split("/"),[r,s]=t.split(":"),[a,c]=i.split(":");if(!r||r.toLowerCase()!=="eip155")throw new Yr({reason:"Only EIP-155 supported"});if(!s)throw new Yr({reason:"Chain ID not found"});if(!c)throw new Yr({reason:"Contract address not found"});if(!o)throw new Yr({reason:"Token ID not found"});if(!a)throw new Yr({reason:"ERC namespace not found"});return{chainID:parseInt(s),namespace:a.toLowerCase(),contractAddress:c,tokenID:o}}async function ag(n,{nft:e}){if(e.namespace==="erc721")return pr(n,{address:e.contractAddress,abi:[{name:"tokenURI",type:"function",stateMutability:"view",inputs:[{name:"tokenId",type:"uint256"}],outputs:[{name:"",type:"string"}]}],functionName:"tokenURI",args:[BigInt(e.tokenID)]});if(e.namespace==="erc1155")return pr(n,{address:e.contractAddress,abi:[{name:"uri",type:"function",stateMutability:"view",inputs:[{name:"_id",type:"uint256"}],outputs:[{name:"",type:"string"}]}],functionName:"uri",args:[BigInt(e.tokenID)]});throw new Xf({namespace:e.namespace})}async function cg(n,{gatewayUrls:e,record:t}){return/eip155:/i.test(t)?lg(n,{gatewayUrls:e,record:t}):Pl({uri:t,gatewayUrls:e})}async function lg(n,{gatewayUrls:e,record:t}){const i=sg(t),o=await ag(n,{nft:i}),{uri:r,isOnChain:s,isEncoded:a}=B0({uri:o,gatewayUrls:e});if(s&&(r.includes("data:application/json;base64,")||r.startsWith("{"))){const u=a?atob(r.replace("data:application/json;base64,","")):r,h=JSON.parse(u);return Pl({uri:j0(h),gatewayUrls:e})}let c=i.tokenID;return i.namespace==="erc1155"&&(c=c.replace("0x","").padStart(64,"0")),og({gatewayUrls:e,uri:r.replace(/(?:0x)?{id}/,c)})}async function ug(n,{blockNumber:e,blockTag:t,name:i,key:o,gatewayUrls:r,strict:s,universalResolverAddress:a}){let c=a;if(!c){if(!n.chain)throw new Error("client chain not configured. universalResolverAddress is required.");c=Ea({blockNumber:e,chain:n.chain,contract:"ensUniversalResolver"})}try{const u={address:c,abi:Pf,functionName:"resolve",args:[va(L0(i)),Ca({abi:Du,functionName:"text",args:[Yf(i),o]})],blockNumber:e,blockTag:t},h=ss(n,pr,"readContract"),p=r?await h({...u,args:[...u.args,r]}):await h(u);if(p[0]==="0x")return null;const g=_a({abi:Du,functionName:"text",data:p[0]});return g===""?null:g}catch(u){if(s)throw u;if(N0(u,"resolve"))return null;throw u}}async function dg(n,{blockNumber:e,blockTag:t,assetGatewayUrls:i,name:o,gatewayUrls:r,strict:s,universalResolverAddress:a}){const c=await ss(n,ug,"getEnsText")({blockNumber:e,blockTag:t,key:"avatar",name:o,universalResolverAddress:a,gatewayUrls:r,strict:s});if(!c)return null;try{return await cg(n,{record:c,gatewayUrls:i})}catch{return null}}async function hg(n,{address:e,blockNumber:t,blockTag:i,gatewayUrls:o,strict:r,universalResolverAddress:s}){let a=s;if(!a){if(!n.chain)throw new Error("client chain not configured. universalResolverAddress is required.");a=Ea({blockNumber:t,chain:n.chain,contract:"ensUniversalResolver"})}const c=`${e.toLowerCase().substring(2)}.addr.reverse`;try{const u={address:a,abi:Of,functionName:"reverse",args:[va(L0(c))],blockNumber:t,blockTag:i},h=ss(n,pr,"readContract"),[p,g]=o?await h({...u,args:[...u.args,o]}):await h(u);return e.toLowerCase()!==g.toLowerCase()?null:p}catch(u){if(r)throw u;if(N0(u,"reverse"))return null;throw u}}async function pg(n,{address:e,blockNumber:t,blockTag:i="latest"}){const o=t?Ne(t):void 0,r=await n.request({method:"eth_getBalance",params:[e,o||i]});return BigInt(r)}async function fg(n,e){var C;const{allowFailure:t=!0,batchSize:i,blockNumber:o,blockTag:r,multicallAddress:s,stateOverride:a}=e,c=e.contracts,u=i??(typeof((C=n.batch)==null?void 0:C.multicall)=="object"&&n.batch.multicall.batchSize||1024);let h=s;if(!h){if(!n.chain)throw new Error("client chain not configured. multicallAddress is required.");h=Ea({blockNumber:o,chain:n.chain,contract:"multicall3"})}const p=[[]];let g=0,b=0;for(let $=0;$<c.length;$++){const{abi:R,address:T,args:y,functionName:S}=c[$];try{const M=Ca({abi:R,args:y,functionName:S});b+=(M.length-2)/2,u>0&&b>u&&p[g].length>0&&(g++,b=(M.length-2)/2,p[g]=[]),p[g]=[...p[g],{allowFailure:!0,callData:M,target:T}]}catch(M){const D=jc(M,{abi:R,address:T,args:y,docsPath:"/docs/contract/multicall",functionName:S});if(!t)throw D;p[g]=[...p[g],{allowFailure:!0,callData:"0x",target:T}]}}const _=await Promise.allSettled(p.map($=>ss(n,pr,"readContract")({abi:qc,address:h,args:[$],blockNumber:o,blockTag:r,functionName:"aggregate3",stateOverride:a}))),x=[];for(let $=0;$<_.length;$++){const R=_[$];if(R.status==="rejected"){if(!t)throw R.reason;for(let y=0;y<p[$].length;y++)x.push({status:"failure",error:R.reason,result:void 0});continue}const T=R.value;for(let y=0;y<T.length;y++){const{returnData:S,success:M}=T[y],{callData:D}=p[$][y],{abi:ee,address:K,functionName:H,args:V}=c[x.length];try{if(D==="0x")throw new xa;if(!M)throw new Rl({data:S});const re=_a({abi:ee,args:V,data:S,functionName:H});x.push(t?{result:re,status:"success"}:re)}catch(re){const me=jc(re,{abi:ee,address:K,args:V,docsPath:"/docs/contract/multicall",functionName:H});if(!t)throw me;x.push({error:me,result:void 0,status:"failure"})}}}if(x.length!==c.length)throw new G("multicall results mismatch");return x}async function gg(n,{account:e=n.account,message:t}){if(!e)throw new Tf({docsPath:"/docs/actions/wallet/signMessage"});const i=jr(e);if(i.type==="local")return i.signMessage({message:t});const o=typeof t=="string"?s0(t):t.raw instanceof Uint8Array?va(t.raw):t.raw;return n.request({method:"personal_sign",params:[o,i.address]},{retryCount:0})}const mg=H1({id:1,name:"Ethereum",nativeCurrency:{name:"Ether",symbol:"ETH",decimals:18},rpcUrls:{default:{http:["https://cloudflare-eth.com"]}},blockExplorers:{default:{name:"Etherscan",url:"https://etherscan.io",apiUrl:"https://api.etherscan.io/api"}},contracts:{ensRegistry:{address:"0x00000000000C2E074eC69A0dFb2997BA6C7d2e1e"},ensUniversalResolver:{address:"0x8cab227b1162f03b8338331adaad7aadc83b895e",blockCreated:18958930},multicall3:{address:"0xca11bde05977b3631167028862be2a173976ca11",blockCreated:14353601}}});function wg(n){const e=t=>n(t.detail);return window.addEventListener("eip6963:announceProvider",e),window.dispatchEvent(new CustomEvent("eip6963:requestProvider")),()=>window.removeEventListener("eip6963:announceProvider",e)}function bg(){const n=new Set;let e=[];const t=()=>wg(o=>{e.some(({info:r})=>r.uuid===o.info.uuid)||(e=[...e,o],n.forEach(r=>r(e,{added:[o]})))});let i=t();return{_listeners(){return n},clear(){n.forEach(o=>o([],{removed:[...e]})),e=[]},destroy(){this.clear(),n.clear(),i()},findProvider({rdns:o}){return e.find(r=>r.info.rdns===o)},getProviders(){return e},reset(){this.clear(),i(),i=t()},subscribe(o,{emitImmediately:r}={}){return n.add(o),r&&o(e,{added:e}),()=>n.delete(o)}}}var vg={BASE_URL:"./",MODE:"production",DEV:!1,PROD:!0,SSR:!1};const yg=n=>(e,t,i)=>{const o=i.subscribe;return i.subscribe=(s,a,c)=>{let u=s;if(a){const h=(c==null?void 0:c.equalityFn)||Object.is;let p=s(i.getState());u=g=>{const b=s(g);if(!h(p,b)){const _=p;a(p=b,_)}},c!=null&&c.fireImmediately&&a(p,p)}return o(u)},n(e,t,i)},xg=yg;function Cg(n,e){let t;try{t=n()}catch{return}return{getItem:o=>{var r;const s=c=>c===null?null:JSON.parse(c,e==null?void 0:e.reviver),a=(r=t.getItem(o))!=null?r:null;return a instanceof Promise?a.then(s):s(a)},setItem:(o,r)=>t.setItem(o,JSON.stringify(r,e==null?void 0:e.replacer)),removeItem:o=>t.removeItem(o)}}const Ro=n=>e=>{try{const t=n(e);return t instanceof Promise?t:{then(i){return Ro(i)(t)},catch(i){return this}}}catch(t){return{then(i){return this},catch(i){return Ro(i)(t)}}}},_g=(n,e)=>(t,i,o)=>{let r={getStorage:()=>localStorage,serialize:JSON.stringify,deserialize:JSON.parse,partialize:C=>C,version:0,merge:(C,$)=>({...$,...C}),...e},s=!1;const a=new Set,c=new Set;let u;try{u=r.getStorage()}catch{}if(!u)return n((...C)=>{console.warn(`[zustand persist middleware] Unable to update item '${r.name}', the given storage is currently unavailable.`),t(...C)},i,o);const h=Ro(r.serialize),p=()=>{const C=r.partialize({...i()});let $;const R=h({state:C,version:r.version}).then(T=>u.setItem(r.name,T)).catch(T=>{$=T});if($)throw $;return R},g=o.setState;o.setState=(C,$)=>{g(C,$),p()};const b=n((...C)=>{t(...C),p()},i,o);let _;const x=()=>{var C;if(!u)return;s=!1,a.forEach(R=>R(i()));const $=((C=r.onRehydrateStorage)==null?void 0:C.call(r,i()))||void 0;return Ro(u.getItem.bind(u))(r.name).then(R=>{if(R)return r.deserialize(R)}).then(R=>{if(R)if(typeof R.version=="number"&&R.version!==r.version){if(r.migrate)return r.migrate(R.state,R.version);console.error("State loaded from storage couldn't be migrated since no migrate function was provided")}else return R.state}).then(R=>{var T;return _=r.merge(R,(T=i())!=null?T:b),t(_,!0),p()}).then(()=>{$==null||$(_,void 0),s=!0,c.forEach(R=>R(_))}).catch(R=>{$==null||$(void 0,R)})};return o.persist={setOptions:C=>{r={...r,...C},C.getStorage&&(u=C.getStorage())},clearStorage:()=>{u==null||u.removeItem(r.name)},getOptions:()=>r,rehydrate:()=>x(),hasHydrated:()=>s,onHydrate:C=>(a.add(C),()=>{a.delete(C)}),onFinishHydration:C=>(c.add(C),()=>{c.delete(C)})},x(),_||b},Eg=(n,e)=>(t,i,o)=>{let r={storage:Cg(()=>localStorage),partialize:x=>x,version:0,merge:(x,C)=>({...C,...x}),...e},s=!1;const a=new Set,c=new Set;let u=r.storage;if(!u)return n((...x)=>{console.warn(`[zustand persist middleware] Unable to update item '${r.name}', the given storage is currently unavailable.`),t(...x)},i,o);const h=()=>{const x=r.partialize({...i()});return u.setItem(r.name,{state:x,version:r.version})},p=o.setState;o.setState=(x,C)=>{p(x,C),h()};const g=n((...x)=>{t(...x),h()},i,o);let b;const _=()=>{var x,C;if(!u)return;s=!1,a.forEach(R=>{var T;return R((T=i())!=null?T:g)});const $=((C=r.onRehydrateStorage)==null?void 0:C.call(r,(x=i())!=null?x:g))||void 0;return Ro(u.getItem.bind(u))(r.name).then(R=>{if(R)if(typeof R.version=="number"&&R.version!==r.version){if(r.migrate)return r.migrate(R.state,R.version);console.error("State loaded from storage couldn't be migrated since no migrate function was provided")}else return R.state}).then(R=>{var T;return b=r.merge(R,(T=i())!=null?T:g),t(b,!0),h()}).then(()=>{$==null||$(b,void 0),b=i(),s=!0,c.forEach(R=>R(b))}).catch(R=>{$==null||$(void 0,R)})};return o.persist={setOptions:x=>{r={...r,...x},x.storage&&(u=x.storage)},clearStorage:()=>{u==null||u.removeItem(r.name)},getOptions:()=>r,rehydrate:()=>_(),hasHydrated:()=>s,onHydrate:x=>(a.add(x),()=>{a.delete(x)}),onFinishHydration:x=>(c.add(x),()=>{c.delete(x)})},r.skipHydration||_(),b||g},$g=(n,e)=>"getStorage"in e||"serialize"in e||"deserialize"in e?((vg?"production":void 0)!=="production"&&console.warn("[DEPRECATED] `getStorage`, `serialize` and `deserialize` options are deprecated. Use `storage` option instead."),_g(n,e)):Eg(n,e),Ag=$g;var Sg={BASE_URL:"./",MODE:"production",DEV:!1,PROD:!0,SSR:!1};const Hu=n=>{let e;const t=new Set,i=(c,u)=>{const h=typeof c=="function"?c(e):c;if(!Object.is(h,e)){const p=e;e=u??typeof h!="object"?h:Object.assign({},e,h),t.forEach(g=>g(e,p))}},o=()=>e,a={setState:i,getState:o,subscribe:c=>(t.add(c),()=>t.delete(c)),destroy:()=>{(Sg?"production":void 0)!=="production"&&console.warn("[DEPRECATED] The `destroy` method will be unsupported in a future version. Instead use unsubscribe function returned by subscribe. Everything will be garbage-collected if store is garbage-collected."),t.clear()}};return e=n(i,o,a),a},sc=n=>n?Hu(n):Hu;var D0={exports:{}};(function(n){var e=Object.prototype.hasOwnProperty,t="~";function i(){}Object.create&&(i.prototype=Object.create(null),new i().__proto__||(t=!1));function o(c,u,h){this.fn=c,this.context=u,this.once=h||!1}function r(c,u,h,p,g){if(typeof h!="function")throw new TypeError("The listener must be a function");var b=new o(h,p||c,g),_=t?t+u:u;return c._events[_]?c._events[_].fn?c._events[_]=[c._events[_],b]:c._events[_].push(b):(c._events[_]=b,c._eventsCount++),c}function s(c,u){--c._eventsCount===0?c._events=new i:delete c._events[u]}function a(){this._events=new i,this._eventsCount=0}a.prototype.eventNames=function(){var u=[],h,p;if(this._eventsCount===0)return u;for(p in h=this._events)e.call(h,p)&&u.push(t?p.slice(1):p);return Object.getOwnPropertySymbols?u.concat(Object.getOwnPropertySymbols(h)):u},a.prototype.listeners=function(u){var h=t?t+u:u,p=this._events[h];if(!p)return[];if(p.fn)return[p.fn];for(var g=0,b=p.length,_=new Array(b);g<b;g++)_[g]=p[g].fn;return _},a.prototype.listenerCount=function(u){var h=t?t+u:u,p=this._events[h];return p?p.fn?1:p.length:0},a.prototype.emit=function(u,h,p,g,b,_){var x=t?t+u:u;if(!this._events[x])return!1;var C=this._events[x],$=arguments.length,R,T;if(C.fn){switch(C.once&&this.removeListener(u,C.fn,void 0,!0),$){case 1:return C.fn.call(C.context),!0;case 2:return C.fn.call(C.context,h),!0;case 3:return C.fn.call(C.context,h,p),!0;case 4:return C.fn.call(C.context,h,p,g),!0;case 5:return C.fn.call(C.context,h,p,g,b),!0;case 6:return C.fn.call(C.context,h,p,g,b,_),!0}for(T=1,R=new Array($-1);T<$;T++)R[T-1]=arguments[T];C.fn.apply(C.context,R)}else{var y=C.length,S;for(T=0;T<y;T++)switch(C[T].once&&this.removeListener(u,C[T].fn,void 0,!0),$){case 1:C[T].fn.call(C[T].context);break;case 2:C[T].fn.call(C[T].context,h);break;case 3:C[T].fn.call(C[T].context,h,p);break;case 4:C[T].fn.call(C[T].context,h,p,g);break;default:if(!R)for(S=1,R=new Array($-1);S<$;S++)R[S-1]=arguments[S];C[T].fn.apply(C[T].context,R)}}return!0},a.prototype.on=function(u,h,p){return r(this,u,h,p,!1)},a.prototype.once=function(u,h,p){return r(this,u,h,p,!0)},a.prototype.removeListener=function(u,h,p,g){var b=t?t+u:u;if(!this._events[b])return this;if(!h)return s(this,b),this;var _=this._events[b];if(_.fn)_.fn===h&&(!g||_.once)&&(!p||_.context===p)&&s(this,b);else{for(var x=0,C=[],$=_.length;x<$;x++)(_[x].fn!==h||g&&!_[x].once||p&&_[x].context!==p)&&C.push(_[x]);C.length?this._events[b]=C.length===1?C[0]:C:s(this,b)}return this},a.prototype.removeAllListeners=function(u){var h;return u?(h=t?t+u:u,this._events[h]&&s(this,h)):(this._events=new i,this._eventsCount=0),this},a.prototype.off=a.prototype.removeListener,a.prototype.addListener=a.prototype.on,a.prefixed=t,a.EventEmitter=a,n.exports=a})(D0);var Ig=D0.exports;const Rg=r0(Ig);var Kr=function(n,e,t,i){if(t==="a"&&!i)throw new TypeError("Private accessor was defined without a getter");if(typeof e=="function"?n!==e||!i:!e.has(n))throw new TypeError("Cannot read private member from an object whose class did not declare it");return t==="m"?i:t==="a"?i.call(n):i?i.value:e.get(n)},li;class Tg{constructor(e){Object.defineProperty(this,"uid",{enumerable:!0,configurable:!0,writable:!0,value:e}),li.set(this,new Rg)}on(e,t){Kr(this,li,"f").on(e,t)}once(e,t){Kr(this,li,"f").once(e,t)}off(e,t){Kr(this,li,"f").off(e,t)}emit(e,...t){const i=t[0];Kr(this,li,"f").emit(e,{uid:this.uid,...i})}listenerCount(e){return Kr(this,li,"f").listenerCount(e)}}li=new WeakMap;function Pg(n){return new Tg(n)}function Og(n,e){return JSON.parse(n,(t,i)=>{let o=i;return(o==null?void 0:o.__type)==="bigint"&&(o=BigInt(o.value)),(o==null?void 0:o.__type)==="Map"&&(o=new Map(o.value)),(e==null?void 0:e(t,o))??o})}function Vu(n,e){return n.slice(0,e).join(".")||"."}function Zu(n,e){const{length:t}=n;for(let i=0;i<t;++i)if(n[i]===e)return i+1;return 0}function kg(n,e){const t=typeof n=="function",i=typeof e=="function",o=[],r=[];return function(a,c){if(typeof c=="object")if(o.length){const u=Zu(o,this);u===0?o[o.length]=this:(o.splice(u),r.splice(u)),r[r.length]=a;const h=Zu(o,c);if(h!==0)return i?e.call(this,a,c,Vu(r,h)):`[ref=${Vu(r,h)}]`}else o[0]=c,r[0]=a;return t?n.call(this,a,c):c}}function Ng(n,e,t,i){return JSON.stringify(n,kg((o,r)=>{let s=r;return typeof s=="bigint"&&(s={__type:"bigint",value:r.toString()}),s instanceof Map&&(s={__type:"Map",value:Array.from(r.entries())}),(e==null?void 0:e(o,s))??s},i),t??void 0)}function Mg(n){const{deserialize:e=Og,key:t="wagmi",serialize:i=Ng,storage:o=U0}=n;function r(s){return s instanceof Promise?s.then(a=>a).catch(()=>null):s}return{...o,key:t,async getItem(s,a){const c=o.getItem(`${t}.${s}`),u=await r(c);return u?e(u)??null:a??null},async setItem(s,a){const c=`${t}.${s}`;a===null?await r(o.removeItem(c)):await r(o.setItem(c,i(a)))},async removeItem(s){await r(o.removeItem(`${t}.${s}`))}}}const U0={getItem:()=>null,setItem:()=>{},removeItem:()=>{}};const Is="2.6.5",Lg=()=>`@wagmi/core@${Is}`;var W0=function(n,e,t,i){if(t==="a"&&!i)throw new TypeError("Private accessor was defined without a getter");if(typeof e=="function"?n!==e||!i:!e.has(n))throw new TypeError("Cannot read private member from an object whose class did not declare it");return t==="m"?i:t==="a"?i.call(n):i?i.value:e.get(n)},js,z0;class Cn extends Error{get docsBaseUrl(){return"https://wagmi.sh/core"}get version(){return Lg()}constructor(e,t={}){var r;super(),js.add(this),Object.defineProperty(this,"details",{enumerable:!0,configurable:!0,writable:!0,value:void 0}),Object.defineProperty(this,"docsPath",{enumerable:!0,configurable:!0,writable:!0,value:void 0}),Object.defineProperty(this,"metaMessages",{enumerable:!0,configurable:!0,writable:!0,value:void 0}),Object.defineProperty(this,"shortMessage",{enumerable:!0,configurable:!0,writable:!0,value:void 0}),Object.defineProperty(this,"name",{enumerable:!0,configurable:!0,writable:!0,value:"WagmiCoreError"});const i=t.cause instanceof Cn?t.cause.details:(r=t.cause)!=null&&r.message?t.cause.message:t.details,o=t.cause instanceof Cn&&t.cause.docsPath||t.docsPath;this.message=[e||"An error occurred.","",...t.metaMessages?[...t.metaMessages,""]:[],...o?[`Docs: ${this.docsBaseUrl}${o}.html${t.docsSlug?`#${t.docsSlug}`:""}`]:[],...i?[`Details: ${i}`]:[],`Version: ${this.version}`].join(`
`),t.cause&&(this.cause=t.cause),this.details=i,this.docsPath=o,this.metaMessages=t.metaMessages,this.shortMessage=e}walk(e){return W0(this,js,"m",z0).call(this,this,e)}}js=new WeakSet,z0=function n(e,t){return t!=null&&t(e)?e:e.cause?W0(this,js,"m",n).call(this,e.cause,t):e};class fr extends Cn{constructor(){super("Chain not configured."),Object.defineProperty(this,"name",{enumerable:!0,configurable:!0,writable:!0,value:"ChainNotConfiguredError"})}}class Bg extends Cn{constructor(){super("Connector already connected."),Object.defineProperty(this,"name",{enumerable:!0,configurable:!0,writable:!0,value:"ConnectorAlreadyConnectedError"})}}class jg extends Cn{constructor(){super("Connector not connected."),Object.defineProperty(this,"name",{enumerable:!0,configurable:!0,writable:!0,value:"ConnectorNotConnectedError"})}}class Dg extends Cn{constructor({address:e,connector:t}){super(`Account "${e}" not found for connector "${t.name}".`),Object.defineProperty(this,"name",{enumerable:!0,configurable:!0,writable:!0,value:"ConnectorAccountNotFoundError"})}}class ui extends Cn{constructor(){super("Provider not found."),Object.defineProperty(this,"name",{enumerable:!0,configurable:!0,writable:!0,value:"ProviderNotFoundError"})}}class Ug extends Cn{constructor({connector:e}){super(`"${e.name}" does not support programmatic chain switching.`),Object.defineProperty(this,"name",{enumerable:!0,configurable:!0,writable:!0,value:"SwitchChainNotSupportedError"})}}function en(n){if(typeof n=="string")return Number.parseInt(n,n.trim().substring(0,2)==="0x"?16:10);if(typeof n=="bigint")return Number(n);if(typeof n=="number")return n;throw new Error(`Cannot normalize chainId "${n}" of type "${typeof n}"`)}const Wg={coinbaseWallet:{id:"coinbaseWallet",name:"Coinbase Wallet",provider(n){return n!=null&&n.coinbaseWalletExtension?n.coinbaseWalletExtension:Rs(n,"isCoinbaseWallet")}},metaMask:{id:"metaMask",name:"MetaMask",provider(n){return Rs(n,e=>{if(!e.isMetaMask||e.isBraveWallet&&!e._events&&!e._state)return!1;const t=["isApexWallet","isAvalanche","isBitKeep","isBlockWallet","isKuCoinWallet","isMathWallet","isOkxWallet","isOKExWallet","isOneInchIOSWallet","isOneInchAndroidWallet","isOpera","isPortal","isRabby","isTokenPocket","isTokenary","isZerion"];for(const i of t)if(e[i])return!1;return!0})}},phantom:{id:"phantom",name:"Phantom",provider(n){var e,t;return(e=n==null?void 0:n.phantom)!=null&&e.ethereum?(t=n.phantom)==null?void 0:t.ethereum:Rs(n,"isPhantom")}}};$a.type="injected";function $a(n={}){const{shimDisconnect:e=!0,unstable_shimAsyncInject:t}=n;function i(){const o=n.target;if(typeof o=="function"){const r=o();if(r)return r}return typeof o=="object"?o:typeof o=="string"?{...Wg[o]??{id:o,name:`${o[0].toUpperCase()}${o.slice(1)}`,provider:`is${o[0].toUpperCase()}${o.slice(1)}`}}:{id:"injected",name:"Injected",provider(r){return r==null?void 0:r.ethereum}}}return o=>({get icon(){return i().icon},get id(){return i().id},get name(){return i().name},type:$a.type,async setup(){const r=await this.getProvider();r&&n.target&&r.on("connect",this.onConnect.bind(this))},async connect({chainId:r,isReconnecting:s}={}){var u,h,p,g,b,_;const a=await this.getProvider();if(!a)throw new ui;let c=null;if(!s&&(c=await this.getAccounts().catch(()=>null),!!(c!=null&&c.length)))try{c=(g=(p=(h=(u=(await a.request({method:"wallet_requestPermissions",params:[{eth_accounts:{}}]}))[0])==null?void 0:u.caveats)==null?void 0:h[0])==null?void 0:p.value)==null?void 0:g.map($=>Ot($))}catch(C){const $=C;if($.code===De.code)throw new De($);if($.code===Bn.code)throw $}try{c!=null&&c.length||(c=(await a.request({method:"eth_requestAccounts"})).map($=>Ot($))),a.removeListener("connect",this.onConnect.bind(this)),a.on("accountsChanged",this.onAccountsChanged.bind(this)),a.on("chainChanged",this.onChainChanged),a.on("disconnect",this.onDisconnect.bind(this));let x=await this.getChainId();if(r&&x!==r){const C=await this.switchChain({chainId:r}).catch($=>{if($.code===De.code)throw $;return{id:x}});x=(C==null?void 0:C.id)??x}return e&&(await((b=o.storage)==null?void 0:b.removeItem(`${this.id}.disconnected`)),n.target||await((_=o.storage)==null?void 0:_.setItem("injected.connected",!0))),{accounts:c,chainId:x}}catch(x){const C=x;throw C.code===De.code?new De(C):C.code===Bn.code?new Bn(C):C}},async disconnect(){var s,a;const r=await this.getProvider();if(!r)throw new ui;r.removeListener("accountsChanged",this.onAccountsChanged.bind(this)),r.removeListener("chainChanged",this.onChainChanged),r.removeListener("disconnect",this.onDisconnect.bind(this)),r.on("connect",this.onConnect.bind(this)),e&&(await((s=o.storage)==null?void 0:s.setItem(`${this.id}.disconnected`,!0)),n.target||await((a=o.storage)==null?void 0:a.removeItem("injected.connected")))},async getAccounts(){const r=await this.getProvider();if(!r)throw new ui;return(await r.request({method:"eth_accounts"})).map(a=>Ot(a))},async getChainId(){const r=await this.getProvider();if(!r)throw new ui;const s=await r.request({method:"eth_chainId"});return en(s)},async getProvider(){if(typeof window>"u")return;let r;const s=i();return typeof s.provider=="function"?r=s.provider(window):typeof s.provider=="string"?r=Rs(window,s.provider):r=s.provider,r&&!r.removeListener&&("off"in r&&typeof r.off=="function"?r.removeListener=r.off:r.removeListener=()=>{}),r},async isAuthorized(){var r,s;try{if(e&&await((r=o.storage)==null?void 0:r.getItem(`${this.id}.disconnected`))||!n.target&&!await((s=o.storage)==null?void 0:s.getItem("injected.connected")))return!1;if(!await this.getProvider()){if(t!==void 0&&t!==!1){const h=async()=>(typeof window<"u"&&window.removeEventListener("ethereum#initialized",h),!!await this.getProvider()),p=typeof t=="number"?t:1e3;if(await Promise.race([...typeof window<"u"?[new Promise(b=>window.addEventListener("ethereum#initialized",()=>b(h()),{once:!0}))]:[],new Promise(b=>setTimeout(()=>b(h()),p))]))return!0}throw new ui}return!!(await P0(()=>k0(()=>this.getAccounts(),{timeout:100}))).length}catch{return!1}},async switchChain({chainId:r}){var c,u,h;const s=await this.getProvider();if(!s)throw new ui;const a=o.chains.find(p=>p.id===r);if(!a)throw new ft(new fr);try{return await Promise.all([s.request({method:"wallet_switchEthereumChain",params:[{chainId:Ne(r)}]}),new Promise(p=>o.emitter.once("change",({chainId:g})=>{g===r&&p()}))]),a}catch(p){const g=p;if(g.code===4902||((u=(c=g==null?void 0:g.data)==null?void 0:c.originalError)==null?void 0:u.code)===4902)try{const{default:b,..._}=a.blockExplorers??{};let x=[];if(b&&(x=[b.url,...Object.values(_).map($=>$.url)]),await s.request({method:"wallet_addEthereumChain",params:[{chainId:Ne(r),chainName:a.name,nativeCurrency:a.nativeCurrency,rpcUrls:[((h=a.rpcUrls.default)==null?void 0:h.http[0])??""],blockExplorerUrls:x}]}),await this.getChainId()!==r)throw new De(new Error("User rejected switch after adding network."));return a}catch(b){throw new De(b)}throw g.code===De.code?new De(g):new ft(g)}},async onAccountsChanged(r){var s;if(r.length===0)this.onDisconnect();else if(o.emitter.listenerCount("connect")){const a=(await this.getChainId()).toString();this.onConnect({chainId:a}),e&&await((s=o.storage)==null?void 0:s.removeItem(`${this.id}.disconnected`))}else o.emitter.emit("change",{accounts:r.map(a=>Ot(a))})},onChainChanged(r){const s=en(r);o.emitter.emit("change",{chainId:s})},async onConnect(r){const s=await this.getAccounts();if(s.length===0)return;const a=en(r.chainId);o.emitter.emit("connect",{accounts:s,chainId:a});const c=await this.getProvider();c&&(c.removeListener("connect",this.onConnect.bind(this)),c.on("accountsChanged",this.onAccountsChanged.bind(this)),c.on("chainChanged",this.onChainChanged),c.on("disconnect",this.onDisconnect.bind(this)))},async onDisconnect(r){const s=await this.getProvider();r&&r.code===1013&&s&&(await this.getAccounts()).length||(o.emitter.emit("disconnect"),s&&(s.removeListener("accountsChanged",this.onAccountsChanged.bind(this)),s.removeListener("chainChanged",this.onChainChanged),s.removeListener("disconnect",this.onDisconnect.bind(this)),s.on("connect",this.onConnect.bind(this))))}})}function Rs(n,e){function t(o){return typeof e=="function"?e(o):typeof e=="string"?o[e]:!0}const i=n.ethereum;if(i!=null&&i.providers)return i.providers.find(o=>t(o));if(i&&t(i))return i}const Kc=256;let xs=Kc,Cs;function zg(n=11){if(!Cs||xs+n>Kc*2){Cs="",xs=0;for(let e=0;e<Kc;e++)Cs+=(256+Math.random()*256|0).toString(16).substring(1)}return Cs.substring(xs,xs+++n)}function Fg(n){const{multiInjectedProviderDiscovery:e=!0,storage:t=Mg({storage:typeof window<"u"&&window.localStorage?window.localStorage:U0}),syncConnectedChain:i=!0,ssr:o,...r}=n,s=typeof window<"u"&&e?bg():void 0,a=sc(()=>r.chains),c=sc(()=>[...r.connectors??[],...o?[]:(s==null?void 0:s.getProviders().map(h))??[]].map(u));function u(y){var D;const S=Pg(zg()),M={...y({emitter:S,chains:a.getState(),storage:t}),emitter:S,uid:S.uid};return S.on("connect",R),(D=M.setup)==null||D.call(M),M}function h(y){const{info:S}=y,M=y.provider;return $a({target:{...S,id:S.rdns,provider:M}})}const p=new Map;function g(y={}){const S=y.chainId??C.getState().chainId,M=a.getState().find(ee=>ee.id===S);if(y.chainId&&!M)throw new fr;{const ee=p.get(C.getState().chainId);if(ee&&!M)return ee;if(!M)throw new fr}{const ee=p.get(S);if(ee)return ee}let D;if(r.client)D=r.client({chain:M});else{const ee=M.id,K=a.getState().map(re=>re.id),H={},V=Object.entries(r);for(const[re,me]of V)if(!(re==="chains"||re==="client"||re==="connectors"||re==="transports"))if(typeof me=="object")if(ee in me)H[re]=me[ee];else{if(K.some(mn=>mn in me))continue;H[re]=me}else H[re]=me;D=T0({...H,chain:M,batch:H.batch??{multicall:!0},transport:re=>r.transports[ee]({...re,connectors:c})})}return p.set(S,D),D}function b(){return{chainId:a.getState()[0].id,connections:new Map,current:void 0,status:"disconnected"}}let _;const x="0.0.0-canary-";Is.startsWith(x)?_=parseInt(Is.replace(x,"")):_=parseInt(Is.split(".")[0]??"0");const C=sc(xg(t?Ag(b,{migrate(y,S){if(S===_)return y;const M=b(),D=y&&typeof y=="object"&&"chainId"in y&&typeof y.chainId=="number"?y.chainId:M.chainId;return{...M,chainId:D}},name:"store",partialize(y){return{connections:{__type:"Map",value:Array.from(y.connections.entries()).map(([S,M])=>{const{id:D,name:ee,type:K,uid:H}=M.connector;return[S,{...M,connector:{id:D,name:ee,type:K,uid:H}}]})},chainId:y.chainId,current:y.current}},skipHydration:o,storage:t,version:_}):b));i&&C.subscribe(({connections:y,current:S})=>{var M;return S?(M=y.get(S))==null?void 0:M.chainId:void 0},y=>{if(a.getState().some(M=>M.id===y))return C.setState(M=>({...M,chainId:y??M.chainId}))}),s==null||s.subscribe(y=>{const S=new Map;for(const D of c.getState())S.set(D.id,!0);const M=[];for(const D of y){const ee=u(h(D));S.has(ee.id)||M.push(ee)}c.setState(D=>[...D,...M],!0)});function $(y){C.setState(S=>{const M=S.connections.get(y.uid);return M?{...S,connections:new Map(S.connections).set(y.uid,{accounts:y.accounts??M.accounts,chainId:y.chainId??M.chainId,connector:M.connector})}:S})}function R(y){C.getState().status==="connecting"||C.getState().status==="reconnecting"||C.setState(S=>{const M=c.getState().find(D=>D.uid===y.uid);return M?{...S,connections:new Map(S.connections).set(y.uid,{accounts:y.accounts,chainId:y.chainId,connector:M}),current:y.uid,status:"connected"}:S})}function T(y){C.setState(S=>{const M=S.connections.get(y.uid);if(M&&(M.connector.emitter.off("change",$),M.connector.emitter.off("disconnect",T),M.connector.emitter.on("connect",R)),S.connections.delete(y.uid),S.connections.size===0)return{...S,connections:new Map,current:void 0,status:"disconnected"};const D=S.connections.values().next().value;return{...S,connections:new Map(S.connections),current:D.connector.uid}})}return{get chains(){return a.getState()},get connectors(){return c.getState()},storage:t,getClient:g,get state(){return C.getState()},setState(y){let S;typeof y=="function"?S=y(C.getState()):S=y;const M=b();typeof S!="object"&&(S=M),Object.keys(M).some(ee=>!(ee in S))&&(S=M),C.setState(S,!0)},subscribe(y,S,M){return C.subscribe(y,S,M?{...M,fireImmediately:M.emitImmediately}:void 0)},_internal:{mipd:s,store:C,ssr:!!o,syncConnectedChain:i,transports:r.transports,chains:{setState(y){const S=typeof y=="function"?y(a.getState()):y;if(S.length!==0)return a.setState(S,!0)},subscribe(y){return a.subscribe(y)}},connectors:{providerDetailToConnector:h,setup:u,setState(y){return c.setState(typeof y=="function"?y(c.getState()):y,!0)},subscribe(y){return c.subscribe(y)}},events:{change:$,connect:R,disconnect:T}}}}function Ur(n,e,t){const i=n[e.name??t];return typeof i=="function"?i:o=>e(n,o)}async function qu(n,e){var i;let t;if(typeof e.connector=="function"?t=n._internal.connectors.setup(e.connector):t=e.connector,t.uid===n.state.current)throw new Bg;try{n.setState(s=>({...s,status:"connecting"})),t.emitter.emit("message",{type:"connecting"});const o=await t.connect({chainId:e.chainId}),r=o.accounts;return t.emitter.off("connect",n._internal.events.connect),t.emitter.on("change",n._internal.events.change),t.emitter.on("disconnect",n._internal.events.disconnect),await((i=n.storage)==null?void 0:i.setItem("recentConnectorId",t.id)),n.setState(s=>({...s,connections:new Map(s.connections).set(t.uid,{accounts:r,chainId:o.chainId,connector:t}),current:t.uid,status:"connected"})),{accounts:r,chainId:o.chainId}}catch(o){throw n.setState(r=>({...r,status:r.current?"connected":"disconnected"})),o}}async function Hg(n,e={}){var o,r;let t;if(e.connector)t=e.connector;else{const{connections:s,current:a}=n.state,c=s.get(a);t=c==null?void 0:c.connector}const i=n.state.connections;t&&(await t.disconnect(),t.emitter.off("change",n._internal.events.change),t.emitter.off("disconnect",n._internal.events.disconnect),t.emitter.on("connect",n._internal.events.connect),i.delete(t.uid)),n.setState(s=>{if(i.size===0)return{...s,connections:new Map,current:void 0,status:"disconnected"};const a=i.values().next().value;return{...s,connections:new Map(i),current:a.connector.uid}});{const s=n.state.current;if(!s)return;const a=(o=n.state.connections.get(s))==null?void 0:o.connector;if(!a)return;await((r=n.storage)==null?void 0:r.setItem("recentConnectorId",a.id))}}async function Vg(n,e={}){let t;if(e.connector){const{connector:c}=e,[u,h]=await Promise.all([c.getAccounts(),c.getChainId()]);t={accounts:u,chainId:h,connector:c}}else t=n.state.connections.get(n.state.current);if(!t)throw new jg;const i=e.chainId??t.chainId,o=t.connector;if(o.getClient)return o.getClient({chainId:i});const r=jr(e.account??t.accounts[0]),s=n.chains.find(c=>c.id===i),a=await t.connector.getProvider({chainId:i});if(e.account&&!t.accounts.includes(r.address))throw new Dg({address:r.address,connector:o});return T0({account:r,chain:s,name:"Connector Client",transport:c=>Vf(a)({...c,retryCount:0})})}function F0(n){return typeof n=="number"?n:n==="wei"?0:Math.abs(ff[n])}function Ds(n){const e=n.state.current,t=n.state.connections.get(e),i=t==null?void 0:t.accounts,o=i==null?void 0:i[0],r=n.chains.find(a=>a.id===(t==null?void 0:t.chainId)),s=n.state.status;switch(s){case"connected":return{address:o,addresses:i,chain:r,chainId:t==null?void 0:t.chainId,connector:t==null?void 0:t.connector,isConnected:!0,isConnecting:!1,isDisconnected:!1,isReconnecting:!1,status:s};case"reconnecting":return{address:o,addresses:i,chain:r,chainId:t==null?void 0:t.chainId,connector:t==null?void 0:t.connector,isConnected:!!o,isConnecting:!1,isDisconnected:!1,isReconnecting:!0,status:s};case"connecting":return{address:o,addresses:i,chain:r,chainId:t==null?void 0:t.chainId,connector:t==null?void 0:t.connector,isConnected:!1,isConnecting:!0,isDisconnected:!1,isReconnecting:!1,status:s};case"disconnected":return{address:void 0,addresses:void 0,chain:void 0,chainId:void 0,connector:void 0,isConnected:!1,isConnecting:!1,isDisconnected:!0,isReconnecting:!1,status:s}}}async function Zg(n,e){const{allowFailure:t=!0,chainId:i,contracts:o,...r}=e,s=n.getClient({chainId:i});return Ur(s,fg,"multicall")({allowFailure:t,contracts:o,...r})}function qg(n,e){const{chainId:t,...i}=e,o=n.getClient({chainId:t});return Ur(o,pr,"readContract")(i)}async function Gg(n,e){const{allowFailure:t=!0,blockNumber:i,blockTag:o,...r}=e,s=e.contracts;try{const a=s.reduce((p,g,b)=>{const _=g.chainId??n.state.chainId;return{...p,[_]:[...p[_]||[],{contract:g,index:b}]}},{}),c=()=>Object.entries(a).map(([p,g])=>Zg(n,{...r,allowFailure:t,blockNumber:i,blockTag:o,chainId:parseInt(p),contracts:g.map(({contract:b})=>b)})),u=(await Promise.all(c())).flat(),h=Object.values(a).flatMap(p=>p.map(({index:g})=>g));return u.reduce((p,g,b)=>(p&&(p[h[b]]=g),p),[])}catch(a){if(a instanceof Il)throw a;const c=()=>s.map(u=>qg(n,{...u,blockNumber:i,blockTag:o}));return t?(await Promise.allSettled(c())).map(u=>u.status==="fulfilled"?{result:u.value,status:"success"}:{error:u.reason,result:void 0,status:"failure"}):await Promise.all(c())}}async function Yg(n,e){const{address:t,blockNumber:i,blockTag:o,chainId:r,token:s,unit:a="ether"}=e;if(s)try{return Gu(n,{balanceAddress:t,chainId:r,symbolType:"string",tokenAddress:s})}catch(g){if(g instanceof Il){const b=await Gu(n,{balanceAddress:t,chainId:r,symbolType:"bytes32",tokenAddress:s}),_=V1(a0(b.symbol,{dir:"right"}));return{...b,symbol:_}}throw g}const c=n.getClient({chainId:r}),h=await Ur(c,pg,"getBalance")(i?{address:t,blockNumber:i}:{address:t,blockTag:o}),p=n.chains.find(g=>g.id===r)??c.chain;return{decimals:p.nativeCurrency.decimals,formatted:ya(h,F0(a)),symbol:p.nativeCurrency.symbol,value:h}}async function Gu(n,e){const{balanceAddress:t,chainId:i,symbolType:o,tokenAddress:r,unit:s}=e,a={abi:[{type:"function",name:"balanceOf",stateMutability:"view",inputs:[{type:"address"}],outputs:[{type:"uint256"}]},{type:"function",name:"decimals",stateMutability:"view",inputs:[],outputs:[{type:"uint8"}]},{type:"function",name:"symbol",stateMutability:"view",inputs:[],outputs:[{type:o}]}],address:r},[c,u,h]=await Gg(n,{allowFailure:!1,contracts:[{...a,functionName:"balanceOf",args:[t],chainId:i},{...a,functionName:"decimals",chainId:i},{...a,functionName:"symbol",chainId:i}]}),p=ya(c??"0",F0(s??u));return{decimals:u,formatted:p,symbol:h,value:c}}function Jc(n,e){if(n===e)return!0;if(n&&e&&typeof n=="object"&&typeof e=="object"){if(n.constructor!==e.constructor)return!1;let t,i;if(Array.isArray(n)&&Array.isArray(e)){if(t=n.length,t!==e.length)return!1;for(i=t;i--!==0;)if(!Jc(n[i],e[i]))return!1;return!0}if(n.valueOf!==Object.prototype.valueOf)return n.valueOf()===e.valueOf();if(n.toString!==Object.prototype.toString)return n.toString()===e.toString();const o=Object.keys(n);if(t=o.length,t!==Object.keys(e).length)return!1;for(i=t;i--!==0;)if(!Object.prototype.hasOwnProperty.call(e,o[i]))return!1;for(i=t;i--!==0;){const r=o[i];if(r&&!Jc(n[r],e[r]))return!1}return!0}return n!==n&&e!==e}function Kg(n,e){const{chainId:t,...i}=e,o=n.getClient({chainId:t});return Ur(o,dg,"getEnsAvatar")(i)}function Jg(n,e){const{chainId:t,...i}=e,o=n.getClient({chainId:t});return Ur(o,hg,"getEnsName")(i)}let ac=!1;async function Qg(n,e={}){var u,h;if(ac)return[];ac=!0,n.setState(p=>({...p,status:p.current?"reconnecting":"connecting"}));const t=[];if((u=e.connectors)!=null&&u.length)for(const p of e.connectors){let g;typeof p=="function"?g=n._internal.connectors.setup(p):g=p,t.push(g)}else t.push(...n.connectors);let i;try{i=await((h=n.storage)==null?void 0:h.getItem("recentConnectorId"))}catch{}const o={};for(const[,p]of n.state.connections)o[p.connector.id]=1;i&&(o[i]=0);const r=Object.keys(o).length>0?[...t].sort((p,g)=>(o[p.id]??10)-(o[g.id]??10)):t;let s=!1;const a=[],c=[];for(const p of r){const g=await p.getProvider();if(!g||c.some(x=>x===g)||!await p.isAuthorized())continue;const _=await p.connect({isReconnecting:!0}).catch(()=>null);_&&(p.emitter.off("connect",n._internal.events.connect),p.emitter.on("change",n._internal.events.change),p.emitter.on("disconnect",n._internal.events.disconnect),n.setState(x=>{const C=new Map(s?x.connections:new Map).set(p.uid,{accounts:_.accounts,chainId:_.chainId,connector:p});return{...x,current:s?x.current:p.uid,connections:C}}),a.push({accounts:_.accounts,chainId:_.chainId,connector:p}),c.push(g),s=!0)}return s?n.setState(p=>({...p,status:"connected"})):n.setState(p=>({...p,connections:new Map,current:void 0,status:"disconnected"})),ac=!1,a}async function Xg(n,e){const{account:t,connector:i,...o}=e;let r;return typeof t=="object"&&t.type==="local"?r=n.getClient():r=await Vg(n,{account:t,connector:i}),Ur(r,gg,"signMessage")({...o,...t?{account:t}:{}})}async function em(n,e){var r;const{chainId:t}=e,i=n.state.connections.get(((r=e.connector)==null?void 0:r.uid)??n.state.current);if(i){const s=i.connector;if(!s.switchChain)throw new Ug({connector:s});return await s.switchChain({chainId:t})}const o=n.chains.find(s=>s.id===t);if(!o)throw new fr;return n.setState(s=>({...s,chainId:t})),o}function tm(n,e){const{onChange:t}=e;return n.subscribe(()=>Ds(n),t,{equalityFn(i,o){const{connector:r,...s}=i,{connector:a,...c}=o;return Jc(s,c)&&(r==null?void 0:r.id)===(a==null?void 0:a.id)&&(r==null?void 0:r.uid)===(a==null?void 0:a.uid)}})}function nm(n,e){const{onChange:t}=e;return n._internal.connectors.subscribe((i,o)=>{t(Object.values(i),o)})}const im=Symbol(),Yu=Object.getPrototypeOf,Qc=new WeakMap,rm=n=>n&&(Qc.has(n)?Qc.get(n):Yu(n)===Object.prototype||Yu(n)===Array.prototype),om=n=>rm(n)&&n[im]||null,Ku=(n,e=!0)=>{Qc.set(n,e)};var Us={BASE_URL:"./",MODE:"production",DEV:!1,PROD:!0,SSR:!1};const cc=n=>typeof n=="object"&&n!==null,Pn=new WeakMap,to=new WeakSet,sm=(n=Object.is,e=(u,h)=>new Proxy(u,h),t=u=>cc(u)&&!to.has(u)&&(Array.isArray(u)||!(Symbol.iterator in u))&&!(u instanceof WeakMap)&&!(u instanceof WeakSet)&&!(u instanceof Error)&&!(u instanceof Number)&&!(u instanceof Date)&&!(u instanceof String)&&!(u instanceof RegExp)&&!(u instanceof ArrayBuffer),i=u=>{switch(u.status){case"fulfilled":return u.value;case"rejected":throw u.reason;default:throw u}},o=new WeakMap,r=(u,h,p=i)=>{const g=o.get(u);if((g==null?void 0:g[0])===h)return g[1];const b=Array.isArray(u)?[]:Object.create(Object.getPrototypeOf(u));return Ku(b,!0),o.set(u,[h,b]),Reflect.ownKeys(u).forEach(_=>{if(Object.getOwnPropertyDescriptor(b,_))return;const x=Reflect.get(u,_),C={value:x,enumerable:!0,configurable:!0};if(to.has(x))Ku(x,!1);else if(x instanceof Promise)delete C.value,C.get=()=>p(x);else if(Pn.has(x)){const[$,R]=Pn.get(x);C.value=r($,R(),p)}Object.defineProperty(b,_,C)}),Object.preventExtensions(b)},s=new WeakMap,a=[1,1],c=u=>{if(!cc(u))throw new Error("object required");const h=s.get(u);if(h)return h;let p=a[0];const g=new Set,b=(K,H=++a[0])=>{p!==H&&(p=H,g.forEach(V=>V(K,H)))};let _=a[1];const x=(K=++a[1])=>(_!==K&&!g.size&&(_=K,$.forEach(([H])=>{const V=H[1](K);V>p&&(p=V)})),p),C=K=>(H,V)=>{const re=[...H];re[1]=[K,...re[1]],b(re,V)},$=new Map,R=(K,H)=>{if((Us?"production":void 0)!=="production"&&$.has(K))throw new Error("prop listener already exists");if(g.size){const V=H[3](C(K));$.set(K,[H,V])}else $.set(K,[H])},T=K=>{var H;const V=$.get(K);V&&($.delete(K),(H=V[1])==null||H.call(V))},y=K=>(g.add(K),g.size===1&&$.forEach(([V,re],me)=>{if((Us?"production":void 0)!=="production"&&re)throw new Error("remove already exists");const gn=V[3](C(me));$.set(me,[V,gn])}),()=>{g.delete(K),g.size===0&&$.forEach(([V,re],me)=>{re&&(re(),$.set(me,[V]))})}),S=Array.isArray(u)?[]:Object.create(Object.getPrototypeOf(u)),D=e(S,{deleteProperty(K,H){const V=Reflect.get(K,H);T(H);const re=Reflect.deleteProperty(K,H);return re&&b(["delete",[H],V]),re},set(K,H,V,re){const me=Reflect.has(K,H),gn=Reflect.get(K,H,re);if(me&&(n(gn,V)||s.has(V)&&n(gn,s.get(V))))return!0;T(H),cc(V)&&(V=om(V)||V);let mn=V;if(V instanceof Promise)V.then(Vt=>{V.status="fulfilled",V.value=Vt,b(["resolve",[H],Vt])}).catch(Vt=>{V.status="rejected",V.reason=Vt,b(["reject",[H],Vt])});else{!Pn.has(V)&&t(V)&&(mn=c(V));const Vt=!to.has(mn)&&Pn.get(mn);Vt&&R(H,Vt)}return Reflect.set(K,H,mn,re),b(["set",[H],V,gn]),!0}});s.set(u,D);const ee=[S,x,r,y];return Pn.set(D,ee),Reflect.ownKeys(u).forEach(K=>{const H=Object.getOwnPropertyDescriptor(u,K);"value"in H&&(D[K]=u[K],delete H.value,delete H.writable),Object.defineProperty(S,K,H)}),D})=>[c,Pn,to,n,e,t,i,o,r,s,a],[am]=sm();function Ke(n={}){return am(n)}function Lt(n,e,t){const i=Pn.get(n);(Us?"production":void 0)!=="production"&&!i&&console.warn("Please use proxy object");let o;const r=[],s=i[3];let a=!1;const u=s(h=>{if(r.push(h),t){e(r.splice(0));return}o||(o=Promise.resolve().then(()=>{o=void 0,a&&e(r.splice(0))}))});return a=!0,()=>{a=!1,u()}}function H0(n,e){const t=Pn.get(n);(Us?"production":void 0)!=="production"&&!t&&console.warn("Please use proxy object");const[i,o,r]=t;return r(i,o(),e)}function To(n){return to.add(n),n}function At(n,e,t,i){let o=n[e];return Lt(n,()=>{const r=n[e];Object.is(o,r)||t(o=r)},i)}const lc="https://secure.walletconnect.com",cm=[{label:"Coinbase",name:"coinbase",feeRange:"1-2%",url:""}],pt={FOUR_MINUTES_MS:24e4,TEN_SEC_MS:1e4,ONE_SEC_MS:1e3,SECURE_SITE:lc,SECURE_SITE_DASHBOARD:`${lc}/dashboard`,SECURE_SITE_FAVICON:`${lc}/images/favicon.png`,RESTRICTED_TIMEZONES:["ASIA/SHANGHAI","ASIA/URUMQI","ASIA/CHONGQING","ASIA/HARBIN","ASIA/KASHGAR","ASIA/MACAU","ASIA/HONG_KONG","ASIA/MACAO","ASIA/BEIJING","ASIA/HARBIN"],CONNECTOR_RDNS_MAP:{coinbaseWallet:"com.coinbase.wallet"},WC_COINBASE_PAY_SDK_CHAINS:["ethereum","arbitrum","polygon","avalanche-c-chain","optimism","celo","base"],WC_COINBASE_PAY_SDK_FALLBACK_CHAIN:"ethereum",WC_COINBASE_PAY_SDK_CHAIN_NAME_MAP:{Ethereum:"ethereum","Arbitrum One":"arbitrum",Polygon:"polygon",Avalanche:"avalanche-c-chain","OP Mainnet":"optimism",Celo:"celo",Base:"base"},WC_COINBASE_ONRAMP_APP_ID:"bf18c88d-495a-463b-b249-0b9d3656cf5e"},F={isMobile(){return typeof window<"u"?!!(window.matchMedia("(pointer:coarse)").matches||/Android|webOS|iPhone|iPad|iPod|BlackBerry|Opera Mini/u.test(navigator.userAgent)):!1},isAndroid(){const n=window.navigator.userAgent.toLowerCase();return F.isMobile()&&n.includes("android")},isIos(){const n=window.navigator.userAgent.toLowerCase();return F.isMobile()&&(n.includes("iphone")||n.includes("ipad"))},isClient(){return typeof window<"u"},isPairingExpired(n){return n?n-Date.now()<=pt.TEN_SEC_MS:!0},isAllowedRetry(n){return Date.now()-n>=pt.ONE_SEC_MS},copyToClopboard(n){navigator.clipboard.writeText(n)},getPairingExpiry(){return Date.now()+pt.FOUR_MINUTES_MS},getPlainAddress(n){return n.split(":")[2]},async wait(n){return new Promise(e=>{setTimeout(e,n)})},debounce(n,e=500){let t;return(...i)=>{function o(){n(...i)}t&&clearTimeout(t),t=setTimeout(o,e)}},isHttpUrl(n){return n.startsWith("http://")||n.startsWith("https://")},formatNativeUrl(n,e){if(F.isHttpUrl(n))return this.formatUniversalUrl(n,e);let t=n;t.includes("://")||(t=n.replaceAll("/","").replaceAll(":",""),t=`${t}://`),t.endsWith("/")||(t=`${t}/`);const i=encodeURIComponent(e);return{redirect:`${t}wc?uri=${i}`,href:t}},formatUniversalUrl(n,e){if(!F.isHttpUrl(n))return this.formatNativeUrl(n,e);let t=n;t.endsWith("/")||(t=`${t}/`);const i=encodeURIComponent(e);return{redirect:`${t}wc?uri=${i}`,href:t}},openHref(n,e,t){window.open(n,e,t||"noreferrer noopener")},async preloadImage(n){const e=new Promise((t,i)=>{const o=new Image;o.onload=t,o.onerror=i,o.crossOrigin="anonymous",o.src=n});return Promise.race([e,F.wait(2e3)])},formatBalance(n,e){var i;let t;if(n==="0")t="0.000";else if(typeof n=="string"){const o=Number(n);o&&(t=(i=o.toString().match(/^-?\d+(?:\.\d{0,3})?/u))==null?void 0:i[0])}return t?`${t} ${e??""}`:`0.000 ${e??""}`},formatBalance2(n,e){var i;let t;if(n==="0")t="0";else if(typeof n=="string"){const o=Number(n);o&&(t=(i=o.toString().match(/^-?\d+(?:\.\d{0,3})?/u))==null?void 0:i[0])}return{value:t??"0",rest:t==="0"?"000":"",symbol:e}},isRestrictedRegion(){try{const{timeZone:n}=new Intl.DateTimeFormat().resolvedOptions(),e=n.toUpperCase();return pt.RESTRICTED_TIMEZONES.includes(e)}catch{return!1}},getApiUrl(){return F.isRestrictedRegion()?"https://api.web3modal.org":"https://api.web3modal.com"},getBlockchainApiUrl(){return F.isRestrictedRegion()?"https://rpc.walletconnect.org":"https://rpc.walletconnect.com"},getAnalyticsUrl(){return F.isRestrictedRegion()?"https://pulse.walletconnect.org":"https://pulse.walletconnect.com"},getUUID(){return crypto!=null&&crypto.randomUUID?crypto.randomUUID():"xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/gu,n=>{const e=Math.random()*16|0;return(n==="x"?e:e&3|8).toString(16)})},parseError(n){var e,t;return typeof n=="string"?n:typeof((t=(e=n==null?void 0:n.issues)==null?void 0:e[0])==null?void 0:t.message)=="string"?n.issues[0].message:n instanceof Error?n.message:"Unknown error"},sortRequestedNetworks(n,e=[]){const t={};return e&&n&&(n.forEach((i,o)=>{t[i]=o}),e.sort((i,o)=>{const r=t[i.id],s=t[o.id];return r!==void 0&&s!==void 0?r-s:r!==void 0?-1:s!==void 0?1:0})),e}},je=Ke({isConnected:!1}),ne={state:je,subscribe(n){return Lt(je,()=>n(je))},subscribeKey(n,e){return At(je,n,e)},setIsConnected(n){je.isConnected=n},setCaipAddress(n){je.caipAddress=n,je.address=n?F.getPlainAddress(n):void 0},setBalance(n,e){je.balance=n,je.balanceSymbol=e},setProfileName(n){je.profileName=n},setProfileImage(n){je.profileImage=n},setAddressExplorerUrl(n){je.addressExplorerUrl=n},resetAccount(){je.isConnected=!1,je.caipAddress=void 0,je.address=void 0,je.balance=void 0,je.balanceSymbol=void 0,je.profileName=void 0,je.profileImage=void 0,je.addressExplorerUrl=void 0}};class Ol{constructor({baseUrl:e}){this.baseUrl=e}async get({headers:e,signal:t,...i}){const o=this.createUrl(i);return(await fetch(o,{method:"GET",headers:e,signal:t,cache:"no-cache"})).json()}async getBlob({headers:e,signal:t,...i}){const o=this.createUrl(i);return(await fetch(o,{method:"GET",headers:e,signal:t})).blob()}async post({body:e,headers:t,signal:i,...o}){const r=this.createUrl(o);return(await fetch(r,{method:"POST",headers:t,body:e?JSON.stringify(e):void 0,signal:i})).json()}async put({body:e,headers:t,signal:i,...o}){const r=this.createUrl(o);return(await fetch(r,{method:"PUT",headers:t,body:e?JSON.stringify(e):void 0,signal:i})).json()}async delete({body:e,headers:t,signal:i,...o}){const r=this.createUrl(o);return(await fetch(r,{method:"DELETE",headers:t,body:e?JSON.stringify(e):void 0,signal:i})).json()}createUrl({path:e,params:t}){const i=new URL(e,this.baseUrl);return t&&Object.entries(t).forEach(([o,r])=>{r&&i.searchParams.append(o,r)}),i}}const uc="WALLETCONNECT_DEEPLINK_CHOICE",Ju="@w3m/recent",Qu="@w3m/connected_wallet_image_url",Xu="@w3m/connected_connector",Ze={setWalletConnectDeepLink({href:n,name:e}){try{localStorage.setItem(uc,JSON.stringify({href:n,name:e}))}catch{console.info("Unable to set WalletConnect deep link")}},getWalletConnectDeepLink(){try{const n=localStorage.getItem(uc);if(n)return JSON.parse(n)}catch{console.info("Unable to get WalletConnect deep link")}},deleteWalletConnectDeepLink(){try{localStorage.removeItem(uc)}catch{console.info("Unable to delete WalletConnect deep link")}},setWeb3ModalRecent(n){try{const e=Ze.getRecentWallets();e.find(i=>i.id===n.id)||(e.unshift(n),e.length>2&&e.pop(),localStorage.setItem(Ju,JSON.stringify(e)))}catch{console.info("Unable to set Web3Modal recent")}},getRecentWallets(){try{const n=localStorage.getItem(Ju);return n?JSON.parse(n):[]}catch{console.info("Unable to get Web3Modal recent")}return[]},setConnectedWalletImageUrl(n){try{localStorage.setItem(Qu,n)}catch{console.info("Unable to set Connected Wallet Image Url")}},getConnectedWalletImageUrl(){try{return localStorage.getItem(Qu)}catch{console.info("Unable to set Connected Wallet Image Url")}},setConnectedConnector(n){try{localStorage.setItem(Xu,n)}catch{console.info("Unable to set Connected Connector")}},getConnectedConnector(){try{return localStorage.getItem(Xu)}catch{console.info("Unable to get Connected Connector")}}},Rt=Ke({walletImages:{},networkImages:{},connectorImages:{},tokenImages:{},currencyImages:{}}),He={state:Rt,subscribeNetworkImages(n){return Lt(Rt.networkImages,()=>n(Rt.networkImages))},subscribeKey(n,e){return At(Rt,n,e)},subscribe(n){return Lt(Rt,()=>n(Rt))},setWalletImage(n,e){Rt.walletImages[n]=e},setNetworkImage(n,e){Rt.networkImages[n]=e},setConnectorImage(n,e){Rt.connectorImages[n]=e},setTokenImage(n,e){Rt.tokenImages[n]=e},setCurrencyImage(n,e){Rt.currencyImages[n]=e}},Je=Ke({projectId:"",sdkType:"w3m",sdkVersion:"html-wagmi-undefined"}),ce={state:Je,subscribeKey(n,e){return At(Je,n,e)},setProjectId(n){Je.projectId=n},setAllWallets(n){Je.allWallets=n},setIncludeWalletIds(n){Je.includeWalletIds=n},setExcludeWalletIds(n){Je.excludeWalletIds=n},setFeaturedWalletIds(n){Je.featuredWalletIds=n},setTokens(n){Je.tokens=n},setTermsConditionsUrl(n){Je.termsConditionsUrl=n},setPrivacyPolicyUrl(n){Je.privacyPolicyUrl=n},setCustomWallets(n){Je.customWallets=n},setEnableAnalytics(n){Je.enableAnalytics=n},setSdkVersion(n){Je.sdkVersion=n},setMetadata(n){Je.metadata=n},setOnrampEnabled(n){Je.enableOnramp=n}},ri=Ke({themeMode:"dark",themeVariables:{}}),Fe={state:ri,subscribe(n){return Lt(ri,()=>n(ri))},setThemeMode(n){ri.themeMode=n;try{const e=Ee.getEmailConnector();e&&e.provider.syncTheme({themeMode:Fe.getSnapshot().themeMode})}catch{console.info("Unable to sync theme to email connector")}},setThemeVariables(n){ri.themeVariables={...ri.themeVariables,...n};try{const e=Ee.getEmailConnector();e&&e.provider.syncTheme({themeVariables:Fe.getSnapshot().themeVariables})}catch{console.info("Unable to sync theme to email connector")}},getSnapshot(){return H0(ri)}},oi=Ke({connectors:[]}),Ee={state:oi,subscribeKey(n,e){return At(oi,n,e)},setConnectors(n){oi.connectors=n.map(e=>To(e))},addConnector(n){var e,t;if(oi.connectors.push(To(n)),n.id==="w3mEmail"){const i=n,o=H0(ce.state);(t=(e=i==null?void 0:i.provider)==null?void 0:e.syncDappData)==null||t.call(e,{metadata:o.metadata,sdkVersion:o.sdkVersion,projectId:o.projectId}),i.provider.syncTheme({themeMode:Fe.getSnapshot().themeMode,themeVariables:Fe.getSnapshot().themeVariables})}},getEmailConnector(){return oi.connectors.find(n=>n.type==="EMAIL")},getAnnouncedConnectorRdns(){return oi.connectors.filter(n=>n.type==="ANNOUNCED").map(n=>{var e;return(e=n.info)==null?void 0:e.rdns})},getConnectors(){return oi.connectors}},Jr=Ke({open:!1,selectedNetworkId:void 0}),gr={state:Jr,subscribe(n){return Lt(Jr,()=>n(Jr))},set(n){Object.assign(Jr,{...Jr,...n})}},lm=F.getAnalyticsUrl(),um=new Ol({baseUrl:lm}),dm=["MODAL_CREATED"],Xi=Ke({timestamp:Date.now(),data:{type:"track",event:"MODAL_CREATED"}}),Y={state:Xi,subscribe(n){return Lt(Xi,()=>n(Xi))},_getApiHeaders(){const{projectId:n,sdkType:e,sdkVersion:t}=ce.state;return{"x-project-id":n,"x-sdk-type":e,"x-sdk-version":t}},async _sendAnalyticsEvent(n){try{if(dm.includes(n.data.event)||typeof window>"u")return;await um.post({path:"/e",headers:Y._getApiHeaders(),body:{eventId:F.getUUID(),url:window.location.href,domain:window.location.hostname,timestamp:n.timestamp,props:n.data}})}catch{}},sendEvent(n){Xi.timestamp=Date.now(),Xi.data=n,ce.state.enableAnalytics&&Y._sendAnalyticsEvent(Xi)}},ke=Ke({supportsAllNetworks:!0,isDefaultCaipNetwork:!1}),ge={state:ke,subscribeKey(n,e){return At(ke,n,e)},_getClient(){if(!ke._client)throw new Error("NetworkController client not set");return ke._client},setClient(n){ke._client=To(n)},setCaipNetwork(n){ke.caipNetwork=n,gr.set({selectedNetworkId:n==null?void 0:n.id}),this.checkIfSupportedNetwork()},setDefaultCaipNetwork(n){ke.caipNetwork=n,gr.set({selectedNetworkId:n==null?void 0:n.id}),ke.isDefaultCaipNetwork=!0},setRequestedCaipNetworks(n){ke.requestedCaipNetworks=n},getRequestedCaipNetworks(){const{approvedCaipNetworkIds:n,requestedCaipNetworks:e}=ke,t=n,i=e;return F.sortRequestedNetworks(t,i)},async getApprovedCaipNetworksData(){const n=await this._getClient().getApprovedCaipNetworksData();ke.supportsAllNetworks=n.supportsAllNetworks,ke.approvedCaipNetworkIds=n.approvedCaipNetworkIds},async switchActiveNetwork(n){await this._getClient().switchCaipNetwork(n),ke.caipNetwork=n,n&&Y.sendEvent({type:"track",event:"SWITCH_NETWORK",properties:{network:n.id}})},checkIfSupportedNetwork(){var n;ke.isUnsupportedChain=!((n=ke.requestedCaipNetworks)!=null&&n.some(e=>{var t;return e.id===((t=ke.caipNetwork)==null?void 0:t.id)})),ke.isUnsupportedChain&&this.showUnsupportedChainUI()},resetNetwork(){ke.isDefaultCaipNetwork||(ke.caipNetwork=void 0),ke.approvedCaipNetworkIds=void 0,ke.supportsAllNetworks=!0},showUnsupportedChainUI(){setTimeout(()=>{he.open({view:"UnsupportedChain"})},300)}},hm=F.getApiUrl(),Qe=new Ol({baseUrl:hm}),pm="40",ed="4",Xe=Ke({page:1,count:0,featured:[],recommended:[],wallets:[],search:[],isAnalyticsEnabled:!1}),ie={state:Xe,subscribeKey(n,e){return At(Xe,n,e)},_getApiHeaders(){const{projectId:n,sdkType:e,sdkVersion:t}=ce.state;return{"x-project-id":n,"x-sdk-type":e,"x-sdk-version":t}},async _fetchWalletImage(n){const e=`${Qe.baseUrl}/getWalletImage/${n}`,t=await Qe.getBlob({path:e,headers:ie._getApiHeaders()});He.setWalletImage(n,URL.createObjectURL(t))},async _fetchNetworkImage(n){const e=`${Qe.baseUrl}/public/getAssetImage/${n}`,t=await Qe.getBlob({path:e,headers:ie._getApiHeaders()});He.setNetworkImage(n,URL.createObjectURL(t))},async _fetchConnectorImage(n){const e=`${Qe.baseUrl}/public/getAssetImage/${n}`,t=await Qe.getBlob({path:e,headers:ie._getApiHeaders()});He.setConnectorImage(n,URL.createObjectURL(t))},async _fetchCurrencyImage(n){const e=`${Qe.baseUrl}/public/getCurrencyImage/${n}`,t=await Qe.getBlob({path:e,headers:ie._getApiHeaders()});He.setCurrencyImage(n,URL.createObjectURL(t))},async _fetchTokenImage(n){const e=`${Qe.baseUrl}/public/getTokenImage/${n}`,t=await Qe.getBlob({path:e,headers:ie._getApiHeaders()});He.setTokenImage(n,URL.createObjectURL(t))},async fetchNetworkImages(){const{requestedCaipNetworks:n}=ge.state,e=n==null?void 0:n.map(({imageId:t})=>t).filter(Boolean);e&&await Promise.allSettled(e.map(t=>ie._fetchNetworkImage(t)))},async fetchConnectorImages(){const{connectors:n}=Ee.state,e=n.map(({imageId:t})=>t).filter(Boolean);await Promise.allSettled(e.map(t=>ie._fetchConnectorImage(t)))},async fetchCurrencyImages(n=[]){await Promise.allSettled(n.map(e=>ie._fetchCurrencyImage(e)))},async fetchTokenImages(n=[]){await Promise.allSettled(n.map(e=>ie._fetchTokenImage(e)))},async fetchFeaturedWallets(){const{featuredWalletIds:n}=ce.state;if(n!=null&&n.length){const{data:e}=await Qe.get({path:"/getWallets",headers:ie._getApiHeaders(),params:{page:"1",entries:n!=null&&n.length?String(n.length):ed,include:n==null?void 0:n.join(",")}});e.sort((i,o)=>n.indexOf(i.id)-n.indexOf(o.id));const t=e.map(i=>i.image_id).filter(Boolean);await Promise.allSettled(t.map(i=>ie._fetchWalletImage(i))),Xe.featured=e}},async fetchRecommendedWallets(){const{includeWalletIds:n,excludeWalletIds:e,featuredWalletIds:t}=ce.state,i=[...e??[],...t??[]].filter(Boolean),{data:o,count:r}=await Qe.get({path:"/getWallets",headers:ie._getApiHeaders(),params:{page:"1",entries:ed,include:n==null?void 0:n.join(","),exclude:i==null?void 0:i.join(",")}}),s=Ze.getRecentWallets(),a=o.map(u=>u.image_id).filter(Boolean),c=s.map(u=>u.image_id).filter(Boolean);await Promise.allSettled([...a,...c].map(u=>ie._fetchWalletImage(u))),Xe.recommended=o,Xe.count=r??0},async fetchWallets({page:n}){const{includeWalletIds:e,excludeWalletIds:t,featuredWalletIds:i}=ce.state,o=[...Xe.recommended.map(({id:c})=>c),...t??[],...i??[]].filter(Boolean),{data:r,count:s}=await Qe.get({path:"/getWallets",headers:ie._getApiHeaders(),params:{page:String(n),entries:pm,include:e==null?void 0:e.join(","),exclude:o.join(",")}}),a=r.map(c=>c.image_id).filter(Boolean);await Promise.allSettled([...a.map(c=>ie._fetchWalletImage(c)),F.wait(300)]),Xe.wallets=[...Xe.wallets,...r],Xe.count=s>Xe.count?s:Xe.count,Xe.page=n},async searchWallet({search:n}){const{includeWalletIds:e,excludeWalletIds:t}=ce.state;Xe.search=[];const{data:i}=await Qe.get({path:"/getWallets",headers:ie._getApiHeaders(),params:{page:"1",entries:"100",search:n,include:e==null?void 0:e.join(","),exclude:t==null?void 0:t.join(",")}}),o=i.map(r=>r.image_id).filter(Boolean);await Promise.allSettled([...o.map(r=>ie._fetchWalletImage(r)),F.wait(300)]),Xe.search=i},prefetch(){const n=[ie.fetchFeaturedWallets(),ie.fetchRecommendedWallets(),ie.fetchNetworkImages(),ie.fetchConnectorImages()];ce.state.enableAnalytics===void 0&&n.push(ie.fetchAnalyticsConfig()),Xe.prefetchPromise=Promise.race([Promise.allSettled(n),F.wait(3e3)])},async fetchAnalyticsConfig(){const{isAnalyticsEnabled:n}=await Qe.get({path:"/getAnalyticsConfig",headers:ie._getApiHeaders()});ce.setEnableAnalytics(n)}},Ie=Ke({view:"Connect",history:["Connect"]}),j={state:Ie,subscribeKey(n,e){return At(Ie,n,e)},push(n,e){n!==Ie.view&&(Ie.view=n,Ie.history.push(n),Ie.data=e)},reset(n){Ie.view=n,Ie.history=[n]},replace(n,e){Ie.history.length>1&&Ie.history.at(-1)!==n&&(Ie.view=n,Ie.history[Ie.history.length-1]=n,Ie.data=e)},goBack(){if(Ie.history.length>1){Ie.history.pop();const[n]=Ie.history.slice(-1);n&&(Ie.view=n)}},goBackToIndex(n){if(Ie.history.length>1){Ie.history=Ie.history.slice(0,n+1);const[e]=Ie.history.slice(-1);e&&(Ie.view=e)}}},si=Ke({loading:!1,open:!1}),he={state:si,subscribe(n){return Lt(si,()=>n(si))},subscribeKey(n,e){return At(si,n,e)},async open(n){await ie.state.prefetchPromise;const e=ne.state.isConnected;n!=null&&n.view?j.reset(n.view):e?j.reset("Account"):j.reset("Connect"),si.open=!0,gr.set({open:!0}),Y.sendEvent({type:"track",event:"MODAL_OPEN",properties:{connected:e}})},close(){const n=ne.state.isConnected;si.open=!1,gr.set({open:!1}),Y.sendEvent({type:"track",event:"MODAL_CLOSE",properties:{connected:n}})},setLoading(n){si.loading=n}},fm={purchaseCurrencies:[{id:"2b92315d-eab7-5bef-84fa-089a131333f5",name:"USD Coin",symbol:"USDC",networks:[{name:"ethereum-mainnet",display_name:"Ethereum",chain_id:"1",contract_address:"0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48"},{name:"polygon-mainnet",display_name:"Polygon",chain_id:"137",contract_address:"0x2791Bca1f2de4661ED88A30C99A7a9449Aa84174"}]},{id:"2b92315d-eab7-5bef-84fa-089a131333f5",name:"Ether",symbol:"ETH",networks:[{name:"ethereum-mainnet",display_name:"Ethereum",chain_id:"1",contract_address:"0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48"},{name:"polygon-mainnet",display_name:"Polygon",chain_id:"137",contract_address:"0x2791Bca1f2de4661ED88A30C99A7a9449Aa84174"}]}],paymentCurrencies:[{id:"USD",payment_method_limits:[{id:"card",min:"10.00",max:"7500.00"},{id:"ach_bank_account",min:"10.00",max:"25000.00"}]},{id:"EUR",payment_method_limits:[{id:"card",min:"10.00",max:"7500.00"},{id:"ach_bank_account",min:"10.00",max:"25000.00"}]}]},gm=F.getBlockchainApiUrl(),Qr=new Ol({baseUrl:gm}),mr={fetchIdentity({caipChainId:n,address:e}){return Qr.get({path:`/v1/identity/${e}`,params:{chainId:n,projectId:ce.state.projectId}})},fetchTransactions({account:n,projectId:e,cursor:t,onramp:i,signal:o}){const r=t?{cursor:t}:{};return Qr.get({path:`/v1/account/${n}/history?projectId=${e}${i?`&onramp=${i}`:""}`,params:r,signal:o})},async generateOnRampURL({destinationWallets:n,partnerUserId:e,defaultNetwork:t,purchaseAmount:i,paymentAmount:o}){return(await Qr.post({path:`/v1/generators/onrampurl?projectId=${ce.state.projectId}`,body:{destinationWallets:n,defaultNetwork:t,partnerUserId:e,defaultExperience:"buy",presetCryptoAmount:i,presetFiatAmount:o}})).url},async getOnrampOptions(){try{return await Qr.get({path:`/v1/onramp/options?projectId=${ce.state.projectId}`})}catch{return fm}},async getOnrampQuote({purchaseCurrency:n,paymentCurrency:e,amount:t,network:i}){try{return await Qr.post({path:`/v1/onramp/quote?projectId=${ce.state.projectId}`,body:{purchaseCurrency:n,paymentCurrency:e,amount:t,network:i}})}catch{return{coinbaseFee:{amount:t,currency:e.id},networkFee:{amount:t,currency:e.id},paymentSubtotal:{amount:t,currency:e.id},paymentTotal:{amount:t,currency:e.id},purchaseAmount:{amount:t,currency:e.id},quoteId:"mocked-quote-id"}}}},Xc={id:"2b92315d-eab7-5bef-84fa-089a131333f5",name:"USD Coin",symbol:"USDC",networks:[{name:"ethereum-mainnet",display_name:"Ethereum",chain_id:"1",contract_address:"0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48"},{name:"polygon-mainnet",display_name:"Polygon",chain_id:"137",contract_address:"0x2791Bca1f2de4661ED88A30C99A7a9449Aa84174"}]},V0={id:"USD",payment_method_limits:[{id:"card",min:"10.00",max:"7500.00"},{id:"ach_bank_account",min:"10.00",max:"25000.00"}]},We=Ke({providers:cm,selectedProvider:null,error:null,purchaseCurrency:Xc,paymentCurrency:V0,purchaseCurrencies:[Xc],paymentCurrencies:[],quotesLoading:!1}),ve={state:We,subscribe(n){return Lt(We,()=>n(We))},subscribeKey(n,e){return At(We,n,e)},setSelectedProvider(n){We.selectedProvider=n},setPurchaseCurrency(n){We.purchaseCurrency=n},setPaymentCurrency(n){We.paymentCurrency=n},setPurchaseAmount(n){this.state.purchaseAmount=n},setPaymentAmount(n){this.state.paymentAmount=n},async getAvailableCurrencies(){const n=await mr.getOnrampOptions();We.purchaseCurrencies=n.purchaseCurrencies,We.paymentCurrencies=n.paymentCurrencies,We.paymentCurrency=n.paymentCurrencies[0]||V0,We.purchaseCurrency=n.purchaseCurrencies[0]||Xc,await ie.fetchCurrencyImages(n.paymentCurrencies.map(e=>e.id)),await ie.fetchTokenImages(n.purchaseCurrencies.map(e=>e.symbol))},async getQuote(){var e,t;We.quotesLoading=!0;const n=await mr.getOnrampQuote({purchaseCurrency:We.purchaseCurrency,paymentCurrency:We.paymentCurrency,amount:((e=We.paymentAmount)==null?void 0:e.toString())||"0",network:(t=We.purchaseCurrency)==null?void 0:t.name});return We.quotesLoading=!1,We.purchaseAmount=Number(n.purchaseAmount.amount),n}},wn=Ke({message:"",variant:"success",open:!1}),xe={state:wn,subscribeKey(n,e){return At(wn,n,e)},showSuccess(n){wn.message=n,wn.variant="success",wn.open=!0},showError(n){const e=F.parseError(n);wn.message=e,wn.variant="error",wn.open=!0},hide(){wn.open=!1}},Oe=Ke({transactions:[],coinbaseTransactions:{},transactionsByYear:{},loading:!1,empty:!1,next:void 0}),rt={state:Oe,subscribe(n){return Lt(Oe,()=>n(Oe))},async fetchTransactions(n,e){const{projectId:t}=ce.state;if(!t||!n)throw new Error("Transactions can't be fetched without a projectId and an accountAddress");Oe.loading=!0;try{const i=await mr.fetchTransactions({account:n,projectId:t,cursor:Oe.next,onramp:e}),o=this.filterSpamTransactions(i.data),r=[...Oe.transactions,...o];Oe.loading=!1,e==="coinbase"?Oe.coinbaseTransactions=this.groupTransactionsByYearAndMonth(Oe.coinbaseTransactions,i.data):(Oe.transactions=r,Oe.transactionsByYear=this.groupTransactionsByYearAndMonth(Oe.transactionsByYear,o)),Oe.empty=r.length===0,Oe.next=i.next?i.next:void 0}catch{Y.sendEvent({type:"track",event:"ERROR_FETCH_TRANSACTIONS",properties:{address:n,projectId:t,cursor:Oe.next}}),xe.showError("Failed to fetch transactions"),Oe.loading=!1,Oe.empty=!0}},groupTransactionsByYearAndMonth(n={},e=[]){const t=n;return e.forEach(i=>{const o=new Date(i.metadata.minedAt).getFullYear(),r=new Date(i.metadata.minedAt).getMonth(),s=t[o]??{},c=(s[r]??[]).filter(u=>u.id!==i.id);t[o]={...s,[r]:[...c,i].sort((u,h)=>new Date(h.metadata.minedAt).getTime()-new Date(u.metadata.minedAt).getTime())}}),t},filterSpamTransactions(n){return n.filter(e=>!e.transfers.every(i=>{var o;return((o=i.nft_info)==null?void 0:o.flags.is_spam)===!0}))},resetTransactions(){Oe.transactions=[],Oe.transactionsByYear={},Oe.loading=!1,Oe.empty=!1,Oe.next=void 0}},ze=Ke({wcError:!1,buffering:!1}),fe={state:ze,subscribeKey(n,e){return At(ze,n,e)},_getClient(){if(!ze._client)throw new Error("ConnectionController client not set");return ze._client},setClient(n){ze._client=To(n)},connectWalletConnect(){ze.wcPromise=this._getClient().connectWalletConnect(n=>{ze.wcUri=n,ze.wcPairingExpiry=F.getPairingExpiry()}),Ze.setConnectedConnector("WALLET_CONNECT")},async connectExternal(n){var e,t;await((t=(e=this._getClient()).connectExternal)==null?void 0:t.call(e,n)),Ze.setConnectedConnector(n.type)},async signMessage(n){return this._getClient().signMessage(n)},checkInstalled(n){var e,t;return(t=(e=this._getClient()).checkInstalled)==null?void 0:t.call(e,n)},resetWcConnection(){ze.wcUri=void 0,ze.wcPairingExpiry=void 0,ze.wcPromise=void 0,ze.wcLinking=void 0,ze.recentWallet=void 0,rt.resetTransactions(),Ze.deleteWalletConnectDeepLink()},setWcLinking(n){ze.wcLinking=n},setWcError(n){ze.wcError=n,ze.buffering=!1},setRecentWallet(n){ze.recentWallet=n},setBuffering(n){ze.buffering=n},async disconnect(){await this._getClient().disconnect(),this.resetWcConnection()}},ut=Ke({status:"uninitialized",isSiweEnabled:!1}),Me={state:ut,subscribeKey(n,e){return At(ut,n,e)},subscribe(n){return Lt(ut,()=>n(ut))},_getClient(){if(!ut._client)throw new Error("SIWEController client not set");return ut._client},async getNonce(){const e=await this._getClient().getNonce();return this.setNonce(e),e},async getSession(){const e=await this._getClient().getSession();return e&&(this.setSession(e),this.setStatus("success")),e},createMessage(n){const t=this._getClient().createMessage(n);return this.setMessage(t),t},async verifyMessage(n){return await this._getClient().verifyMessage(n)},async signIn(){return await this._getClient().signIn()},async signOut(){var e;const n=this._getClient();await n.signOut(),this.setStatus("ready"),(e=n.onSignOut)==null||e.call(n)},onSignIn(n){var t;const e=this._getClient();(t=e.onSignIn)==null||t.call(e,n)},onSignOut(){var e;const n=this._getClient();(e=n.onSignOut)==null||e.call(n)},setSIWEClient(n){ut._client=To(n),ut.status="ready",ut.isSiweEnabled=n.options.enabled},setNonce(n){ut.nonce=n},setStatus(n){ut.status=n},setMessage(n){ut.message=n},setSession(n){ut.session=n}},Se={getWalletImage(n){if(n!=null&&n.image_url)return n==null?void 0:n.image_url;if(n!=null&&n.image_id)return He.state.walletImages[n.image_id]},getNetworkImage(n){if(n!=null&&n.imageUrl)return n==null?void 0:n.imageUrl;if(n!=null&&n.imageId)return He.state.networkImages[n.imageId]},getConnectorImage(n){if(n!=null&&n.imageUrl)return n.imageUrl;if(n!=null&&n.imageId)return He.state.connectorImages[n.imageId]}},kl={goBackOrCloseModal(){j.state.history.length>1?j.goBack():he.close()},navigateAfterNetworkSwitch(){const{history:n}=j.state,e=n.findIndex(t=>t==="Networks");e>=1?j.goBackToIndex(e-1):he.close()}};/**
 * @license
 * Copyright 2019 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const Ts=globalThis,Nl=Ts.ShadowRoot&&(Ts.ShadyCSS===void 0||Ts.ShadyCSS.nativeShadow)&&"adoptedStyleSheets"in Document.prototype&&"replace"in CSSStyleSheet.prototype,Ml=Symbol(),td=new WeakMap;let Z0=class{constructor(e,t,i){if(this._$cssResult$=!0,i!==Ml)throw Error("CSSResult is not constructable. Use `unsafeCSS` or `css` instead.");this.cssText=e,this.t=t}get styleSheet(){let e=this.o;const t=this.t;if(Nl&&e===void 0){const i=t!==void 0&&t.length===1;i&&(e=td.get(t)),e===void 0&&((this.o=e=new CSSStyleSheet).replaceSync(this.cssText),i&&td.set(t,e))}return e}toString(){return this.cssText}};const qt=n=>new Z0(typeof n=="string"?n:n+"",void 0,Ml),Z=(n,...e)=>{const t=n.length===1?n[0]:e.reduce((i,o,r)=>i+(s=>{if(s._$cssResult$===!0)return s.cssText;if(typeof s=="number")return s;throw Error("Value passed to 'css' function must be a 'css' function result: "+s+". Use 'unsafeCSS' to pass non-literal values, but take care to ensure page security.")})(o)+n[r+1],n[0]);return new Z0(t,n,Ml)},mm=(n,e)=>{if(Nl)n.adoptedStyleSheets=e.map(t=>t instanceof CSSStyleSheet?t:t.styleSheet);else for(const t of e){const i=document.createElement("style"),o=Ts.litNonce;o!==void 0&&i.setAttribute("nonce",o),i.textContent=t.cssText,n.appendChild(i)}},nd=Nl?n=>n:n=>n instanceof CSSStyleSheet?(e=>{let t="";for(const i of e.cssRules)t+=i.cssText;return qt(t)})(n):n;/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const{is:wm,defineProperty:bm,getOwnPropertyDescriptor:vm,getOwnPropertyNames:ym,getOwnPropertySymbols:xm,getPrototypeOf:Cm}=Object,jn=globalThis,id=jn.trustedTypes,_m=id?id.emptyScript:"",dc=jn.reactiveElementPolyfillSupport,io=(n,e)=>n,Ws={toAttribute(n,e){switch(e){case Boolean:n=n?_m:null;break;case Object:case Array:n=n==null?n:JSON.stringify(n)}return n},fromAttribute(n,e){let t=n;switch(e){case Boolean:t=n!==null;break;case Number:t=n===null?null:Number(n);break;case Object:case Array:try{t=JSON.parse(n)}catch{t=null}}return t}},Ll=(n,e)=>!wm(n,e),rd={attribute:!0,type:String,converter:Ws,reflect:!1,hasChanged:Ll};Symbol.metadata??(Symbol.metadata=Symbol("metadata")),jn.litPropertyMetadata??(jn.litPropertyMetadata=new WeakMap);let nr=class extends HTMLElement{static addInitializer(e){this._$Ei(),(this.l??(this.l=[])).push(e)}static get observedAttributes(){return this.finalize(),this._$Eh&&[...this._$Eh.keys()]}static createProperty(e,t=rd){if(t.state&&(t.attribute=!1),this._$Ei(),this.elementProperties.set(e,t),!t.noAccessor){const i=Symbol(),o=this.getPropertyDescriptor(e,i,t);o!==void 0&&bm(this.prototype,e,o)}}static getPropertyDescriptor(e,t,i){const{get:o,set:r}=vm(this.prototype,e)??{get(){return this[t]},set(s){this[t]=s}};return{get(){return o==null?void 0:o.call(this)},set(s){const a=o==null?void 0:o.call(this);r.call(this,s),this.requestUpdate(e,a,i)},configurable:!0,enumerable:!0}}static getPropertyOptions(e){return this.elementProperties.get(e)??rd}static _$Ei(){if(this.hasOwnProperty(io("elementProperties")))return;const e=Cm(this);e.finalize(),e.l!==void 0&&(this.l=[...e.l]),this.elementProperties=new Map(e.elementProperties)}static finalize(){if(this.hasOwnProperty(io("finalized")))return;if(this.finalized=!0,this._$Ei(),this.hasOwnProperty(io("properties"))){const t=this.properties,i=[...ym(t),...xm(t)];for(const o of i)this.createProperty(o,t[o])}const e=this[Symbol.metadata];if(e!==null){const t=litPropertyMetadata.get(e);if(t!==void 0)for(const[i,o]of t)this.elementProperties.set(i,o)}this._$Eh=new Map;for(const[t,i]of this.elementProperties){const o=this._$Eu(t,i);o!==void 0&&this._$Eh.set(o,t)}this.elementStyles=this.finalizeStyles(this.styles)}static finalizeStyles(e){const t=[];if(Array.isArray(e)){const i=new Set(e.flat(1/0).reverse());for(const o of i)t.unshift(nd(o))}else e!==void 0&&t.push(nd(e));return t}static _$Eu(e,t){const i=t.attribute;return i===!1?void 0:typeof i=="string"?i:typeof e=="string"?e.toLowerCase():void 0}constructor(){super(),this._$Ep=void 0,this.isUpdatePending=!1,this.hasUpdated=!1,this._$Em=null,this._$Ev()}_$Ev(){var e;this._$ES=new Promise(t=>this.enableUpdating=t),this._$AL=new Map,this._$E_(),this.requestUpdate(),(e=this.constructor.l)==null||e.forEach(t=>t(this))}addController(e){var t;(this._$EO??(this._$EO=new Set)).add(e),this.renderRoot!==void 0&&this.isConnected&&((t=e.hostConnected)==null||t.call(e))}removeController(e){var t;(t=this._$EO)==null||t.delete(e)}_$E_(){const e=new Map,t=this.constructor.elementProperties;for(const i of t.keys())this.hasOwnProperty(i)&&(e.set(i,this[i]),delete this[i]);e.size>0&&(this._$Ep=e)}createRenderRoot(){const e=this.shadowRoot??this.attachShadow(this.constructor.shadowRootOptions);return mm(e,this.constructor.elementStyles),e}connectedCallback(){var e;this.renderRoot??(this.renderRoot=this.createRenderRoot()),this.enableUpdating(!0),(e=this._$EO)==null||e.forEach(t=>{var i;return(i=t.hostConnected)==null?void 0:i.call(t)})}enableUpdating(e){}disconnectedCallback(){var e;(e=this._$EO)==null||e.forEach(t=>{var i;return(i=t.hostDisconnected)==null?void 0:i.call(t)})}attributeChangedCallback(e,t,i){this._$AK(e,i)}_$EC(e,t){var r;const i=this.constructor.elementProperties.get(e),o=this.constructor._$Eu(e,i);if(o!==void 0&&i.reflect===!0){const s=(((r=i.converter)==null?void 0:r.toAttribute)!==void 0?i.converter:Ws).toAttribute(t,i.type);this._$Em=e,s==null?this.removeAttribute(o):this.setAttribute(o,s),this._$Em=null}}_$AK(e,t){var r;const i=this.constructor,o=i._$Eh.get(e);if(o!==void 0&&this._$Em!==o){const s=i.getPropertyOptions(o),a=typeof s.converter=="function"?{fromAttribute:s.converter}:((r=s.converter)==null?void 0:r.fromAttribute)!==void 0?s.converter:Ws;this._$Em=o,this[o]=a.fromAttribute(t,s.type),this._$Em=null}}requestUpdate(e,t,i){if(e!==void 0){if(i??(i=this.constructor.getPropertyOptions(e)),!(i.hasChanged??Ll)(this[e],t))return;this.P(e,t,i)}this.isUpdatePending===!1&&(this._$ES=this._$ET())}P(e,t,i){this._$AL.has(e)||this._$AL.set(e,t),i.reflect===!0&&this._$Em!==e&&(this._$Ej??(this._$Ej=new Set)).add(e)}async _$ET(){this.isUpdatePending=!0;try{await this._$ES}catch(t){Promise.reject(t)}const e=this.scheduleUpdate();return e!=null&&await e,!this.isUpdatePending}scheduleUpdate(){return this.performUpdate()}performUpdate(){var i;if(!this.isUpdatePending)return;if(!this.hasUpdated){if(this.renderRoot??(this.renderRoot=this.createRenderRoot()),this._$Ep){for(const[r,s]of this._$Ep)this[r]=s;this._$Ep=void 0}const o=this.constructor.elementProperties;if(o.size>0)for(const[r,s]of o)s.wrapped!==!0||this._$AL.has(r)||this[r]===void 0||this.P(r,this[r],s)}let e=!1;const t=this._$AL;try{e=this.shouldUpdate(t),e?(this.willUpdate(t),(i=this._$EO)==null||i.forEach(o=>{var r;return(r=o.hostUpdate)==null?void 0:r.call(o)}),this.update(t)):this._$EU()}catch(o){throw e=!1,this._$EU(),o}e&&this._$AE(t)}willUpdate(e){}_$AE(e){var t;(t=this._$EO)==null||t.forEach(i=>{var o;return(o=i.hostUpdated)==null?void 0:o.call(i)}),this.hasUpdated||(this.hasUpdated=!0,this.firstUpdated(e)),this.updated(e)}_$EU(){this._$AL=new Map,this.isUpdatePending=!1}get updateComplete(){return this.getUpdateComplete()}getUpdateComplete(){return this._$ES}shouldUpdate(e){return!0}update(e){this._$Ej&&(this._$Ej=this._$Ej.forEach(t=>this._$EC(t,this[t]))),this._$EU()}updated(e){}firstUpdated(e){}};nr.elementStyles=[],nr.shadowRootOptions={mode:"open"},nr[io("elementProperties")]=new Map,nr[io("finalized")]=new Map,dc==null||dc({ReactiveElement:nr}),(jn.reactiveElementVersions??(jn.reactiveElementVersions=[])).push("2.0.4");/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const ro=globalThis,zs=ro.trustedTypes,od=zs?zs.createPolicy("lit-html",{createHTML:n=>n}):void 0,q0="$lit$",On=`lit$${(Math.random()+"").slice(9)}$`,G0="?"+On,Em=`<${G0}>`,yi=document,Po=()=>yi.createComment(""),Oo=n=>n===null||typeof n!="object"&&typeof n!="function",Y0=Array.isArray,$m=n=>Y0(n)||typeof(n==null?void 0:n[Symbol.iterator])=="function",hc=`[ 	
\f\r]`,Xr=/<(?:(!--|\/[^a-zA-Z])|(\/?[a-zA-Z][^>\s]*)|(\/?$))/g,sd=/-->/g,ad=/>/g,ai=RegExp(`>|${hc}(?:([^\\s"'>=/]+)(${hc}*=${hc}*(?:[^ 	
\f\r"'\`<>=]|("|')|))|$)`,"g"),cd=/'/g,ld=/"/g,K0=/^(?:script|style|textarea|title)$/i,J0=n=>(e,...t)=>({_$litType$:n,strings:e,values:t}),P=J0(1),B=J0(2),xi=Symbol.for("lit-noChange"),Le=Symbol.for("lit-nothing"),ud=new WeakMap,di=yi.createTreeWalker(yi,129);function Q0(n,e){if(!Array.isArray(n)||!n.hasOwnProperty("raw"))throw Error("invalid template strings array");return od!==void 0?od.createHTML(e):e}const Am=(n,e)=>{const t=n.length-1,i=[];let o,r=e===2?"<svg>":"",s=Xr;for(let a=0;a<t;a++){const c=n[a];let u,h,p=-1,g=0;for(;g<c.length&&(s.lastIndex=g,h=s.exec(c),h!==null);)g=s.lastIndex,s===Xr?h[1]==="!--"?s=sd:h[1]!==void 0?s=ad:h[2]!==void 0?(K0.test(h[2])&&(o=RegExp("</"+h[2],"g")),s=ai):h[3]!==void 0&&(s=ai):s===ai?h[0]===">"?(s=o??Xr,p=-1):h[1]===void 0?p=-2:(p=s.lastIndex-h[2].length,u=h[1],s=h[3]===void 0?ai:h[3]==='"'?ld:cd):s===ld||s===cd?s=ai:s===sd||s===ad?s=Xr:(s=ai,o=void 0);const b=s===ai&&n[a+1].startsWith("/>")?" ":"";r+=s===Xr?c+Em:p>=0?(i.push(u),c.slice(0,p)+q0+c.slice(p)+On+b):c+On+(p===-2?a:b)}return[Q0(n,r+(n[t]||"<?>")+(e===2?"</svg>":"")),i]};let el=class X0{constructor({strings:e,_$litType$:t},i){let o;this.parts=[];let r=0,s=0;const a=e.length-1,c=this.parts,[u,h]=Am(e,t);if(this.el=X0.createElement(u,i),di.currentNode=this.el.content,t===2){const p=this.el.content.firstChild;p.replaceWith(...p.childNodes)}for(;(o=di.nextNode())!==null&&c.length<a;){if(o.nodeType===1){if(o.hasAttributes())for(const p of o.getAttributeNames())if(p.endsWith(q0)){const g=h[s++],b=o.getAttribute(p).split(On),_=/([.?@])?(.*)/.exec(g);c.push({type:1,index:r,name:_[2],strings:b,ctor:_[1]==="."?Im:_[1]==="?"?Rm:_[1]==="@"?Tm:Aa}),o.removeAttribute(p)}else p.startsWith(On)&&(c.push({type:6,index:r}),o.removeAttribute(p));if(K0.test(o.tagName)){const p=o.textContent.split(On),g=p.length-1;if(g>0){o.textContent=zs?zs.emptyScript:"";for(let b=0;b<g;b++)o.append(p[b],Po()),di.nextNode(),c.push({type:2,index:++r});o.append(p[g],Po())}}}else if(o.nodeType===8)if(o.data===G0)c.push({type:2,index:r});else{let p=-1;for(;(p=o.data.indexOf(On,p+1))!==-1;)c.push({type:7,index:r}),p+=On.length-1}r++}}static createElement(e,t){const i=yi.createElement("template");return i.innerHTML=e,i}};function wr(n,e,t=n,i){var s,a;if(e===xi)return e;let o=i!==void 0?(s=t._$Co)==null?void 0:s[i]:t._$Cl;const r=Oo(e)?void 0:e._$litDirective$;return(o==null?void 0:o.constructor)!==r&&((a=o==null?void 0:o._$AO)==null||a.call(o,!1),r===void 0?o=void 0:(o=new r(n),o._$AT(n,t,i)),i!==void 0?(t._$Co??(t._$Co=[]))[i]=o:t._$Cl=o),o!==void 0&&(e=wr(n,o._$AS(n,e.values),o,i)),e}let Sm=class{constructor(e,t){this._$AV=[],this._$AN=void 0,this._$AD=e,this._$AM=t}get parentNode(){return this._$AM.parentNode}get _$AU(){return this._$AM._$AU}u(e){const{el:{content:t},parts:i}=this._$AD,o=((e==null?void 0:e.creationScope)??yi).importNode(t,!0);di.currentNode=o;let r=di.nextNode(),s=0,a=0,c=i[0];for(;c!==void 0;){if(s===c.index){let u;c.type===2?u=new Bl(r,r.nextSibling,this,e):c.type===1?u=new c.ctor(r,c.name,c.strings,this,e):c.type===6&&(u=new Pm(r,this,e)),this._$AV.push(u),c=i[++a]}s!==(c==null?void 0:c.index)&&(r=di.nextNode(),s++)}return di.currentNode=yi,o}p(e){let t=0;for(const i of this._$AV)i!==void 0&&(i.strings!==void 0?(i._$AI(e,i,t),t+=i.strings.length-2):i._$AI(e[t])),t++}},Bl=class eh{get _$AU(){var e;return((e=this._$AM)==null?void 0:e._$AU)??this._$Cv}constructor(e,t,i,o){this.type=2,this._$AH=Le,this._$AN=void 0,this._$AA=e,this._$AB=t,this._$AM=i,this.options=o,this._$Cv=(o==null?void 0:o.isConnected)??!0}get parentNode(){let e=this._$AA.parentNode;const t=this._$AM;return t!==void 0&&(e==null?void 0:e.nodeType)===11&&(e=t.parentNode),e}get startNode(){return this._$AA}get endNode(){return this._$AB}_$AI(e,t=this){e=wr(this,e,t),Oo(e)?e===Le||e==null||e===""?(this._$AH!==Le&&this._$AR(),this._$AH=Le):e!==this._$AH&&e!==xi&&this._(e):e._$litType$!==void 0?this.$(e):e.nodeType!==void 0?this.T(e):$m(e)?this.k(e):this._(e)}S(e){return this._$AA.parentNode.insertBefore(e,this._$AB)}T(e){this._$AH!==e&&(this._$AR(),this._$AH=this.S(e))}_(e){this._$AH!==Le&&Oo(this._$AH)?this._$AA.nextSibling.data=e:this.T(yi.createTextNode(e)),this._$AH=e}$(e){var r;const{values:t,_$litType$:i}=e,o=typeof i=="number"?this._$AC(e):(i.el===void 0&&(i.el=el.createElement(Q0(i.h,i.h[0]),this.options)),i);if(((r=this._$AH)==null?void 0:r._$AD)===o)this._$AH.p(t);else{const s=new Sm(o,this),a=s.u(this.options);s.p(t),this.T(a),this._$AH=s}}_$AC(e){let t=ud.get(e.strings);return t===void 0&&ud.set(e.strings,t=new el(e)),t}k(e){Y0(this._$AH)||(this._$AH=[],this._$AR());const t=this._$AH;let i,o=0;for(const r of e)o===t.length?t.push(i=new eh(this.S(Po()),this.S(Po()),this,this.options)):i=t[o],i._$AI(r),o++;o<t.length&&(this._$AR(i&&i._$AB.nextSibling,o),t.length=o)}_$AR(e=this._$AA.nextSibling,t){var i;for((i=this._$AP)==null?void 0:i.call(this,!1,!0,t);e&&e!==this._$AB;){const o=e.nextSibling;e.remove(),e=o}}setConnected(e){var t;this._$AM===void 0&&(this._$Cv=e,(t=this._$AP)==null||t.call(this,e))}},Aa=class{get tagName(){return this.element.tagName}get _$AU(){return this._$AM._$AU}constructor(e,t,i,o,r){this.type=1,this._$AH=Le,this._$AN=void 0,this.element=e,this.name=t,this._$AM=o,this.options=r,i.length>2||i[0]!==""||i[1]!==""?(this._$AH=Array(i.length-1).fill(new String),this.strings=i):this._$AH=Le}_$AI(e,t=this,i,o){const r=this.strings;let s=!1;if(r===void 0)e=wr(this,e,t,0),s=!Oo(e)||e!==this._$AH&&e!==xi,s&&(this._$AH=e);else{const a=e;let c,u;for(e=r[0],c=0;c<r.length-1;c++)u=wr(this,a[i+c],t,c),u===xi&&(u=this._$AH[c]),s||(s=!Oo(u)||u!==this._$AH[c]),u===Le?e=Le:e!==Le&&(e+=(u??"")+r[c+1]),this._$AH[c]=u}s&&!o&&this.j(e)}j(e){e===Le?this.element.removeAttribute(this.name):this.element.setAttribute(this.name,e??"")}},Im=class extends Aa{constructor(){super(...arguments),this.type=3}j(e){this.element[this.name]=e===Le?void 0:e}},Rm=class extends Aa{constructor(){super(...arguments),this.type=4}j(e){this.element.toggleAttribute(this.name,!!e&&e!==Le)}},Tm=class extends Aa{constructor(e,t,i,o,r){super(e,t,i,o,r),this.type=5}_$AI(e,t=this){if((e=wr(this,e,t,0)??Le)===xi)return;const i=this._$AH,o=e===Le&&i!==Le||e.capture!==i.capture||e.once!==i.once||e.passive!==i.passive,r=e!==Le&&(i===Le||o);o&&this.element.removeEventListener(this.name,this,i),r&&this.element.addEventListener(this.name,this,e),this._$AH=e}handleEvent(e){var t;typeof this._$AH=="function"?this._$AH.call(((t=this.options)==null?void 0:t.host)??this.element,e):this._$AH.handleEvent(e)}},Pm=class{constructor(e,t,i){this.element=e,this.type=6,this._$AN=void 0,this._$AM=t,this.options=i}get _$AU(){return this._$AM._$AU}_$AI(e){wr(this,e)}};const pc=ro.litHtmlPolyfillSupport;pc==null||pc(el,Bl),(ro.litHtmlVersions??(ro.litHtmlVersions=[])).push("3.1.2");const Om=(n,e,t)=>{const i=(t==null?void 0:t.renderBefore)??e;let o=i._$litPart$;if(o===void 0){const r=(t==null?void 0:t.renderBefore)??null;i._$litPart$=o=new Bl(e.insertBefore(Po(),r),r,void 0,t??{})}return o._$AI(n),o};/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */let q=class extends nr{constructor(){super(...arguments),this.renderOptions={host:this},this._$Do=void 0}createRenderRoot(){var t;const e=super.createRenderRoot();return(t=this.renderOptions).renderBefore??(t.renderBefore=e.firstChild),e}update(e){const t=this.render();this.hasUpdated||(this.renderOptions.isConnected=this.isConnected),super.update(e),this._$Do=Om(t,this.renderRoot,this.renderOptions)}connectedCallback(){var e;super.connectedCallback(),(e=this._$Do)==null||e.setConnected(!0)}disconnectedCallback(){var e;super.disconnectedCallback(),(e=this._$Do)==null||e.setConnected(!1)}render(){return xi}};var Yd;q._$litElement$=!0,q.finalized=!0,(Yd=globalThis.litElementHydrateSupport)==null||Yd.call(globalThis,{LitElement:q});const fc=globalThis.litElementPolyfillSupport;fc==null||fc({LitElement:q});(globalThis.litElementVersions??(globalThis.litElementVersions=[])).push("4.0.4");let oo,Dn,Un;function th(n,e){oo=document.createElement("style"),Dn=document.createElement("style"),Un=document.createElement("style"),oo.textContent=lr(n).core.cssText,Dn.textContent=lr(n).dark.cssText,Un.textContent=lr(n).light.cssText,document.head.appendChild(oo),document.head.appendChild(Dn),document.head.appendChild(Un),jl(e)}function jl(n){Dn&&Un&&(n==="light"?(Dn.removeAttribute("media"),Un.media="enabled"):(Un.removeAttribute("media"),Dn.media="enabled"))}function nh(n){oo&&Dn&&Un&&(oo.textContent=lr(n).core.cssText,Dn.textContent=lr(n).dark.cssText,Un.textContent=lr(n).light.cssText)}function lr(n){return{core:Z`
      @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');
      :root {
        --w3m-color-mix-strength: ${qt(n!=null&&n["--w3m-color-mix-strength"]?`${n["--w3m-color-mix-strength"]}%`:"0%")};
        --w3m-font-family: ${qt((n==null?void 0:n["--w3m-font-family"])||"Inter, Segoe UI, Roboto, Oxygen, Ubuntu, Cantarell, Fira Sans, Droid Sans, Helvetica Neue, sans-serif;")};
        --w3m-font-size-master: ${qt((n==null?void 0:n["--w3m-font-size-master"])||"10px")};
        --w3m-border-radius-master: ${qt((n==null?void 0:n["--w3m-border-radius-master"])||"4px")};
        --w3m-z-index: ${qt((n==null?void 0:n["--w3m-z-index"])||100)};

        --wui-font-family: var(--w3m-font-family);

        --wui-font-size-micro: var(--w3m-font-size-master);
        --wui-font-size-tiny: calc(var(--w3m-font-size-master) * 1.2);
        --wui-font-size-small: calc(var(--w3m-font-size-master) * 1.4);
        --wui-font-size-paragraph: calc(var(--w3m-font-size-master) * 1.6);
        --wui-font-size-large: calc(var(--w3m-font-size-master) * 2);
        --wui-font-size-medium-title: calc(var(--w3m-font-size-master) * 2.4);
        --wui-font-size-2xl: calc(var(--w3m-font-size-master) * 4);

        --wui-border-radius-5xs: var(--w3m-border-radius-master);
        --wui-border-radius-4xs: calc(var(--w3m-border-radius-master) * 1.5);
        --wui-border-radius-3xs: calc(var(--w3m-border-radius-master) * 2);
        --wui-border-radius-xxs: calc(var(--w3m-border-radius-master) * 3);
        --wui-border-radius-xs: calc(var(--w3m-border-radius-master) * 4);
        --wui-border-radius-s: calc(var(--w3m-border-radius-master) * 5);
        --wui-border-radius-m: calc(var(--w3m-border-radius-master) * 7);
        --wui-border-radius-l: calc(var(--w3m-border-radius-master) * 9);
        --wui-border-radius-3xl: calc(var(--w3m-border-radius-master) * 20);

        --wui-font-weight-light: 400;
        --wui-font-weight-regular: 500;
        --wui-font-weight-medium: 600;
        --wui-font-weight-bold: 700;

        --wui-letter-spacing-2xl: -1.6px;
        --wui-letter-spacing-medium-title: -0.96px;
        --wui-letter-spacing-large: -0.8px;
        --wui-letter-spacing-paragraph: -0.64px;
        --wui-letter-spacing-small: -0.56px;
        --wui-letter-spacing-tiny: -0.48px;
        --wui-letter-spacing-micro: -0.2px;

        --wui-spacing-0: 0px;
        --wui-spacing-4xs: 2px;
        --wui-spacing-3xs: 4px;
        --wui-spacing-xxs: 6px;
        --wui-spacing-2xs: 7px;
        --wui-spacing-xs: 8px;
        --wui-spacing-1xs: 10px;
        --wui-spacing-s: 12px;
        --wui-spacing-m: 14px;
        --wui-spacing-l: 16px;
        --wui-spacing-2l: 18px;
        --wui-spacing-xl: 20px;
        --wui-spacing-xxl: 24px;
        --wui-spacing-2xl: 32px;
        --wui-spacing-3xl: 40px;
        --wui-spacing-4xl: 90px;

        --wui-icon-box-size-xxs: 14px;
        --wui-icon-box-size-xs: 20px;
        --wui-icon-box-size-sm: 24px;
        --wui-icon-box-size-md: 32px;
        --wui-icon-box-size-lg: 40px;
        --wui-icon-box-size-xl: 64px;

        --wui-icon-size-inherit: inherit;
        --wui-icon-size-xxs: 10px;
        --wui-icon-size-xs: 12px;
        --wui-icon-size-sm: 14px;
        --wui-icon-size-md: 16px;
        --wui-icon-size-mdl: 18px;
        --wui-icon-size-lg: 20px;
        --wui-icon-size-xl: 24px;

        --wui-wallet-image-size-inherit: inherit;
        --wui-wallet-image-size-sm: 40px;
        --wui-wallet-image-size-md: 56px;
        --wui-wallet-image-size-lg: 80px;

        --wui-visual-size-size-inherit: inherit;
        --wui-visual-size-sm: 40px;
        --wui-visual-size-md: 55px;
        --wui-visual-size-lg: 80px;

        --wui-box-size-md: 100px;
        --wui-box-size-lg: 120px;

        --wui-ease-out-power-2: cubic-bezier(0, 0, 0.22, 1);
        --wui-ease-out-power-1: cubic-bezier(0, 0, 0.55, 1);

        --wui-ease-in-power-3: cubic-bezier(0.66, 0, 1, 1);
        --wui-ease-in-power-2: cubic-bezier(0.45, 0, 1, 1);
        --wui-ease-in-power-1: cubic-bezier(0.3, 0, 1, 1);

        --wui-ease-inout-power-1: cubic-bezier(0.45, 0, 0.55, 1);

        --wui-duration-lg: 200ms;
        --wui-duration-md: 125ms;
        --wui-duration-sm: 75ms;

        --wui-path-network-sm: path(
          'M15.4 2.1a5.21 5.21 0 0 1 5.2 0l11.61 6.7a5.21 5.21 0 0 1 2.61 4.52v13.4c0 1.87-1 3.59-2.6 4.52l-11.61 6.7c-1.62.93-3.6.93-5.22 0l-11.6-6.7a5.21 5.21 0 0 1-2.61-4.51v-13.4c0-1.87 1-3.6 2.6-4.52L15.4 2.1Z'
        );

        --wui-path-network-md: path(
          'M43.4605 10.7248L28.0485 1.61089C25.5438 0.129705 22.4562 0.129705 19.9515 1.61088L4.53951 10.7248C2.03626 12.2051 0.5 14.9365 0.5 17.886V36.1139C0.5 39.0635 2.03626 41.7949 4.53951 43.2752L19.9515 52.3891C22.4562 53.8703 25.5438 53.8703 28.0485 52.3891L43.4605 43.2752C45.9637 41.7949 47.5 39.0635 47.5 36.114V17.8861C47.5 14.9365 45.9637 12.2051 43.4605 10.7248Z'
        );

        --wui-path-network-lg: path(
          'M78.3244 18.926L50.1808 2.45078C45.7376 -0.150261 40.2624 -0.150262 35.8192 2.45078L7.6756 18.926C3.23322 21.5266 0.5 26.3301 0.5 31.5248V64.4752C0.5 69.6699 3.23322 74.4734 7.6756 77.074L35.8192 93.5492C40.2624 96.1503 45.7376 96.1503 50.1808 93.5492L78.3244 77.074C82.7668 74.4734 85.5 69.6699 85.5 64.4752V31.5248C85.5 26.3301 82.7668 21.5266 78.3244 18.926Z'
        );

        --wui-width-network-sm: 36px;
        --wui-width-network-md: 48px;
        --wui-width-network-lg: 86px;

        --wui-height-network-sm: 40px;
        --wui-height-network-md: 54px;
        --wui-height-network-lg: 96px;

        --wui-icon-size-network-sm: 16px;
        --wui-icon-size-network-md: 24px;
        --wui-icon-size-network-lg: 42px;

        --wui-color-inherit: inherit;

        --wui-color-inverse-100: #fff;
        --wui-color-inverse-000: #000;

        --wui-cover: rgba(20, 20, 20, 0.8);

        --wui-color-modal-bg: var(--wui-color-modal-bg-base);

        --wui-color-blue-100: var(--wui-color-blue-base-100);

        --wui-color-accent-100: var(--wui-color-accent-base-100);
        --wui-color-accent-090: var(--wui-color-accent-base-090);
        --wui-color-accent-080: var(--wui-color-accent-base-080);

        --wui-accent-glass-090: var(--wui-accent-glass-base-090);
        --wui-accent-glass-080: var(--wui-accent-glass-base-080);
        --wui-accent-glass-020: var(--wui-accent-glass-base-020);
        --wui-accent-glass-015: var(--wui-accent-glass-base-015);
        --wui-accent-glass-010: var(--wui-accent-glass-base-010);
        --wui-accent-glass-005: var(--wui-accent-glass-base-005);
        --wui-accent-glass-002: var(--wui-accent-glass-base-002);

        --wui-color-fg-100: var(--wui-color-fg-base-100);
        --wui-color-fg-125: var(--wui-color-fg-base-125);
        --wui-color-fg-150: var(--wui-color-fg-base-150);
        --wui-color-fg-175: var(--wui-color-fg-base-175);
        --wui-color-fg-200: var(--wui-color-fg-base-200);
        --wui-color-fg-225: var(--wui-color-fg-base-225);
        --wui-color-fg-250: var(--wui-color-fg-base-250);
        --wui-color-fg-275: var(--wui-color-fg-base-275);
        --wui-color-fg-300: var(--wui-color-fg-base-300);

        --wui-color-bg-100: var(--wui-color-bg-base-100);
        --wui-color-bg-125: var(--wui-color-bg-base-125);
        --wui-color-bg-150: var(--wui-color-bg-base-150);
        --wui-color-bg-175: var(--wui-color-bg-base-175);
        --wui-color-bg-200: var(--wui-color-bg-base-200);
        --wui-color-bg-225: var(--wui-color-bg-base-225);
        --wui-color-bg-250: var(--wui-color-bg-base-250);
        --wui-color-bg-275: var(--wui-color-bg-base-275);
        --wui-color-bg-300: var(--wui-color-bg-base-300);

        --wui-color-success-100: var(--wui-color-success-base-100);
        --wui-color-error-100: var(--wui-color-error-base-100);

        --wui-icon-box-bg-error-100: var(--wui-icon-box-bg-error-base-100);
        --wui-icon-box-bg-blue-100: var(--wui-icon-box-bg-blue-base-100);
        --wui-icon-box-bg-success-100: var(--wui-icon-box-bg-success-base-100);
        --wui-icon-box-bg-inverse-100: var(--wui-icon-box-bg-inverse-base-100);

        --wui-all-wallets-bg-100: var(--wui-all-wallets-bg-base-100);

        --wui-avatar-border: var(--wui-avatar-border-base);

        --wui-thumbnail-border: var(--wui-thumbnail-border-base);

        --wui-box-shadow-blue: rgba(71, 161, 255, 0.16);
      }

      @supports (background: color-mix(in srgb, white 50%, black)) {
        :root {
          --wui-color-modal-bg: color-mix(
            in srgb,
            var(--w3m-color-mix) var(--w3m-color-mix-strength),
            var(--wui-color-modal-bg-base)
          );

          --wui-box-shadow-blue: color-mix(in srgb, var(--wui-color-accent-100) 16%, transparent);

          --wui-color-accent-090: color-mix(
            in srgb,
            var(--wui-color-accent-base-100) 90%,
            var(--w3m-default)
          );
          --wui-color-accent-080: color-mix(
            in srgb,
            var(--wui-color-accent-base-100) 80%,
            var(--w3m-default)
          );

          --wui-color-accent-090: color-mix(
            in srgb,
            var(--wui-color-accent-base-100) 90%,
            transparent
          );
          --wui-color-accent-080: color-mix(
            in srgb,
            var(--wui-color-accent-base-100) 80%,
            transparent
          );

          --wui-accent-glass-090: color-mix(
            in srgb,
            var(--wui-color-accent-base-100) 90%,
            transparent
          );
          --wui-accent-glass-080: color-mix(
            in srgb,
            var(--wui-color-accent-base-100) 80%,
            transparent
          );
          --wui-accent-glass-020: color-mix(
            in srgb,
            var(--wui-color-accent-base-100) 20%,
            transparent
          );
          --wui-accent-glass-015: color-mix(
            in srgb,
            var(--wui-color-accent-base-100) 15%,
            transparent
          );
          --wui-accent-glass-010: color-mix(
            in srgb,
            var(--wui-color-accent-base-100) 10%,
            transparent
          );
          --wui-accent-glass-005: color-mix(
            in srgb,
            var(--wui-color-accent-base-100) 5%,
            transparent
          );
          --wui-color-accent-002: color-mix(
            in srgb,
            var(--wui-color-accent-base-100) 2%,
            transparent
          );

          --wui-color-fg-100: color-mix(
            in srgb,
            var(--w3m-color-mix) var(--w3m-color-mix-strength),
            var(--wui-color-fg-base-100)
          );
          --wui-color-fg-125: color-mix(
            in srgb,
            var(--w3m-color-mix) var(--w3m-color-mix-strength),
            var(--wui-color-fg-base-125)
          );
          --wui-color-fg-150: color-mix(
            in srgb,
            var(--w3m-color-mix) var(--w3m-color-mix-strength),
            var(--wui-color-fg-base-150)
          );
          --wui-color-fg-175: color-mix(
            in srgb,
            var(--w3m-color-mix) var(--w3m-color-mix-strength),
            var(--wui-color-fg-base-175)
          );
          --wui-color-fg-200: color-mix(
            in srgb,
            var(--w3m-color-mix) var(--w3m-color-mix-strength),
            var(--wui-color-fg-base-200)
          );
          --wui-color-fg-225: color-mix(
            in srgb,
            var(--w3m-color-mix) var(--w3m-color-mix-strength),
            var(--wui-color-fg-base-225)
          );
          --wui-color-fg-250: color-mix(
            in srgb,
            var(--w3m-color-mix) var(--w3m-color-mix-strength),
            var(--wui-color-fg-base-250)
          );
          --wui-color-fg-275: color-mix(
            in srgb,
            var(--w3m-color-mix) var(--w3m-color-mix-strength),
            var(--wui-color-fg-base-275)
          );
          --wui-color-fg-300: color-mix(
            in srgb,
            var(--w3m-color-mix) var(--w3m-color-mix-strength),
            var(--wui-color-fg-base-300)
          );

          --wui-color-bg-100: color-mix(
            in srgb,
            var(--w3m-color-mix) var(--w3m-color-mix-strength),
            var(--wui-color-bg-base-100)
          );
          --wui-color-bg-125: color-mix(
            in srgb,
            var(--w3m-color-mix) var(--w3m-color-mix-strength),
            var(--wui-color-bg-base-125)
          );
          --wui-color-bg-150: color-mix(
            in srgb,
            var(--w3m-color-mix) var(--w3m-color-mix-strength),
            var(--wui-color-bg-base-150)
          );
          --wui-color-bg-175: color-mix(
            in srgb,
            var(--w3m-color-mix) var(--w3m-color-mix-strength),
            var(--wui-color-bg-base-175)
          );
          --wui-color-bg-200: color-mix(
            in srgb,
            var(--w3m-color-mix) var(--w3m-color-mix-strength),
            var(--wui-color-bg-base-200)
          );
          --wui-color-bg-225: color-mix(
            in srgb,
            var(--w3m-color-mix) var(--w3m-color-mix-strength),
            var(--wui-color-bg-base-225)
          );
          --wui-color-bg-250: color-mix(
            in srgb,
            var(--w3m-color-mix) var(--w3m-color-mix-strength),
            var(--wui-color-bg-base-250)
          );
          --wui-color-bg-275: color-mix(
            in srgb,
            var(--w3m-color-mix) var(--w3m-color-mix-strength),
            var(--wui-color-bg-base-275)
          );
          --wui-color-bg-300: color-mix(
            in srgb,
            var(--w3m-color-mix) var(--w3m-color-mix-strength),
            var(--wui-color-bg-base-300)
          );

          --wui-color-success-100: color-mix(
            in srgb,
            var(--w3m-color-mix) var(--w3m-color-mix-strength),
            var(--wui-color-success-base-100)
          );
          --wui-color-error-100: color-mix(
            in srgb,
            var(--w3m-color-mix) var(--w3m-color-mix-strength),
            var(--wui-color-error-base-100)
          );

          --wui-icon-box-bg-error-100: color-mix(
            in srgb,
            var(--w3m-color-mix) var(--w3m-color-mix-strength),
            var(--wui-icon-box-bg-error-base-100)
          );
          --wui-icon-box-bg-accent-100: color-mix(
            in srgb,
            var(--w3m-color-mix) var(--w3m-color-mix-strength),
            var(--wui-icon-box-bg-blue-base-100)
          );
          --wui-icon-box-bg-success-100: color-mix(
            in srgb,
            var(--w3m-color-mix) var(--w3m-color-mix-strength),
            var(--wui-icon-box-bg-success-base-100)
          );
          --wui-icon-box-bg-inverse-100: color-mix(
            in srgb,
            var(--w3m-color-mix) var(--w3m-color-mix-strength),
            var(--wui-icon-box-bg-inverse-base-100)
          );

          --wui-all-wallets-bg-100: color-mix(
            in srgb,
            var(--w3m-color-mix) var(--w3m-color-mix-strength),
            var(--wui-all-wallets-bg-base-100)
          );

          --wui-avatar-border: color-mix(
            in srgb,
            var(--w3m-color-mix) var(--w3m-color-mix-strength),
            var(--wui-avatar-border-base)
          );

          --wui-thumbnail-border: color-mix(
            in srgb,
            var(--w3m-color-mix) var(--w3m-color-mix-strength),
            var(--wui-thumbnail-border-base)
          );
        }
      }
    `,light:Z`
      :root {
        --w3m-color-mix: ${qt((n==null?void 0:n["--w3m-color-mix"])||"#fff")};
        --w3m-accent: ${qt((n==null?void 0:n["--w3m-accent"])||"#47a1ff")};
        --w3m-default: #fff;

        --wui-color-modal-bg-base: #191a1a;

        --wui-color-blue-base-100: #47a1ff;

        --wui-color-accent-base-100: var(--w3m-accent);
        --wui-color-accent-base-090: #59aaff;
        --wui-color-accent-base-080: #6cb4ff;

        --wui-accent-glass-base-090: rgba(71, 161, 255, 0.9);
        --wui-accent-glass-base-080: rgba(71, 161, 255, 0.8);
        --wui-accent-glass-base-020: rgba(71, 161, 255, 0.2);
        --wui-accent-glass-base-015: rgba(71, 161, 255, 0.15);
        --wui-accent-glass-base-010: rgba(71, 161, 255, 0.1);
        --wui-accent-glass-base-005: rgba(71, 161, 255, 0.05);
        --wui-accent-glass-base-002: rgba(71, 161, 255, 0.02);

        --wui-color-fg-base-100: #e4e7e7;
        --wui-color-fg-base-125: #d0d5d5;
        --wui-color-fg-base-150: #a8b1b1;
        --wui-color-fg-base-175: #a8b0b0;
        --wui-color-fg-base-200: #949e9e;
        --wui-color-fg-base-225: #868f8f;
        --wui-color-fg-base-250: #788080;
        --wui-color-fg-base-275: #788181;
        --wui-color-fg-base-300: #6e7777;

        --wui-color-bg-base-100: #141414;
        --wui-color-bg-base-125: #191a1a;
        --wui-color-bg-base-150: #1e1f1f;
        --wui-color-bg-base-175: #222525;
        --wui-color-bg-base-200: #272a2a;
        --wui-color-bg-base-225: #2c3030;
        --wui-color-bg-base-250: #313535;
        --wui-color-bg-base-275: #363b3b;
        --wui-color-bg-base-300: #3b4040;

        --wui-color-success-base-100: #26d962;
        --wui-color-error-base-100: #f25a67;

        --wui-success-glass-001: rgba(38, 217, 98, 0.01);
        --wui-success-glass-002: rgba(38, 217, 98, 0.02);
        --wui-success-glass-005: rgba(38, 217, 98, 0.05);
        --wui-success-glass-010: rgba(38, 217, 98, 0.1);
        --wui-success-glass-015: rgba(38, 217, 98, 0.15);
        --wui-success-glass-020: rgba(38, 217, 98, 0.2);
        --wui-success-glass-025: rgba(38, 217, 98, 0.25);
        --wui-success-glass-030: rgba(38, 217, 98, 0.3);
        --wui-success-glass-060: rgba(38, 217, 98, 0.6);
        --wui-success-glass-080: rgba(38, 217, 98, 0.8);

        --wui-error-glass-001: rgba(242, 90, 103, 0.01);
        --wui-error-glass-002: rgba(242, 90, 103, 0.02);
        --wui-error-glass-005: rgba(242, 90, 103, 0.05);
        --wui-error-glass-010: rgba(242, 90, 103, 0.1);
        --wui-error-glass-015: rgba(242, 90, 103, 0.15);
        --wui-error-glass-020: rgba(242, 90, 103, 0.2);
        --wui-error-glass-025: rgba(242, 90, 103, 0.25);
        --wui-error-glass-030: rgba(242, 90, 103, 0.3);
        --wui-error-glass-060: rgba(242, 90, 103, 0.6);
        --wui-error-glass-080: rgba(242, 90, 103, 0.8);

        --wui-icon-box-bg-error-base-100: #3c2426;
        --wui-icon-box-bg-blue-base-100: #20303f;
        --wui-icon-box-bg-success-base-100: #1f3a28;
        --wui-icon-box-bg-inverse-base-100: #243240;

        --wui-all-wallets-bg-base-100: #222b35;

        --wui-avatar-border-base: #252525;

        --wui-thumbnail-border-base: #252525;

        --wui-gray-glass-001: rgba(255, 255, 255, 0.01);
        --wui-gray-glass-002: rgba(255, 255, 255, 0.02);
        --wui-gray-glass-005: rgba(255, 255, 255, 0.05);
        --wui-gray-glass-010: rgba(255, 255, 255, 0.1);
        --wui-gray-glass-015: rgba(255, 255, 255, 0.15);
        --wui-gray-glass-020: rgba(255, 255, 255, 0.2);
        --wui-gray-glass-025: rgba(255, 255, 255, 0.25);
        --wui-gray-glass-030: rgba(255, 255, 255, 0.3);
        --wui-gray-glass-060: rgba(255, 255, 255, 0.6);
        --wui-gray-glass-080: rgba(255, 255, 255, 0.8);
      }
    `,dark:Z`
      :root {
        --w3m-color-mix: ${qt((n==null?void 0:n["--w3m-color-mix"])||"#000")};
        --w3m-accent: ${qt((n==null?void 0:n["--w3m-accent"])||"#3396ff")};
        --w3m-default: #000;

        --wui-color-modal-bg-base: #fff;

        --wui-color-blue-base-100: #3396ff;

        --wui-color-accent-base-100: var(--w3m-accent);
        --wui-color-accent-base-090: #2d7dd2;
        --wui-color-accent-base-080: #2978cc;

        --wui-accent-glass-base-090: rgba(51, 150, 255, 0.9);
        --wui-accent-glass-base-080: rgba(51, 150, 255, 0.8);
        --wui-accent-glass-base-020: rgba(51, 150, 255, 0.2);
        --wui-accent-glass-base-015: rgba(51, 150, 255, 0.15);
        --wui-accent-glass-base-010: rgba(51, 150, 255, 0.1);
        --wui-accent-glass-base-005: rgba(51, 150, 255, 0.05);
        --wui-accent-glass-base-002: rgba(51, 150, 255, 0.02);

        --wui-color-fg-base-100: #141414;
        --wui-color-fg-base-125: #2d3131;
        --wui-color-fg-base-150: #474d4d;
        --wui-color-fg-base-175: #636d6d;
        --wui-color-fg-base-200: #798686;
        --wui-color-fg-base-225: #828f8f;
        --wui-color-fg-base-250: #8b9797;
        --wui-color-fg-base-275: #95a0a0;
        --wui-color-fg-base-300: #9ea9a9;

        --wui-color-bg-base-100: #ffffff;
        --wui-color-bg-base-125: #f5fafa;
        --wui-color-bg-base-150: #f3f8f8;
        --wui-color-bg-base-175: #eef4f4;
        --wui-color-bg-base-200: #eaf1f1;
        --wui-color-bg-base-225: #e5eded;
        --wui-color-bg-base-250: #e1e9e9;
        --wui-color-bg-base-275: #dce7e7;
        --wui-color-bg-base-300: #d8e3e3;

        --wui-color-success-base-100: #26b562;
        --wui-color-error-base-100: #f05142;

        --wui-success-glass-001: rgba(38, 181, 98, 0.01);
        --wui-success-glass-002: rgba(38, 181, 98, 0.02);
        --wui-success-glass-005: rgba(38, 181, 98, 0.05);
        --wui-success-glass-010: rgba(38, 181, 98, 0.1);
        --wui-success-glass-015: rgba(38, 181, 98, 0.15);
        --wui-success-glass-020: rgba(38, 181, 98, 0.2);
        --wui-success-glass-025: rgba(38, 181, 98, 0.25);
        --wui-success-glass-030: rgba(38, 181, 98, 0.3);
        --wui-success-glass-060: rgba(38, 181, 98, 0.6);
        --wui-success-glass-080: rgba(38, 181, 98, 0.8);

        --wui-error-glass-001: rgba(240, 81, 66, 0.01);
        --wui-error-glass-002: rgba(240, 81, 66, 0.02);
        --wui-error-glass-005: rgba(240, 81, 66, 0.05);
        --wui-error-glass-010: rgba(240, 81, 66, 0.1);
        --wui-error-glass-015: rgba(240, 81, 66, 0.15);
        --wui-error-glass-020: rgba(240, 81, 66, 0.2);
        --wui-error-glass-025: rgba(240, 81, 66, 0.25);
        --wui-error-glass-030: rgba(240, 81, 66, 0.3);
        --wui-error-glass-060: rgba(240, 81, 66, 0.6);
        --wui-error-glass-080: rgba(240, 81, 66, 0.8);

        --wui-icon-box-bg-error-base-100: #f4dfdd;
        --wui-icon-box-bg-blue-base-100: #d9ecfb;
        --wui-icon-box-bg-success-base-100: #daf0e4;
        --wui-icon-box-bg-inverse-base-100: #dcecfc;

        --wui-all-wallets-bg-base-100: #e8f1fa;

        --wui-avatar-border-base: #f3f4f4;

        --wui-thumbnail-border-base: #eaefef;

        --wui-gray-glass-001: rgba(0, 0, 0, 0.01);
        --wui-gray-glass-002: rgba(0, 0, 0, 0.02);
        --wui-gray-glass-005: rgba(0, 0, 0, 0.05);
        --wui-gray-glass-010: rgba(0, 0, 0, 0.1);
        --wui-gray-glass-015: rgba(0, 0, 0, 0.15);
        --wui-gray-glass-020: rgba(0, 0, 0, 0.2);
        --wui-gray-glass-025: rgba(0, 0, 0, 0.25);
        --wui-gray-glass-030: rgba(0, 0, 0, 0.3);
        --wui-gray-glass-060: rgba(0, 0, 0, 0.6);
        --wui-gray-glass-080: rgba(0, 0, 0, 0.8);
      }
    `}}const Q=Z`
  *,
  *::after,
  *::before,
  :host {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-style: normal;
    text-rendering: optimizeSpeed;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
    -webkit-tap-highlight-color: transparent;
    font-family: var(--wui-font-family);
    backface-visibility: hidden;
  }
`,$e=Z`
  button,
  a {
    cursor: pointer;
    display: flex;
    justify-content: center;
    align-items: center;
    position: relative;
    transition: all var(--wui-ease-out-power-1) var(--wui-duration-lg);
    outline: none;
    border: 1px solid transparent;
    column-gap: var(--wui-spacing-3xs);
    background-color: transparent;
    text-decoration: none;
  }

  @media (hover: hover) and (pointer: fine) {
    button:hover:enabled {
      background-color: var(--wui-gray-glass-005);
    }

    button:active:enabled {
      transition: all var(--wui-ease-out-power-2) var(--wui-duration-sm);
      background-color: var(--wui-gray-glass-010);
    }

    button[data-variant='fill']:hover:enabled {
      background-color: var(--wui-color-accent-090);
    }

    button[data-variant='accentBg']:hover:enabled {
      background: var(--wui-accent-glass-015);
    }

    button[data-variant='accentBg']:active:enabled {
      background: var(--wui-accent-glass-020);
    }
  }

  button:disabled {
    cursor: not-allowed;
    background-color: var(--wui-gray-glass-005);
  }

  button[data-variant='shade']:disabled,
  button[data-variant='accent']:disabled,
  button[data-variant='accentBg']:disabled {
    background-color: var(--wui-gray-glass-010);
    color: var(--wui-gray-glass-015);
    filter: grayscale(1);
  }

  button:disabled > wui-wallet-image,
  button:disabled > wui-all-wallets-image,
  button:disabled > wui-network-image,
  button:disabled > wui-image,
  button:disabled > wui-icon-box,
  button:disabled > wui-transaction-visual,
  button:disabled > wui-logo {
    filter: grayscale(1);
  }

  button:focus-visible,
  a:focus-visible {
    border: 1px solid var(--wui-color-accent-100);
    background-color: var(--wui-gray-glass-005);
    -webkit-box-shadow: 0px 0px 0px 4px var(--wui-box-shadow-blue);
    -moz-box-shadow: 0px 0px 0px 4px var(--wui-box-shadow-blue);
    box-shadow: 0px 0px 0px 4px var(--wui-box-shadow-blue);
  }

  button[data-variant='fill']:focus-visible {
    background-color: var(--wui-color-accent-090);
  }

  button[data-variant='fill'] {
    color: var(--wui-color-inverse-100);
    background-color: var(--wui-color-accent-100);
  }

  button[data-variant='fill']:disabled {
    color: var(--wui-gray-glass-015);
    background-color: var(--wui-gray-glass-015);
  }

  button[data-variant='fill']:disabled > wui-icon {
    color: var(--wui-gray-glass-015);
  }

  button[data-variant='shade'] {
    color: var(--wui-color-fg-200);
  }

  button[data-variant='accent'],
  button[data-variant='accentBg'] {
    color: var(--wui-color-accent-100);
  }

  button[data-variant='accentBg'] {
    background: var(--wui-accent-glass-010);
    border: 1px solid var(--wui-accent-glass-010);
  }

  button[data-variant='fullWidth'] {
    width: 100%;
    border-radius: var(--wui-border-radius-xs);
    height: 56px;
    border: none;
    background-color: var(--wui-gray-glass-002);
    color: var(--wui-color-fg-200);
    gap: var(--wui-spacing-xs);
  }

  button:active:enabled {
    background-color: var(--wui-gray-glass-010);
  }

  button[data-variant='fill']:active:enabled {
    background-color: var(--wui-color-accent-080);
    border: 1px solid var(--wui-gray-glass-010);
  }

  input {
    border: none;
    outline: none;
    appearance: none;
  }
`,Dl=Z`
  .wui-color-inherit {
    color: var(--wui-color-inherit);
  }

  .wui-color-accent-100 {
    color: var(--wui-color-accent-100);
  }

  .wui-color-error-100 {
    color: var(--wui-color-error-100);
  }

  .wui-color-success-100 {
    color: var(--wui-color-success-100);
  }

  .wui-color-inverse-100 {
    color: var(--wui-color-inverse-100);
  }

  .wui-color-inverse-000 {
    color: var(--wui-color-inverse-000);
  }

  .wui-color-fg-100 {
    color: var(--wui-color-fg-100);
  }

  .wui-color-fg-200 {
    color: var(--wui-color-fg-200);
  }

  .wui-color-fg-300 {
    color: var(--wui-color-fg-300);
  }

  .wui-bg-color-inherit {
    background-color: var(--wui-color-inherit);
  }

  .wui-bg-color-blue-100 {
    background-color: var(--wui-color-accent-100);
  }

  .wui-bg-color-error-100 {
    background-color: var(--wui-color-error-100);
  }

  .wui-bg-color-success-100 {
    background-color: var(--wui-color-success-100);
  }

  .wui-bg-color-inverse-100 {
    background-color: var(--wui-color-inverse-100);
  }

  .wui-bg-color-inverse-000 {
    background-color: var(--wui-color-inverse-000);
  }

  .wui-bg-color-fg-100 {
    background-color: var(--wui-color-fg-100);
  }

  .wui-bg-color-fg-200 {
    background-color: var(--wui-color-fg-200);
  }

  .wui-bg-color-fg-300 {
    background-color: var(--wui-color-fg-300);
  }
`;function km(n,e){const{kind:t,elements:i}=e;return{kind:t,elements:i,finisher(o){customElements.get(n)||customElements.define(n,o)}}}function Nm(n,e){return customElements.get(n)||customElements.define(n,e),e}function k(n){return function(t){return typeof t=="function"?Nm(n,t):km(n,t)}}const Mm=Z`
  :host {
    display: block;
    border-radius: clamp(0px, var(--wui-border-radius-l), 44px);
    box-shadow: 0 0 0 1px var(--wui-gray-glass-005);
    background-color: var(--wui-color-modal-bg);
    overflow: hidden;
  }
`;var Lm=function(n,e,t,i){var o=arguments.length,r=o<3?e:i===null?i=Object.getOwnPropertyDescriptor(e,t):i,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")r=Reflect.decorate(n,e,t,i);else for(var a=n.length-1;a>=0;a--)(s=n[a])&&(r=(o<3?s(r):o>3?s(e,t,r):s(e,t))||r);return o>3&&r&&Object.defineProperty(e,t,r),r};let Fs=class extends q{render(){return P`<slot></slot>`}};Fs.styles=[Q,Mm];Fs=Lm([k("wui-card")],Fs);/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const Bm={attribute:!0,type:String,converter:Ws,reflect:!1,hasChanged:Ll},jm=(n=Bm,e,t)=>{const{kind:i,metadata:o}=t;let r=globalThis.litPropertyMetadata.get(o);if(r===void 0&&globalThis.litPropertyMetadata.set(o,r=new Map),r.set(t.name,n),i==="accessor"){const{name:s}=t;return{set(a){const c=e.get.call(this);e.set.call(this,a),this.requestUpdate(s,c,n)},init(a){return a!==void 0&&this.P(s,void 0,n),a}}}if(i==="setter"){const{name:s}=t;return function(a){const c=this[s];e.call(this,a),this.requestUpdate(s,c,n)}}throw Error("Unsupported decorator location: "+i)};function v(n){return(e,t)=>typeof t=="object"?jm(n,e,t):((i,o,r)=>{const s=o.hasOwnProperty(r);return o.constructor.createProperty(r,s?{...i,wrapped:!0}:i),s?Object.getOwnPropertyDescriptor(o,r):void 0})(n,e,t)}/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */function Sa(n){return v({...n,state:!0,attribute:!1})}const Dm=Z`
  :host {
    display: flex;
    aspect-ratio: 1 / 1;
    color: var(--local-color);
    width: var(--local-width);
  }

  svg {
    width: inherit;
    height: inherit;
    object-fit: contain;
    object-position: center;
  }
`,Um=B`<svg fill="none" viewBox="0 0 24 24">
  <path
    style="fill: var(--wui-color-accent-100);"
    d="M10.2 6.6a3.6 3.6 0 1 1-7.2 0 3.6 3.6 0 0 1 7.2 0ZM21 6.6a3.6 3.6 0 1 1-7.2 0 3.6 3.6 0 0 1 7.2 0ZM10.2 17.4a3.6 3.6 0 1 1-7.2 0 3.6 3.6 0 0 1 7.2 0ZM21 17.4a3.6 3.6 0 1 1-7.2 0 3.6 3.6 0 0 1 7.2 0Z"
  />
</svg>`,Wm=B`<svg
  fill="none"
  viewBox="0 0 21 20"
>
  <path
    fill="currentColor"
    fill-rule="evenodd"
    d="M10.5 2.42908C6.31875 2.42908 2.92859 5.81989 2.92859 10.0034C2.92859 14.1869 6.31875 17.5777 10.5 17.5777C14.6813 17.5777 18.0714 14.1869 18.0714 10.0034C18.0714 5.81989 14.6813 2.42908 10.5 2.42908ZM0.928589 10.0034C0.928589 4.71596 5.21355 0.429077 10.5 0.429077C15.7865 0.429077 20.0714 4.71596 20.0714 10.0034C20.0714 15.2908 15.7865 19.5777 10.5 19.5777C5.21355 19.5777 0.928589 15.2908 0.928589 10.0034ZM10.5 5.75003C11.0523 5.75003 11.5 6.19774 11.5 6.75003L11.5 10.8343L12.7929 9.54137C13.1834 9.15085 13.8166 9.15085 14.2071 9.54137C14.5976 9.9319 14.5976 10.5651 14.2071 10.9556L11.2071 13.9556C10.8166 14.3461 10.1834 14.3461 9.79291 13.9556L6.79291 10.9556C6.40239 10.5651 6.40239 9.9319 6.79291 9.54137C7.18343 9.15085 7.8166 9.15085 8.20712 9.54137L9.50002 10.8343L9.50002 6.75003C9.50002 6.19774 9.94773 5.75003 10.5 5.75003Z"
    clip-rule="evenodd"
  /></svg
>`,zm=B`
<svg width="36" height="36">
  <path
    d="M28.724 0H7.271A7.269 7.269 0 0 0 0 7.272v21.46A7.268 7.268 0 0 0 7.271 36H28.73A7.272 7.272 0 0 0 36 28.728V7.272A7.275 7.275 0 0 0 28.724 0Z"
    fill="url(#a)"
  />
  <path
    d="m17.845 8.271.729-1.26a1.64 1.64 0 1 1 2.843 1.638l-7.023 12.159h5.08c1.646 0 2.569 1.935 1.853 3.276H6.434a1.632 1.632 0 0 1-1.638-1.638c0-.909.73-1.638 1.638-1.638h4.176l5.345-9.265-1.67-2.898a1.642 1.642 0 0 1 2.844-1.638l.716 1.264Zm-6.317 17.5-1.575 2.732a1.64 1.64 0 1 1-2.844-1.638l1.17-2.025c1.323-.41 2.398-.095 3.249.931Zm13.56-4.954h4.262c.909 0 1.638.729 1.638 1.638 0 .909-.73 1.638-1.638 1.638h-2.367l1.597 2.772c.45.788.185 1.782-.602 2.241a1.642 1.642 0 0 1-2.241-.603c-2.69-4.666-4.711-8.159-6.052-10.485-1.372-2.367-.391-4.743.576-5.549 1.075 1.846 2.682 4.631 4.828 8.348Z"
    fill="#fff"
  />
  <defs>
    <linearGradient id="a" x1="18" y1="0" x2="18" y2="36" gradientUnits="userSpaceOnUse">
      <stop stop-color="#18BFFB" />
      <stop offset="1" stop-color="#2072F3" />
    </linearGradient>
  </defs>
</svg>`,Fm=B`<svg fill="none" viewBox="0 0 40 40">
  <g clip-path="url(#a)">
    <g clip-path="url(#b)">
      <circle cx="20" cy="19.89" r="20" fill="#000" />
      <g clip-path="url(#c)">
        <path
          fill="#fff"
          d="M28.77 23.3c-.69 1.99-2.75 5.52-4.87 5.56-1.4.03-1.86-.84-3.46-.84-1.61 0-2.12.81-3.45.86-2.25.1-5.72-5.1-5.72-9.62 0-4.15 2.9-6.2 5.42-6.25 1.36-.02 2.64.92 3.47.92.83 0 2.38-1.13 4.02-.97.68.03 2.6.28 3.84 2.08-3.27 2.14-2.76 6.61.75 8.25ZM24.2 7.88c-2.47.1-4.49 2.69-4.2 4.84 2.28.17 4.47-2.39 4.2-4.84Z"
        />
      </g>
    </g>
  </g>
  <defs>
    <clipPath id="a"><rect width="40" height="40" fill="#fff" rx="20" /></clipPath>
    <clipPath id="b"><path fill="#fff" d="M0 0h40v40H0z" /></clipPath>
    <clipPath id="c"><path fill="#fff" d="M8 7.89h24v24H8z" /></clipPath>
  </defs>
</svg>`,Hm=B`<svg fill="none" viewBox="0 0 14 15">
  <path
    fill="currentColor"
    fill-rule="evenodd"
    d="M7 1.99a1 1 0 0 1 1 1v7.58l2.46-2.46a1 1 0 0 1 1.41 1.42L7.7 13.69a1 1 0 0 1-1.41 0L2.12 9.53A1 1 0 0 1 3.54 8.1L6 10.57V3a1 1 0 0 1 1-1Z"
    clip-rule="evenodd"
  />
</svg>`,Vm=B`<svg fill="none" viewBox="0 0 14 15">
  <path
    fill="currentColor"
    fill-rule="evenodd"
    d="M13 7.99a1 1 0 0 1-1 1H4.4l2.46 2.46a1 1 0 1 1-1.41 1.41L1.29 8.7a1 1 0 0 1 0-1.41L5.46 3.1a1 1 0 0 1 1.41 1.42L4.41 6.99H12a1 1 0 0 1 1 1Z"
    clip-rule="evenodd"
  />
</svg>`,Zm=B`<svg fill="none" viewBox="0 0 14 15">
  <path
    fill="currentColor"
    fill-rule="evenodd"
    d="M1 7.99a1 1 0 0 1 1-1h7.58L7.12 4.53A1 1 0 1 1 8.54 3.1l4.16 4.17a1 1 0 0 1 0 1.41l-4.16 4.17a1 1 0 1 1-1.42-1.41l2.46-2.46H2a1 1 0 0 1-1-1Z"
    clip-rule="evenodd"
  />
</svg>`,qm=B`<svg fill="none" viewBox="0 0 14 15">
  <path
    fill="currentColor"
    fill-rule="evenodd"
    d="M7 13.99a1 1 0 0 1-1-1V5.4L3.54 7.86a1 1 0 0 1-1.42-1.41L6.3 2.28a1 1 0 0 1 1.41 0l4.17 4.17a1 1 0 1 1-1.41 1.41L8 5.4v7.59a1 1 0 0 1-1 1Z"
    clip-rule="evenodd"
  />
</svg>`,Gm=B`<svg fill="none" viewBox="0 0 20 20">
  <path
    fill="currentColor"
    fill-rule="evenodd"
    d="M4 6.4a1 1 0 0 1-.46.89 6.98 6.98 0 0 0 .38 6.18A7 7 0 0 0 16.46 7.3a1 1 0 0 1-.47-.92 7 7 0 0 0-12 .03Zm-2.02-.5a9 9 0 1 1 16.03 8.2A9 9 0 0 1 1.98 5.9Z"
    clip-rule="evenodd"
  />
  <path
    fill="currentColor"
    fill-rule="evenodd"
    d="M6.03 8.63c-1.46-.3-2.72-.75-3.6-1.35l-.02-.01-.14-.11a1 1 0 0 1 1.2-1.6l.1.08c.6.4 1.52.74 2.69 1 .16-.99.39-1.88.67-2.65.3-.79.68-1.5 1.15-2.02A2.58 2.58 0 0 1 9.99 1c.8 0 1.45.44 1.92.97.47.52.84 1.23 1.14 2.02.29.77.52 1.66.68 2.64a8 8 0 0 0 2.7-1l.26-.18h.48a1 1 0 0 1 .12 2c-.86.51-2.01.91-3.34 1.18a22.24 22.24 0 0 1-.03 3.19c1.45.29 2.7.73 3.58 1.31a1 1 0 0 1-1.1 1.68c-.6-.4-1.56-.76-2.75-1-.15.8-.36 1.55-.6 2.2-.3.79-.67 1.5-1.14 2.02-.47.53-1.12.97-1.92.97-.8 0-1.45-.44-1.91-.97a6.51 6.51 0 0 1-1.15-2.02c-.24-.65-.44-1.4-.6-2.2-1.18.24-2.13.6-2.73.99a1 1 0 1 1-1.1-1.67c.88-.58 2.12-1.03 3.57-1.31a22.03 22.03 0 0 1-.04-3.2Zm2.2-1.7c.15-.86.34-1.61.58-2.24.24-.65.51-1.12.76-1.4.25-.28.4-.29.42-.29.03 0 .17.01.42.3.25.27.52.74.77 1.4.23.62.43 1.37.57 2.22a19.96 19.96 0 0 1-3.52 0Zm-.18 4.6a20.1 20.1 0 0 1-.03-2.62 21.95 21.95 0 0 0 3.94 0 20.4 20.4 0 0 1-.03 2.63 21.97 21.97 0 0 0-3.88 0Zm.27 2c.13.66.3 1.26.49 1.78.24.65.51 1.12.76 1.4.25.28.4.29.42.29.03 0 .17-.01.42-.3.25-.27.52-.74.77-1.4.19-.5.36-1.1.49-1.78a20.03 20.03 0 0 0-3.35 0Z"
    clip-rule="evenodd"
  />
</svg>`,Ym=B`<svg
  xmlns="http://www.w3.org/2000/svg"
  width="12"
  height="12"
  viewBox="0 0 12 12"
  fill="none"
>
  <path
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M10.537 2.34245C10.8997 2.64654 10.9471 3.187 10.6429 3.54959L5.61072 9.54757C5.45645 9.73144 5.23212 9.84222 4.99229 9.85295C4.75247 9.86368 4.51914 9.77337 4.34906 9.60401L1.40881 6.6761C1.07343 6.34213 1.07238 5.7996 1.40647 5.46433C1.74055 5.12906 2.28326 5.12801 2.61865 5.46198L4.89731 7.73108L9.32942 2.44834C9.63362 2.08576 10.1743 2.03835 10.537 2.34245Z"
    fill="currentColor"
  /></svg
>`,Km=B`<svg fill="none" viewBox="0 0 16 16">
  <path
    fill="currentColor"
    fill-rule="evenodd"
    d="M1.46 4.96a1 1 0 0 1 1.41 0L8 10.09l5.13-5.13a1 1 0 1 1 1.41 1.41l-5.83 5.84a1 1 0 0 1-1.42 0L1.46 6.37a1 1 0 0 1 0-1.41Z"
    clip-rule="evenodd"
  />
</svg>`,Jm=B`<svg fill="none" viewBox="0 0 16 16">
  <path
    fill="currentColor"
    fill-rule="evenodd"
    d="M11.04 1.46a1 1 0 0 1 0 1.41L5.91 8l5.13 5.13a1 1 0 1 1-1.41 1.41L3.79 8.71a1 1 0 0 1 0-1.42l5.84-5.83a1 1 0 0 1 1.41 0Z"
    clip-rule="evenodd"
  />
</svg>`,Qm=B`<svg fill="none" viewBox="0 0 16 16">
  <path
    fill="currentColor"
    fill-rule="evenodd"
    d="M4.96 14.54a1 1 0 0 1 0-1.41L10.09 8 4.96 2.87a1 1 0 0 1 1.41-1.41l5.84 5.83a1 1 0 0 1 0 1.42l-5.84 5.83a1 1 0 0 1-1.41 0Z"
    clip-rule="evenodd"
  />
</svg>`,Xm=B`<svg fill="none" viewBox="0 0 16 16">
  <path
    fill="currentColor"
    fill-rule="evenodd"
    d="M14.54 11.04a1 1 0 0 1-1.41 0L8 5.92l-5.13 5.12a1 1 0 1 1-1.41-1.41l5.83-5.84a1 1 0 0 1 1.42 0l5.83 5.84a1 1 0 0 1 0 1.41Z"
    clip-rule="evenodd"
  />
</svg>`,ew=B`<svg width="36" height="36" fill="none">
  <path
    fill="#fff"
    fill-opacity=".05"
    d="M0 14.94c0-5.55 0-8.326 1.182-10.4a9 9 0 0 1 3.359-3.358C6.614 0 9.389 0 14.94 0h6.12c5.55 0 8.326 0 10.4 1.182a9 9 0 0 1 3.358 3.359C36 6.614 36 9.389 36 14.94v6.12c0 5.55 0 8.326-1.182 10.4a9 9 0 0 1-3.359 3.358C29.386 36 26.611 36 21.06 36h-6.12c-5.55 0-8.326 0-10.4-1.182a9 9 0 0 1-3.358-3.359C0 29.386 0 26.611 0 21.06v-6.12Z"
  />
  <path
    stroke="#fff"
    stroke-opacity=".05"
    d="M14.94.5h6.12c2.785 0 4.84 0 6.46.146 1.612.144 2.743.43 3.691.97a8.5 8.5 0 0 1 3.172 3.173c.541.948.826 2.08.971 3.692.145 1.62.146 3.675.146 6.459v6.12c0 2.785 0 4.84-.146 6.46-.145 1.612-.43 2.743-.97 3.691a8.5 8.5 0 0 1-3.173 3.172c-.948.541-2.08.826-3.692.971-1.62.145-3.674.146-6.459.146h-6.12c-2.784 0-4.84 0-6.46-.146-1.612-.145-2.743-.43-3.691-.97a8.5 8.5 0 0 1-3.172-3.173c-.541-.948-.827-2.08-.971-3.692C.5 25.9.5 23.845.5 21.06v-6.12c0-2.784 0-4.84.146-6.46.144-1.612.43-2.743.97-3.691A8.5 8.5 0 0 1 4.79 1.617C5.737 1.076 6.869.79 8.48.646 10.1.5 12.156.5 14.94.5Z"
  />
  <path
    fill="url(#a)"
    d="M17.998 10.8h12.469a14.397 14.397 0 0 0-24.938.001l6.234 10.798.006-.001a7.19 7.19 0 0 1 6.23-10.799Z"
  />
  <path
    fill="url(#b)"
    d="m24.237 21.598-6.234 10.798A14.397 14.397 0 0 0 30.47 10.798H18.002l-.002.006a7.191 7.191 0 0 1 6.237 10.794Z"
  />
  <path
    fill="url(#c)"
    d="M11.765 21.601 5.531 10.803A14.396 14.396 0 0 0 18.001 32.4l6.235-10.798-.004-.004a7.19 7.19 0 0 1-12.466.004Z"
  />
  <path fill="#fff" d="M18 25.2a7.2 7.2 0 1 0 0-14.4 7.2 7.2 0 0 0 0 14.4Z" />
  <path fill="#1A73E8" d="M18 23.7a5.7 5.7 0 1 0 0-11.4 5.7 5.7 0 0 0 0 11.4Z" />
  <defs>
    <linearGradient
      id="a"
      x1="6.294"
      x2="41.1"
      y1="5.995"
      y2="5.995"
      gradientUnits="userSpaceOnUse"
    >
      <stop stop-color="#D93025" />
      <stop offset="1" stop-color="#EA4335" />
    </linearGradient>
    <linearGradient
      id="b"
      x1="20.953"
      x2="37.194"
      y1="32.143"
      y2="2.701"
      gradientUnits="userSpaceOnUse"
    >
      <stop stop-color="#FCC934" />
      <stop offset="1" stop-color="#FBBC04" />
    </linearGradient>
    <linearGradient
      id="c"
      x1="25.873"
      x2="9.632"
      y1="31.2"
      y2="1.759"
      gradientUnits="userSpaceOnUse"
    >
      <stop stop-color="#1E8E3E" />
      <stop offset="1" stop-color="#34A853" />
    </linearGradient>
  </defs>
</svg>`,tw=B`<svg fill="none" viewBox="0 0 16 16">
  <path
    fill="currentColor"
    fill-rule="evenodd"
    d="M7 2.99a5 5 0 1 0 0 10 5 5 0 0 0 0-10Zm-7 5a7 7 0 1 1 14 0 7 7 0 0 1-14 0Zm7-4a1 1 0 0 1 1 1v2.58l1.85 1.85a1 1 0 0 1-1.41 1.42L6.29 8.69A1 1 0 0 1 6 8v-3a1 1 0 0 1 1-1Z"
    clip-rule="evenodd"
  />
</svg>`,nw=B`<svg fill="none" viewBox="0 0 16 16">
  <path
    fill="currentColor"
    fill-rule="evenodd"
    d="M2.54 2.54a1 1 0 0 1 1.42 0L8 6.6l4.04-4.05a1 1 0 1 1 1.42 1.42L9.4 8l4.05 4.04a1 1 0 0 1-1.42 1.42L8 9.4l-4.04 4.05a1 1 0 0 1-1.42-1.42L6.6 8 2.54 3.96a1 1 0 0 1 0-1.42Z"
    clip-rule="evenodd"
  />
</svg>`,iw=B`<svg fill="none" viewBox="0 0 20 20">
  <path
    fill="currentColor"
    fill-rule="evenodd"
    d="M10 3a7 7 0 0 0-6.85 8.44l8.29-8.3C10.97 3.06 10.49 3 10 3Zm3.49.93-9.56 9.56c.32.55.71 1.06 1.16 1.5L15 5.1a7.03 7.03 0 0 0-1.5-1.16Zm2.7 2.8-9.46 9.46a7 7 0 0 0 9.46-9.46ZM1.99 5.9A9 9 0 1 1 18 14.09 9 9 0 0 1 1.98 5.91Z"
    clip-rule="evenodd"
  />
</svg>`,rw=B`<svg fill="none" viewBox="0 0 16 16">
  <path
    fill="currentColor"
    fill-rule="evenodd"
    d="M8 2a6 6 0 1 0 0 12A6 6 0 0 0 8 2ZM0 8a8 8 0 1 1 16 0A8 8 0 0 1 0 8Zm10.66-2.65a1 1 0 0 1 .23 1.06L9.83 9.24a1 1 0 0 1-.59.58l-2.83 1.06A1 1 0 0 1 5.13 9.6l1.06-2.82a1 1 0 0 1 .58-.59L9.6 5.12a1 1 0 0 1 1.06.23ZM7.9 7.89l-.13.35.35-.13.12-.35-.34.13Z"
    clip-rule="evenodd"
  />
</svg>`,ow=B`<svg
  xmlns="http://www.w3.org/2000/svg"
  width="16"
  height="16"
  viewBox="0 0 16 16"
  fill="none"
>
  <path
    fill="currentColor"
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M9.21498 1.28565H10.5944C11.1458 1.28562 11.6246 1.2856 12.0182 1.32093C12.4353 1.35836 12.853 1.44155 13.2486 1.66724C13.7005 1.92498 14.0749 2.29935 14.3326 2.75122C14.5583 3.14689 14.6415 3.56456 14.6789 3.9817C14.7143 4.37531 14.7142 4.85403 14.7142 5.40545V6.78489C14.7142 7.33631 14.7143 7.81503 14.6789 8.20865C14.6415 8.62578 14.5583 9.04345 14.3326 9.43912C14.0749 9.89099 13.7005 10.2654 13.2486 10.5231C12.853 10.7488 12.4353 10.832 12.0182 10.8694C11.7003 10.8979 11.3269 10.9034 10.9045 10.9045C10.9034 11.3269 10.8979 11.7003 10.8694 12.0182C10.832 12.4353 10.7488 12.853 10.5231 13.2486C10.2654 13.7005 9.89099 14.0749 9.43912 14.3326C9.04345 14.5583 8.62578 14.6415 8.20865 14.6789C7.81503 14.7143 7.33631 14.7142 6.78489 14.7142H5.40545C4.85403 14.7142 4.37531 14.7143 3.9817 14.6789C3.56456 14.6415 3.14689 14.5583 2.75122 14.3326C2.29935 14.0749 1.92498 13.7005 1.66724 13.2486C1.44155 12.853 1.35836 12.4353 1.32093 12.0182C1.2856 11.6246 1.28562 11.1458 1.28565 10.5944V9.21498C1.28562 8.66356 1.2856 8.18484 1.32093 7.79122C1.35836 7.37409 1.44155 6.95642 1.66724 6.56074C1.92498 6.10887 2.29935 5.73451 2.75122 5.47677C3.14689 5.25108 3.56456 5.16789 3.9817 5.13045C4.2996 5.10192 4.67301 5.09645 5.09541 5.09541C5.09645 4.67302 5.10192 4.2996 5.13045 3.9817C5.16789 3.56456 5.25108 3.14689 5.47676 2.75122C5.73451 2.29935 6.10887 1.92498 6.56074 1.66724C6.95642 1.44155 7.37409 1.35836 7.79122 1.32093C8.18484 1.2856 8.66356 1.28562 9.21498 1.28565ZM5.09541 7.09552C4.68397 7.09667 4.39263 7.10161 4.16046 7.12245C3.88053 7.14757 3.78516 7.18949 3.74214 7.21403C3.60139 7.29431 3.48478 7.41091 3.4045 7.55166C3.37997 7.59468 3.33804 7.69005 3.31292 7.96999C3.28659 8.26345 3.28565 8.65147 3.28565 9.25708V10.5523C3.28565 11.1579 3.28659 11.5459 3.31292 11.8394C3.33804 12.1193 3.37997 12.2147 3.4045 12.2577C3.48478 12.3985 3.60139 12.5151 3.74214 12.5954C3.78516 12.6199 3.88053 12.6618 4.16046 12.6869C4.45393 12.7133 4.84195 12.7142 5.44755 12.7142H6.74279C7.3484 12.7142 7.73641 12.7133 8.02988 12.6869C8.30981 12.6618 8.40518 12.6199 8.44821 12.5954C8.58895 12.5151 8.70556 12.3985 8.78584 12.2577C8.81038 12.2147 8.8523 12.1193 8.87742 11.8394C8.89825 11.6072 8.90319 11.3159 8.90435 10.9045C8.48219 10.9034 8.10898 10.8979 7.79122 10.8694C7.37409 10.832 6.95641 10.7488 6.56074 10.5231C6.10887 10.2654 5.73451 9.89099 5.47676 9.43912C5.25108 9.04345 5.16789 8.62578 5.13045 8.20865C5.10194 7.89089 5.09645 7.51767 5.09541 7.09552ZM7.96999 3.31292C7.69005 3.33804 7.59468 3.37997 7.55166 3.4045C7.41091 3.48478 7.29431 3.60139 7.21403 3.74214C7.18949 3.78516 7.14757 3.88053 7.12245 4.16046C7.09611 4.45393 7.09517 4.84195 7.09517 5.44755V6.74279C7.09517 7.3484 7.09611 7.73641 7.12245 8.02988C7.14757 8.30981 7.18949 8.40518 7.21403 8.4482C7.29431 8.58895 7.41091 8.70556 7.55166 8.78584C7.59468 8.81038 7.69005 8.8523 7.96999 8.87742C8.26345 8.90376 8.65147 8.9047 9.25708 8.9047H10.5523C11.1579 8.9047 11.5459 8.90376 11.8394 8.87742C12.1193 8.8523 12.2147 8.81038 12.2577 8.78584C12.3985 8.70556 12.5151 8.58895 12.5954 8.4482C12.6199 8.40518 12.6618 8.30981 12.6869 8.02988C12.7133 7.73641 12.7142 7.3484 12.7142 6.74279V5.44755C12.7142 4.84195 12.7133 4.45393 12.6869 4.16046C12.6618 3.88053 12.6199 3.78516 12.5954 3.74214C12.5151 3.60139 12.3985 3.48478 12.2577 3.4045C12.2147 3.37997 12.1193 3.33804 11.8394 3.31292C11.5459 3.28659 11.1579 3.28565 10.5523 3.28565H9.25708C8.65147 3.28565 8.26345 3.28659 7.96999 3.31292Z"
    fill="#788181"
  /></svg
>`,sw=B`<svg
  width="14"
  height="14"
  viewBox="0 0 14 14"
  fill="none"
  xmlns="http://www.w3.org/2000/svg"
>
  <path
    fill="currentColor"
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M7.0023 0.875C7.48571 0.875 7.8776 1.26675 7.8776 1.75V6.125H12.2541C12.7375 6.125 13.1294 6.51675 13.1294 7C13.1294 7.48325 12.7375 7.875 12.2541 7.875H7.8776V12.25C7.8776 12.7332 7.48571 13.125 7.0023 13.125C6.51889 13.125 6.12701 12.7332 6.12701 12.25V7.875H1.75054C1.26713 7.875 0.875244 7.48325 0.875244 7C0.875244 6.51675 1.26713 6.125 1.75054 6.125H6.12701V1.75C6.12701 1.26675 6.51889 0.875 7.0023 0.875Z"
    fill="#47A1FF"
  /></svg
>`,aw=B` <svg fill="none" viewBox="0 0 13 4">
  <path fill="currentColor" d="M.5 0h12L8.9 3.13a3.76 3.76 0 0 1-4.8 0L.5 0Z" />
</svg>`,cw=B`<svg fill="none" viewBox="0 0 20 20">
  <path
    fill="currentColor"
    fill-rule="evenodd"
    d="M13.66 2H6.34c-1.07 0-1.96 0-2.68.08-.74.08-1.42.25-2.01.68a4 4 0 0 0-.89.89c-.43.6-.6 1.27-.68 2.01C0 6.38 0 7.26 0 8.34v.89c0 1.07 0 1.96.08 2.68.08.74.25 1.42.68 2.01a4 4 0 0 0 .89.89c.6.43 1.27.6 2.01.68a27 27 0 0 0 2.68.08h7.32a27 27 0 0 0 2.68-.08 4.03 4.03 0 0 0 2.01-.68 4 4 0 0 0 .89-.89c.43-.6.6-1.27.68-2.01.08-.72.08-1.6.08-2.68v-.89c0-1.07 0-1.96-.08-2.68a4.04 4.04 0 0 0-.68-2.01 4 4 0 0 0-.89-.89c-.6-.43-1.27-.6-2.01-.68C15.62 2 14.74 2 13.66 2ZM2.82 4.38c.2-.14.48-.25 1.06-.31C4.48 4 5.25 4 6.4 4h7.2c1.15 0 1.93 0 2.52.07.58.06.86.17 1.06.31a2 2 0 0 1 .44.44c.14.2.25.48.31 1.06.07.6.07 1.37.07 2.52v.77c0 1.15 0 1.93-.07 2.52-.06.58-.17.86-.31 1.06a2 2 0 0 1-.44.44c-.2.14-.48.25-1.06.32-.6.06-1.37.06-2.52.06H6.4c-1.15 0-1.93 0-2.52-.06-.58-.07-.86-.18-1.06-.32a2 2 0 0 1-.44-.44c-.14-.2-.25-.48-.31-1.06C2 11.1 2 10.32 2 9.17V8.4c0-1.15 0-1.93.07-2.52.06-.58.17-.86.31-1.06a2 2 0 0 1 .44-.44Z"
    clip-rule="evenodd"
  />
  <path fill="currentColor" d="M6.14 17.57a1 1 0 1 0 0 2h7.72a1 1 0 1 0 0-2H6.14Z" />
</svg>`,lw=B`<svg fill="none" viewBox="0 0 16 16">
  <path
    fill="currentColor"
    fill-rule="evenodd"
    d="M6.07 1h.57a1 1 0 0 1 0 2h-.52c-.98 0-1.64 0-2.14.06-.48.05-.7.14-.84.24-.13.1-.25.22-.34.35-.1.14-.2.35-.25.83-.05.5-.05 1.16-.05 2.15v2.74c0 .99 0 1.65.05 2.15.05.48.14.7.25.83.1.14.2.25.34.35.14.1.36.2.84.25.5.05 1.16.05 2.14.05h.52a1 1 0 0 1 0 2h-.57c-.92 0-1.69 0-2.3-.07a3.6 3.6 0 0 1-1.8-.61c-.3-.22-.57-.49-.8-.8a3.6 3.6 0 0 1-.6-1.79C.5 11.11.5 10.35.5 9.43V6.58c0-.92 0-1.7.06-2.31a3.6 3.6 0 0 1 .62-1.8c.22-.3.48-.57.79-.79a3.6 3.6 0 0 1 1.8-.61C4.37 1 5.14 1 6.06 1ZM9.5 3a1 1 0 0 1 1.42 0l4.28 4.3a1 1 0 0 1 0 1.4L10.93 13a1 1 0 0 1-1.42-1.42L12.1 9H6.8a1 1 0 1 1 0-2h5.3L9.51 4.42a1 1 0 0 1 0-1.41Z"
    clip-rule="evenodd"
  />
</svg>`,uw=B`<svg fill="none" viewBox="0 0 40 40">
  <g clip-path="url(#a)">
    <g clip-path="url(#b)">
      <circle cx="20" cy="19.89" r="20" fill="#5865F2" />
      <path
        fill="#fff"
        fill-rule="evenodd"
        d="M25.71 28.15C30.25 28 32 25.02 32 25.02c0-6.61-2.96-11.98-2.96-11.98-2.96-2.22-5.77-2.15-5.77-2.15l-.29.32c3.5 1.07 5.12 2.61 5.12 2.61a16.75 16.75 0 0 0-10.34-1.93l-.35.04a15.43 15.43 0 0 0-5.88 1.9s1.71-1.63 5.4-2.7l-.2-.24s-2.81-.07-5.77 2.15c0 0-2.96 5.37-2.96 11.98 0 0 1.73 2.98 6.27 3.13l1.37-1.7c-2.6-.79-3.6-2.43-3.6-2.43l.58.35.09.06.08.04.02.01.08.05a17.25 17.25 0 0 0 4.52 1.58 14.4 14.4 0 0 0 8.3-.86c.72-.27 1.52-.66 2.37-1.21 0 0-1.03 1.68-3.72 2.44.61.78 1.35 1.67 1.35 1.67Zm-9.55-9.6c-1.17 0-2.1 1.03-2.1 2.28 0 1.25.95 2.28 2.1 2.28 1.17 0 2.1-1.03 2.1-2.28.01-1.25-.93-2.28-2.1-2.28Zm7.5 0c-1.17 0-2.1 1.03-2.1 2.28 0 1.25.95 2.28 2.1 2.28 1.17 0 2.1-1.03 2.1-2.28 0-1.25-.93-2.28-2.1-2.28Z"
        clip-rule="evenodd"
      />
    </g>
  </g>
  <defs>
    <clipPath id="a"><rect width="40" height="40" fill="#fff" rx="20" /></clipPath>
    <clipPath id="b"><path fill="#fff" d="M0 0h40v40H0z" /></clipPath>
  </defs>
</svg>`,dw=B`<svg fill="none" viewBox="0 0 16 16">
  <path
    fill="currentColor"
    d="M4.25 7a.63.63 0 0 0-.63.63v3.97c0 .28-.2.51-.47.54l-.75.07a.93.93 0 0 1-.9-.47A7.51 7.51 0 0 1 5.54.92a7.5 7.5 0 0 1 9.54 4.62c.12.35.06.72-.16 1-.74.97-1.68 1.78-2.6 2.44V4.44a.64.64 0 0 0-.63-.64h-1.06c-.35 0-.63.3-.63.64v5.5c0 .23-.12.42-.32.5l-.52.23V6.05c0-.36-.3-.64-.64-.64H7.45c-.35 0-.64.3-.64.64v4.97c0 .25-.17.46-.4.52a5.8 5.8 0 0 0-.45.11v-4c0-.36-.3-.65-.64-.65H4.25ZM14.07 12.4A7.49 7.49 0 0 1 3.6 14.08c4.09-.58 9.14-2.5 11.87-6.6v.03a7.56 7.56 0 0 1-1.41 4.91Z"
  />
</svg>`,hw=B`<svg fill="none" viewBox="0 0 14 15">
  <path
    fill="currentColor"
    fill-rule="evenodd"
    d="M6.71 2.99a.57.57 0 0 0-.57.57 1 1 0 0 1-1 1c-.58 0-.96 0-1.24.03-.27.03-.37.07-.42.1a.97.97 0 0 0-.36.35c-.04.08-.09.21-.11.67a2.57 2.57 0 0 1 0 5.13c.02.45.07.6.11.66.09.15.21.28.36.36.07.04.21.1.67.12a2.57 2.57 0 0 1 5.12 0c.46-.03.6-.08.67-.12a.97.97 0 0 0 .36-.36c.03-.04.07-.14.1-.41.02-.29.03-.66.03-1.24a1 1 0 0 1 1-1 .57.57 0 0 0 0-1.15 1 1 0 0 1-1-1c0-.58 0-.95-.03-1.24a1.04 1.04 0 0 0-.1-.42.97.97 0 0 0-.36-.36 1.04 1.04 0 0 0-.42-.1c-.28-.02-.65-.02-1.24-.02a1 1 0 0 1-1-1 .57.57 0 0 0-.57-.57ZM5.15 13.98a1 1 0 0 0 .99-1v-.78a.57.57 0 0 1 1.14 0v.78a1 1 0 0 0 .99 1H8.36a66.26 66.26 0 0 0 .73 0 3.78 3.78 0 0 0 1.84-.38c.46-.26.85-.64 1.1-1.1.23-.4.32-.8.36-1.22.02-.2.03-.4.03-.63a2.57 2.57 0 0 0 0-4.75c0-.23-.01-.44-.03-.63a2.96 2.96 0 0 0-.35-1.22 2.97 2.97 0 0 0-1.1-1.1c-.4-.22-.8-.31-1.22-.35a8.7 8.7 0 0 0-.64-.04 2.57 2.57 0 0 0-4.74 0c-.23 0-.44.02-.63.04-.42.04-.83.13-1.22.35-.46.26-.84.64-1.1 1.1-.33.57-.37 1.2-.39 1.84a21.39 21.39 0 0 0 0 .72v.1a1 1 0 0 0 1 .99h.78a.57.57 0 0 1 0 1.15h-.77a1 1 0 0 0-1 .98v.1a63.87 63.87 0 0 0 0 .73c0 .64.05 1.27.38 1.83.26.47.64.85 1.1 1.11.56.32 1.2.37 1.84.38a20.93 20.93 0 0 0 .72 0h.1Z"
    clip-rule="evenodd"
  />
</svg>`,pw=B`<svg fill="none" viewBox="0 0 14 15">
  <path
    fill="currentColor"
    fill-rule="evenodd"
    d="M3.74 3.99a1 1 0 0 1 1-1H11a1 1 0 0 1 1 1v6.26a1 1 0 0 1-2 0V6.4l-6.3 6.3a1 1 0 0 1-1.4-1.42l6.29-6.3H4.74a1 1 0 0 1-1-1Z"
    clip-rule="evenodd"
  />
</svg>`,fw=B`<svg fill="none" viewBox="0 0 40 40">
  <g clip-path="url(#a)">
    <g clip-path="url(#b)">
      <circle cx="20" cy="19.89" r="20" fill="#1877F2" />
      <g clip-path="url(#c)">
        <path
          fill="#fff"
          d="M26 12.38h-2.89c-.92 0-1.61.38-1.61 1.34v1.66H26l-.36 4.5H21.5v12H17v-12h-3v-4.5h3V12.5c0-3.03 1.6-4.62 5.2-4.62H26v4.5Z"
        />
      </g>
    </g>
    <path
      fill="#1877F2"
      d="M40 20a20 20 0 1 0-23.13 19.76V25.78H11.8V20h5.07v-4.4c0-5.02 3-7.79 7.56-7.79 2.19 0 4.48.4 4.48.4v4.91h-2.53c-2.48 0-3.25 1.55-3.25 3.13V20h5.54l-.88 5.78h-4.66v13.98A20 20 0 0 0 40 20Z"
    />
    <path
      fill="#fff"
      d="m27.79 25.78.88-5.78h-5.55v-3.75c0-1.58.78-3.13 3.26-3.13h2.53V8.2s-2.3-.39-4.48-.39c-4.57 0-7.55 2.77-7.55 7.78V20H11.8v5.78h5.07v13.98a20.15 20.15 0 0 0 6.25 0V25.78h4.67Z"
    />
  </g>
  <defs>
    <clipPath id="a"><rect width="40" height="40" fill="#fff" rx="20" /></clipPath>
    <clipPath id="b"><path fill="#fff" d="M0 0h40v40H0z" /></clipPath>
    <clipPath id="c"><path fill="#fff" d="M8 7.89h24v24H8z" /></clipPath>
  </defs>
</svg>`,gw=B`<svg fill="none" viewBox="0 0 16 16">
  <path
    fill="currentColor"
    fill-rule="evenodd"
    d="M0 3a1 1 0 0 1 1-1h14a1 1 0 1 1 0 2H1a1 1 0 0 1-1-1Zm2.63 5.25a1 1 0 0 1 1-1h8.75a1 1 0 1 1 0 2H3.63a1 1 0 0 1-1-1Zm2.62 5.25a1 1 0 0 1 1-1h3.5a1 1 0 0 1 0 2h-3.5a1 1 0 0 1-1-1Z"
    clip-rule="evenodd"
  />
</svg>`,mw=B`<svg fill="none" viewBox="0 0 40 40">
  <g clip-path="url(#a)">
    <g clip-path="url(#b)">
      <circle cx="20" cy="19.89" r="20" fill="#1B1F23" />
      <g clip-path="url(#c)">
        <path
          fill="#fff"
          d="M8 19.89a12 12 0 1 1 15.8 11.38c-.6.12-.8-.26-.8-.57v-3.3c0-1.12-.4-1.85-.82-2.22 2.67-.3 5.48-1.31 5.48-5.92 0-1.31-.47-2.38-1.24-3.22.13-.3.54-1.52-.12-3.18 0 0-1-.32-3.3 1.23a11.54 11.54 0 0 0-6 0c-2.3-1.55-3.3-1.23-3.3-1.23a4.32 4.32 0 0 0-.12 3.18 4.64 4.64 0 0 0-1.24 3.22c0 4.6 2.8 5.63 5.47 5.93-.34.3-.65.83-.76 1.6-.69.31-2.42.84-3.5-1 0 0-.63-1.15-1.83-1.23 0 0-1.18-.02-.09.73 0 0 .8.37 1.34 1.76 0 0 .7 2.14 4.03 1.41v2.24c0 .31-.2.68-.8.57A12 12 0 0 1 8 19.9Z"
        />
      </g>
    </g>
  </g>
  <defs>
    <clipPath id="a"><rect width="40" height="40" fill="#fff" rx="20" /></clipPath>
    <clipPath id="b"><path fill="#fff" d="M0 0h40v40H0z" /></clipPath>
    <clipPath id="c"><path fill="#fff" d="M8 7.89h24v24H8z" /></clipPath>
  </defs>
</svg>`,ww=B`<svg fill="none" viewBox="0 0 40 40">
  <g clip-path="url(#a)">
    <g clip-path="url(#b)">
      <circle cx="20" cy="19.89" r="20" fill="#fff" fill-opacity=".05" />
      <g clip-path="url(#c)">
        <path
          fill="#4285F4"
          d="M20 17.7v4.65h6.46a5.53 5.53 0 0 1-2.41 3.61l3.9 3.02c2.26-2.09 3.57-5.17 3.57-8.82 0-.85-.08-1.67-.22-2.46H20Z"
        />
        <path
          fill="#34A853"
          d="m13.27 22.17-.87.67-3.11 2.42A12 12 0 0 0 20 31.9c3.24 0 5.96-1.07 7.94-2.9l-3.9-3.03A7.15 7.15 0 0 1 20 27.12a7.16 7.16 0 0 1-6.72-4.94v-.01Z"
        />
        <path
          fill="#FBBC05"
          d="M9.29 14.5a11.85 11.85 0 0 0 0 10.76l3.99-3.1a7.19 7.19 0 0 1 0-4.55l-4-3.1Z"
        />
        <path
          fill="#EA4335"
          d="M20 12.66c1.77 0 3.34.61 4.6 1.8l3.43-3.44A11.51 11.51 0 0 0 20 7.89c-4.7 0-8.74 2.69-10.71 6.62l3.99 3.1A7.16 7.16 0 0 1 20 12.66Z"
        />
      </g>
    </g>
  </g>
  <defs>
    <clipPath id="a"><rect width="40" height="40" fill="#fff" rx="20" /></clipPath>
    <clipPath id="b"><path fill="#fff" d="M0 0h40v40H0z" /></clipPath>
    <clipPath id="c"><path fill="#fff" d="M8 7.89h24v24H8z" /></clipPath>
  </defs>
</svg>`,bw=B`<svg fill="none" viewBox="0 0 16 16">
  <path
    fill="currentColor"
    d="M8.51 5.66a.83.83 0 0 0-.57-.2.83.83 0 0 0-.52.28.8.8 0 0 0-.25.52 1 1 0 0 1-2 0c0-.75.34-1.43.81-1.91a2.75 2.75 0 0 1 4.78 1.92c0 1.24-.8 1.86-1.25 2.2l-.04.03c-.47.36-.5.43-.5.65a1 1 0 1 1-2 0c0-1.25.8-1.86 1.24-2.2l.04-.04c.47-.36.5-.43.5-.65 0-.3-.1-.49-.24-.6ZM9.12 11.87a1.13 1.13 0 1 1-2.25 0 1.13 1.13 0 0 1 2.25 0Z"
  />
  <path
    fill="currentColor"
    fill-rule="evenodd"
    d="M0 8a8 8 0 1 1 16 0A8 8 0 0 1 0 8Zm8-6a6 6 0 1 0 0 12A6 6 0 0 0 8 2Z"
    clip-rule="evenodd"
  />
</svg>`,vw=B`<svg fill="none" viewBox="0 0 14 15">
  <path
    fill="currentColor"
    d="M6 10.49a1 1 0 1 0 2 0v-2a1 1 0 0 0-2 0v2ZM7 4.49a1 1 0 1 0 0 2 1 1 0 0 0 0-2Z"
  />
  <path
    fill="currentColor"
    fill-rule="evenodd"
    d="M7 14.99a7 7 0 1 0 0-14 7 7 0 0 0 0 14Zm5-7a5 5 0 1 1-10 0 5 5 0 0 1 10 0Z"
    clip-rule="evenodd"
  />
</svg>`,yw=B`<svg fill="none" viewBox="0 0 16 16">
  <path
    fill="currentColor"
    fill-rule="evenodd"
    d="M4.83 1.34h6.34c.68 0 1.26 0 1.73.04.5.05.97.15 1.42.4.52.3.95.72 1.24 1.24.26.45.35.92.4 1.42.04.47.04 1.05.04 1.73v3.71c0 .69 0 1.26-.04 1.74-.05.5-.14.97-.4 1.41-.3.52-.72.95-1.24 1.25-.45.25-.92.35-1.42.4-.47.03-1.05.03-1.73.03H4.83c-.68 0-1.26 0-1.73-.04-.5-.04-.97-.14-1.42-.4-.52-.29-.95-.72-1.24-1.24a3.39 3.39 0 0 1-.4-1.41A20.9 20.9 0 0 1 0 9.88v-3.7c0-.7 0-1.27.04-1.74.05-.5.14-.97.4-1.42.3-.52.72-.95 1.24-1.24.45-.25.92-.35 1.42-.4.47-.04 1.05-.04 1.73-.04ZM3.28 3.38c-.36.03-.51.08-.6.14-.21.11-.39.29-.5.5a.8.8 0 0 0-.08.19l5.16 3.44c.45.3 1.03.3 1.48 0L13.9 4.2a.79.79 0 0 0-.08-.2c-.11-.2-.29-.38-.5-.5-.09-.05-.24-.1-.6-.13-.37-.04-.86-.04-1.6-.04H4.88c-.73 0-1.22 0-1.6.04ZM14 6.54 9.85 9.31a3.33 3.33 0 0 1-3.7 0L2 6.54v3.3c0 .74 0 1.22.03 1.6.04.36.1.5.15.6.11.2.29.38.5.5.09.05.24.1.6.14.37.03.86.03 1.6.03h6.25c.73 0 1.22 0 1.6-.03.35-.03.5-.09.6-.14.2-.12.38-.3.5-.5.05-.1.1-.24.14-.6.03-.38.03-.86.03-1.6v-3.3Z"
    clip-rule="evenodd"
  />
</svg>`,xw=B`<svg fill="none" viewBox="0 0 20 20">
  <path fill="currentColor" d="M10.81 5.81a2 2 0 1 1-4 0 2 2 0 0 1 4 0Z" />
  <path
    fill="currentColor"
    fill-rule="evenodd"
    d="M3 4.75A4.75 4.75 0 0 1 7.75 0h4.5A4.75 4.75 0 0 1 17 4.75v10.5A4.75 4.75 0 0 1 12.25 20h-4.5A4.75 4.75 0 0 1 3 15.25V4.75ZM7.75 2A2.75 2.75 0 0 0 5 4.75v10.5A2.75 2.75 0 0 0 7.75 18h4.5A2.75 2.75 0 0 0 15 15.25V4.75A2.75 2.75 0 0 0 12.25 2h-4.5Z"
    clip-rule="evenodd"
  />
</svg>`,Cw=B`<svg fill="none" viewBox="0 0 22 20">
  <path
    fill="currentColor"
    fill-rule="evenodd"
    d="M16.32 13.62a3.14 3.14 0 1 1-.99 1.72l-1.6-.93a3.83 3.83 0 0 1-3.71 1 3.66 3.66 0 0 1-1.74-1l-1.6.94a3.14 3.14 0 1 1-1-1.73l1.6-.94a3.7 3.7 0 0 1 0-2 3.81 3.81 0 0 1 1.8-2.33c.29-.17.6-.3.92-.38V6.1a3.14 3.14 0 1 1 2 0l-.01.02v1.85H12a3.82 3.82 0 0 1 2.33 1.8 3.7 3.7 0 0 1 .39 2.91l1.6.93ZM2.6 16.54a1.14 1.14 0 0 0 1.98-1.14 1.14 1.14 0 0 0-1.98 1.14ZM11 2.01a1.14 1.14 0 1 0 0 2.28 1.14 1.14 0 0 0 0-2.28Zm1.68 10.45c.08-.19.14-.38.16-.58v-.05l.02-.13v-.13a1.92 1.92 0 0 0-.24-.8l-.11-.15a1.89 1.89 0 0 0-.74-.6 1.86 1.86 0 0 0-.77-.17h-.19a1.97 1.97 0 0 0-.89.34 1.98 1.98 0 0 0-.61.74 1.99 1.99 0 0 0-.16.9v.05a1.87 1.87 0 0 0 .24.74l.1.15c.12.16.26.3.42.42l.16.1.13.07.04.02a1.84 1.84 0 0 0 .76.17h.17a2 2 0 0 0 .91-.35 1.78 1.78 0 0 0 .52-.58l.03-.05a.84.84 0 0 0 .05-.11Zm5.15 4.5a1.14 1.14 0 0 0 1.14-1.97 1.13 1.13 0 0 0-1.55.41c-.32.55-.13 1.25.41 1.56Z"
    clip-rule="evenodd"
  />
  <path
    fill="currentColor"
    fill-rule="evenodd"
    d="M4.63 9.43a1.5 1.5 0 1 0 1.5-2.6 1.5 1.5 0 0 0-1.5 2.6Zm.32-1.55a.5.5 0 0 1 .68-.19.5.5 0 0 1 .18.68.5.5 0 0 1-.68.19.5.5 0 0 1-.18-.68ZM17.94 8.88a1.5 1.5 0 1 1-2.6-1.5 1.5 1.5 0 1 1 2.6 1.5ZM16.9 7.69a.5.5 0 0 0-.68.19.5.5 0 0 0 .18.68.5.5 0 0 0 .68-.19.5.5 0 0 0-.18-.68ZM9.75 17.75a1.5 1.5 0 1 1 2.6 1.5 1.5 1.5 0 1 1-2.6-1.5Zm1.05 1.18a.5.5 0 0 0 .68-.18.5.5 0 0 0-.18-.68.5.5 0 0 0-.68.18.5.5 0 0 0 .18.68Z"
    clip-rule="evenodd"
  />
</svg>`,_w=B`<svg fill="none" viewBox="0 0 20 20">
  <path
    fill="currentColor"
    fill-rule="evenodd"
    d="M9.13 1h1.71c1.46 0 2.63 0 3.56.1.97.1 1.8.33 2.53.85a5 5 0 0 1 1.1 1.11c.53.73.75 1.56.86 2.53.1.93.1 2.1.1 3.55v1.72c0 1.45 0 2.62-.1 3.55-.1.97-.33 1.8-.86 2.53a5 5 0 0 1-1.1 1.1c-.73.53-1.56.75-2.53.86-.93.1-2.1.1-3.55.1H9.13c-1.45 0-2.62 0-3.56-.1-.96-.1-1.8-.33-2.52-.85a5 5 0 0 1-1.1-1.11 5.05 5.05 0 0 1-.86-2.53c-.1-.93-.1-2.1-.1-3.55V9.14c0-1.45 0-2.62.1-3.55.1-.97.33-1.8.85-2.53a5 5 0 0 1 1.1-1.1 5.05 5.05 0 0 1 2.53-.86C6.51 1 7.67 1 9.13 1ZM5.79 3.09a3.1 3.1 0 0 0-1.57.48 3 3 0 0 0-.66.67c-.24.32-.4.77-.48 1.56-.1.82-.1 1.88-.1 3.4v1.6c0 1.15 0 2.04.05 2.76l.41-.42c.5-.5.93-.92 1.32-1.24.41-.33.86-.6 1.43-.7a3 3 0 0 1 .94 0c.35.06.66.2.95.37a17.11 17.11 0 0 0 .8.45c.1-.08.2-.2.41-.4l.04-.03a27 27 0 0 1 1.95-1.84 4.03 4.03 0 0 1 1.91-.94 4 4 0 0 1 1.25 0c.73.11 1.33.46 1.91.94l.64.55V9.2c0-1.52 0-2.58-.1-3.4a3.1 3.1 0 0 0-.48-1.56 3 3 0 0 0-.66-.67 3.1 3.1 0 0 0-1.56-.48C13.37 3 12.3 3 10.79 3h-1.6c-1.52 0-2.59 0-3.4.09Zm11.18 10-.04-.05a26.24 26.24 0 0 0-1.83-1.74c-.45-.36-.73-.48-.97-.52a2 2 0 0 0-.63 0c-.24.04-.51.16-.97.52-.46.38-1.01.93-1.83 1.74l-.02.02c-.17.18-.34.34-.49.47a2.04 2.04 0 0 1-1.08.5 1.97 1.97 0 0 1-1.25-.27l-.79-.46-.02-.02a.65.65 0 0 0-.24-.1 1 1 0 0 0-.31 0c-.08.02-.21.06-.49.28-.3.24-.65.59-1.2 1.14l-.56.56-.65.66a3 3 0 0 0 .62.6c.33.24.77.4 1.57.49.81.09 1.88.09 3.4.09h1.6c1.52 0 2.58 0 3.4-.09a3.1 3.1 0 0 0 1.56-.48 3 3 0 0 0 .66-.67c.24-.32.4-.77.49-1.56l.07-1.12Zm-8.02-1.03ZM4.99 7a2 2 0 1 1 4 0 2 2 0 0 1-4 0Z"
    clip-rule="evenodd"
  />
</svg>`,Ew=B`<svg fill="none" viewBox="0 0 16 16">
  <path
    fill="currentColor"
    fill-rule="evenodd"
    d="M8 0a1 1 0 0 1 1 1v5.38a1 1 0 0 1-2 0V1a1 1 0 0 1 1-1ZM5.26 2.6a1 1 0 0 1-.28 1.39 5.46 5.46 0 1 0 6.04 0 1 1 0 1 1 1.1-1.67 7.46 7.46 0 1 1-8.25 0 1 1 0 0 1 1.4.28Z"
    clip-rule="evenodd"
  />
</svg>`,$w=B` <svg
  width="36"
  height="36"
  fill="none"
>
  <path
    d="M0 8a8 8 0 0 1 8-8h20a8 8 0 0 1 8 8v20a8 8 0 0 1-8 8H8a8 8 0 0 1-8-8V8Z"
    fill="#fff"
    fill-opacity=".05"
  />
  <path
    d="m18.262 17.513-8.944 9.49v.01a2.417 2.417 0 0 0 3.56 1.452l.026-.017 10.061-5.803-4.703-5.132Z"
    fill="#EA4335"
  />
  <path
    d="m27.307 15.9-.008-.008-4.342-2.52-4.896 4.36 4.913 4.912 4.325-2.494a2.42 2.42 0 0 0 .008-4.25Z"
    fill="#FBBC04"
  />
  <path
    d="M9.318 8.997c-.05.202-.084.403-.084.622V26.39c0 .218.025.42.084.621l9.246-9.247-9.246-8.768Z"
    fill="#4285F4"
  />
  <path
    d="m18.33 18 4.627-4.628-10.053-5.828a2.427 2.427 0 0 0-3.586 1.444L18.329 18Z"
    fill="#34A853"
  />
  <path
    d="M8 .5h20A7.5 7.5 0 0 1 35.5 8v20a7.5 7.5 0 0 1-7.5 7.5H8A7.5 7.5 0 0 1 .5 28V8A7.5 7.5 0 0 1 8 .5Z"
    stroke="#fff"
    stroke-opacity=".05"
  />
</svg>`,Aw=B`<svg fill="none" viewBox="0 0 20 20">
  <path
    fill="currentColor"
    d="M3 6a3 3 0 0 1 3-3h1a1 1 0 1 0 0-2H6a5 5 0 0 0-5 5v1a1 1 0 0 0 2 0V6ZM13 1a1 1 0 1 0 0 2h1a3 3 0 0 1 3 3v1a1 1 0 1 0 2 0V6a5 5 0 0 0-5-5h-1ZM3 13a1 1 0 1 0-2 0v1a5 5 0 0 0 5 5h1a1 1 0 1 0 0-2H6a3 3 0 0 1-3-3v-1ZM19 13a1 1 0 1 0-2 0v1a3 3 0 0 1-3 3h-1a1 1 0 1 0 0 2h1.01a5 5 0 0 0 5-5v-1ZM5.3 6.36c-.04.2-.04.43-.04.89s0 .7.05.89c.14.52.54.92 1.06 1.06.19.05.42.05.89.05.46 0 .7 0 .88-.05A1.5 1.5 0 0 0 9.2 8.14c.06-.2.06-.43.06-.89s0-.7-.06-.89A1.5 1.5 0 0 0 8.14 5.3c-.19-.05-.42-.05-.88-.05-.47 0-.7 0-.9.05a1.5 1.5 0 0 0-1.05 1.06ZM10.8 6.36c-.04.2-.04.43-.04.89s0 .7.05.89c.14.52.54.92 1.06 1.06.19.05.42.05.89.05.46 0 .7 0 .88-.05a1.5 1.5 0 0 0 1.06-1.06c.06-.2.06-.43.06-.89s0-.7-.06-.89a1.5 1.5 0 0 0-1.06-1.06c-.19-.05-.42-.05-.88-.05-.47 0-.7 0-.9.05a1.5 1.5 0 0 0-1.05 1.06ZM5.26 12.75c0-.46 0-.7.05-.89a1.5 1.5 0 0 1 1.06-1.06c.19-.05.42-.05.89-.05.46 0 .7 0 .88.05.52.14.93.54 1.06 1.06.06.2.06.43.06.89s0 .7-.06.89a1.5 1.5 0 0 1-1.06 1.06c-.19.05-.42.05-.88.05-.47 0-.7 0-.9-.05a1.5 1.5 0 0 1-1.05-1.06c-.05-.2-.05-.43-.05-.89ZM10.8 11.86c-.04.2-.04.43-.04.89s0 .7.05.89c.14.52.54.92 1.06 1.06.19.05.42.05.89.05.46 0 .7 0 .88-.05a1.5 1.5 0 0 0 1.06-1.06c.06-.2.06-.43.06-.89s0-.7-.06-.89a1.5 1.5 0 0 0-1.06-1.06c-.19-.05-.42-.05-.88-.05-.47 0-.7 0-.9.05a1.5 1.5 0 0 0-1.05 1.06Z"
  />
</svg>`,Sw=B`<svg fill="none" viewBox="0 0 14 16">
  <path
    fill="currentColor"
    fill-rule="evenodd"
    d="M3.94 1.04a1 1 0 0 1 .7 1.23l-.48 1.68a5.85 5.85 0 0 1 8.53 4.32 5.86 5.86 0 0 1-11.4 2.56 1 1 0 0 1 1.9-.57 3.86 3.86 0 1 0 1.83-4.5l1.87.53a1 1 0 0 1-.55 1.92l-4.1-1.15a1 1 0 0 1-.69-1.23l1.16-4.1a1 1 0 0 1 1.23-.7Z"
    clip-rule="evenodd"
  />
</svg>`,Iw=B`<svg fill="none" viewBox="0 0 20 20">
  <path
    fill="currentColor"
    fill-rule="evenodd"
    d="M9.36 4.21a5.14 5.14 0 1 0 0 10.29 5.14 5.14 0 0 0 0-10.29ZM1.64 9.36a7.71 7.71 0 1 1 14 4.47l2.52 2.5a1.29 1.29 0 1 1-1.82 1.83l-2.51-2.51A7.71 7.71 0 0 1 1.65 9.36Z"
    clip-rule="evenodd"
  />
</svg>`,Rw=B`<svg fill="none" viewBox="0 0 21 20">
  <path
    fill="currentColor"
    fill-rule="evenodd"
    d="M14.3808 4.34812C13.72 4.47798 12.8501 4.7587 11.5748 5.17296L9.00869 6.00646C6.90631 6.68935 5.40679 7.17779 4.38121 7.63178C3.87166 7.85734 3.5351 8.05091 3.32022 8.22035C3.11183 8.38466 3.07011 8.48486 3.05969 8.51817C2.98058 8.77103 2.98009 9.04195 3.05831 9.29509C3.06861 9.32844 3.10998 9.42878 3.31777 9.59384C3.53205 9.76404 3.86792 9.95881 4.37667 10.1862C5.29287 10.5957 6.58844 11.0341 8.35529 11.6164L10.8876 8.59854C11.2426 8.17547 11.8733 8.12028 12.2964 8.47528C12.7195 8.83029 12.7746 9.46104 12.4196 9.88412L9.88738 12.9019C10.7676 14.5408 11.4244 15.7406 11.9867 16.5718C12.299 17.0333 12.5491 17.3303 12.7539 17.5117C12.9526 17.6877 13.0586 17.711 13.0932 17.7154C13.3561 17.7484 13.6228 17.7009 13.8581 17.5791C13.8891 17.563 13.9805 17.5046 14.1061 17.2708C14.2357 17.0298 14.3679 16.6647 14.5015 16.1237C14.7705 15.0349 14.9912 13.4733 15.2986 11.2843L15.6738 8.61249C15.8603 7.28456 15.9857 6.37917 15.9989 5.7059C16.012 5.03702 15.9047 4.8056 15.8145 4.69183C15.7044 4.55297 15.5673 4.43792 15.4114 4.35365C15.2837 4.28459 15.0372 4.2191 14.3808 4.34812ZM7.99373 13.603C6.11919 12.9864 4.6304 12.4902 3.5606 12.0121C2.98683 11.7557 2.4778 11.4808 2.07383 11.1599C1.66337 10.8339 1.31312 10.4217 1.14744 9.88551C0.949667 9.24541 0.950886 8.56035 1.15094 7.92096C1.31852 7.38534 1.67024 6.97442 2.08185 6.64985C2.48697 6.33041 2.99697 6.05734 3.57166 5.80295C4.70309 5.3021 6.30179 4.78283 8.32903 4.12437L11.0196 3.25042C12.2166 2.86159 13.2017 2.54158 13.9951 2.38566C14.8065 2.22618 15.6202 2.19289 16.3627 2.59437C16.7568 2.80747 17.1035 3.09839 17.3818 3.4495C17.9062 4.111 18.0147 4.91815 17.9985 5.74496C17.9827 6.55332 17.8386 7.57903 17.6636 8.82534L17.2701 11.6268C16.9737 13.7376 16.7399 15.4022 16.4432 16.6034C16.2924 17.2135 16.1121 17.7632 15.8678 18.2176C15.6197 18.6794 15.2761 19.0971 14.7777 19.3551C14.1827 19.6632 13.5083 19.7833 12.8436 19.6997C12.2867 19.6297 11.82 19.3563 11.4277 19.0087C11.0415 18.6666 10.6824 18.213 10.3302 17.6925C9.67361 16.722 8.92648 15.342 7.99373 13.603Z"
    clip-rule="evenodd"
  />
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width="21"
    height="20"
    viewBox="0 0 21 20"
    fill="none"
  ></svg></svg
>`,Tw=B`<svg fill="none" viewBox="0 0 20 20">
  <path
    fill="currentColor"
    fill-rule="evenodd"
    d="M6.76.3a1 1 0 0 1 0 1.4L4.07 4.4h9a1 1 0 1 1 0 2h-9l2.69 2.68a1 1 0 1 1-1.42 1.42L.95 6.09a1 1 0 0 1 0-1.4l4.4-4.4a1 1 0 0 1 1.4 0Zm6.49 9.21a1 1 0 0 1 1.41 0l4.39 4.4a1 1 0 0 1 0 1.4l-4.39 4.4a1 1 0 0 1-1.41-1.42l2.68-2.68h-9a1 1 0 0 1 0-2h9l-2.68-2.68a1 1 0 0 1 0-1.42Z"
    clip-rule="evenodd"
  />
</svg>`,Pw=B`<svg width="10" height="10" viewBox="0 0 10 10">
  <path
    fill="currentColor"
    fill-rule="evenodd"
    d="M3.77986 0.566631C4.0589 0.845577 4.0589 1.29784 3.77986 1.57678L3.08261 2.2738H6.34184C6.73647 2.2738 7.05637 2.5936 7.05637 2.98808C7.05637 3.38257 6.73647 3.70237 6.34184 3.70237H3.08261L3.77986 4.39938C4.0589 4.67833 4.0589 5.13059 3.77986 5.40954C3.50082 5.68848 3.04841 5.68848 2.76937 5.40954L0.852346 3.49316C0.573306 3.21421 0.573306 2.76195 0.852346 2.48301L2.76937 0.566631C3.04841 0.287685 3.50082 0.287685 3.77986 0.566631ZM6.22 4.59102C6.49904 4.31208 6.95145 4.31208 7.23049 4.59102L9.14751 6.5074C9.42655 6.78634 9.42655 7.23861 9.14751 7.51755L7.23049 9.43393C6.95145 9.71287 6.49904 9.71287 6.22 9.43393C5.94096 9.15498 5.94096 8.70272 6.22 8.42377L6.91725 7.72676L3.65802 7.72676C3.26339 7.72676 2.94349 7.40696 2.94349 7.01247C2.94349 6.61798 3.26339 6.29819 3.65802 6.29819L6.91725 6.29819L6.22 5.60117C5.94096 5.32223 5.94096 4.86997 6.22 4.59102Z"
    clip-rule="evenodd"
  />
</svg>`,Ow=B`<svg
  width="14"
  height="14"
  viewBox="0 0 14 14"
  fill="none"
  xmlns="http://www.w3.org/2000/svg"
>
  <path
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M13.7306 3.24213C14.0725 3.58384 14.0725 4.13786 13.7306 4.47957L10.7418 7.46737C10.4 7.80908 9.84581 7.80908 9.50399 7.46737C9.16216 7.12567 9.16216 6.57165 9.50399 6.22994L10.9986 4.73585H5.34082C4.85741 4.73585 4.46553 4.3441 4.46553 3.86085C4.46553 3.3776 4.85741 2.98585 5.34082 2.98585L10.9986 2.98585L9.50399 1.49177C9.16216 1.15006 9.16216 0.596037 9.50399 0.254328C9.84581 -0.0873803 10.4 -0.0873803 10.7418 0.254328L13.7306 3.24213ZM9.52515 10.1352C9.52515 10.6185 9.13327 11.0102 8.64986 11.0102L2.9921 11.0102L4.48669 12.5043C4.82852 12.846 4.82852 13.4001 4.48669 13.7418C4.14487 14.0835 3.59066 14.0835 3.24884 13.7418L0.26003 10.754C0.0958806 10.5899 0.0036621 10.3673 0.00366211 10.1352C0.00366212 9.90318 0.0958806 9.68062 0.26003 9.51652L3.24884 6.52872C3.59066 6.18701 4.14487 6.18701 4.48669 6.52872C4.82851 6.87043 4.82851 7.42445 4.48669 7.76616L2.9921 9.26024L8.64986 9.26024C9.13327 9.26024 9.52515 9.65199 9.52515 10.1352Z"
    fill="currentColor"
  />
</svg>

`,kw=B`<svg fill="none" viewBox="0 0 14 14">
  <path
    fill="currentColor"
    fill-rule="evenodd"
    d="M3.48 2.18a1 1 0 0 1 1.41 0l2.68 2.68a1 1 0 1 1-1.41 1.42l-.98-.98v4.56a1 1 0 0 1-2 0V5.3l-.97.98A1 1 0 0 1 .79 4.86l2.69-2.68Zm6.34 2.93a1 1 0 0 1 1 1v4.56l.97-.98a1 1 0 1 1 1.42 1.42l-2.69 2.68a1 1 0 0 1-1.41 0l-2.68-2.68a1 1 0 0 1 1.41-1.42l.98.98V6.1a1 1 0 0 1 1-1Z"
    clip-rule="evenodd"
  />
</svg>`,Nw=B`<svg fill="none" viewBox="0 0 40 40">
  <g clip-path="url(#a)">
    <g clip-path="url(#b)">
      <circle cx="20" cy="19.89" r="20" fill="#5865F2" />
      <path
        fill="#fff"
        fill-rule="evenodd"
        d="M25.71 28.15C30.25 28 32 25.02 32 25.02c0-6.61-2.96-11.98-2.96-11.98-2.96-2.22-5.77-2.15-5.77-2.15l-.29.32c3.5 1.07 5.12 2.61 5.12 2.61a16.75 16.75 0 0 0-10.34-1.93l-.35.04a15.43 15.43 0 0 0-5.88 1.9s1.71-1.63 5.4-2.7l-.2-.24s-2.81-.07-5.77 2.15c0 0-2.96 5.37-2.96 11.98 0 0 1.73 2.98 6.27 3.13l1.37-1.7c-2.6-.79-3.6-2.43-3.6-2.43l.58.35.09.06.08.04.02.01.08.05a17.25 17.25 0 0 0 4.52 1.58 14.4 14.4 0 0 0 8.3-.86c.72-.27 1.52-.66 2.37-1.21 0 0-1.03 1.68-3.72 2.44.61.78 1.35 1.67 1.35 1.67Zm-9.55-9.6c-1.17 0-2.1 1.03-2.1 2.28 0 1.25.95 2.28 2.1 2.28 1.17 0 2.1-1.03 2.1-2.28.01-1.25-.93-2.28-2.1-2.28Zm7.5 0c-1.17 0-2.1 1.03-2.1 2.28 0 1.25.95 2.28 2.1 2.28 1.17 0 2.1-1.03 2.1-2.28 0-1.25-.93-2.28-2.1-2.28Z"
        clip-rule="evenodd"
      />
    </g>
  </g>
  <defs>
    <clipPath id="a"><rect width="40" height="40" fill="#fff" rx="20" /></clipPath>
    <clipPath id="b"><path fill="#fff" d="M0 0h40v40H0z" /></clipPath>
  </defs>
</svg> `,Mw=B`<svg fill="none" viewBox="0 0 40 40">
  <g clip-path="url(#a)">
    <g clip-path="url(#b)">
      <circle cx="20" cy="19.89" r="20" fill="#5A3E85" />
      <g clip-path="url(#c)">
        <path
          fill="#fff"
          d="M18.22 25.7 20 23.91h3.34l2.1-2.1v-6.68H15.4v8.78h2.82v1.77Zm3.87-8.16h1.25v3.66H22.1v-3.66Zm-3.34 0H20v3.66h-1.25v-3.66ZM20 7.9a12 12 0 1 0 0 24 12 12 0 0 0 0-24Zm6.69 14.56-3.66 3.66h-2.72l-1.77 1.78h-1.88V26.1H13.3v-9.82l.94-2.4H26.7v8.56Z"
        />
      </g>
    </g>
  </g>
  <defs>
    <clipPath id="a"><rect width="40" height="40" fill="#fff" rx="20" /></clipPath>
    <clipPath id="b"><path fill="#fff" d="M0 0h40v40H0z" /></clipPath>
    <clipPath id="c"><path fill="#fff" d="M8 7.89h24v24H8z" /></clipPath>
  </defs>
</svg>`,Lw=B`<svg fill="none" viewBox="0 0 40 40">
  <g clip-path="url(#a)">
    <g clip-path="url(#b)">
      <circle cx="20" cy="19.89" r="20" fill="#1D9BF0" />
      <path
        fill="#fff"
        d="M30 13.81c-.74.33-1.53.55-2.36.65.85-.51 1.5-1.32 1.8-2.27-.79.47-1.66.8-2.6 1a4.1 4.1 0 0 0-7 3.73c-3.4-.17-6.42-1.8-8.45-4.28a4.1 4.1 0 0 0 1.27 5.47c-.67-.02-1.3-.2-1.86-.5a4.1 4.1 0 0 0 3.3 4.07c-.58.15-1.21.19-1.86.07a4.1 4.1 0 0 0 3.83 2.85A8.25 8.25 0 0 1 10 26.3a11.62 11.62 0 0 0 6.29 1.84c7.62 0 11.92-6.44 11.66-12.2.8-.59 1.5-1.3 2.05-2.13Z"
      />
    </g>
  </g>
  <defs>
    <clipPath id="a"><rect width="40" height="40" fill="#fff" rx="20" /></clipPath>
    <clipPath id="b"><path fill="#fff" d="M0 0h40v40H0z" /></clipPath>
  </defs>
</svg>`,Bw=B`<svg fill="none" viewBox="0 0 16 16">
  <path
    fill="currentColor"
    d="m14.36 4.74.01.42c0 4.34-3.3 9.34-9.34 9.34A9.3 9.3 0 0 1 0 13.03a6.6 6.6 0 0 0 4.86-1.36 3.29 3.29 0 0 1-3.07-2.28c.5.1 1 .07 1.48-.06A3.28 3.28 0 0 1 .64 6.11v-.04c.46.26.97.4 1.49.41A3.29 3.29 0 0 1 1.11 2.1a9.32 9.32 0 0 0 6.77 3.43 3.28 3.28 0 0 1 5.6-3 6.59 6.59 0 0 0 2.08-.8 3.3 3.3 0 0 1-1.45 1.82A6.53 6.53 0 0 0 16 3.04c-.44.66-1 1.23-1.64 1.7Z"
  />
</svg>`,jw=B`<svg fill="none" viewBox="0 0 28 28">
  <path
    fill="currentColor"
    fill-rule="evenodd"
    d="M18.1 4.76c-.42-.73-1.33-1.01-2.09-.66l-1.42.66c-.37.18-.8.18-1.18 0l-1.4-.65a1.63 1.63 0 0 0-2.1.66l-.84 1.45c-.2.34-.53.59-.92.67l-1.7.35c-.83.17-1.39.94-1.3 1.78l.19 1.56c.04.39-.08.78-.33 1.07l-1.12 1.3c-.52.6-.52 1.5 0 2.11L5 16.38c.25.3.37.68.33 1.06l-.18 1.57c-.1.83.46 1.6 1.28 1.78l1.7.35c.4.08.73.32.93.66l.84 1.43a1.63 1.63 0 0 0 2.09.66l1.41-.66c.37-.17.8-.17 1.18 0l1.43.67c.76.35 1.66.07 2.08-.65l.86-1.45c.2-.34.54-.58.92-.66l1.68-.35A1.63 1.63 0 0 0 22.84 19l-.18-1.57a1.4 1.4 0 0 1 .33-1.06l1.12-1.32c.52-.6.52-1.5 0-2.11l-1.12-1.3a1.4 1.4 0 0 1-.33-1.07l.18-1.57c.1-.83-.46-1.6-1.28-1.77l-1.68-.35a1.4 1.4 0 0 1-.92-.66l-.86-1.47Zm-3.27-3.2a4.43 4.43 0 0 1 5.69 1.78l.54.93 1.07.22a4.43 4.43 0 0 1 3.5 4.84l-.11.96.7.83a4.43 4.43 0 0 1 .02 5.76l-.72.85.1.96a4.43 4.43 0 0 1-3.5 4.84l-1.06.22-.54.92a4.43 4.43 0 0 1-5.68 1.77l-.84-.4-.82.39a4.43 4.43 0 0 1-5.7-1.79l-.51-.89-1.09-.22a4.43 4.43 0 0 1-3.5-4.84l.1-.96-.72-.85a4.43 4.43 0 0 1 .01-5.76l.71-.83-.1-.95a4.43 4.43 0 0 1 3.5-4.84l1.08-.23.53-.9a4.43 4.43 0 0 1 5.7-1.8l.81.38.83-.39ZM18.2 9.4c.65.42.84 1.28.42 1.93l-4.4 6.87a1.4 1.4 0 0 1-2.26.14L9.5 15.39a1.4 1.4 0 0 1 2.15-1.8l1.23 1.48 3.38-5.26a1.4 1.4 0 0 1 1.93-.42Z"
    clip-rule="evenodd"
  />
</svg>`,Dw=B`<svg fill="none" viewBox="0 0 14 14">
  <path
    fill="currentColor"
    fill-rule="evenodd"
    d="m4.1 12.43-.45-.78-.93-.2a1.65 1.65 0 0 1-1.31-1.8l.1-.86-.61-.71a1.65 1.65 0 0 1 0-2.16l.6-.7-.09-.85c-.1-.86.47-1.64 1.3-1.81l.94-.2.45-.78A1.65 1.65 0 0 1 6.23.9l.77.36.78-.36c.77-.36 1.69-.07 2.12.66l.47.8.91.2c.84.17 1.4.95 1.31 1.8l-.1.86.6.7c.54.62.54 1.54.01 2.16l-.6.71.09.86c.1.85-.47 1.63-1.3 1.8l-.92.2-.47.79a1.65 1.65 0 0 1-2.12.66L7 12.74l-.77.36c-.78.35-1.7.07-2.13-.67Zm5.74-6.9a1 1 0 1 0-1.68-1.07L6.32 7.3l-.55-.66a1 1 0 0 0-1.54 1.28l1.43 1.71a1 1 0 0 0 1.61-.1l2.57-4Z"
    clip-rule="evenodd"
  />
</svg>`,Uw=B`
  <svg fill="none" viewBox="0 0 48 44">
    <path
      style="fill: var(--wui-color-bg-300);"
      d="M4.56 8.64c-1.23 1.68-1.23 4.08-1.23 8.88v8.96c0 4.8 0 7.2 1.23 8.88.39.55.87 1.02 1.41 1.42C7.65 38 10.05 38 14.85 38h14.3c4.8 0 7.2 0 8.88-1.22a6.4 6.4 0 0 0 1.41-1.42c.83-1.14 1.1-2.6 1.19-4.92a6.4 6.4 0 0 0 5.16-4.65c.21-.81.21-1.8.21-3.79 0-1.98 0-2.98-.22-3.79a6.4 6.4 0 0 0-5.15-4.65c-.1-2.32-.36-3.78-1.19-4.92a6.4 6.4 0 0 0-1.41-1.42C36.35 6 33.95 6 29.15 6h-14.3c-4.8 0-7.2 0-8.88 1.22a6.4 6.4 0 0 0-1.41 1.42Z"
    />
    <path
      style="fill: var(--wui-color-fg-200);"
      fill-rule="evenodd"
      d="M2.27 11.33a6.4 6.4 0 0 1 6.4-6.4h26.66a6.4 6.4 0 0 1 6.4 6.4v1.7a6.4 6.4 0 0 1 5.34 6.3v5.34a6.4 6.4 0 0 1-5.34 6.3v1.7a6.4 6.4 0 0 1-6.4 6.4H8.67a6.4 6.4 0 0 1-6.4-6.4V11.33ZM39.6 31.07h-6.93a9.07 9.07 0 1 1 0-18.14h6.93v-1.6a4.27 4.27 0 0 0-4.27-4.26H8.67a4.27 4.27 0 0 0-4.27 4.26v21.34a4.27 4.27 0 0 0 4.27 4.26h26.66a4.27 4.27 0 0 0 4.27-4.26v-1.6Zm-6.93-16a6.93 6.93 0 0 0 0 13.86h8a4.27 4.27 0 0 0 4.26-4.26v-5.34a4.27 4.27 0 0 0-4.26-4.26h-8Z"
      clip-rule="evenodd"
    />
  </svg>
`,Ww=B`<svg fill="none" viewBox="0 0 20 20">
  <path
    fill="currentColor"
    fill-rule="evenodd"
    d="M0 5.5c0-1.8 1.46-3.25 3.25-3.25H14.5c1.8 0 3.25 1.46 3.25 3.25v.28A3.25 3.25 0 0 1 20 8.88v2.24c0 1.45-.94 2.68-2.25 3.1v.28c0 1.8-1.46 3.25-3.25 3.25H3.25A3.25 3.25 0 0 1 0 14.5v-9Zm15.75 8.88h-2.38a4.38 4.38 0 0 1 0-8.76h2.38V5.5c0-.69-.56-1.25-1.25-1.25H3.25C2.56 4.25 2 4.81 2 5.5v9c0 .69.56 1.25 1.25 1.25H14.5c.69 0 1.25-.56 1.25-1.25v-.13Zm-2.38-6.76a2.37 2.37 0 1 0 0 4.75h3.38c.69 0 1.25-.55 1.25-1.24V8.87c0-.69-.56-1.24-1.25-1.24h-3.38Z"
    clip-rule="evenodd"
  />
</svg>`,zw=B`<svg fill="none" viewBox="0 0 96 67">
  <path
    fill="currentColor"
    d="M25.32 18.8a32.56 32.56 0 0 1 45.36 0l1.5 1.47c.63.62.63 1.61 0 2.22l-5.15 5.05c-.31.3-.82.3-1.14 0l-2.07-2.03a22.71 22.71 0 0 0-31.64 0l-2.22 2.18c-.31.3-.82.3-1.14 0l-5.15-5.05a1.55 1.55 0 0 1 0-2.22l1.65-1.62Zm56.02 10.44 4.59 4.5c.63.6.63 1.6 0 2.21l-20.7 20.26c-.62.61-1.63.61-2.26 0L48.28 41.83a.4.4 0 0 0-.56 0L33.03 56.21c-.63.61-1.64.61-2.27 0L10.07 35.95a1.55 1.55 0 0 1 0-2.22l4.59-4.5a1.63 1.63 0 0 1 2.27 0L31.6 43.63a.4.4 0 0 0 .57 0l14.69-14.38a1.63 1.63 0 0 1 2.26 0l14.69 14.38a.4.4 0 0 0 .57 0l14.68-14.38a1.63 1.63 0 0 1 2.27 0Z"
  />
  <path
    stroke="#000"
    stroke-opacity=".1"
    d="M25.67 19.15a32.06 32.06 0 0 1 44.66 0l1.5 1.48c.43.42.43 1.09 0 1.5l-5.15 5.05a.31.31 0 0 1-.44 0l-2.07-2.03a23.21 23.21 0 0 0-32.34 0l-2.22 2.18a.31.31 0 0 1-.44 0l-5.15-5.05a1.05 1.05 0 0 1 0-1.5l1.65-1.63ZM81 29.6l4.6 4.5c.42.41.42 1.09 0 1.5l-20.7 20.26c-.43.43-1.14.43-1.57 0L48.63 41.47a.9.9 0 0 0-1.26 0L32.68 55.85c-.43.43-1.14.43-1.57 0L10.42 35.6a1.05 1.05 0 0 1 0-1.5l4.59-4.5a1.13 1.13 0 0 1 1.57 0l14.68 14.38a.9.9 0 0 0 1.27 0l-.35-.35.35.35L47.22 29.6a1.13 1.13 0 0 1 1.56 0l14.7 14.38a.9.9 0 0 0 1.26 0L79.42 29.6a1.13 1.13 0 0 1 1.57 0Z"
  />
</svg>`,Fw=B`<svg fill="none" viewBox="0 0 20 20">
  <path
    fill="currentColor"
    d="M11 6.67a1 1 0 1 0-2 0v2.66a1 1 0 0 0 2 0V6.67ZM10 14.5a1.25 1.25 0 1 0 0-2.5 1.25 1.25 0 0 0 0 2.5Z"
  />
  <path
    fill="currentColor"
    fill-rule="evenodd"
    d="M10 1a9 9 0 1 0 0 18 9 9 0 0 0 0-18Zm-7 9a7 7 0 1 1 14 0 7 7 0 0 1-14 0Z"
    clip-rule="evenodd"
  />
</svg>`,Hw=B`<svg
  fill="none"
  viewBox="0 0 21 20"
>
  <path
    fill="currentColor"
    d="M8.8071 0.292893C9.19763 0.683417 9.19763 1.31658 8.8071 1.70711L6.91421 3.6H11.8404C14.3368 3.6 16.5533 5.1975 17.3427 7.56588L17.4487 7.88377C17.6233 8.40772 17.3402 8.97404 16.8162 9.14868C16.2923 9.32333 15.726 9.04017 15.5513 8.51623L15.4453 8.19834C14.9281 6.64664 13.476 5.6 11.8404 5.6H6.91421L8.8071 7.49289C9.19763 7.88342 9.19763 8.51658 8.8071 8.90711C8.41658 9.29763 7.78341 9.29763 7.39289 8.90711L3.79289 5.30711C3.40236 4.91658 3.40236 4.28342 3.79289 3.89289L7.39289 0.292893C7.78341 -0.0976311 8.41658 -0.0976311 8.8071 0.292893ZM4.18377 10.8513C4.70771 10.6767 5.27403 10.9598 5.44868 11.4838L5.55464 11.8017C6.07188 13.3534 7.52401 14.4 9.15964 14.4L14.0858 14.4L12.1929 12.5071C11.8024 12.1166 11.8024 11.4834 12.1929 11.0929C12.5834 10.7024 13.2166 10.7024 13.6071 11.0929L17.2071 14.6929C17.5976 15.0834 17.5976 15.7166 17.2071 16.1071L13.6071 19.7071C13.2166 20.0976 12.5834 20.0976 12.1929 19.7071C11.8024 19.3166 11.8024 18.6834 12.1929 18.2929L14.0858 16.4L9.15964 16.4C6.66314 16.4 4.44674 14.8025 3.65728 12.4341L3.55131 12.1162C3.37667 11.5923 3.65983 11.026 4.18377 10.8513Z"
  /></svg
>`,Vw=B`<svg
  xmlns="http://www.w3.org/2000/svg"
  width="12"
  height="13"
  viewBox="0 0 12 13"
  fill="none"
>
  <path
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M5.61391 1.57124C5.85142 1.42873 6.14813 1.42873 6.38564 1.57124L11.0793 4.38749C11.9179 4.89067 11.5612 6.17864 10.5832 6.17864H9.96398V10.0358H10.2854C10.6996 10.0358 11.0354 10.3716 11.0354 10.7858C11.0354 11.2 10.6996 11.5358 10.2854 11.5358H1.71416C1.29995 11.5358 0.964172 11.2 0.964172 10.7858C0.964172 10.3716 1.29995 10.0358 1.71416 10.0358H2.03558L2.03558 6.17864H1.41637C0.438389 6.17864 0.0816547 4.89066 0.920263 4.38749L5.61391 1.57124ZM3.53554 6.17864V10.0358H5.24979V6.17864H3.53554ZM6.74976 6.17864V10.0358H8.46401V6.17864H6.74976ZM8.64913 4.67864H3.35043L5.99978 3.089L8.64913 4.67864Z"
    fill="currentColor"
  /></svg
>`,Zw=B`<svg
  xmlns="http://www.w3.org/2000/svg"
  width="12"
  height="13"
  viewBox="0 0 12 13"
  fill="none"
>
  <path
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M4.16072 2C4.17367 2 4.18665 2 4.19968 2L7.83857 2C8.36772 1.99998 8.82398 1.99996 9.19518 2.04018C9.5895 2.0829 9.97577 2.17811 10.3221 2.42971C10.5131 2.56849 10.6811 2.73647 10.8198 2.92749C11.0714 3.27379 11.1666 3.66007 11.2094 4.0544C11.2496 4.42561 11.2496 4.88188 11.2495 5.41105V7.58896C11.2496 8.11812 11.2496 8.57439 11.2094 8.94561C11.1666 9.33994 11.0714 9.72621 10.8198 10.0725C10.6811 10.2635 10.5131 10.4315 10.3221 10.5703C9.97577 10.8219 9.5895 10.9171 9.19518 10.9598C8.82398 11 8.36772 11 7.83856 11H4.16073C3.63157 11 3.17531 11 2.80411 10.9598C2.40979 10.9171 2.02352 10.8219 1.67722 10.5703C1.48621 10.4315 1.31824 10.2635 1.17946 10.0725C0.927858 9.72621 0.832652 9.33994 0.78993 8.94561C0.749713 8.5744 0.749733 8.11813 0.749757 7.58896L0.749758 5.45C0.749758 5.43697 0.749758 5.42399 0.749757 5.41104C0.749733 4.88188 0.749713 4.42561 0.78993 4.0544C0.832652 3.66007 0.927858 3.27379 1.17946 2.92749C1.31824 2.73647 1.48621 2.56849 1.67722 2.42971C2.02352 2.17811 2.40979 2.0829 2.80411 2.04018C3.17531 1.99996 3.63157 1.99998 4.16072 2ZM2.96567 3.53145C2.69897 3.56034 2.60687 3.60837 2.55888 3.64324C2.49521 3.6895 2.43922 3.74549 2.39296 3.80916C2.35809 3.85715 2.31007 3.94926 2.28117 4.21597C2.26629 4.35335 2.25844 4.51311 2.25431 4.70832H9.74498C9.74085 4.51311 9.733 4.35335 9.71812 4.21597C9.68922 3.94926 9.6412 3.85715 9.60633 3.80916C9.56007 3.74549 9.50408 3.6895 9.44041 3.64324C9.39242 3.60837 9.30031 3.56034 9.03362 3.53145C8.75288 3.50103 8.37876 3.5 7.79961 3.5H4.19968C3.62053 3.5 3.24641 3.50103 2.96567 3.53145ZM9.74956 6.20832H2.24973V7.55C2.24973 8.12917 2.25076 8.5033 2.28117 8.78404C2.31007 9.05074 2.35809 9.14285 2.39296 9.19084C2.43922 9.25451 2.49521 9.31051 2.55888 9.35677C2.60687 9.39163 2.69897 9.43966 2.96567 9.46856C3.24641 9.49897 3.62053 9.5 4.19968 9.5H7.79961C8.37876 9.5 8.75288 9.49897 9.03362 9.46856C9.30032 9.43966 9.39242 9.39163 9.44041 9.35677C9.50408 9.31051 9.56007 9.25451 9.60633 9.19084C9.6412 9.14285 9.68922 9.05075 9.71812 8.78404C9.74854 8.5033 9.74956 8.12917 9.74956 7.55V6.20832ZM6.74963 8C6.74963 7.58579 7.08541 7.25 7.49961 7.25H8.2496C8.6638 7.25 8.99958 7.58579 8.99958 8C8.99958 8.41422 8.6638 8.75 8.2496 8.75H7.49961C7.08541 8.75 6.74963 8.41422 6.74963 8Z"
    fill="currentColor"
  /></svg
>`,qw=B`<svg
  width="13"
  height="12"
  viewBox="0 0 13 12"
  fill="none"
>
  <path
    fill="currentColor"
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M0.794373 5.99982C0.794373 5.52643 1.17812 5.14268 1.6515 5.14268H5.643V1.15109C5.643 0.677701 6.02675 0.293946 6.50012 0.293945C6.9735 0.293946 7.35725 0.677701 7.35725 1.15109V5.14268H11.3488C11.8221 5.14268 12.2059 5.52643 12.2059 5.99982C12.2059 6.47321 11.8221 6.85696 11.3488 6.85696H7.35725V10.8486C7.35725 11.3219 6.9735 11.7057 6.50012 11.7057C6.02675 11.7057 5.643 11.3219 5.643 10.8486V6.85696H1.6515C1.17812 6.85696 0.794373 6.47321 0.794373 5.99982Z"
  /></svg
>`;var Ia=function(n,e,t,i){var o=arguments.length,r=o<3?e:i===null?i=Object.getOwnPropertyDescriptor(e,t):i,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")r=Reflect.decorate(n,e,t,i);else for(var a=n.length-1;a>=0;a--)(s=n[a])&&(r=(o<3?s(r):o>3?s(e,t,r):s(e,t))||r);return o>3&&r&&Object.defineProperty(e,t,r),r};const Gw={add:sw,allWallets:Um,arrowBottomCircle:Wm,appStore:zm,apple:Fm,arrowBottom:Hm,arrowLeft:Vm,arrowRight:Zm,arrowTop:qm,bank:Vw,browser:Gm,card:Zw,checkmark:Ym,chevronBottom:Km,chevronLeft:Jm,chevronRight:Qm,chevronTop:Xm,chromeStore:ew,clock:tw,close:nw,compass:rw,coinPlaceholder:iw,copy:ow,cursor:aw,desktop:cw,disconnect:lw,discord:uw,etherscan:dw,extension:hw,externalLink:pw,facebook:fw,filters:gw,github:mw,google:ww,helpCircle:bw,infoCircle:vw,mail:yw,mobile:xw,networkPlaceholder:Cw,nftPlaceholder:_w,off:Ew,playStore:$w,plus:qw,qrCode:Aw,recycleHorizontal:Hw,refresh:Sw,search:Iw,send:Rw,swapHorizontal:Tw,swapHorizontalMedium:Ow,swapHorizontalBold:Pw,swapVertical:kw,telegram:Nw,twitch:Mw,twitter:Lw,twitterIcon:Bw,verify:jw,verifyFilled:Dw,wallet:Ww,walletConnect:zw,walletPlaceholder:Uw,warningCircle:Fw};let Ci=class extends q{constructor(){super(...arguments),this.size="md",this.name="copy",this.color="fg-300"}render(){return this.style.cssText=`
      --local-color: ${`var(--wui-color-${this.color});`}
      --local-width: ${`var(--wui-icon-size-${this.size});`}
    `,P`${Gw[this.name]}`}};Ci.styles=[Q,Dl,Dm];Ia([v()],Ci.prototype,"size",void 0);Ia([v()],Ci.prototype,"name",void 0);Ia([v()],Ci.prototype,"color",void 0);Ci=Ia([k("wui-icon")],Ci);const Yw=Z`
  :host {
    display: block;
    width: 100%;
    height: 100%;
  }

  img {
    display: block;
    width: 100%;
    height: 100%;
    object-fit: cover;
    object-position: center center;
    border-radius: inherit;
  }
`;var Ul=function(n,e,t,i){var o=arguments.length,r=o<3?e:i===null?i=Object.getOwnPropertyDescriptor(e,t):i,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")r=Reflect.decorate(n,e,t,i);else for(var a=n.length-1;a>=0;a--)(s=n[a])&&(r=(o<3?s(r):o>3?s(e,t,r):s(e,t))||r);return o>3&&r&&Object.defineProperty(e,t,r),r};let br=class extends q{constructor(){super(...arguments),this.src="./path/to/image.jpg",this.alt="Image"}render(){return P`<img src=${this.src} alt=${this.alt} />`}};br.styles=[Q,Dl,Yw];Ul([v()],br.prototype,"src",void 0);Ul([v()],br.prototype,"alt",void 0);br=Ul([k("wui-image")],br);const Kw=Z`
  :host {
    display: block;
    width: var(--wui-box-size-lg);
    height: var(--wui-box-size-lg);
  }

  svg {
    width: var(--wui-box-size-lg);
    height: var(--wui-box-size-lg);
    fill: none;
    stroke: transparent;
    stroke-linecap: round;
    transition: all var(--wui-ease-in-power-3) var(--wui-duration-lg);
  }

  use {
    stroke: var(--wui-color-accent-100);
    stroke-width: 2px;
    stroke-dasharray: 54, 118;
    stroke-dashoffset: 172;
    animation: dash 1s linear infinite;
  }

  @keyframes dash {
    to {
      stroke-dashoffset: 0px;
    }
  }
`;var Jw=function(n,e,t,i){var o=arguments.length,r=o<3?e:i===null?i=Object.getOwnPropertyDescriptor(e,t):i,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")r=Reflect.decorate(n,e,t,i);else for(var a=n.length-1;a>=0;a--)(s=n[a])&&(r=(o<3?s(r):o>3?s(e,t,r):s(e,t))||r);return o>3&&r&&Object.defineProperty(e,t,r),r};let Hs=class extends q{render(){return P`
      <svg viewBox="0 0 54 59">
        <path
          id="wui-loader-path"
          d="M17.22 5.295c3.877-2.277 5.737-3.363 7.72-3.726a11.44 11.44 0 0 1 4.12 0c1.983.363 3.844 1.45 7.72 3.726l6.065 3.562c3.876 2.276 5.731 3.372 7.032 4.938a11.896 11.896 0 0 1 2.06 3.63c.683 1.928.688 4.11.688 8.663v7.124c0 4.553-.005 6.735-.688 8.664a11.896 11.896 0 0 1-2.06 3.63c-1.3 1.565-3.156 2.66-7.032 4.937l-6.065 3.563c-3.877 2.276-5.737 3.362-7.72 3.725a11.46 11.46 0 0 1-4.12 0c-1.983-.363-3.844-1.449-7.72-3.726l-6.065-3.562c-3.876-2.276-5.731-3.372-7.032-4.938a11.885 11.885 0 0 1-2.06-3.63c-.682-1.928-.688-4.11-.688-8.663v-7.124c0-4.553.006-6.735.688-8.664a11.885 11.885 0 0 1 2.06-3.63c1.3-1.565 3.156-2.66 7.032-4.937l6.065-3.562Z"
        />
        <use xlink:href="#wui-loader-path"></use>
      </svg>
    `}};Hs.styles=[Q,Kw];Hs=Jw([k("wui-loading-hexagon")],Hs);const Qw=Z`
  :host {
    display: flex;
  }

  :host([data-size='sm']) > svg {
    width: 12px;
    height: 12px;
  }

  :host([data-size='md']) > svg {
    width: 16px;
    height: 16px;
  }

  :host([data-size='lg']) > svg {
    width: 24px;
    height: 24px;
  }

  :host([data-size='xl']) > svg {
    width: 32px;
    height: 32px;
  }

  svg {
    animation: rotate 2s linear infinite;
    transition: all var(--wui-ease-in-power-3) var(--wui-duration-lg);
  }

  circle {
    fill: none;
    stroke: var(--local-color);
    stroke-width: 4px;
    stroke-dasharray: 1, 124;
    stroke-dashoffset: 0;
    stroke-linecap: round;
    animation: dash 1.5s ease-in-out infinite;
  }

  :host([data-size='md']) > svg > circle {
    stroke-width: 6px;
  }

  :host([data-size='sm']) > svg > circle {
    stroke-width: 8px;
  }

  @keyframes rotate {
    100% {
      transform: rotate(360deg);
    }
  }

  @keyframes dash {
    0% {
      stroke-dasharray: 1, 124;
      stroke-dashoffset: 0;
    }

    50% {
      stroke-dasharray: 90, 124;
      stroke-dashoffset: -35;
    }

    100% {
      stroke-dashoffset: -125;
    }
  }
`;var Wl=function(n,e,t,i){var o=arguments.length,r=o<3?e:i===null?i=Object.getOwnPropertyDescriptor(e,t):i,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")r=Reflect.decorate(n,e,t,i);else for(var a=n.length-1;a>=0;a--)(s=n[a])&&(r=(o<3?s(r):o>3?s(e,t,r):s(e,t))||r);return o>3&&r&&Object.defineProperty(e,t,r),r};let vr=class extends q{constructor(){super(...arguments),this.color="accent-100",this.size="lg"}render(){return this.style.cssText=`--local-color: var(--wui-color-${this.color});`,this.dataset.size=this.size,P`<svg viewBox="25 25 50 50">
      <circle r="20" cy="50" cx="50"></circle>
    </svg>`}};vr.styles=[Q,Qw];Wl([v()],vr.prototype,"color",void 0);Wl([v()],vr.prototype,"size",void 0);vr=Wl([k("wui-loading-spinner")],vr);const Xw=Z`
  :host {
    display: block;
    width: var(--wui-box-size-md);
    height: var(--wui-box-size-md);
  }

  svg {
    width: var(--wui-box-size-md);
    height: var(--wui-box-size-md);
    transition: all var(--wui-ease-in-power-3) var(--wui-duration-lg);
  }

  rect {
    fill: none;
    stroke: var(--wui-color-accent-100);
    stroke-width: 4px;
    stroke-linecap: round;
    animation: dash 1s linear infinite;
  }

  @keyframes dash {
    to {
      stroke-dashoffset: 0px;
    }
  }
`;var ih=function(n,e,t,i){var o=arguments.length,r=o<3?e:i===null?i=Object.getOwnPropertyDescriptor(e,t):i,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")r=Reflect.decorate(n,e,t,i);else for(var a=n.length-1;a>=0;a--)(s=n[a])&&(r=(o<3?s(r):o>3?s(e,t,r):s(e,t))||r);return o>3&&r&&Object.defineProperty(e,t,r),r};let ko=class extends q{constructor(){super(...arguments),this.radius=36}render(){return this.svgLoaderTemplate()}svgLoaderTemplate(){const e=this.radius>50?50:this.radius,i=36-e,o=116+i,r=245+i,s=360+i*1.75;return P`
      <svg viewBox="0 0 110 110" width="110" height="110">
        <rect
          x="2"
          y="2"
          width="106"
          height="106"
          rx=${e}
          stroke-dasharray="${o} ${r}"
          stroke-dashoffset=${s}
        />
      </svg>
    `}};ko.styles=[Q,Xw];ih([v({type:Number})],ko.prototype,"radius",void 0);ko=ih([k("wui-loading-thumbnail")],ko);const e2=Z`
  :host {
    display: block;
    box-shadow: inset 0 0 0 1px var(--wui-gray-glass-005);
    background: linear-gradient(
      120deg,
      var(--wui-color-bg-200) 5%,
      var(--wui-color-bg-200) 48%,
      var(--wui-color-bg-300) 55%,
      var(--wui-color-bg-300) 60%,
      var(--wui-color-bg-300) calc(60% + 10px),
      var(--wui-color-bg-200) calc(60% + 12px),
      var(--wui-color-bg-200) 100%
    );
    background-size: 250%;
    animation: shimmer 3s linear infinite reverse;
  }

  @keyframes shimmer {
    from {
      background-position: -250% 0;
    }
    to {
      background-position: 250% 0;
    }
  }
`;var Ra=function(n,e,t,i){var o=arguments.length,r=o<3?e:i===null?i=Object.getOwnPropertyDescriptor(e,t):i,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")r=Reflect.decorate(n,e,t,i);else for(var a=n.length-1;a>=0;a--)(s=n[a])&&(r=(o<3?s(r):o>3?s(e,t,r):s(e,t))||r);return o>3&&r&&Object.defineProperty(e,t,r),r};let _i=class extends q{constructor(){super(...arguments),this.width="",this.height="",this.borderRadius="m"}render(){return this.style.cssText=`
      width: ${this.width};
      height: ${this.height};
      border-radius: ${`clamp(0px,var(--wui-border-radius-${this.borderRadius}), 40px)`};
    `,P`<slot></slot>`}};_i.styles=[e2];Ra([v()],_i.prototype,"width",void 0);Ra([v()],_i.prototype,"height",void 0);Ra([v()],_i.prototype,"borderRadius",void 0);_i=Ra([k("wui-shimmer")],_i);/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const rh={ATTRIBUTE:1,CHILD:2,PROPERTY:3,BOOLEAN_ATTRIBUTE:4,EVENT:5,ELEMENT:6},oh=n=>(...e)=>({_$litDirective$:n,values:e});let sh=class{constructor(e){}get _$AU(){return this._$AM._$AU}_$AT(e,t,i){this._$Ct=e,this._$AM=t,this._$Ci=i}_$AS(e,t){return this.update(e,t)}update(e,t){return this.render(...t)}};/**
 * @license
 * Copyright 2018 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const t2=oh(class extends sh{constructor(n){var e;if(super(n),n.type!==rh.ATTRIBUTE||n.name!=="class"||((e=n.strings)==null?void 0:e.length)>2)throw Error("`classMap()` can only be used in the `class` attribute and must be the only part in the attribute.")}render(n){return" "+Object.keys(n).filter(e=>n[e]).join(" ")+" "}update(n,[e]){var i,o;if(this.st===void 0){this.st=new Set,n.strings!==void 0&&(this.nt=new Set(n.strings.join(" ").split(/\s/).filter(r=>r!=="")));for(const r in e)e[r]&&!((i=this.nt)!=null&&i.has(r))&&this.st.add(r);return this.render(e)}const t=n.element.classList;for(const r of this.st)r in e||(t.remove(r),this.st.delete(r));for(const r in e){const s=!!e[r];s===this.st.has(r)||(o=this.nt)!=null&&o.has(r)||(s?(t.add(r),this.st.add(r)):(t.remove(r),this.st.delete(r)))}return xi}}),n2=Z`
  :host {
    display: inline-flex !important;
  }

  slot {
    display: inline-block;
    font-style: normal;
    font-family: var(--wui-font-family);
    font-feature-settings:
      'tnum' on,
      'lnum' on,
      'case' on;
    line-height: 130%;
    font-weight: var(--wui-font-weight-regular);
    overflow: inherit;
    text-overflow: inherit;
    text-align: var(--local-align);
    color: var(--local-color);
  }

  .wui-font-medium-title-600 {
    font-size: var(--wui-font-size-medium-title);
    letter-spacing: var(--wui-letter-spacing-medium-title);
  }

  .wui-font-large-500,
  .wui-font-large-600,
  .wui-font-large-700 {
    font-size: var(--wui-font-size-large);
    letter-spacing: var(--wui-letter-spacing-large);
  }

  .wui-font-2xl-500,
  .wui-font-2xl-600,
  .wui-font-2xl-700 {
    font-size: var(--wui-font-size-2xl);
    letter-spacing: var(--wui-letter-spacing-2xl);
  }

  .wui-font-paragraph-500,
  .wui-font-paragraph-600,
  .wui-font-paragraph-700 {
    font-size: var(--wui-font-size-paragraph);
    letter-spacing: var(--wui-letter-spacing-paragraph);
  }

  .wui-font-small-400,
  .wui-font-small-500,
  .wui-font-small-600 {
    font-size: var(--wui-font-size-small);
    letter-spacing: var(--wui-letter-spacing-small);
  }

  .wui-font-tiny-400,
  .wui-font-tiny-500,
  .wui-font-tiny-600 {
    font-size: var(--wui-font-size-tiny);
    letter-spacing: var(--wui-letter-spacing-tiny);
  }

  .wui-font-micro-700,
  .wui-font-micro-600 {
    font-size: var(--wui-font-size-micro);
    letter-spacing: var(--wui-letter-spacing-micro);
    text-transform: uppercase;
  }

  .wui-font-tiny-400,
  .wui-font-small-400,
  .wui-font-paragraph-400 {
    font-weight: var(--wui-font-weight-light);
  }

  .wui-font-large-700,
  .wui-font-paragraph-700,
  .wui-font-micro-700 {
    font-weight: var(--wui-font-weight-bold);
  }

  .wui-font-medium-title-600,
  .wui-font-large-600,
  .wui-font-paragraph-600,
  .wui-font-small-600,
  .wui-font-tiny-600,
  .wui-font-micro-600 {
    font-weight: var(--wui-font-weight-medium);
  }
`;var Ta=function(n,e,t,i){var o=arguments.length,r=o<3?e:i===null?i=Object.getOwnPropertyDescriptor(e,t):i,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")r=Reflect.decorate(n,e,t,i);else for(var a=n.length-1;a>=0;a--)(s=n[a])&&(r=(o<3?s(r):o>3?s(e,t,r):s(e,t))||r);return o>3&&r&&Object.defineProperty(e,t,r),r};let Ei=class extends q{constructor(){super(...arguments),this.variant="paragraph-500",this.color="fg-300",this.align="left"}render(){const e={[`wui-font-${this.variant}`]:!0,[`wui-color-${this.color}`]:!0};return this.style.cssText=`
      --local-align: ${this.align};
      --local-color: var(--wui-color-${this.color});
    `,P`<slot class=${t2(e)}></slot>`}};Ei.styles=[Q,n2];Ta([v()],Ei.prototype,"variant",void 0);Ta([v()],Ei.prototype,"color",void 0);Ta([v()],Ei.prototype,"align",void 0);Ei=Ta([k("wui-text")],Ei);const i2=B`<svg fill="none" viewBox="0 0 60 60">
  <rect width="60" height="60" fill="#1DC956" rx="30" />
  <circle cx="30" cy="30" r="3" fill="#fff" />
  <path
    fill="#2BEE6C"
    stroke="#fff"
    stroke-width="2"
    d="m45.32 17.9-.88-.42.88.42.02-.05c.1-.2.21-.44.26-.7l-.82-.15.82.16a2 2 0 0 0-.24-1.4c-.13-.23-.32-.42-.47-.57a8.42 8.42 0 0 1-.04-.04l-.04-.04a2.9 2.9 0 0 0-.56-.47l-.51.86.5-.86a2 2 0 0 0-1.4-.24c-.26.05-.5.16-.69.26l-.05.02-15.05 7.25-.1.05c-1.14.55-1.85.89-2.46 1.37a7 7 0 0 0-1.13 1.14c-.5.6-.83 1.32-1.38 2.45l-.05.11-7.25 15.05-.02.05c-.1.2-.21.43-.26.69a2 2 0 0 0 .24 1.4l.85-.5-.85.5c.13.23.32.42.47.57l.04.04.04.04c.15.15.34.34.56.47a2 2 0 0 0 1.41.24l-.2-.98.2.98c.25-.05.5-.17.69-.26l.05-.02-.42-.87.42.87 15.05-7.25.1-.05c1.14-.55 1.85-.89 2.46-1.38a7 7 0 0 0 1.13-1.13 12.87 12.87 0 0 0 1.43-2.56l7.25-15.05Z"
  />
  <path
    fill="#1DC956"
    d="M33.38 32.72 30.7 29.3 15.86 44.14l.2.2a1 1 0 0 0 1.14.2l15.1-7.27a3 3 0 0 0 1.08-4.55Z"
  />
  <path
    fill="#86F999"
    d="m26.62 27.28 2.67 3.43 14.85-14.85-.2-.2a1 1 0 0 0-1.14-.2l-15.1 7.27a3 3 0 0 0-1.08 4.55Z"
  />
  <circle cx="30" cy="30" r="3" fill="#fff" transform="rotate(45 30 30)" />
  <rect width="59" height="59" x=".5" y=".5" stroke="#062B2B" stroke-opacity=".1" rx="29.5" />
</svg> `,r2=B`<svg viewBox="0 0 60 60" fill="none">
  <g clip-path="url(#clip0_7734_50402)">
    <path
      d="M0 24.9C0 15.6485 0 11.0228 1.97053 7.56812C3.3015 5.23468 5.23468 3.3015 7.56812 1.97053C11.0228 0 15.6485 0 24.9 0H35.1C44.3514 0 48.9772 0 52.4319 1.97053C54.7653 3.3015 56.6985 5.23468 58.0295 7.56812C60 11.0228 60 15.6485 60 24.9V35.1C60 44.3514 60 48.9772 58.0295 52.4319C56.6985 54.7653 54.7653 56.6985 52.4319 58.0295C48.9772 60 44.3514 60 35.1 60H24.9C15.6485 60 11.0228 60 7.56812 58.0295C5.23468 56.6985 3.3015 54.7653 1.97053 52.4319C0 48.9772 0 44.3514 0 35.1V24.9Z"
      fill="#EB8B47"
    />
    <path
      d="M0.5 24.9C0.5 20.2652 0.50047 16.8221 0.744315 14.105C0.987552 11.3946 1.46987 9.45504 2.40484 7.81585C3.69145 5.56019 5.56019 3.69145 7.81585 2.40484C9.45504 1.46987 11.3946 0.987552 14.105 0.744315C16.8221 0.50047 20.2652 0.5 24.9 0.5H35.1C39.7348 0.5 43.1779 0.50047 45.895 0.744315C48.6054 0.987552 50.545 1.46987 52.1841 2.40484C54.4398 3.69145 56.3086 5.56019 57.5952 7.81585C58.5301 9.45504 59.0124 11.3946 59.2557 14.105C59.4995 16.8221 59.5 20.2652 59.5 24.9V35.1C59.5 39.7348 59.4995 43.1779 59.2557 45.895C59.0124 48.6054 58.5301 50.545 57.5952 52.1841C56.3086 54.4398 54.4398 56.3086 52.1841 57.5952C50.545 58.5301 48.6054 59.0124 45.895 59.2557C43.1779 59.4995 39.7348 59.5 35.1 59.5H24.9C20.2652 59.5 16.8221 59.4995 14.105 59.2557C11.3946 59.0124 9.45504 58.5301 7.81585 57.5952C5.56019 56.3086 3.69145 54.4398 2.40484 52.1841C1.46987 50.545 0.987552 48.6054 0.744315 45.895C0.50047 43.1779 0.5 39.7348 0.5 35.1V24.9Z"
      stroke="#062B2B"
      stroke-opacity="0.1"
    />
    <path
      d="M19 52C24.5228 52 29 47.5228 29 42C29 36.4772 24.5228 32 19 32C13.4772 32 9 36.4772 9 42C9 47.5228 13.4772 52 19 52Z"
      fill="#FF974C"
      stroke="white"
      stroke-width="2"
    />
    <path
      fill-rule="evenodd"
      clip-rule="evenodd"
      d="M42.8437 8.3264C42.4507 7.70891 41.5493 7.70891 41.1564 8.32641L28.978 27.4638C28.5544 28.1295 29.0326 29.0007 29.8217 29.0007H54.1783C54.9674 29.0007 55.4456 28.1295 55.022 27.4638L42.8437 8.3264Z"
      fill="white"
    />
    <path
      fill-rule="evenodd"
      clip-rule="evenodd"
      d="M42.3348 11.6456C42.659 11.7608 42.9061 12.1492 43.4005 12.926L50.7332 24.4488C51.2952 25.332 51.5763 25.7737 51.5254 26.1382C51.4915 26.3808 51.3698 26.6026 51.1833 26.7614C50.9031 27 50.3796 27 49.3327 27H34.6673C33.6204 27 33.0969 27 32.8167 26.7614C32.6302 26.6026 32.5085 26.3808 32.4746 26.1382C32.4237 25.7737 32.7048 25.332 33.2669 24.4488L40.5995 12.926C41.0939 12.1492 41.341 11.7608 41.6652 11.6456C41.8818 11.5687 42.1182 11.5687 42.3348 11.6456ZM35.0001 26.999C38.8661 26.999 42.0001 23.865 42.0001 19.999C42.0001 23.865 45.1341 26.999 49.0001 26.999H35.0001Z"
      fill="#FF974C"
    />
    <path
      d="M10.1061 9.35712C9.9973 9.67775 9.99867 10.0388 9.99978 10.3323C9.99989 10.3611 10 10.3893 10 10.4167V25.5833C10 25.6107 9.99989 25.6389 9.99978 25.6677C9.99867 25.9612 9.9973 26.3222 10.1061 26.6429C10.306 27.2317 10.7683 27.694 11.3571 27.8939C11.6777 28.0027 12.0388 28.0013 12.3323 28.0002C12.3611 28.0001 12.3893 28 12.4167 28H19C24.5228 28 29 23.5228 29 18C29 12.4772 24.5228 8 19 8H12.4167C12.3893 8 12.3611 7.99989 12.3323 7.99978C12.0388 7.99867 11.6778 7.9973 11.3571 8.10614C10.7683 8.306 10.306 8.76834 10.1061 9.35712Z"
      fill="#FF974C"
      stroke="white"
      stroke-width="2"
    />
    <circle cx="19" cy="18" r="4" fill="#EB8B47" stroke="white" stroke-width="2" />
    <circle cx="19" cy="42" r="4" fill="#EB8B47" stroke="white" stroke-width="2" />
  </g>
  <defs>
    <clipPath id="clip0_7734_50402">
      <rect width="60" height="60" fill="white" />
    </clipPath>
  </defs>
</svg> `,o2=B`<svg fill="none" viewBox="0 0 60 60">
  <g clip-path="url(#a)">
    <path
      fill="#1DC956"
      d="M0 25.01c0-9.25 0-13.88 1.97-17.33a15 15 0 0 1 5.6-5.6C11.02.11 15.65.11 24.9.11h10.2c9.25 0 13.88 0 17.33 1.97a15 15 0 0 1 5.6 5.6C60 11.13 60 15.76 60 25v10.2c0 9.25 0 13.88-1.97 17.33a15 15 0 0 1-5.6 5.6c-3.45 1.97-8.08 1.97-17.33 1.97H24.9c-9.25 0-13.88 0-17.33-1.97a15 15 0 0 1-5.6-5.6C0 49.1 0 44.46 0 35.21v-10.2Z"
    />
    <path
      fill="#2BEE6C"
      d="M16.1 60c-3.82-.18-6.4-.64-8.53-1.86a15 15 0 0 1-5.6-5.6C.55 50.06.16 46.97.04 41.98L4.2 40.6a4 4 0 0 0 2.48-2.39l4.65-12.4a2 2 0 0 1 2.5-1.2l2.53.84a2 2 0 0 0 2.43-1l2.96-5.94a2 2 0 0 1 3.7.32l3.78 12.58a2 2 0 0 0 3.03 1.09l3.34-2.23a2 2 0 0 0 .65-.7l5.3-9.72a2 2 0 0 1 1.42-1.01l4.14-.69a2 2 0 0 1 1.6.44l3.9 3.24a2 2 0 0 0 2.7-.12l4.62-4.63c.08 2.2.08 4.8.08 7.93v10.2c0 9.25 0 13.88-1.97 17.33a15 15 0 0 1-5.6 5.6c-2.13 1.22-4.7 1.68-8.54 1.86H16.11Z"
    />
    <path
      fill="#fff"
      d="m.07 43.03-.05-2.1 3.85-1.28a3 3 0 0 0 1.86-1.79l4.66-12.4a3 3 0 0 1 3.75-1.8l2.53.84a1 1 0 0 0 1.21-.5l2.97-5.94a3 3 0 0 1 5.56.48l3.77 12.58a1 1 0 0 0 1.51.55l3.34-2.23a1 1 0 0 0 .33-.35l5.3-9.71a3 3 0 0 1 2.14-1.53l4.13-.69a3 3 0 0 1 2.41.66l3.9 3.24a1 1 0 0 0 1.34-.06l5.28-5.28c.05.85.08 1.75.1 2.73L56 22.41a3 3 0 0 1-4.04.19l-3.9-3.25a1 1 0 0 0-.8-.21l-4.13.69a1 1 0 0 0-.72.5l-5.3 9.72a3 3 0 0 1-.97 1.05l-3.34 2.23a3 3 0 0 1-4.53-1.63l-3.78-12.58a1 1 0 0 0-1.85-.16l-2.97 5.94a3 3 0 0 1-3.63 1.5l-2.53-.84a1 1 0 0 0-1.25.6l-4.65 12.4a5 5 0 0 1-3.1 3L.07 43.02Z"
    />
    <path
      fill="#fff"
      fill-rule="evenodd"
      d="M49.5 19a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0Z"
      clip-rule="evenodd"
    />
    <path fill="#fff" d="M45 .28v59.66l-2 .1V.19c.7.02 1.37.05 2 .1Z" />
    <path fill="#2BEE6C" d="M47.5 19a3.5 3.5 0 1 1-7 0 3.5 3.5 0 0 1 7 0Z" />
    <path
      stroke="#fff"
      stroke-opacity=".1"
      d="M.5 25.01c0-4.63 0-8.08.24-10.8.25-2.7.73-4.64 1.66-6.28a14.5 14.5 0 0 1 5.42-5.41C9.46 1.58 11.39 1.1 14.1.85A133 133 0 0 1 24.9.61h10.2c4.63 0 8.08 0 10.8.24 2.7.25 4.65.73 6.28 1.67a14.5 14.5 0 0 1 5.42 5.4c.93 1.65 1.41 3.58 1.66 6.3.24 2.71.24 6.16.24 10.79v10.2c0 4.64 0 8.08-.24 10.8-.25 2.7-.73 4.65-1.66 6.28a14.5 14.5 0 0 1-5.42 5.42c-1.63.93-3.57 1.41-6.28 1.66-2.72.24-6.17.24-10.8.24H24.9c-4.63 0-8.08 0-10.8-.24-2.7-.25-4.64-.73-6.28-1.66a14.5 14.5 0 0 1-5.42-5.42C1.47 50.66 1 48.72.74 46.01A133 133 0 0 1 .5 35.2v-10.2Z"
    />
  </g>
  <defs>
    <clipPath id="a"><path fill="#fff" d="M0 0h60v60H0z" /></clipPath>
  </defs>
</svg>`,s2=B`<svg fill="none" viewBox="0 0 60 60">
  <g clip-path="url(#a)">
    <rect width="60" height="60" fill="#C653C6" rx="30" />
    <path
      fill="#E87DE8"
      d="M57.98.01v19.5a4.09 4.09 0 0 0-2.63 2.29L50.7 34.2a2 2 0 0 1-2.5 1.2l-2.53-.84a2 2 0 0 0-2.42 1l-2.97 5.94a2 2 0 0 1-3.7-.32L32.8 28.6a2 2 0 0 0-3.02-1.09l-3.35 2.23a2 2 0 0 0-.64.7l-5.3 9.72a2 2 0 0 1-1.43 1.01l-4.13.69a2 2 0 0 1-1.61-.44l-3.9-3.24a2 2 0 0 0-2.69.12L2.1 42.93.02 43V.01h57.96Z"
    />
    <path
      fill="#fff"
      d="m61.95 16.94.05 2.1-3.85 1.28a3 3 0 0 0-1.86 1.79l-4.65 12.4a3 3 0 0 1-3.76 1.8l-2.53-.84a1 1 0 0 0-1.2.5l-2.98 5.94a3 3 0 0 1-5.55-.48l-3.78-12.58a1 1 0 0 0-1.5-.55l-3.35 2.23a1 1 0 0 0-.32.35l-5.3 9.72a3 3 0 0 1-2.14 1.52l-4.14.69a3 3 0 0 1-2.41-.66l-3.9-3.24a1 1 0 0 0-1.34.06l-5.28 5.28c-.05-.84-.08-1.75-.1-2.73l3.97-3.96a3 3 0 0 1 4.04-.19l3.89 3.25a1 1 0 0 0 .8.21l4.14-.68a1 1 0 0 0 .71-.51l5.3-9.71a3 3 0 0 1 .97-1.06l3.34-2.23a3 3 0 0 1 4.54 1.63l3.77 12.58a1 1 0 0 0 1.86.16l2.96-5.93a3 3 0 0 1 3.64-1.5l2.52.83a1 1 0 0 0 1.25-.6l4.66-12.4a5 5 0 0 1 3.1-2.99l4.43-1.48Z"
    />
    <path
      fill="#fff"
      fill-rule="evenodd"
      d="M35.5 27a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0Z"
      clip-rule="evenodd"
    />
    <path fill="#fff" d="M31 0v60h-2V0h2Z" />
    <path fill="#E87DE8" d="M33.5 27a3.5 3.5 0 1 1-7 0 3.5 3.5 0 0 1 7 0Z" />
  </g>
  <rect width="59" height="59" x=".5" y=".5" stroke="#fff" stroke-opacity=".1" rx="29.5" />
  <defs>
    <clipPath id="a"><rect width="60" height="60" fill="#fff" rx="30" /></clipPath>
  </defs>
</svg> `,a2=B`<svg fill="none" viewBox="0 0 60 60">
  <g clip-path="url(#a)">
    <rect width="60" height="60" fill="#987DE8" rx="30" />
    <path
      fill="#fff"
      fill-rule="evenodd"
      d="m15.48 28.37 11.97-19.3a3 3 0 0 1 5.1 0l11.97 19.3a6 6 0 0 1 .9 3.14v.03a6 6 0 0 1-1.16 3.56L33.23 50.2a4 4 0 0 1-6.46 0L15.73 35.1a6 6 0 0 1-1.15-3.54v-.03a6 6 0 0 1 .9-3.16Z"
      clip-rule="evenodd"
    />
    <path
      fill="#643CDD"
      d="M30.84 10.11a1 1 0 0 0-.84-.46V24.5l12.6 5.53a2 2 0 0 0-.28-1.4L30.84 10.11Z"
    />
    <path
      fill="#BDADEB"
      d="M30 9.65a1 1 0 0 0-.85.46L17.66 28.64a2 2 0 0 0-.26 1.39L30 24.5V9.65Z"
    />
    <path
      fill="#643CDD"
      d="M30 50.54a1 1 0 0 0 .8-.4l11.24-15.38c.3-.44-.2-1-.66-.73l-9.89 5.68a3 3 0 0 1-1.5.4v10.43Z"
    />
    <path
      fill="#BDADEB"
      d="m17.97 34.76 11.22 15.37c.2.28.5.41.8.41V40.11a3 3 0 0 1-1.49-.4l-9.88-5.68c-.47-.27-.97.3-.65.73Z"
    />
    <path
      fill="#401AB3"
      d="M42.6 30.03 30 24.5v13.14a3 3 0 0 0 1.5-.4l10.14-5.83a2 2 0 0 0 .95-1.38Z"
    />
    <path
      fill="#7C5AE2"
      d="M30 37.64V24.46l-12.6 5.57a2 2 0 0 0 .97 1.39l10.13 5.82a3 3 0 0 0 1.5.4Z"
    />
  </g>
  <rect width="59" height="59" x=".5" y=".5" stroke="#fff" stroke-opacity=".1" rx="29.5" />
  <defs>
    <clipPath id="a"><rect width="60" height="60" fill="#fff" rx="30" /></clipPath>
  </defs>
</svg> `,c2=B`<svg fill="none" viewBox="0 0 60 60">
  <rect width="60" height="60" fill="#1DC956" rx="3" />
  <path
    fill="#1FAD7E"
    stroke="#fff"
    stroke-width="2"
    d="m30.49 29.13-.49-.27-.49.27-12.77 7.1-.05.02c-.86.48-1.58.88-2.1 1.24-.54.37-1.04.81-1.28 1.45a3 3 0 0 0 0 2.12c.24.63.74 1.08 1.27 1.45.53.36 1.25.76 2.11 1.24l.05.03 6.33 3.51.17.1c2.33 1.3 3.72 2.06 5.22 2.32a9 9 0 0 0 3.08 0c1.5-.26 2.9-1.03 5.22-2.32l.18-.1 6.32-3.51.05-.03a26.9 26.9 0 0 0 2.1-1.24 3.21 3.21 0 0 0 1.28-1.45l-.94-.35.94.35a3 3 0 0 0 0-2.12l-.94.35.94-.35a3.21 3.21 0 0 0-1.27-1.45c-.53-.36-1.25-.76-2.11-1.24l-.05-.03-12.77-7.1Z"
  />
  <path
    fill="#2BEE6C"
    stroke="#fff"
    stroke-width="2"
    d="m30.49 19.13-.49-.27-.49.27-12.77 7.1-.05.02c-.86.48-1.58.88-2.1 1.24-.54.37-1.04.81-1.28 1.45a3 3 0 0 0 0 2.12c.24.63.74 1.08 1.27 1.45.53.36 1.25.76 2.11 1.24l.05.03 6.33 3.51.17.1c2.33 1.3 3.72 2.06 5.22 2.32a9 9 0 0 0 3.08 0c1.5-.26 2.9-1.03 5.22-2.32l.18-.1 6.32-3.51.05-.03a26.9 26.9 0 0 0 2.1-1.24 3.21 3.21 0 0 0 1.28-1.45l-.94-.35.94.35a3 3 0 0 0 0-2.12l-.94.35.94-.35a3.21 3.21 0 0 0-1.27-1.45c-.53-.36-1.25-.76-2.11-1.24l-.05-.03-12.77-7.1Z"
  />
  <path
    fill="#86F999"
    stroke="#fff"
    stroke-width="2"
    d="m46.69 21.06-.94-.35.94.35a3 3 0 0 0 0-2.12l-.94.35.94-.35a3.21 3.21 0 0 0-1.27-1.45c-.53-.36-1.25-.76-2.11-1.24l-.05-.03-6.32-3.51-.18-.1c-2.33-1.3-3.72-2.06-5.22-2.33a9 9 0 0 0-3.08 0c-1.5.27-2.9 1.04-5.22 2.33l-.17.1-6.33 3.51-.05.03c-.86.48-1.58.88-2.1 1.24-.54.37-1.04.81-1.28 1.45a3 3 0 0 0 0 2.12c.24.63.74 1.08 1.27 1.45.53.36 1.25.76 2.11 1.24l.05.03 6.33 3.51.17.1c2.33 1.3 3.72 2.06 5.22 2.32a9 9 0 0 0 3.08 0c1.5-.26 2.9-1.03 5.22-2.32l.18-.1 6.32-3.51.05-.03a26.9 26.9 0 0 0 2.1-1.24 3.21 3.21 0 0 0 1.28-1.45Z"
  />
  <rect width="59" height="59" x=".5" y=".5" stroke="#fff" stroke-opacity=".1" rx="2.5" />
</svg>`,l2=B`<svg fill="none" viewBox="0 0 60 60">
  <rect width="60" height="60" fill="#C653C6" rx="3" />
  <path
    fill="#fff"
    d="M20.03 15.22C20 15.6 20 16.07 20 17v2.8c0 1.14 0 1.7-.2 2.12-.15.31-.3.5-.58.71-.37.28-1.06.42-2.43.7-.59.12-1.11.29-1.6.51a9 9 0 0 0-4.35 4.36C10 30 10 32.34 10 37c0 4.66 0 7 .84 8.8a9 9 0 0 0 4.36 4.36C17 51 19.34 51 24 51h12c4.66 0 7 0 8.8-.84a9 9 0 0 0 4.36-4.36C50 44 50 41.66 50 37c0-4.66 0-7-.84-8.8a9 9 0 0 0-4.36-4.36c-.48-.22-1-.39-1.6-.5-1.36-.29-2.05-.43-2.42-.7-.27-.22-.43-.4-.58-.72-.2-.42-.2-.98-.2-2.11V17c0-.93 0-1.4-.03-1.78a9 9 0 0 0-8.19-8.19C31.4 7 30.93 7 30 7s-1.4 0-1.78.03a9 9 0 0 0-8.19 8.19Z"
  />
  <path
    fill="#E87DE8"
    d="M22 17c0-.93 0-1.4.04-1.78a7 7 0 0 1 6.18-6.18C28.6 9 29.07 9 30 9s1.4 0 1.78.04a7 7 0 0 1 6.18 6.18c.04.39.04.85.04 1.78v4.5a1.5 1.5 0 0 1-3 0V17c0-.93 0-1.4-.08-1.78a4 4 0 0 0-3.14-3.14C31.39 12 30.93 12 30 12s-1.4 0-1.78.08a4 4 0 0 0-3.14 3.14c-.08.39-.08.85-.08 1.78v4.5a1.5 1.5 0 0 1-3 0V17Z"
  />
  <path
    fill="#E87DE8"
    fill-rule="evenodd"
    d="M12 36.62c0-4.32 0-6.48.92-8.09a7 7 0 0 1 2.61-2.61C17.14 25 19.3 25 23.62 25h6.86c.46 0 .7 0 .9.02 2.73.22 4.37 2.43 4.62 4.98.27-2.7 2.11-5 5.02-5A6.98 6.98 0 0 1 48 31.98v5.4c0 4.32 0 6.48-.92 8.09a7 7 0 0 1-2.61 2.61c-1.61.92-3.77.92-8.09.92h-5.86c-.46 0-.7 0-.9-.02-2.73-.22-4.37-2.43-4.62-4.98-.26 2.58-1.94 4.82-4.71 4.99l-.7.01c-.55 0-.82 0-1.05-.02a7 7 0 0 1-6.52-6.52c-.02-.23-.02-.5-.02-1.05v-4.79Zm21.24-.27a4 4 0 1 0-6.48 0 31.28 31.28 0 0 1 1.57 2.23c.17.4.17.81.17 1.24V42.5a1.5 1.5 0 0 0 3 0V39.82c0-.43 0-.85.17-1.24.09-.2.58-.87 1.57-2.23Z"
    clip-rule="evenodd"
  />
  <rect width="59" height="59" x=".5" y=".5" stroke="#fff" stroke-opacity=".1" rx="2.5" />
</svg>`,u2=B`<svg fill="none" viewBox="0 0 60 60">
  <g clip-path="url(#a)">
    <path
      fill="#EB8B47"
      d="M0 24.9c0-9.25 0-13.88 1.97-17.33a15 15 0 0 1 5.6-5.6C11.02 0 15.65 0 24.9 0h10.2c9.25 0 13.88 0 17.33 1.97a15 15 0 0 1 5.6 5.6C60 11.02 60 15.65 60 24.9v10.2c0 9.25 0 13.88-1.97 17.33a15 15 0 0 1-5.6 5.6C48.98 60 44.35 60 35.1 60H24.9c-9.25 0-13.88 0-17.33-1.97a15 15 0 0 1-5.6-5.6C0 48.98 0 44.35 0 35.1V24.9Z"
    />
    <path
      stroke="#062B2B"
      stroke-opacity=".1"
      d="M.5 24.9c0-4.64 0-8.08.24-10.8.25-2.7.73-4.65 1.66-6.28A14.5 14.5 0 0 1 7.82 2.4C9.46 1.47 11.39 1 14.1.74A133 133 0 0 1 24.9.5h10.2c4.63 0 8.08 0 10.8.24 2.7.25 4.65.73 6.28 1.66a14.5 14.5 0 0 1 5.42 5.42c.93 1.63 1.41 3.57 1.66 6.28.24 2.72.24 6.16.24 10.8v10.2c0 4.63 0 8.08-.24 10.8-.25 2.7-.73 4.64-1.66 6.28a14.5 14.5 0 0 1-5.42 5.41c-1.63.94-3.57 1.42-6.28 1.67-2.72.24-6.17.24-10.8.24H24.9c-4.63 0-8.08 0-10.8-.24-2.7-.25-4.64-.73-6.28-1.67a14.5 14.5 0 0 1-5.42-5.4C1.47 50.53 1 48.6.74 45.88A133 133 0 0 1 .5 35.1V24.9Z"
    />
    <path
      fill="#FF974C"
      stroke="#fff"
      stroke-width="2"
      d="M39.2 29.2a13 13 0 1 0-18.4 0l1.3 1.28a12.82 12.82 0 0 1 2.1 2.39 6 6 0 0 1 .6 1.47c.2.76.2 1.56.2 3.17v11.24c0 1.08 0 1.61.13 2.12a4 4 0 0 0 .41.98c.26.45.64.83 1.4 1.6l.3.29c.65.65.98.98 1.36 1.09.26.07.54.07.8 0 .38-.11.7-.44 1.36-1.1l3.48-3.47c.65-.65.98-.98 1.09-1.36a1.5 1.5 0 0 0 0-.8c-.1-.38-.44-.7-1.1-1.36l-.47-.48c-.65-.65-.98-.98-1.09-1.36a1.5 1.5 0 0 1 0-.8c.1-.38.44-.7 1.1-1.36l.47-.48c.65-.65.98-.98 1.09-1.36a1.5 1.5 0 0 0 0-.8c-.1-.38-.44-.7-1.1-1.36l-.48-.5c-.65-.64-.98-.97-1.08-1.35a1.5 1.5 0 0 1 0-.79c.1-.38.42-.7 1.06-1.36l5.46-5.55Z"
    />
    <circle cx="30" cy="17" r="4" fill="#EB8B47" stroke="#fff" stroke-width="2" />
  </g>
  <defs>
    <clipPath id="a"><path fill="#fff" d="M0 0h60v60H0z" /></clipPath>
  </defs>
</svg> `,d2=B`<svg fill="none" viewBox="0 0 60 60">
  <g clip-path="url(#a)">
    <rect width="60" height="60" fill="#00ACE6" rx="30" />
    <circle cx="64" cy="39" r="50" fill="#1AC6FF" stroke="#fff" stroke-width="2" />
    <circle cx="78" cy="30" r="50" fill="#4DD2FF" stroke="#fff" stroke-width="2" />
    <circle cx="72" cy="15" r="35" fill="#80DFFF" stroke="#fff" stroke-width="2" />
    <circle cx="34" cy="-17" r="45" stroke="#fff" stroke-width="2" />
    <circle cx="34" cy="-5" r="50" stroke="#fff" stroke-width="2" />
    <circle cx="30" cy="45" r="4" fill="#4DD2FF" stroke="#fff" stroke-width="2" />
    <circle cx="39.5" cy="27.5" r="4" fill="#80DFFF" stroke="#fff" stroke-width="2" />
    <circle cx="16" cy="24" r="4" fill="#19C6FF" stroke="#fff" stroke-width="2" />
  </g>
  <rect width="59" height="59" x=".5" y=".5" stroke="#062B2B" stroke-opacity=".1" rx="29.5" />
  <defs>
    <clipPath id="a"><rect width="60" height="60" fill="#fff" rx="30" /></clipPath>
  </defs>
</svg>`,h2=B`<svg fill="none" viewBox="0 0 60 60">
  <g clip-path="url(#a)">
    <rect width="60" height="60" fill="#C653C6" rx="3" />
    <path
      fill="#E87DE8"
      stroke="#fff"
      stroke-width="2"
      d="M52.1 47.34c0-4.24-1.44-9.55-5.9-12.4a2.86 2.86 0 0 0-1.6-3.89v-.82c0-1.19-.52-2.26-1.35-3a4.74 4.74 0 0 0-2.4-6.26v-5.5a11.31 11.31 0 1 0-22.63 0v2.15a3.34 3.34 0 0 0-1.18 5.05 4.74 4.74 0 0 0-.68 6.44A5.22 5.22 0 0 0 14 35.92c-3.06 4.13-6.1 8.3-6.1 15.64 0 2.67.37 4.86.74 6.39a20.3 20.3 0 0 0 .73 2.39l.02.04v.01l.92-.39-.92.4.26.6h38.26l.3-.49-.87-.51.86.5.02-.01.03-.07a16.32 16.32 0 0 0 .57-1.05c.36-.72.85-1.74 1.33-2.96a25.51 25.51 0 0 0 1.94-9.07Z"
    />
    <path
      fill="#fff"
      fill-rule="evenodd"
      d="M26.5 29.5c-3-.5-5.5-3-5.5-7v-7c0-.47 0-.7.03-.9a3 3 0 0 1 2.58-2.57c.2-.03.42-.03.89-.03 2 0 2.5-2.5 2.5-2.5s0 2.5 2.5 2.5c1.4 0 2.1 0 2.65.23a3 3 0 0 1 1.62 1.62c.23.55.23 1.25.23 2.65v6c0 4-3 7-6.5 7 1.35.23 4 0 6.5-2v9.53C34 38.5 31.5 40 28 40s-6-1.5-6-2.97L24 34l2.5 1.5v-6ZM26 47h4.5c2.5 0 3 4 3 5.5h-3l-1-1.5H26v-4Zm-6.25 5.5H24V57h-8c0-1 1-4.5 3.75-4.5Z"
      clip-rule="evenodd"
    />
  </g>
  <rect width="59" height="59" x=".5" y=".5" stroke="#fff" stroke-opacity=".1" rx="2.5" />
  <defs>
    <clipPath id="a"><rect width="60" height="60" fill="#fff" rx="3" /></clipPath>
  </defs>
</svg> `,p2=B`<svg fill="none" viewBox="0 0 60 60">
  <rect width="60" height="60" fill="#794CFF" rx="3" />
  <path
    fill="#987DE8"
    stroke="#fff"
    stroke-width="2"
    d="M33 22.5v-1H16v5H8.5V36H13v-5h3v7.5h17V31h1v7.5h17v-17H34v5h-1v-4Z"
  />
  <path fill="#fff" d="M37.5 25h10v10h-10z" />
  <path fill="#4019B2" d="M42.5 25h5v10h-5z" />
  <path fill="#fff" d="M19.5 25h10v10h-10z" />
  <path fill="#4019B2" d="M24.5 25h5v10h-5z" />
  <path fill="#fff" d="M12 30.5h4V37h-4v-6.5Z" />
  <rect width="59" height="59" x=".5" y=".5" stroke="#fff" stroke-opacity=".1" rx="2.5" />
</svg>`,f2=B`<svg
  viewBox="0 0 60 60"
  fill="none"
>
  <g clip-path="url(#1)">
    <rect width="60" height="60" rx="30" fill="#00ACE6" />
    <path
      d="M59 73C59 89.0163 46.0163 102 30 102C13.9837 102 1 89.0163 1 73C1 56.9837 12 44 30 44C48 44 59 56.9837 59 73Z"
      fill="#1AC6FF"
      stroke="white"
      stroke-width="2"
    />
    <path
      d="M18.6904 19.9015C19.6264 15.3286 23.3466 11.8445 27.9708 11.2096C29.3231 11.024 30.6751 11.0238 32.0289 11.2096C36.6532 11.8445 40.3733 15.3286 41.3094 19.9015C41.4868 20.7681 41.6309 21.6509 41.7492 22.5271C41.8811 23.5041 41.8811 24.4944 41.7492 25.4715C41.6309 26.3476 41.4868 27.2304 41.3094 28.097C40.3733 32.6699 36.6532 36.154 32.0289 36.7889C30.6772 36.9744 29.3216 36.9743 27.9708 36.7889C23.3466 36.154 19.6264 32.6699 18.6904 28.097C18.513 27.2304 18.3689 26.3476 18.2506 25.4715C18.1186 24.4944 18.1186 23.5041 18.2506 22.5271C18.3689 21.6509 18.513 20.7681 18.6904 19.9015Z"
      fill="#1AC6FF"
      stroke="white"
      stroke-width="2"
    />
    <circle cx="24.5" cy="23.5" r="1.5" fill="white" />
    <circle cx="35.5" cy="23.5" r="1.5" fill="white" />
    <path
      d="M31 20L28 28H32"
      stroke="white"
      stroke-width="2"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
  </g>
  <rect x="0.5" y="0.5" width="59" height="59" rx="29.5" stroke="white" stroke-opacity="0.1" />
  <defs>
    <clipPath id="1">
      <rect width="60" height="60" rx="30" fill="white" />
    </clipPath>
  </defs>
</svg> `,g2=B`<svg viewBox="0 0 60 60" fill="none">
  <g clip-path="url(#1)">
    <path
      d="M0 24.9C0 15.6485 0 11.0228 1.97053 7.56812C3.3015 5.23468 5.23468 3.3015 7.56812 1.97053C11.0228 0 15.6485 0 24.9 0H35.1C44.3514 0 48.9772 0 52.4319 1.97053C54.7653 3.3015 56.6985 5.23468 58.0295 7.56812C60 11.0228 60 15.6485 60 24.9V35.1C60 44.3514 60 48.9772 58.0295 52.4319C56.6985 54.7653 54.7653 56.6985 52.4319 58.0295C48.9772 60 44.3514 60 35.1 60H24.9C15.6485 60 11.0228 60 7.56812 58.0295C5.23468 56.6985 3.3015 54.7653 1.97053 52.4319C0 48.9772 0 44.3514 0 35.1V24.9Z"
      fill="#794CFF"
    />
    <path
      d="M0.5 24.9C0.5 20.2652 0.50047 16.8221 0.744315 14.105C0.987552 11.3946 1.46987 9.45504 2.40484 7.81585C3.69145 5.56019 5.56019 3.69145 7.81585 2.40484C9.45504 1.46987 11.3946 0.987552 14.105 0.744315C16.8221 0.50047 20.2652 0.5 24.9 0.5H35.1C39.7348 0.5 43.1779 0.50047 45.895 0.744315C48.6054 0.987552 50.545 1.46987 52.1841 2.40484C54.4398 3.69145 56.3086 5.56019 57.5952 7.81585C58.5301 9.45504 59.0124 11.3946 59.2557 14.105C59.4995 16.8221 59.5 20.2652 59.5 24.9V35.1C59.5 39.7348 59.4995 43.1779 59.2557 45.895C59.0124 48.6054 58.5301 50.545 57.5952 52.1841C56.3086 54.4398 54.4398 56.3086 52.1841 57.5952C50.545 58.5301 48.6054 59.0124 45.895 59.2557C43.1779 59.4995 39.7348 59.5 35.1 59.5H24.9C20.2652 59.5 16.8221 59.4995 14.105 59.2557C11.3946 59.0124 9.45504 58.5301 7.81585 57.5952C5.56019 56.3086 3.69145 54.4398 2.40484 52.1841C1.46987 50.545 0.987552 48.6054 0.744315 45.895C0.50047 43.1779 0.5 39.7348 0.5 35.1V24.9Z"
      stroke="#062B2B"
      stroke-opacity="0.1"
    />
    <path
      d="M35.1403 31.5016C35.1193 30.9637 35.388 30.4558 35.8446 30.1707C36.1207 29.9982 36.4761 29.8473 36.7921 29.7685C37.3143 29.6382 37.8664 29.7977 38.2386 30.1864C38.8507 30.8257 39.3004 31.6836 39.8033 32.408C40.2796 33.0942 41.4695 33.2512 41.9687 32.5047C42.4839 31.7341 42.9405 30.8229 43.572 30.1399C43.9375 29.7447 44.4866 29.5756 45.0111 29.6967C45.3283 29.7701 45.6863 29.9147 45.9655 30.0823C46.4269 30.3595 46.7045 30.8626 46.6928 31.4008C46.6731 32.3083 46.3764 33.2571 46.2158 34.1473C46.061 35.0048 46.9045 35.8337 47.7592 35.664C48.6464 35.4878 49.5899 35.1747 50.497 35.1391C51.0348 35.1181 51.5427 35.3868 51.8279 35.8433C52.0004 36.1195 52.1513 36.4749 52.2301 36.7908C52.3604 37.3131 52.2009 37.8651 51.8121 38.2374C51.1729 38.8495 50.3151 39.2991 49.5908 39.8019C48.9046 40.2782 48.7473 41.4683 49.4939 41.9675C50.2644 42.4827 51.1757 42.9393 51.8587 43.5708C52.2539 43.9362 52.423 44.4854 52.3018 45.0099C52.2285 45.3271 52.0839 45.6851 51.9162 45.9642C51.6391 46.4257 51.1359 46.7032 50.5978 46.6916C49.6903 46.6719 48.7417 46.3753 47.8516 46.2146C46.9939 46.0598 46.1648 46.9035 46.3346 47.7583C46.5108 48.6454 46.8239 49.5888 46.8594 50.4958C46.8805 51.0336 46.6117 51.5415 46.1552 51.8267C45.879 51.9992 45.5236 52.15 45.2077 52.2289C44.6854 52.3592 44.1334 52.1997 43.7611 51.8109C43.1491 51.1718 42.6996 50.314 42.1968 49.5897C41.7203 48.9034 40.5301 48.7463 40.0309 49.493C39.5157 50.2634 39.0592 51.1746 38.4278 51.8574C38.0623 52.2527 37.5132 52.4218 36.9887 52.3006C36.6715 52.2273 36.3135 52.0826 36.0343 51.915C35.5729 51.6379 35.2953 51.1347 35.307 50.5966C35.3267 49.6891 35.6233 48.7405 35.7839 47.8505C35.9388 46.9928 35.0951 46.1636 34.2402 46.3334C33.3531 46.5096 32.4098 46.8227 31.5028 46.8582C30.9649 46.8793 30.457 46.6105 30.1719 46.154C29.9994 45.8778 29.8485 45.5224 29.7697 45.2065C29.6394 44.6842 29.7989 44.1322 30.1877 43.7599C30.8269 43.1479 31.6847 42.6982 32.4091 42.1954C33.0954 41.7189 33.2522 40.5289 32.5056 40.0297C31.7351 39.5145 30.824 39.058 30.1411 38.4265C29.7459 38.0611 29.5768 37.5119 29.698 36.9875C29.7713 36.6702 29.9159 36.3122 30.0836 36.0331C30.3607 35.5717 30.8638 35.2941 31.402 35.3058C32.3095 35.3255 33.2583 35.6221 34.1485 35.7828C35.006 35.9376 35.8349 35.094 35.6652 34.2393C35.489 33.3521 35.1759 32.4087 35.1403 31.5016Z"
      fill="#906EF7"
      stroke="white"
      stroke-width="2"
    />
    <path
      d="M20.7706 8.22357C20.9036 7.51411 21.5231 7 22.2449 7H23.7551C24.4769 7 25.0964 7.51411 25.2294 8.22357C25.5051 9.69403 25.4829 11.6321 27.1202 12.2606C27.3092 12.3331 27.4958 12.4105 27.6798 12.4926C29.2818 13.2072 30.6374 11.8199 31.8721 10.9752C32.4678 10.5676 33.2694 10.6421 33.7798 11.1525L34.8477 12.2204C35.3581 12.7308 35.4326 13.5323 35.025 14.128C34.1802 15.3627 32.7931 16.7183 33.5077 18.3202C33.5898 18.5043 33.6672 18.6909 33.7398 18.88C34.3683 20.5171 36.3061 20.4949 37.7764 20.7706C38.4859 20.9036 39 21.5231 39 22.2449V23.7551C39 24.4769 38.4859 25.0964 37.7764 25.2294C36.3061 25.5051 34.3685 25.483 33.7401 27.1201C33.6675 27.3093 33.59 27.4961 33.5079 27.6803C32.7934 29.282 34.1803 30.6374 35.025 31.8719C35.4326 32.4677 35.3581 33.2692 34.8477 33.7796L33.7798 34.8475C33.2694 35.3579 32.4678 35.4324 31.8721 35.0248C30.6376 34.1801 29.2823 32.7934 27.6806 33.508C27.4962 33.5903 27.3093 33.6678 27.12 33.7405C25.483 34.3688 25.5051 36.3062 25.2294 37.7764C25.0964 38.4859 24.4769 39 23.7551 39H22.2449C21.5231 39 20.9036 38.4859 20.7706 37.7764C20.4949 36.3062 20.517 34.3688 18.88 33.7405C18.6908 33.6678 18.5039 33.5903 18.3196 33.5081C16.7179 32.7936 15.3625 34.1804 14.1279 35.0251C13.5322 35.4327 12.7307 35.3582 12.2203 34.8478L11.1524 33.7799C10.642 33.2695 10.5675 32.4679 10.9751 31.8722C11.8198 30.6376 13.2067 29.2822 12.4922 27.6804C12.41 27.4962 12.3325 27.3093 12.2599 27.1201C11.6315 25.483 9.69392 25.5051 8.22357 25.2294C7.51411 25.0964 7 24.4769 7 23.7551V22.2449C7 21.5231 7.51411 20.9036 8.22357 20.7706C9.69394 20.4949 11.6317 20.5171 12.2602 18.88C12.3328 18.6909 12.4103 18.5042 12.4924 18.3201C13.207 16.7181 11.8198 15.3625 10.975 14.1278C10.5674 13.5321 10.6419 12.7305 11.1523 12.2201L12.2202 11.1522C12.7306 10.6418 13.5322 10.5673 14.1279 10.9749C15.3626 11.8197 16.7184 13.2071 18.3204 12.4925C18.5044 12.4105 18.6909 12.3331 18.8799 12.2606C20.5171 11.6321 20.4949 9.69403 20.7706 8.22357Z"
      fill="#906EF7"
      stroke="white"
      stroke-width="2"
    />
    <circle cx="23" cy="23" r="6" fill="#794CFF" stroke="white" stroke-width="2" />
    <circle cx="41" cy="41" r="4" fill="#794CFF" stroke="white" stroke-width="2" />
  </g>
  <defs>
    <clipPath id="1">
      <rect width="60" height="60" fill="white" />
    </clipPath>
  </defs>
</svg> `,m2=B`<svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 40 40" fill="none">
  <g clip-path="url(#clip0_187_29)">
    <path d="M1.18187e-05 15.8055C1.18187e-05 9.8015 -5.19442e-07 6.91338 1.69991e-08 0C4.5 3.72236e-05 9.62249 0 16.5 0L23.5 4.31399e-05C29.9349 4.31399e-05 35.5 0.000206332 40 3.73468e-05C40 2.77754 40 9.36708 40 15.8055V22.8364C40 29.2647 40 33.7962 40 40C31.5 40 29.8337 40 23.4 40H16.6C10.5092 40 6.50004 40 4.04289e-05 40C3.05176e-05 32.2453 1.18187e-05 29.6382 1.18187e-05 22.8364V15.8055Z" fill="#0052FF"/>
    <path d="M20.0236 26.5C16.4342 26.5 13.5236 23.5931 13.5236 20C13.5236 16.4069 16.4342 13.5 20.0236 13.5C23.2411 13.5 25.9134 15.8472 26.4261 18.9167H32.9731C32.4206 12.2433 26.8342 7 20.02 7C12.8411 7 7.02002 12.8211 7.02002 20C7.02002 27.1789 12.8411 33 20.02 33C26.8342 33 32.4206 27.7567 32.9731 21.0833H26.4225C25.9061 24.1528 23.2411 26.5 20.0236 26.5Z" fill="white"/>
  </g>
  <defs>
    <clipPath id="clip0_187_29">
      <rect width="40" height="40" fill="white"/>
    </clipPath>
  </defs>
</svg>`,w2=B`
  <svg width="40" height="40" fill="none" xmlns="http://www.w3.org/2000/svg">
    <g clip-path="url(#a)">
      <path
        d="M0 16.6c0-6.168 0-9.251 1.314-11.555a10 10 0 0 1 3.731-3.731C7.35 0 10.432 0 16.6 0h6.8c6.168 0 9.252 0 11.555 1.314a10 10 0 0 1 3.731 3.731C40 7.35 40 10.432 40 16.6v6.8c0 6.168 0 9.252-1.314 11.555a10 10 0 0 1-3.731 3.731C32.652 40 29.568 40 23.4 40h-6.8c-6.168 0-9.251 0-11.555-1.314a10 10 0 0 1-3.731-3.731C0 32.652 0 29.568 0 23.4v-6.8Z"
        fill="#7D00FF"
      />
      <path
        d="M.5 16.6c0-3.093 0-5.38.162-7.182.161-1.795.48-3.061 1.086-4.125a9.5 9.5 0 0 1 3.545-3.545C6.357 1.141 7.623.823 9.418.662 11.221.5 13.508.5 16.6.5h6.8c3.093 0 5.38 0 7.182.162 1.795.161 3.062.48 4.125 1.086a9.5 9.5 0 0 1 3.545 3.545c.607 1.064.925 2.33 1.086 4.125.161 1.803.162 4.09.162 7.182v6.8c0 3.093 0 5.38-.162 7.182-.161 1.795-.48 3.062-1.086 4.125a9.5 9.5 0 0 1-3.545 3.545c-1.063.607-2.33.925-4.125 1.086-1.803.161-4.09.162-7.182.162h-6.8c-3.093 0-5.38 0-7.182-.162-1.795-.161-3.061-.48-4.125-1.086a9.5 9.5 0 0 1-3.545-3.545c-.607-1.063-.925-2.33-1.086-4.125C.5 28.779.5 26.492.5 23.4v-6.8Z"
        stroke="#fff"
        stroke-opacity=".05"
      />
      <path
        d="M28.306 15.381a3.69 3.69 0 1 0 0-7.381 3.69 3.69 0 0 0 0 7.381ZM16.987 32a8.991 8.991 0 1 1 .016-17.983A8.991 8.991 0 0 1 16.988 32Z"
        fill="#fff"
      />
    </g>
    <defs>
      <clipPath id="a"><path fill="#fff" d="M0 0h40v40H0z" /></clipPath>
    </defs>
  </svg>
`,b2=B`
  <svg width="40" height="40" fill="none" xmlns="http://www.w3.org/2000/svg">
    <g clip-path="url(#a)">
      <path
        d="M0 16.6c0-6.168 0-9.251 1.314-11.555a10 10 0 0 1 3.731-3.731C7.35 0 10.432 0 16.6 0h6.8c6.168 0 9.252 0 11.555 1.314a10 10 0 0 1 3.731 3.731C40 7.35 40 10.432 40 16.6v6.8c0 6.168 0 9.252-1.314 11.555a10 10 0 0 1-3.731 3.731C32.652 40 29.568 40 23.4 40h-6.8c-6.168 0-9.251 0-11.555-1.314a10 10 0 0 1-3.731-3.731C0 32.652 0 29.568 0 23.4v-6.8Z"
        fill="#635BFF"
      />
      <path
        d="M.5 16.6c0-3.093 0-5.38.162-7.182.161-1.795.48-3.061 1.086-4.125a9.5 9.5 0 0 1 3.545-3.545C6.357 1.141 7.623.823 9.418.662 11.221.5 13.508.5 16.6.5h6.8c3.093 0 5.38 0 7.182.162 1.795.161 3.062.48 4.125 1.086a9.5 9.5 0 0 1 3.545 3.545c.607 1.064.925 2.33 1.086 4.125.161 1.803.162 4.09.162 7.182v6.8c0 3.093 0 5.38-.162 7.182-.161 1.795-.48 3.062-1.086 4.125a9.5 9.5 0 0 1-3.545 3.545c-1.063.607-2.33.925-4.125 1.086-1.803.161-4.09.162-7.182.162h-6.8c-3.093 0-5.38 0-7.182-.162-1.795-.161-3.061-.48-4.125-1.086a9.5 9.5 0 0 1-3.545-3.545c-.607-1.063-.925-2.33-1.086-4.125C.5 28.779.5 26.492.5 23.4v-6.8Z"
        stroke="#fff"
        stroke-opacity=".05"
      />
      <path
        fill-rule="evenodd"
        clip-rule="evenodd"
        d="M18.299 15.147c0-1.028.844-1.424 2.242-1.424 2.004 0 4.536.607 6.54 1.688V9.213C24.892 8.343 22.73 8 20.541 8c-5.354 0-8.915 2.796-8.915 7.464 0 7.279 10.022 6.118 10.022 9.257 0 1.213-1.055 1.609-2.531 1.609-2.19 0-4.985-.897-7.2-2.11v6.277a18.283 18.283 0 0 0 7.2 1.503c5.485 0 9.257-2.716 9.257-7.437-.027-7.86-10.075-6.462-10.075-9.416Z"
        fill="#fff"
      />
    </g>
    <defs>
      <clipPath id="a"><path fill="#fff" d="M0 0h40v40H0z" /></clipPath>
    </defs>
  </svg>
`,v2=B`
  <svg width="40" height="40" fill="none" xmlns="http://www.w3.org/2000/svg">
    <g clip-path="url(#a)">
      <path
        d="M0 16.6c0-6.168 0-9.251 1.314-11.555a10 10 0 0 1 3.731-3.731C7.35 0 10.432 0 16.6 0h6.8c6.168 0 9.252 0 11.555 1.314a10 10 0 0 1 3.731 3.731C40 7.35 40 10.432 40 16.6v6.8c0 6.168 0 9.252-1.314 11.555a10 10 0 0 1-3.731 3.731C32.652 40 29.568 40 23.4 40h-6.8c-6.168 0-9.251 0-11.555-1.314a10 10 0 0 1-3.731-3.731C0 32.652 0 29.568 0 23.4v-6.8Z"
        fill="#fff"
      />
      <path
        d="M.5 16.6c0-3.093 0-5.38.162-7.182.161-1.795.48-3.061 1.086-4.125a9.5 9.5 0 0 1 3.545-3.545C6.357 1.141 7.623.823 9.418.662 11.221.5 13.508.5 16.6.5h6.8c3.093 0 5.38 0 7.182.162 1.795.161 3.062.48 4.125 1.086a9.5 9.5 0 0 1 3.545 3.545c.607 1.064.925 2.33 1.086 4.125.161 1.803.162 4.09.162 7.182v6.8c0 3.093 0 5.38-.162 7.182-.161 1.795-.48 3.062-1.086 4.125a9.5 9.5 0 0 1-3.545 3.545c-1.063.607-2.33.925-4.125 1.086-1.803.161-4.09.162-7.182.162h-6.8c-3.093 0-5.38 0-7.182-.162-1.795-.161-3.061-.48-4.125-1.086a9.5 9.5 0 0 1-3.545-3.545c-.607-1.063-.925-2.33-1.086-4.125C.5 28.779.5 26.492.5 23.4v-6.8Z"
        stroke="#fff"
        stroke-opacity=".05"
      />
      <path
        d="M18.606 12.642a.781.781 0 0 0-.771.66l-1.281 8.125a.78.78 0 0 1 .77-.66h3.755a7.668 7.668 0 0 0 7.57-6.49 6.26 6.26 0 0 0 .075-.843c-.96-.504-2.089-.792-3.325-.792h-6.793Z"
        fill="#001C64"
      />
      <path
        d="M28.724 13.434c-.006.282-.03.564-.075.843a7.668 7.668 0 0 1-7.57 6.491h-3.754a.78.78 0 0 0-.771.66l-1.916 12.15a.634.634 0 0 0 .626.734h4.075a.781.781 0 0 0 .77-.66l1.074-6.807a.781.781 0 0 1 .772-.66h2.4a7.668 7.668 0 0 0 7.57-6.491c.415-2.651-.92-5.064-3.201-6.26Z"
        fill="#0070E0"
      />
      <path
        d="M13.977 7.226a.78.78 0 0 0-.771.658l-3.198 20.277a.634.634 0 0 0 .626.733h4.742l1.178-7.467 1.281-8.125a.782.782 0 0 1 .771-.66H25.4c1.237 0 2.364.289 3.325.792.065-3.4-2.74-6.208-6.599-6.208h-8.148Z"
        fill="#003087"
      />
    </g>
    <defs>
      <clipPath id="a"><path fill="#fff" d="M0 0h40v40H0z" /></clipPath>
    </defs>
  </svg>
`,y2=B`<svg width="60" height="60" viewBox="0 0 60 60" fill="none">
<g clip-path="url(#clip0_13859_31161)">
  <path d="M0 24.8995C0 15.6481 0 11.0223 1.97053 7.56763C3.3015 5.2342 5.23468 3.30101 7.56812 1.97004C11.0228 -0.000488281 15.6485 -0.000488281 24.9 -0.000488281H35.1C44.3514 -0.000488281 48.9772 -0.000488281 52.4319 1.97004C54.7653 3.30101 56.6985 5.2342 58.0295 7.56763C60 11.0223 60 15.6481 60 24.8995V35.0995C60 44.351 60 48.9767 58.0295 52.4314C56.6985 54.7648 54.7653 56.698 52.4319 58.029C48.9772 59.9995 44.3514 59.9995 35.1 59.9995H24.9C15.6485 59.9995 11.0228 59.9995 7.56812 58.029C5.23468 56.698 3.3015 54.7648 1.97053 52.4314C0 48.9767 0 44.351 0 35.0995V24.8995Z" fill="#EB8B47"/>
  <path d="M0.5 24.8995C0.5 20.2647 0.50047 16.8216 0.744315 14.1045C0.987552 11.3941 1.46987 9.45455 2.40484 7.81536C3.69145 5.55971 5.56019 3.69096 7.81585 2.40435C9.45504 1.46938 11.3946 0.987064 14.105 0.743826C16.8221 0.499981 20.2652 0.499512 24.9 0.499512H35.1C39.7348 0.499512 43.1779 0.499981 45.895 0.743826C48.6054 0.987064 50.545 1.46938 52.1841 2.40435C54.4398 3.69096 56.3086 5.55971 57.5952 7.81536C58.5301 9.45455 59.0124 11.3941 59.2557 14.1045C59.4995 16.8216 59.5 20.2647 59.5 24.8995V35.0995C59.5 39.7343 59.4995 43.1774 59.2557 45.8945C59.0124 48.6049 58.5301 50.5445 57.5952 52.1837C56.3086 54.4393 54.4398 56.3081 52.1841 57.5947C50.545 58.5296 48.6054 59.012 45.895 59.2552C43.1779 59.499 39.7348 59.4995 35.1 59.4995H24.9C20.2652 59.4995 16.8221 59.499 14.105 59.2552C11.3946 59.012 9.45504 58.5296 7.81585 57.5947C5.56019 56.3081 3.69145 54.4393 2.40484 52.1837C1.46987 50.5445 0.987552 48.6049 0.744315 45.8945C0.50047 43.1774 0.5 39.7343 0.5 35.0995V24.8995Z" stroke="#141414" stroke-opacity="0.1"/>
  <path d="M13 26.0335C13 21.7838 13 19.659 14.0822 18.1694C14.4318 17.6883 14.8548 17.2653 15.3359 16.9157C16.8255 15.8335 18.9503 15.8335 23.2 15.8335H36.8C41.0497 15.8335 43.1745 15.8335 44.6641 16.9157C45.1452 17.2653 45.5682 17.6883 45.9178 18.1694C47 19.659 47 21.7838 47 26.0335V33.9668C47 38.2165 47 40.3414 45.9178 41.831C45.5682 42.312 45.1452 42.7351 44.6641 43.0846C43.1745 44.1668 41.0497 44.1668 36.8 44.1668H23.2C18.9503 44.1668 16.8255 44.1668 15.3359 43.0846C14.8548 42.7351 14.4318 42.312 14.0822 41.831C13 40.3414 13 38.2165 13 33.9668V26.0335Z" fill="#FF974C" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
  <path d="M39.5 36.667H36.6666" stroke="white" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/>
  <path d="M45.2 23.0645H14.8C14.0501 23.0645 13.6751 23.0645 13.4122 23.2554C13.3273 23.3171 13.2527 23.3918 13.191 23.4767C13 23.7395 13 24.1145 13 24.8645V27.2645C13 28.0144 13 28.3894 13.191 28.6522C13.2527 28.7371 13.3273 28.8118 13.4122 28.8735C13.6751 29.0645 14.0501 29.0645 14.8 29.0645H45.2C45.9499 29.0645 46.3249 29.0645 46.5878 28.8735C46.6727 28.8118 46.7473 28.7371 46.809 28.6522C47 28.3894 47 28.0144 47 27.2645V24.8645C47 24.1145 47 23.7395 46.809 23.4767C46.7473 23.3918 46.6727 23.3171 46.5878 23.2554C46.3249 23.0645 45.9499 23.0645 45.2 23.0645Z" fill="white" fill-opacity="0.4" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</g>
<defs>
  <clipPath id="clip0_13859_31161">
    <rect width="60" height="60" fill="white"/>
  </clipPath>
</defs>
</svg>`,x2=Z`
  :host {
    display: block;
    width: var(--local-size);
    height: var(--local-size);
  }

  :host svg {
    width: 100%;
    height: 100%;
  }
`;var zl=function(n,e,t,i){var o=arguments.length,r=o<3?e:i===null?i=Object.getOwnPropertyDescriptor(e,t):i,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")r=Reflect.decorate(n,e,t,i);else for(var a=n.length-1;a>=0;a--)(s=n[a])&&(r=(o<3?s(r):o>3?s(e,t,r):s(e,t))||r);return o>3&&r&&Object.defineProperty(e,t,r),r};const C2={browser:i2,dao:r2,defi:o2,defiAlt:s2,eth:a2,layers:c2,lock:l2,login:u2,network:d2,nft:h2,noun:p2,profile:f2,system:g2,coinbase:m2,onrampCard:y2,moonpay:w2,stripe:b2,paypal:v2};let yr=class extends q{constructor(){super(...arguments),this.name="browser",this.size="md"}render(){return this.style.cssText=`
       --local-size: var(--wui-visual-size-${this.size});
   `,P`${C2[this.name]}`}};yr.styles=[Q,x2];zl([v()],yr.prototype,"name",void 0);zl([v()],yr.prototype,"size",void 0);yr=zl([k("wui-visual")],yr);/**
 * @license
 * Copyright 2018 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const Et=n=>n??Le,ye={getSpacingStyles(n,e){if(Array.isArray(n))return n[e]?`var(--wui-spacing-${n[e]})`:void 0;if(typeof n=="string")return`var(--wui-spacing-${n})`},getFormattedDate(n){return new Intl.DateTimeFormat("en-US",{month:"short",day:"numeric"}).format(n)},getHostName(n){return new URL(n).hostname},getTruncateString({string:n,charsStart:e,charsEnd:t,truncate:i}){return n.length<=e+t?n:i==="end"?`${n.substring(0,e)}...`:i==="start"?`...${n.substring(n.length-t)}`:`${n.substring(0,Math.floor(e))}...${n.substring(n.length-Math.floor(t))}`},generateAvatarColors(n){const t=n.toLowerCase().replace(/^0x/iu,"").substring(0,6),i=this.hexToRgb(t),o=getComputedStyle(document.documentElement).getPropertyValue("--w3m-border-radius-master"),s=100-3*Number(o==null?void 0:o.replace("px","")),a=`${s}% ${s}% at 65% 40%`,c=[];for(let u=0;u<5;u+=1){const h=this.tintColor(i,.15*u);c.push(`rgb(${h[0]}, ${h[1]}, ${h[2]})`)}return`
    --local-color-1: ${c[0]};
    --local-color-2: ${c[1]};
    --local-color-3: ${c[2]};
    --local-color-4: ${c[3]};
    --local-color-5: ${c[4]};
    --local-radial-circle: ${a}
   `},hexToRgb(n){const e=parseInt(n,16),t=e>>16&255,i=e>>8&255,o=e&255;return[t,i,o]},tintColor(n,e){const[t,i,o]=n,r=Math.round(t+(255-t)*e),s=Math.round(i+(255-i)*e),a=Math.round(o+(255-o)*e);return[r,s,a]},isNumber(n){return{number:/^[0-9]+$/u}.number.test(n)},getColorTheme(n){return n||(typeof window<"u"&&window.matchMedia?window.matchMedia("(prefers-color-scheme: dark)").matches?"dark":"light":"dark")}},_2=Z`
  :host {
    display: flex;
    width: inherit;
    height: inherit;
  }
`;var yt=function(n,e,t,i){var o=arguments.length,r=o<3?e:i===null?i=Object.getOwnPropertyDescriptor(e,t):i,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")r=Reflect.decorate(n,e,t,i);else for(var a=n.length-1;a>=0;a--)(s=n[a])&&(r=(o<3?s(r):o>3?s(e,t,r):s(e,t))||r);return o>3&&r&&Object.defineProperty(e,t,r),r};let qe=class extends q{render(){return this.style.cssText=`
      flex-direction: ${this.flexDirection};
      flex-wrap: ${this.flexWrap};
      flex-basis: ${this.flexBasis};
      flex-grow: ${this.flexGrow};
      flex-shrink: ${this.flexShrink};
      align-items: ${this.alignItems};
      justify-content: ${this.justifyContent};
      column-gap: ${this.columnGap&&`var(--wui-spacing-${this.columnGap})`};
      row-gap: ${this.rowGap&&`var(--wui-spacing-${this.rowGap})`};
      gap: ${this.gap&&`var(--wui-spacing-${this.gap})`};
      padding-top: ${this.padding&&ye.getSpacingStyles(this.padding,0)};
      padding-right: ${this.padding&&ye.getSpacingStyles(this.padding,1)};
      padding-bottom: ${this.padding&&ye.getSpacingStyles(this.padding,2)};
      padding-left: ${this.padding&&ye.getSpacingStyles(this.padding,3)};
      margin-top: ${this.margin&&ye.getSpacingStyles(this.margin,0)};
      margin-right: ${this.margin&&ye.getSpacingStyles(this.margin,1)};
      margin-bottom: ${this.margin&&ye.getSpacingStyles(this.margin,2)};
      margin-left: ${this.margin&&ye.getSpacingStyles(this.margin,3)};
    `,P`<slot></slot>`}};qe.styles=[Q,_2];yt([v()],qe.prototype,"flexDirection",void 0);yt([v()],qe.prototype,"flexWrap",void 0);yt([v()],qe.prototype,"flexBasis",void 0);yt([v()],qe.prototype,"flexGrow",void 0);yt([v()],qe.prototype,"flexShrink",void 0);yt([v()],qe.prototype,"alignItems",void 0);yt([v()],qe.prototype,"justifyContent",void 0);yt([v()],qe.prototype,"columnGap",void 0);yt([v()],qe.prototype,"rowGap",void 0);yt([v()],qe.prototype,"gap",void 0);yt([v()],qe.prototype,"padding",void 0);yt([v()],qe.prototype,"margin",void 0);qe=yt([k("wui-flex")],qe);const E2=Z`
  :host {
    display: block;
    width: var(--wui-icon-box-size-xl);
    height: var(--wui-icon-box-size-xl);
    border-radius: var(--wui-border-radius-3xl);
    box-shadow: 0 0 0 8px var(--wui-gray-glass-005);
    overflow: hidden;
    position: relative;
  }

  :host([data-variant='generated']) {
    --mixed-local-color-1: var(--local-color-1);
    --mixed-local-color-2: var(--local-color-2);
    --mixed-local-color-3: var(--local-color-3);
    --mixed-local-color-4: var(--local-color-4);
    --mixed-local-color-5: var(--local-color-5);
  }

  @supports (background: color-mix(in srgb, white 50%, black)) {
    :host([data-variant='generated']) {
      --mixed-local-color-1: color-mix(
        in srgb,
        var(--w3m-color-mix) var(--w3m-color-mix-strength),
        var(--local-color-1)
      );
      --mixed-local-color-2: color-mix(
        in srgb,
        var(--w3m-color-mix) var(--w3m-color-mix-strength),
        var(--local-color-2)
      );
      --mixed-local-color-3: color-mix(
        in srgb,
        var(--w3m-color-mix) var(--w3m-color-mix-strength),
        var(--local-color-3)
      );
      --mixed-local-color-4: color-mix(
        in srgb,
        var(--w3m-color-mix) var(--w3m-color-mix-strength),
        var(--local-color-4)
      );
      --mixed-local-color-5: color-mix(
        in srgb,
        var(--w3m-color-mix) var(--w3m-color-mix-strength),
        var(--local-color-5)
      );
    }
  }

  :host([data-variant='generated']) {
    box-shadow: 0 0 0 8px var(--wui-gray-glass-005);
    background: radial-gradient(
      var(--local-radial-circle),
      #fff 0.52%,
      var(--mixed-local-color-5) 31.25%,
      var(--mixed-local-color-3) 51.56%,
      var(--mixed-local-color-2) 65.63%,
      var(--mixed-local-color-1) 82.29%,
      var(--mixed-local-color-4) 100%
    );
  }

  :host([data-variant='default']) {
    box-shadow: 0 0 0 8px var(--wui-gray-glass-005);
    background: radial-gradient(
      75.29% 75.29% at 64.96% 24.36%,
      #fff 0.52%,
      #f5ccfc 31.25%,
      #dba4f5 51.56%,
      #9a8ee8 65.63%,
      #6493da 82.29%,
      #6ebdea 100%
    );
  }
`;var Pa=function(n,e,t,i){var o=arguments.length,r=o<3?e:i===null?i=Object.getOwnPropertyDescriptor(e,t):i,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")r=Reflect.decorate(n,e,t,i);else for(var a=n.length-1;a>=0;a--)(s=n[a])&&(r=(o<3?s(r):o>3?s(e,t,r):s(e,t))||r);return o>3&&r&&Object.defineProperty(e,t,r),r};let $i=class extends q{constructor(){super(...arguments),this.imageSrc=void 0,this.alt=void 0,this.address=void 0}render(){return P`${this.visualTemplate()}`}visualTemplate(){if(this.imageSrc)return this.dataset.variant="image",P`<wui-image src=${this.imageSrc} alt=${this.alt??"avatar"}></wui-image>`;if(this.address){this.dataset.variant="generated";const e=ye.generateAvatarColors(this.address);return this.style.cssText=e,null}return this.dataset.variant="default",null}};$i.styles=[Q,E2];Pa([v()],$i.prototype,"imageSrc",void 0);Pa([v()],$i.prototype,"alt",void 0);Pa([v()],$i.prototype,"address",void 0);$i=Pa([k("wui-avatar")],$i);const $2=Z`
  :host {
    display: inline-flex;
    justify-content: center;
    align-items: center;
    position: relative;
    overflow: hidden;
    background-color: var(--wui-gray-glass-020);
    border-radius: var(--local-border-radius);
    border: var(--local-border);
    box-sizing: content-box;
    width: var(--local-size);
    height: var(--local-size);
    min-height: var(--local-size);
    min-width: var(--local-size);
  }

  @supports (background: color-mix(in srgb, white 50%, black)) {
    :host {
      background-color: color-mix(in srgb, var(--local-bg-value) var(--local-bg-mix), transparent);
    }
  }
`;var In=function(n,e,t,i){var o=arguments.length,r=o<3?e:i===null?i=Object.getOwnPropertyDescriptor(e,t):i,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")r=Reflect.decorate(n,e,t,i);else for(var a=n.length-1;a>=0;a--)(s=n[a])&&(r=(o<3?s(r):o>3?s(e,t,r):s(e,t))||r);return o>3&&r&&Object.defineProperty(e,t,r),r};let $t=class extends q{constructor(){super(...arguments),this.size="md",this.backgroundColor="accent-100",this.iconColor="accent-100",this.background="transparent",this.border=!1,this.borderColor="wui-color-bg-125",this.icon="copy"}render(){const e=this.iconSize||this.size,t=this.size==="lg",i=this.size==="xl",o=t?"12%":"16%",r=t?"xxs":i?"s":"3xl",s=this.background==="gray",a=this.background==="opaque",c=this.backgroundColor==="accent-100"&&a||this.backgroundColor==="success-100"&&a||this.backgroundColor==="error-100"&&a||this.backgroundColor==="inverse-100"&&a;let u=`var(--wui-color-${this.backgroundColor})`;return c?u=`var(--wui-icon-box-bg-${this.backgroundColor})`:s&&(u=`var(--wui-gray-${this.backgroundColor})`),this.style.cssText=`
       --local-bg-value: ${u};
       --local-bg-mix: ${c||s?"100%":o};
       --local-border-radius: var(--wui-border-radius-${r});
       --local-size: var(--wui-icon-box-size-${this.size});
       --local-border: ${this.borderColor==="wui-color-bg-125"?"2px":"1px"} solid ${this.border?`var(--${this.borderColor})`:"transparent"}
   `,P` <wui-icon color=${this.iconColor} size=${e} name=${this.icon}></wui-icon> `}};$t.styles=[Q,$e,$2];In([v()],$t.prototype,"size",void 0);In([v()],$t.prototype,"backgroundColor",void 0);In([v()],$t.prototype,"iconColor",void 0);In([v()],$t.prototype,"iconSize",void 0);In([v()],$t.prototype,"background",void 0);In([v({type:Boolean})],$t.prototype,"border",void 0);In([v()],$t.prototype,"borderColor",void 0);In([v()],$t.prototype,"icon",void 0);$t=In([k("wui-icon-box")],$t);const A2=Z`
  :host {
    display: block;
  }

  button {
    border-radius: var(--wui-border-radius-3xl);
    background: var(--wui-gray-glass-002);
    display: flex;
    gap: var(--wui-spacing-xs);
    padding: var(--wui-spacing-3xs) var(--wui-spacing-xs) var(--wui-spacing-3xs)
      var(--wui-spacing-xs);
    border: 1px solid var(--wui-gray-glass-005);
  }

  button:disabled {
    background: var(--wui-gray-glass-015);
  }

  button:disabled > wui-text {
    color: var(--wui-gray-glass-015);
  }

  button:disabled > wui-flex > wui-text {
    color: var(--wui-gray-glass-015);
  }

  button:disabled > wui-image,
  button:disabled > wui-icon-box,
  button:disabled > wui-flex > wui-avatar {
    filter: grayscale(1);
  }

  button:has(wui-image) {
    padding: var(--wui-spacing-3xs) var(--wui-spacing-3xs) var(--wui-spacing-3xs)
      var(--wui-spacing-xs);
  }

  wui-text {
    color: var(--wui-color-fg-100);
  }

  wui-flex > wui-text {
    color: var(--wui-color-fg-200);
    transition: all var(--wui-ease-out-power-1) var(--wui-duration-lg);
  }

  wui-image,
  wui-icon-box {
    border-radius: var(--wui-border-radius-3xl);
    width: 24px;
    height: 24px;
    box-shadow: 0 0 0 2px var(--wui-gray-glass-005);
  }

  wui-flex {
    border-radius: var(--wui-border-radius-3xl);
    border: 1px solid var(--wui-gray-glass-005);
    background: var(--wui-gray-glass-005);
    padding: 4px var(--wui-spacing-m) 4px var(--wui-spacing-xxs);
  }

  button.local-no-balance {
    border-radius: 0px;
    border: none;
    background: transparent;
  }

  wui-avatar {
    width: 20px;
    height: 20px;
    box-shadow: 0 0 0 2px var(--wui-accent-glass-010);
  }

  @media (max-width: 500px) {
    button {
      gap: 0px;
      padding: var(--wui-spacing-3xs) var(--wui-spacing-xs) !important;
      height: 32px;
    }
    wui-image,
    wui-icon-box,
    button > wui-text {
      visibility: hidden;
      width: 0px;
      height: 0px;
    }
    button {
      border-radius: 0px;
      border: none;
      background: transparent;
      padding: 0px;
    }
  }

  @media (hover: hover) and (pointer: fine) {
    button:hover:enabled > wui-flex > wui-text {
      color: var(--wui-color-fg-175);
    }

    button:active:enabled > wui-flex > wui-text {
      color: var(--wui-color-fg-175);
    }
  }
`;var dn=function(n,e,t,i){var o=arguments.length,r=o<3?e:i===null?i=Object.getOwnPropertyDescriptor(e,t):i,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")r=Reflect.decorate(n,e,t,i);else for(var a=n.length-1;a>=0;a--)(s=n[a])&&(r=(o<3?s(r):o>3?s(e,t,r):s(e,t))||r);return o>3&&r&&Object.defineProperty(e,t,r),r};let gt=class extends q{constructor(){super(...arguments),this.networkSrc=void 0,this.avatarSrc=void 0,this.balance=void 0,this.isUnsupportedChain=void 0,this.disabled=!1,this.isProfileName=!1,this.address="",this.charsStart=4,this.charsEnd=6}render(){return P`
      <button
        ?disabled=${this.disabled}
        class=${Et(this.balance?void 0:"local-no-balance")}
      >
        ${this.balanceTemplate()}
        <wui-flex gap="xxs" alignItems="center">
          <wui-avatar
            .imageSrc=${this.avatarSrc}
            alt=${this.address}
            address=${this.address}
          ></wui-avatar>
          <wui-text variant="paragraph-600" color="inherit">
            ${ye.getTruncateString({string:this.address,charsStart:this.isProfileName?18:this.charsStart,charsEnd:this.isProfileName?0:this.charsEnd,truncate:this.isProfileName?"end":"middle"})}
          </wui-text>
        </wui-flex>
      </button>
    `}balanceTemplate(){if(this.isUnsupportedChain)return P` <wui-icon-box
          size="sm"
          iconColor="error-100"
          backgroundColor="error-100"
          icon="warningCircle"
        ></wui-icon-box>
        <wui-text variant="paragraph-600" color="inherit"> Switch Network</wui-text>`;if(this.balance){const e=this.networkSrc?P`<wui-image src=${this.networkSrc}></wui-image>`:P`
            <wui-icon-box
              size="sm"
              iconColor="fg-200"
              backgroundColor="fg-300"
              icon="networkPlaceholder"
            ></wui-icon-box>
          `;return P`
        ${e}
        <wui-text variant="paragraph-600" color="inherit"> ${this.balance} </wui-text>
      `}return null}};gt.styles=[Q,$e,A2];dn([v()],gt.prototype,"networkSrc",void 0);dn([v()],gt.prototype,"avatarSrc",void 0);dn([v()],gt.prototype,"balance",void 0);dn([v({type:Boolean})],gt.prototype,"isUnsupportedChain",void 0);dn([v({type:Boolean})],gt.prototype,"disabled",void 0);dn([v({type:Boolean})],gt.prototype,"isProfileName",void 0);dn([v()],gt.prototype,"address",void 0);dn([v()],gt.prototype,"charsStart",void 0);dn([v()],gt.prototype,"charsEnd",void 0);gt=dn([k("wui-account-button")],gt);const S2=Z`
  :host {
    position: relative;
    background-color: var(--wui-gray-glass-002);
    display: flex;
    justify-content: center;
    align-items: center;
    width: var(--local-size);
    height: var(--local-size);
    border-radius: inherit;
    border-radius: var(--local-border-radius);
  }

  :host > wui-flex {
    overflow: hidden;
    border-radius: inherit;
    border-radius: var(--local-border-radius);
  }

  :host::after {
    content: '';
    position: absolute;
    top: 0;
    bottom: 0;
    left: 0;
    right: 0;
    border-radius: inherit;
    border: 1px solid var(--wui-gray-glass-010);
    pointer-events: none;
  }

  :host([name='Extension'])::after {
    border: 1px solid var(--wui-accent-glass-010);
  }

  :host([data-wallet-icon='allWallets']) {
    background-color: var(--wui-all-wallets-bg-100);
  }

  :host([data-wallet-icon='allWallets'])::after {
    border: 1px solid var(--wui-accent-glass-010);
  }

  wui-icon[data-parent-size='inherit'] {
    width: 75%;
    height: 75%;
    align-items: center;
  }

  wui-icon[data-parent-size='sm'] {
    width: 18px;
    height: 18px;
  }

  wui-icon[data-parent-size='md'] {
    width: 24px;
    height: 24px;
  }

  wui-icon[data-parent-size='lg'] {
    width: 42px;
    height: 42px;
  }

  wui-icon[data-parent-size='full'] {
    width: 100%;
    height: 100%;
  }

  :host > wui-icon-box {
    position: absolute;
    overflow: hidden;
    right: -1px;
    bottom: -2px;
    z-index: 1;
    border: 2px solid var(--wui-color-bg-base-150, #1e1f1f);
    padding: 1px;
  }
`;var Fi=function(n,e,t,i){var o=arguments.length,r=o<3?e:i===null?i=Object.getOwnPropertyDescriptor(e,t):i,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")r=Reflect.decorate(n,e,t,i);else for(var a=n.length-1;a>=0;a--)(s=n[a])&&(r=(o<3?s(r):o>3?s(e,t,r):s(e,t))||r);return o>3&&r&&Object.defineProperty(e,t,r),r};let tn=class extends q{constructor(){super(...arguments),this.size="md",this.name="",this.installed=!1,this.badgeSize="xs"}render(){let e="xxs";return this.size==="lg"?e="m":this.size==="md"?e="xs":e="xxs",this.style.cssText=`
       --local-border-radius: var(--wui-border-radius-${e});
       --local-size: var(--wui-wallet-image-size-${this.size});
   `,this.walletIcon&&(this.dataset.walletIcon=this.walletIcon),P`
      <wui-flex justifyContent="center" alignItems="center"> ${this.templateVisual()} </wui-flex>
    `}templateVisual(){return this.imageSrc?P`<wui-image src=${this.imageSrc} alt=${this.name}></wui-image>`:this.walletIcon?P`<wui-icon
        data-parent-size="md"
        size="md"
        color="inherit"
        name=${this.walletIcon}
      ></wui-icon>`:P`<wui-icon
      data-parent-size=${this.size}
      size="inherit"
      color="inherit"
      name="walletPlaceholder"
    ></wui-icon>`}};tn.styles=[Q,S2];Fi([v()],tn.prototype,"size",void 0);Fi([v()],tn.prototype,"name",void 0);Fi([v()],tn.prototype,"imageSrc",void 0);Fi([v()],tn.prototype,"walletIcon",void 0);Fi([v({type:Boolean})],tn.prototype,"installed",void 0);Fi([v()],tn.prototype,"badgeSize",void 0);tn=Fi([k("wui-wallet-image")],tn);const I2=Z`
  :host {
    position: relative;
    border-radius: var(--wui-border-radius-xxs);
    width: 40px;
    height: 40px;
    overflow: hidden;
    background: var(--wui-gray-glass-002);
    display: flex;
    justify-content: center;
    align-items: center;
    flex-wrap: wrap;
    gap: var(--wui-spacing-4xs);
    padding: 3.75px !important;
  }

  :host::after {
    content: '';
    position: absolute;
    top: 0;
    bottom: 0;
    left: 0;
    right: 0;
    border-radius: inherit;
    border: 1px solid var(--wui-gray-glass-010);
    pointer-events: none;
  }

  :host > wui-wallet-image {
    width: 14px;
    height: 14px;
    border-radius: var(--wui-border-radius-5xs);
  }

  :host > wui-flex {
    padding: 2px;
    position: fixed;
    overflow: hidden;
    left: 34px;
    bottom: 8px;
    background: var(--dark-background-150, #1e1f1f);
    border-radius: 50%;
    z-index: 2;
    display: flex;
  }
`;var ah=function(n,e,t,i){var o=arguments.length,r=o<3?e:i===null?i=Object.getOwnPropertyDescriptor(e,t):i,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")r=Reflect.decorate(n,e,t,i);else for(var a=n.length-1;a>=0;a--)(s=n[a])&&(r=(o<3?s(r):o>3?s(e,t,r):s(e,t))||r);return o>3&&r&&Object.defineProperty(e,t,r),r};const gc=4;let No=class extends q{constructor(){super(...arguments),this.walletImages=[]}render(){const e=this.walletImages.length<gc;return P`${this.walletImages.slice(0,gc).map(({src:t,walletName:i})=>P`
            <wui-wallet-image
              size="inherit"
              imageSrc=${t}
              name=${Et(i)}
            ></wui-wallet-image>
          `)}
      ${e?[...Array(gc-this.walletImages.length)].map(()=>P` <wui-wallet-image size="inherit" name=""></wui-wallet-image>`):null}
      <wui-flex>
        <wui-icon-box
          size="xxs"
          iconSize="xxs"
          iconcolor="success-100"
          backgroundcolor="success-100"
          icon="checkmark"
          background="opaque"
        ></wui-icon-box>
      </wui-flex>`}};No.styles=[Q,I2];ah([v({type:Array})],No.prototype,"walletImages",void 0);No=ah([k("wui-all-wallets-image")],No);const R2=Z`
  :host {
    width: var(--local-width);
    position: relative;
  }

  button {
    border: 1px solid var(--wui-gray-glass-010);
    border-radius: var(--local-border-radius);
    width: var(--local-width);
  }

  button:disabled {
    border: 1px solid var(--wui-gray-glass-010);
  }

  /* xs settings */
  button[data-size='xs'] {
    padding: var(--wui-spacing-xs) var(--wui-spacing-1xs);
  }

  button[data-size='xs'][data-icon-left='true'][data-icon-right='false'] {
    padding-left: var(--wui-spacing-xxs);
  }

  button[data-size='xs'][data-icon-right='true'][data-icon-left='false'] {
    padding-right: var(--wui-spacing-xxs);
  }

  /* sm settings */
  button[data-size='sm'] {
    padding: var(--wui-spacing-xxs) var(--wui-spacing-s);
  }

  button[data-size='sm'][data-icon-left='true'][data-icon-right='false'] {
    padding: var(--wui-spacing-xxs) var(--wui-spacing-s) var(--wui-spacing-xxs)
      var(--wui-spacing-xs);
  }

  button[data-size='sm'][data-icon-right='true'][data-icon-left='false'] {
    padding: var(--wui-spacing-xxs) var(--wui-spacing-xs) var(--wui-spacing-xxs)
      var(--wui-spacing-s);
  }

  /* md settings */
  button[data-size='md'] {
    padding: 8.2px var(--wui-spacing-l) 9px var(--wui-spacing-l);
  }

  button[data-size='md'][data-icon-left='true'][data-icon-right='false'] {
    padding: 8.2px var(--wui-spacing-l) 9px var(--wui-spacing-s);
  }

  button[data-size='md'][data-icon-right='true'][data-icon-left='false'] {
    padding: 8.2px var(--wui-spacing-s) 9px var(--wui-spacing-l);
  }

  /* lg settings */
  button[data-size='lg'] {
    padding: var(--wui-spacing-m) var(--wui-spacing-2l);
  }

  button[data-size='lg'][data-icon-left='true'][data-icon-right='false'] {
    padding-left: var(--wui-spacing-m);
  }

  button[data-size='lg'][data-icon-right='true'][data-icon-left='false'] {
    padding-right: var(--wui-spacing-m);
  }

  button > wui-text {
    transition: opacity 200ms ease-in-out;
    opacity: var(--local-opacity-100);
  }

  ::slotted(*) {
    transition: opacity 200ms ease-in-out;
    opacity: var(--local-opacity-100);
  }

  wui-loading-spinner {
    position: absolute;
    left: 50%;
    top: 50%;
    transition: all 200ms ease-in-out;
    transform: translate(-50%, -50%);
    opacity: var(--local-opacity-000);
  }
`;var hn=function(n,e,t,i){var o=arguments.length,r=o<3?e:i===null?i=Object.getOwnPropertyDescriptor(e,t):i,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")r=Reflect.decorate(n,e,t,i);else for(var a=n.length-1;a>=0;a--)(s=n[a])&&(r=(o<3?s(r):o>3?s(e,t,r):s(e,t))||r);return o>3&&r&&Object.defineProperty(e,t,r),r};const T2={xs:"small-600",sm:"paragraph-600",md:"small-600",mdl:"small-600",lg:"paragraph-600"};let mt=class extends q{constructor(){super(...arguments),this.size="md",this.disabled=!1,this.fullWidth=!1,this.loading=!1,this.variant="fill",this.hasIconLeft=!1,this.hasIconRight=!1,this.borderRadius="m"}render(){this.style.cssText=`
    --local-width: ${this.fullWidth?"100%":"auto"};
    --local-opacity-100: ${this.loading?0:1};
    --local-opacity-000: ${this.loading?1:0};
    --local-border-radius: var(--wui-border-radius-${this.borderRadius});
    `;const e=this.textVariant??T2[this.size];return P`
      <button
        data-variant=${this.variant}
        data-icon-left=${this.hasIconLeft}
        data-icon-right=${this.hasIconRight}
        data-size=${this.size}
        ?disabled=${this.disabled||this.loading}
        ontouchstart
      >
        ${this.loadingTemplate()}
        <slot name="iconLeft" @slotchange=${()=>this.handleSlotLeftChange()}></slot>
        <wui-text variant=${e} color="inherit">
          <slot></slot>
        </wui-text>
        <slot name="iconRight" @slotchange=${()=>this.handleSlotRightChange()}></slot>
      </button>
    `}handleSlotLeftChange(){this.hasIconLeft=!0}handleSlotRightChange(){this.hasIconRight=!0}loadingTemplate(){return this.loading?P`<wui-loading-spinner color="fg-300"></wui-loading-spinner>`:P``}};mt.styles=[Q,$e,R2];hn([v()],mt.prototype,"size",void 0);hn([v({type:Boolean})],mt.prototype,"disabled",void 0);hn([v({type:Boolean})],mt.prototype,"fullWidth",void 0);hn([v({type:Boolean})],mt.prototype,"loading",void 0);hn([v()],mt.prototype,"variant",void 0);hn([v({type:Boolean})],mt.prototype,"hasIconLeft",void 0);hn([v({type:Boolean})],mt.prototype,"hasIconRight",void 0);hn([v()],mt.prototype,"borderRadius",void 0);hn([v()],mt.prototype,"textVariant",void 0);mt=hn([k("wui-button")],mt);const ch=B`<svg  viewBox="0 0 48 54" fill="none">
  <path
    d="M43.4605 10.7248L28.0485 1.61089C25.5438 0.129705 22.4562 0.129705 19.9515 1.61088L4.53951 10.7248C2.03626 12.2051 0.5 14.9365 0.5 17.886V36.1139C0.5 39.0635 2.03626 41.7949 4.53951 43.2752L19.9515 52.3891C22.4562 53.8703 25.5438 53.8703 28.0485 52.3891L43.4605 43.2752C45.9637 41.7949 47.5 39.0635 47.5 36.114V17.8861C47.5 14.9365 45.9637 12.2051 43.4605 10.7248Z"
  />
</svg>`,P2=Z`
  :host {
    display: flex;
    flex-direction: column;
    align-items: center;
    width: 76px;
    row-gap: var(--wui-spacing-xs);
    padding: var(--wui-spacing-xs) 10px;
    background-color: var(--wui-gray-glass-002);
    border-radius: clamp(0px, var(--wui-border-radius-xs), 20px);
    position: relative;
  }

  wui-shimmer[data-type='network'] {
    border: none;
    -webkit-clip-path: var(--wui-path-network);
    clip-path: var(--wui-path-network);
  }

  svg {
    position: absolute;
    width: 48px;
    height: 54px;
    z-index: 1;
  }

  svg > path {
    stroke: var(--wui-gray-glass-010);
    stroke-width: 1px;
  }
`;var lh=function(n,e,t,i){var o=arguments.length,r=o<3?e:i===null?i=Object.getOwnPropertyDescriptor(e,t):i,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")r=Reflect.decorate(n,e,t,i);else for(var a=n.length-1;a>=0;a--)(s=n[a])&&(r=(o<3?s(r):o>3?s(e,t,r):s(e,t))||r);return o>3&&r&&Object.defineProperty(e,t,r),r};let Mo=class extends q{constructor(){super(...arguments),this.type="wallet"}render(){return P`
      ${this.shimmerTemplate()}
      <wui-shimmer width="56px" height="20px" borderRadius="xs"></wui-shimmer>
    `}shimmerTemplate(){return this.type==="network"?P` <wui-shimmer
          data-type=${this.type}
          width="48px"
          height="54px"
          borderRadius="xs"
        ></wui-shimmer>
        ${ch}`:P`<wui-shimmer width="56px" height="56px" borderRadius="xs"></wui-shimmer>`}};Mo.styles=[Q,$e,P2];lh([v()],Mo.prototype,"type",void 0);Mo=lh([k("wui-card-select-loader")],Mo);const O2=B`
  <svg fill="none" viewBox="0 0 36 40">
    <path
      d="M15.4 2.1a5.21 5.21 0 0 1 5.2 0l11.61 6.7a5.21 5.21 0 0 1 2.61 4.52v13.4c0 1.87-1 3.59-2.6 4.52l-11.61 6.7c-1.62.93-3.6.93-5.22 0l-11.6-6.7a5.21 5.21 0 0 1-2.61-4.51v-13.4c0-1.87 1-3.6 2.6-4.52L15.4 2.1Z"
    />
  </svg>
`,k2=B`<svg width="86" height="96" fill="none">
  <path
    d="M78.3244 18.926L50.1808 2.45078C45.7376 -0.150261 40.2624 -0.150262 35.8192 2.45078L7.6756 18.926C3.23322 21.5266 0.5 26.3301 0.5 31.5248V64.4752C0.5 69.6699 3.23322 74.4734 7.6756 77.074L35.8192 93.5492C40.2624 96.1503 45.7376 96.1503 50.1808 93.5492L78.3244 77.074C82.7668 74.4734 85.5 69.6699 85.5 64.4752V31.5248C85.5 26.3301 82.7668 21.5266 78.3244 18.926Z"
  />
</svg>`,N2=Z`
  :host {
    position: relative;
    border-radius: inherit;
    display: flex;
    justify-content: center;
    align-items: center;
    width: var(--local-width);
    height: var(--local-height);
  }

  svg {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    z-index: 1;
    fill: var(--wui-gray-glass-002);
  }

  svg > path {
    stroke: var(--local-stroke);
    transition: stroke var(--wui-ease-out-power-1) var(--wui-duration-lg);
  }

  wui-image {
    width: 100%;
    height: 100%;
    -webkit-clip-path: var(--local-path);
    clip-path: var(--local-path);
    background: var(--wui-gray-glass-002);
  }

  wui-icon {
    transform: translateY(-5%);
    width: var(--local-icon-size);
    height: var(--local-icon-size);
  }
`;var as=function(n,e,t,i){var o=arguments.length,r=o<3?e:i===null?i=Object.getOwnPropertyDescriptor(e,t):i,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")r=Reflect.decorate(n,e,t,i);else for(var a=n.length-1;a>=0;a--)(s=n[a])&&(r=(o<3?s(r):o>3?s(e,t,r):s(e,t))||r);return o>3&&r&&Object.defineProperty(e,t,r),r};let Fn=class extends q{constructor(){super(...arguments),this.size="md",this.name="uknown",this.selected=!1}render(){const e={sm:O2,md:ch,lg:k2};return this.style.cssText=`
      --local-stroke: ${this.selected?"var(--wui-color-accent-100)":"var(--wui-gray-glass-010)"};
      --local-path: var(--wui-path-network-${this.size});
      --local-width:  var(--wui-width-network-${this.size});
      --local-height:  var(--wui-height-network-${this.size});
      --local-icon-size:  var(--wui-icon-size-network-${this.size});
    `,P`${this.templateVisual()} ${e[this.size]}`}templateVisual(){return this.imageSrc?P`<wui-image src=${this.imageSrc} alt=${this.name}></wui-image>`:P`<wui-icon size="inherit" color="fg-200" name="networkPlaceholder"></wui-icon>`}};Fn.styles=[Q,N2];as([v()],Fn.prototype,"size",void 0);as([v()],Fn.prototype,"name",void 0);as([v()],Fn.prototype,"imageSrc",void 0);as([v({type:Boolean})],Fn.prototype,"selected",void 0);Fn=as([k("wui-network-image")],Fn);const M2=Z`
  button {
    flex-direction: column;
    width: 76px;
    row-gap: var(--wui-spacing-xs);
    padding: var(--wui-spacing-xs) var(--wui-spacing-0);
    background-color: var(--wui-gray-glass-002);
    border-radius: clamp(0px, var(--wui-border-radius-xs), 20px);
  }

  button > wui-text {
    color: var(--wui-color-fg-100);
    max-width: var(--wui-icon-box-size-xl);
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    justify-content: center;
  }

  button:disabled > wui-text {
    color: var(--wui-gray-glass-015);
  }

  [data-selected='true'] {
    background-color: var(--wui-accent-glass-020);
  }

  @media (hover: hover) and (pointer: fine) {
    [data-selected='true']:hover:enabled {
      background-color: var(--wui-accent-glass-015);
    }
  }

  [data-selected='true']:active:enabled {
    background-color: var(--wui-accent-glass-010);
  }
`;var Hi=function(n,e,t,i){var o=arguments.length,r=o<3?e:i===null?i=Object.getOwnPropertyDescriptor(e,t):i,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")r=Reflect.decorate(n,e,t,i);else for(var a=n.length-1;a>=0;a--)(s=n[a])&&(r=(o<3?s(r):o>3?s(e,t,r):s(e,t))||r);return o>3&&r&&Object.defineProperty(e,t,r),r};let nn=class extends q{constructor(){super(...arguments),this.name="Unknown",this.type="wallet",this.imageSrc=void 0,this.disabled=!1,this.selected=!1,this.installed=!1}render(){return P`
      <button data-selected=${Et(this.selected)} ?disabled=${this.disabled} ontouchstart>
        ${this.imageTemplate()}
        <wui-text variant="tiny-500" color=${this.selected?"accent-100":"inherit"}>
          ${this.name}
        </wui-text>
      </button>
    `}imageTemplate(){return this.type==="network"?P`
        <wui-network-image
          .selected=${this.selected}
          imageSrc=${Et(this.imageSrc)}
          name=${this.name}
        >
        </wui-network-image>
      `:P`
      <wui-wallet-image
        size="md"
        imageSrc=${Et(this.imageSrc)}
        name=${this.name}
        .installed=${this.installed}
        badgeSize="sm"
      >
      </wui-wallet-image>
    `}};nn.styles=[Q,$e,M2];Hi([v()],nn.prototype,"name",void 0);Hi([v()],nn.prototype,"type",void 0);Hi([v()],nn.prototype,"imageSrc",void 0);Hi([v({type:Boolean})],nn.prototype,"disabled",void 0);Hi([v({type:Boolean})],nn.prototype,"selected",void 0);Hi([v({type:Boolean})],nn.prototype,"installed",void 0);nn=Hi([k("wui-card-select")],nn);const L2=Z`
  a {
    border: 1px solid var(--wui-gray-glass-010);
    border-radius: var(--wui-border-radius-3xl);
  }

  wui-image {
    border-radius: var(--wui-border-radius-3xl);
    overflow: hidden;
  }

  a.disabled > wui-icon,
  a.disabled > wui-image {
    filter: grayscale(1);
  }

  a[data-variant='fill'] {
    color: var(--wui-color-inverse-100);
    background-color: var(--wui-color-accent-100);
  }

  a[data-variant='shade'],
  a[data-variant='shadeSmall'] {
    background-color: transparent;
    background-color: var(--wui-gray-glass-010);
    color: var(--wui-color-fg-200);
  }

  a[data-variant='success'] {
    column-gap: var(--wui-spacing-xxs);
    border: 1px solid var(--wui-success-glass-010);
    background-color: var(--wui-success-glass-010);
    color: var(--wui-color-success-100);
  }

  a[data-variant='error'] {
    column-gap: var(--wui-spacing-xxs);
    border: 1px solid var(--wui-error-glass-010);
    background-color: var(--wui-error-glass-010);
    color: var(--wui-color-error-100);
  }

  a[data-variant='transparent'] {
    column-gap: var(--wui-spacing-xxs);
    background-color: transparent;
    color: var(--wui-color-fg-150);
  }

  a[data-variant='transparent'],
  a[data-variant='success'],
  a[data-variant='shadeSmall'],
  a[data-variant='error'] {
    padding: 7px var(--wui-spacing-s) 7px 10px;
  }

  a[data-variant='transparent']:has(wui-text:first-child),
  a[data-variant='success']:has(wui-text:first-child),
  a[data-variant='shadeSmall']:has(wui-text:first-child),
  a[data-variant='error']:has(wui-text:first-child) {
    padding: 7px var(--wui-spacing-s);
  }

  a[data-variant='fill'],
  a[data-variant='shade'] {
    column-gap: var(--wui-spacing-xs);
    padding: var(--wui-spacing-xxs) var(--wui-spacing-m) var(--wui-spacing-xxs)
      var(--wui-spacing-xs);
  }

  a[data-variant='fill']:has(wui-text:first-child),
  a[data-variant='shade']:has(wui-text:first-child) {
    padding: 9px var(--wui-spacing-m) 9px var(--wui-spacing-m);
  }

  a[data-variant='fill'] > wui-image,
  a[data-variant='shade'] > wui-image {
    width: 24px;
    height: 24px;
  }

  a[data-variant='fill'] > wui-image {
    box-shadow: inset 0 0 0 1px var(--wui-color-accent-090);
  }

  a[data-variant='shade'] > wui-image,
  a[data-variant='shadeSmall'] > wui-image {
    box-shadow: inset 0 0 0 1px var(--wui-gray-glass-010);
  }

  a[data-variant='fill'] > wui-icon,
  a[data-variant='shade'] > wui-icon {
    width: 14px;
    height: 14px;
  }

  a[data-variant='transparent'] > wui-image,
  a[data-variant='success'] > wui-image,
  a[data-variant='shadeSmall'] > wui-image,
  a[data-variant='error'] > wui-image {
    width: 14px;
    height: 14px;
  }

  a[data-variant='transparent'] > wui-icon,
  a[data-variant='success'] > wui-icon,
  a[data-variant='shadeSmall'] > wui-icon,
  a[data-variant='error'] > wui-icon {
    width: 12px;
    height: 12px;
  }

  a[data-variant='fill']:focus-visible {
    background-color: var(--wui-color-accent-090);
  }

  a[data-variant='shade']:focus-visible,
  a[data-variant='shadeSmall']:focus-visible {
    background-color: var(--wui-gray-glass-015);
  }

  a[data-variant='transparent']:focus-visible {
    background-color: var(--wui-gray-glass-005);
  }

  a[data-variant='success']:focus-visible {
    background-color: var(--wui-success-glass-015);
  }

  a[data-variant='error']:focus-visible {
    background-color: var(--wui-error-glass-015);
  }

  a.disabled {
    color: var(--wui-gray-glass-015);
    background-color: var(--wui-gray-glass-015);
    pointer-events: none;
  }

  @media (hover: hover) and (pointer: fine) {
    a[data-variant='fill']:hover {
      background-color: var(--wui-color-accent-090);
    }

    a[data-variant='shade']:hover,
    a[data-variant='shadeSmall']:hover {
      background-color: var(--wui-gray-glass-015);
    }

    a[data-variant='transparent']:hover {
      background-color: var(--wui-gray-glass-005);
    }

    a[data-variant='success']:hover {
      background-color: var(--wui-success-glass-015);
    }

    a[data-variant='error']:hover {
      background-color: var(--wui-error-glass-015);
    }
  }

  a[data-variant='fill']:active {
    background-color: var(--wui-color-accent-080);
  }

  a[data-variant='shade']:active,
  a[data-variant='shadeSmall']:active {
    background-color: var(--wui-gray-glass-020);
  }

  a[data-variant='transparent']:active {
    background-color: var(--wui-gray-glass-010);
  }

  a[data-variant='success']:active {
    background-color: var(--wui-success-glass-020);
  }

  a[data-variant='error']:active {
    background-color: var(--wui-error-glass-020);
  }
`;var Vi=function(n,e,t,i){var o=arguments.length,r=o<3?e:i===null?i=Object.getOwnPropertyDescriptor(e,t):i,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")r=Reflect.decorate(n,e,t,i);else for(var a=n.length-1;a>=0;a--)(s=n[a])&&(r=(o<3?s(r):o>3?s(e,t,r):s(e,t))||r);return o>3&&r&&Object.defineProperty(e,t,r),r};let rn=class extends q{constructor(){super(...arguments),this.variant="fill",this.imageSrc=void 0,this.disabled=!1,this.icon="externalLink",this.href="",this.text=void 0}render(){const t=this.variant==="success"||this.variant==="transparent"||this.variant==="shadeSmall"?"small-600":"paragraph-600";return P`
      <a
        rel="noreferrer"
        target="_blank"
        href=${this.href}
        class=${this.disabled?"disabled":""}
        data-variant=${this.variant}
      >
        ${this.imageTemplate()}
        <wui-text variant=${t} color="inherit">
          ${this.title?this.title:ye.getHostName(this.href)}
        </wui-text>
        <wui-icon name=${this.icon} color="inherit" size="inherit"></wui-icon>
      </a>
    `}imageTemplate(){return this.imageSrc?P`<wui-image src=${this.imageSrc}></wui-image>`:null}};rn.styles=[Q,$e,L2];Vi([v()],rn.prototype,"variant",void 0);Vi([v()],rn.prototype,"imageSrc",void 0);Vi([v({type:Boolean})],rn.prototype,"disabled",void 0);Vi([v()],rn.prototype,"icon",void 0);Vi([v()],rn.prototype,"href",void 0);Vi([v()],rn.prototype,"text",void 0);rn=Vi([k("wui-chip")],rn);const B2=Z`
  :host {
    position: relative;
    display: block;
  }

  button {
    background: var(--wui-color-accent-100);
    border: 1px solid var(--wui-gray-glass-010);
    border-radius: var(--wui-border-radius-m);
    gap: var(--wui-spacing-xs);
  }

  button.loading {
    background: var(--wui-gray-glass-010);
    border: 1px solid var(--wui-gray-glass-010);
    pointer-events: none;
  }

  button:disabled {
    background-color: var(--wui-gray-glass-015);
    border: 1px solid var(--wui-gray-glass-010);
  }

  button:disabled > wui-text {
    color: var(--wui-gray-glass-015);
  }

  @media (hover: hover) and (pointer: fine) {
    button:hover:enabled {
      background-color: var(--wui-color-accent-090);
    }

    button:active:enabled {
      background-color: var(--wui-color-accent-080);
    }
  }

  button:focus-visible {
    border: 1px solid var(--wui-gray-glass-010);
    background-color: var(--wui-color-accent-090);
    -webkit-box-shadow: 0px 0px 0px 4px var(--wui-box-shadow-blue);
    -moz-box-shadow: 0px 0px 0px 4px var(--wui-box-shadow-blue);
    box-shadow: 0px 0px 0px 4px var(--wui-box-shadow-blue);
  }

  button[data-size='sm'] {
    padding: 6.75px 10px 7.25px;
  }

  ::slotted(*) {
    transition: opacity 200ms ease-in-out;
    opacity: var(--local-opacity-100);
  }

  button > wui-text {
    transition: opacity 200ms ease-in-out;
    opacity: var(--local-opacity-100);
    color: var(--wui-color-inverse-100);
  }

  button[data-size='md'] {
    padding: 9px var(--wui-spacing-l) 9px var(--wui-spacing-l);
  }

  button[data-size='md'] + wui-text {
    padding-left: var(--wui-spacing-3xs);
  }

  @media (max-width: 500px) {
    button[data-size='md'] {
      height: 32px;
      padding: 5px 12px;
    }

    button[data-size='md'] > wui-text > slot {
      font-size: 14px !important;
    }
  }

  wui-loading-spinner {
    width: 14px;
    height: 14px;
  }

  wui-loading-spinner::slotted(svg) {
    width: 10px !important;
    height: 10px !important;
  }

  button[data-size='sm'] > wui-loading-spinner {
    width: 12px;
    height: 12px;
  }
`;var Fl=function(n,e,t,i){var o=arguments.length,r=o<3?e:i===null?i=Object.getOwnPropertyDescriptor(e,t):i,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")r=Reflect.decorate(n,e,t,i);else for(var a=n.length-1;a>=0;a--)(s=n[a])&&(r=(o<3?s(r):o>3?s(e,t,r):s(e,t))||r);return o>3&&r&&Object.defineProperty(e,t,r),r};let xr=class extends q{constructor(){super(...arguments),this.size="md",this.loading=!1}render(){const e=this.size==="md"?"paragraph-600":"small-600";return P`
      <button data-size=${this.size} ?disabled=${this.loading} ontouchstart>
        ${this.loadingTemplate()}
        <wui-text variant=${e} color=${this.loading?"accent-100":"inherit"}>
          <slot></slot>
        </wui-text>
      </button>
    `}loadingTemplate(){return this.loading?P`<wui-loading-spinner size=${this.size} color="accent-100"></wui-loading-spinner>`:null}};xr.styles=[Q,$e,B2];Fl([v()],xr.prototype,"size",void 0);Fl([v({type:Boolean})],xr.prototype,"loading",void 0);xr=Fl([k("wui-connect-button")],xr);const j2=Z`
  wui-flex {
    width: 100%;
    background-color: var(--wui-gray-glass-002);
    border-radius: var(--wui-border-radius-xs);
  }
`;var Oa=function(n,e,t,i){var o=arguments.length,r=o<3?e:i===null?i=Object.getOwnPropertyDescriptor(e,t):i,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")r=Reflect.decorate(n,e,t,i);else for(var a=n.length-1;a>=0;a--)(s=n[a])&&(r=(o<3?s(r):o>3?s(e,t,r):s(e,t))||r);return o>3&&r&&Object.defineProperty(e,t,r),r};let Ai=class extends q{constructor(){super(...arguments),this.disabled=!1,this.label="",this.buttonLabel=""}render(){return P`
      <wui-flex
        justifyContent="space-between"
        alignItems="center"
        .padding=${["1xs","2l","1xs","2l"]}
      >
        <wui-text variant="paragraph-500" color="fg-200">${this.label}</wui-text>
        <wui-button size="sm" variant="accent">
          ${this.buttonLabel}
          <wui-icon size="xs" color="inherit" slot="iconRight" name="chevronRight"></wui-icon>
        </wui-button>
      </wui-flex>
    `}};Ai.styles=[Q,$e,j2];Oa([v({type:Boolean})],Ai.prototype,"disabled",void 0);Oa([v()],Ai.prototype,"label",void 0);Oa([v()],Ai.prototype,"buttonLabel",void 0);Ai=Oa([k("wui-cta-button")],Ai);/**
 * @license
 * Copyright 2020 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const D2=n=>n.strings===void 0;/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const so=(n,e)=>{var i;const t=n._$AN;if(t===void 0)return!1;for(const o of t)(i=o._$AO)==null||i.call(o,e,!1),so(o,e);return!0},Vs=n=>{let e,t;do{if((e=n._$AM)===void 0)break;t=e._$AN,t.delete(n),n=e}while((t==null?void 0:t.size)===0)},uh=n=>{for(let e;e=n._$AM;n=e){let t=e._$AN;if(t===void 0)e._$AN=t=new Set;else if(t.has(n))break;t.add(n),z2(e)}};function U2(n){this._$AN!==void 0?(Vs(this),this._$AM=n,uh(this)):this._$AM=n}function W2(n,e=!1,t=0){const i=this._$AH,o=this._$AN;if(o!==void 0&&o.size!==0)if(e)if(Array.isArray(i))for(let r=t;r<i.length;r++)so(i[r],!1),Vs(i[r]);else i!=null&&(so(i,!1),Vs(i));else so(this,n)}const z2=n=>{n.type==rh.CHILD&&(n._$AP??(n._$AP=W2),n._$AQ??(n._$AQ=U2))};let F2=class extends sh{constructor(){super(...arguments),this._$AN=void 0}_$AT(e,t,i){super._$AT(e,t,i),uh(this),this.isConnected=e._$AU}_$AO(e,t=!0){var i,o;e!==this.isConnected&&(this.isConnected=e,e?(i=this.reconnected)==null||i.call(this):(o=this.disconnected)==null||o.call(this)),t&&(so(this,e),Vs(this))}setValue(e){if(D2(this._$Ct))this._$Ct._$AI(e,this);else{const t=[...this._$Ct._$AH];t[this._$Ci]=e,this._$Ct._$AI(t,this,0)}}disconnected(){}reconnected(){}};/**
 * @license
 * Copyright 2020 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const dh=()=>new H2;let H2=class{};const mc=new WeakMap,hh=oh(class extends F2{render(n){return Le}update(n,[e]){var i;const t=e!==this.Y;return t&&this.Y!==void 0&&this.rt(void 0),(t||this.lt!==this.ct)&&(this.Y=e,this.ht=(i=n.options)==null?void 0:i.host,this.rt(this.ct=n.element)),Le}rt(n){if(typeof this.Y=="function"){const e=this.ht??globalThis;let t=mc.get(e);t===void 0&&(t=new WeakMap,mc.set(e,t)),t.get(this.Y)!==void 0&&this.Y.call(this.ht,void 0),t.set(this.Y,n),n!==void 0&&this.Y.call(this.ht,n)}else this.Y.value=n}get lt(){var n,e;return typeof this.Y=="function"?(n=mc.get(this.ht??globalThis))==null?void 0:n.get(this.Y):(e=this.Y)==null?void 0:e.value}disconnected(){this.lt===this.ct&&this.rt(void 0)}reconnected(){this.rt(this.ct)}}),V2=Z`
  :host {
    position: relative;
    width: 100%;
    display: inline-block;
    color: var(--wui-color-fg-275);
  }

  input {
    width: 100%;
    border-radius: var(--wui-border-radius-xs);
    border: 1px solid var(--wui-gray-glass-005);
    background: var(--wui-gray-glass-005);
    font-size: var(--wui-font-size-paragraph);
    font-weight: var(--wui-font-weight-light);
    letter-spacing: var(--wui-letter-spacing-paragraph);
    color: var(--wui-color-fg-100);
    transition: all var(--wui-ease-inout-power-1) var(--wui-duration-lg);
    caret-color: var(--wui-color-accent-100);
  }

  input:disabled {
    cursor: not-allowed;
    border: 1px solid var(--wui-gray-glass-010);
  }

  input:disabled::placeholder,
  input:disabled + wui-icon {
    color: var(--wui-color-fg-300);
  }

  input::placeholder {
    color: var(--wui-color-fg-275);
  }

  input:focus:enabled {
    transition: all var(--wui-ease-out-power-2) var(--wui-duration-sm);
    background-color: var(--wui-gray-glass-010);
    border: 1px solid var(--wui-color-accent-100);
    -webkit-box-shadow: 0px 0px 0px 4px var(--wui-box-shadow-blue);
    -moz-box-shadow: 0px 0px 0px 4px var(--wui-box-shadow-blue);
    box-shadow: 0px 0px 0px 4px var(--wui-box-shadow-blue);
  }

  input:hover:enabled {
    background-color: var(--wui-gray-glass-010);
  }

  wui-icon {
    position: absolute;
    top: 50%;
    transform: translateY(-50%);
    pointer-events: none;
  }

  .wui-size-sm {
    padding: 9px var(--wui-spacing-m) 10px var(--wui-spacing-s);
  }

  wui-icon + .wui-size-sm {
    padding: 9px var(--wui-spacing-m) 10px 36px;
  }

  wui-icon[data-input='sm'] {
    left: var(--wui-spacing-s);
  }

  .wui-size-md {
    padding: 15px var(--wui-spacing-m) var(--wui-spacing-l) var(--wui-spacing-m);
  }

  wui-icon + .wui-size-md,
  wui-loading-spinner + .wui-size-md {
    padding: 10.5px var(--wui-spacing-3xl) 10.5px 40px;
  }

  wui-icon[data-input='md'] {
    left: var(--wui-spacing-l);
  }

  .wui-size-lg {
    padding: var(--wui-spacing-s) var(--wui-spacing-s) var(--wui-spacing-s) var(--wui-spacing-l);
    letter-spacing: var(--wui-letter-spacing-medium-title);
    font-size: var(--wui-font-size-medium-title);
    font-weight: var(--wui-font-weight-light);
    line-height: 130%;
    color: var(--wui-color-fg-100);
    height: 64px;
  }

  wui-icon + .wui-size-lg,
  wui-loading-spinner + .wui-size-lg {
    padding-left: 50px;
  }

  wui-icon[data-input='lg'] {
    left: var(--wui-spacing-l);
  }

  input:placeholder-shown ~ ::slotted(wui-input-element),
  input:placeholder-shown ~ ::slotted(wui-icon) {
    opacity: 0;
    pointer-events: none;
  }

  input::-webkit-outer-spin-button,
  input::-webkit-inner-spin-button {
    -webkit-appearance: none;
    margin: 0;
  }

  input[type='number'] {
    -moz-appearance: textfield;
  }

  ::slotted(wui-input-element),
  ::slotted(wui-icon) {
    position: absolute;
    top: 50%;
    transform: translateY(-50%);
    transition: all var(--wui-ease-in-power-2) var(--wui-duration-md);
  }

  ::slotted(wui-input-element) {
    right: var(--wui-spacing-m);
  }

  ::slotted(wui-icon) {
    right: 0px;
  }
`;var Jn=function(n,e,t,i){var o=arguments.length,r=o<3?e:i===null?i=Object.getOwnPropertyDescriptor(e,t):i,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")r=Reflect.decorate(n,e,t,i);else for(var a=n.length-1;a>=0;a--)(s=n[a])&&(r=(o<3?s(r):o>3?s(e,t,r):s(e,t))||r);return o>3&&r&&Object.defineProperty(e,t,r),r};let Bt=class extends q{constructor(){super(...arguments),this.inputElementRef=dh(),this.size="md",this.disabled=!1,this.placeholder="",this.type="text"}render(){const e=`wui-size-${this.size}`;return P` ${this.templateIcon()}
      <input
        ${hh(this.inputElementRef)}
        class=${e}
        type=${this.type}
        enterkeyhint=${Et(this.enterKeyHint)}
        ?disabled=${this.disabled}
        placeholder=${this.placeholder}
        @input=${this.dispatchInputChangeEvent.bind(this)}
        value=${Et(this.value)}
        .value=${this.value||""}
      />
      <slot></slot>`}templateIcon(){return this.icon?P`<wui-icon
        data-input=${this.size}
        size=${this.size}
        color="inherit"
        name=${this.icon}
      ></wui-icon>`:null}dispatchInputChangeEvent(){var e;this.dispatchEvent(new CustomEvent("inputChange",{detail:(e=this.inputElementRef.value)==null?void 0:e.value,bubbles:!0,composed:!0}))}};Bt.styles=[Q,$e,V2];Jn([v()],Bt.prototype,"size",void 0);Jn([v()],Bt.prototype,"icon",void 0);Jn([v({type:Boolean})],Bt.prototype,"disabled",void 0);Jn([v()],Bt.prototype,"placeholder",void 0);Jn([v()],Bt.prototype,"type",void 0);Jn([v()],Bt.prototype,"keyHint",void 0);Jn([v()],Bt.prototype,"value",void 0);Bt=Jn([k("wui-input-text")],Bt);const Z2=Z`
  :host {
    position: relative;
    display: inline-block;
  }

  wui-text {
    margin: var(--wui-spacing-xxs) var(--wui-spacing-m) var(--wui-spacing-0) var(--wui-spacing-m);
  }
`;var ka=function(n,e,t,i){var o=arguments.length,r=o<3?e:i===null?i=Object.getOwnPropertyDescriptor(e,t):i,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")r=Reflect.decorate(n,e,t,i);else for(var a=n.length-1;a>=0;a--)(s=n[a])&&(r=(o<3?s(r):o>3?s(e,t,r):s(e,t))||r);return o>3&&r&&Object.defineProperty(e,t,r),r};let Si=class extends q{constructor(){super(...arguments),this.disabled=!1}render(){return P`
      <wui-input-text
        placeholder="Email"
        icon="mail"
        size="md"
        .disabled=${this.disabled}
        .value=${this.value}
        data-testid="wui-email-input"
      ></wui-input-text>
      ${this.templateError()}
    `}templateError(){return this.errorMessage?P`<wui-text variant="tiny-500" color="error-100">${this.errorMessage}</wui-text>`:null}};Si.styles=[Q,Z2];ka([v()],Si.prototype,"errorMessage",void 0);ka([v({type:Boolean})],Si.prototype,"disabled",void 0);ka([v()],Si.prototype,"value",void 0);Si=ka([k("wui-email-input")],Si);const q2=Z`
  button {
    border-radius: var(--local-border-radius);
    color: var(--wui-color-fg-100);
    padding: var(--local-padding);
  }

  @media (max-width: 700px) {
    button {
      padding: var(--wui-spacing-s);
    }
  }

  button > wui-icon {
    pointer-events: none;
  }

  button:disabled > wui-icon {
    color: var(--wui-color-bg-300) !important;
  }

  button:disabled {
    background-color: transparent;
  }
`;var cs=function(n,e,t,i){var o=arguments.length,r=o<3?e:i===null?i=Object.getOwnPropertyDescriptor(e,t):i,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")r=Reflect.decorate(n,e,t,i);else for(var a=n.length-1;a>=0;a--)(s=n[a])&&(r=(o<3?s(r):o>3?s(e,t,r):s(e,t))||r);return o>3&&r&&Object.defineProperty(e,t,r),r};let Hn=class extends q{constructor(){super(...arguments),this.size="md",this.disabled=!1,this.icon="copy",this.iconColor="inherit"}render(){const e=this.size==="lg"?"--wui-border-radius-xs":"--wui-border-radius-xxs",t=this.size==="lg"?"--wui-spacing-1xs":"--wui-spacing-2xs";return this.style.cssText=`
    --local-border-radius: var(${e});
    --local-padding: var(${t});
`,P`
      <button ?disabled=${this.disabled} ontouchstart>
        <wui-icon color=${this.iconColor} size=${this.size} name=${this.icon}></wui-icon>
      </button>
    `}};Hn.styles=[Q,$e,Dl,q2];cs([v()],Hn.prototype,"size",void 0);cs([v({type:Boolean})],Hn.prototype,"disabled",void 0);cs([v()],Hn.prototype,"icon",void 0);cs([v()],Hn.prototype,"iconColor",void 0);Hn=cs([k("wui-icon-link")],Hn);const G2=Z`
  button {
    background-color: var(--wui-color-fg-300);
    border-radius: var(--wui-border-radius-4xs);
    width: 16px;
    height: 16px;
  }

  button:disabled {
    background-color: var(--wui-color-bg-300);
  }

  wui-icon {
    color: var(--wui-color-bg-200) !important;
  }

  button:focus-visible {
    background-color: var(--wui-color-fg-250);
    border: 1px solid var(--wui-color-accent-100);
  }

  button:active:enabled {
    background-color: var(--wui-color-fg-225);
  }

  @media (hover: hover) and (pointer: fine) {
    button:hover:enabled {
      background-color: var(--wui-color-fg-250);
    }
  }
`;var ph=function(n,e,t,i){var o=arguments.length,r=o<3?e:i===null?i=Object.getOwnPropertyDescriptor(e,t):i,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")r=Reflect.decorate(n,e,t,i);else for(var a=n.length-1;a>=0;a--)(s=n[a])&&(r=(o<3?s(r):o>3?s(e,t,r):s(e,t))||r);return o>3&&r&&Object.defineProperty(e,t,r),r};let Lo=class extends q{constructor(){super(...arguments),this.icon="copy"}render(){return P`
      <button>
        <wui-icon color="inherit" size="xxs" name=${this.icon}></wui-icon>
      </button>
    `}};Lo.styles=[Q,$e,G2];ph([v()],Lo.prototype,"icon",void 0);Lo=ph([k("wui-input-element")],Lo);const Y2=Z`
  :host {
    position: relative;
    display: inline-block;
  }

  input {
    width: 50px;
    height: 50px;
    background: var(--wui-gray-glass-010);
    border-radius: var(--wui-border-radius-xs);
    border: 1px solid var(--wui-gray-glass-005);
    font-family: var(--wui-font-family);
    font-size: var(--wui-font-size-large);
    font-weight: var(--wui-font-weight-regular);
    letter-spacing: var(--wui-letter-spacing-large);
    text-align: center;
    color: var(--wui-color-fg-100);
    caret-color: var(--wui-color-accent-100);
    transition: all var(--wui-ease-inout-power-1) var(--wui-duration-lg);
    box-sizing: border-box;
    -webkit-appearance: none;
    -moz-appearance: textfield;
    padding: 0px;
  }

  input::-webkit-outer-spin-button,
  input::-webkit-inner-spin-button {
    -webkit-appearance: none;
    margin: 0;
  }

  input[type='number'] {
    -moz-appearance: textfield;
  }

  input:disabled {
    cursor: not-allowed;
    border: 1px solid var(--wui-gray-glass-010);
    background: var(--wui-gray-glass-005);
  }

  input:focus:enabled {
    transition: all var(--wui-ease-out-power-2) var(--wui-duration-sm);
    background-color: var(--wui-gray-glass-015);
    border: 1px solid var(--wui-color-accent-100);
    -webkit-box-shadow: 0px 0px 0px 4px var(--wui-box-shadow-blue);
    -moz-box-shadow: 0px 0px 0px 4px var(--wui-box-shadow-blue);
    box-shadow: 0px 0px 0px 4px var(--wui-box-shadow-blue);
  }
  @media (hover: hover) and (pointer: fine) {
    input:hover:enabled {
      background-color: var(--wui-gray-glass-015);
    }
  }
`;var Hl=function(n,e,t,i){var o=arguments.length,r=o<3?e:i===null?i=Object.getOwnPropertyDescriptor(e,t):i,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")r=Reflect.decorate(n,e,t,i);else for(var a=n.length-1;a>=0;a--)(s=n[a])&&(r=(o<3?s(r):o>3?s(e,t,r):s(e,t))||r);return o>3&&r&&Object.defineProperty(e,t,r),r};let Cr=class extends q{constructor(){super(...arguments),this.disabled=!1,this.value=""}render(){return P`<input
      type="number"
      maxlength="1"
      inputmode="numeric"
      autofocus
      ?disabled=${this.disabled}
      value=${this.value}
    /> `}};Cr.styles=[Q,$e,Y2];Hl([v({type:Boolean})],Cr.prototype,"disabled",void 0);Hl([v({type:String})],Cr.prototype,"value",void 0);Cr=Hl([k("wui-input-numeric")],Cr);const K2=Z`
  button {
    padding: var(--wui-spacing-4xs) var(--wui-spacing-xxs);
    border-radius: var(--wui-border-radius-3xs);
    background-color: transparent;
    color: var(--wui-color-accent-100);
  }

  button:disabled {
    background-color: transparent;
    color: var(--wui-gray-glass-015);
  }
`;var Vl=function(n,e,t,i){var o=arguments.length,r=o<3?e:i===null?i=Object.getOwnPropertyDescriptor(e,t):i,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")r=Reflect.decorate(n,e,t,i);else for(var a=n.length-1;a>=0;a--)(s=n[a])&&(r=(o<3?s(r):o>3?s(e,t,r):s(e,t))||r);return o>3&&r&&Object.defineProperty(e,t,r),r};let _r=class extends q{constructor(){super(...arguments),this.disabled=!1,this.color="inherit"}render(){return P`
      <button ?disabled=${this.disabled} ontouchstart>
        <slot name="iconLeft"></slot>
        <wui-text variant="small-600" color=${this.color}>
          <slot></slot>
        </wui-text>
        <slot name="iconRight"></slot>
      </button>
    `}};_r.styles=[Q,$e,K2];Vl([v({type:Boolean})],_r.prototype,"disabled",void 0);Vl([v()],_r.prototype,"color",void 0);_r=Vl([k("wui-link")],_r);const J2=Z`
  button {
    column-gap: var(--wui-spacing-s);
    padding: 11px 18px 11px var(--wui-spacing-s);
    width: 100%;
    background-color: var(--wui-gray-glass-002);
    border-radius: var(--wui-border-radius-xs);
    color: var(--wui-color-fg-250);
  }

  button[data-iconvariant='square'],
  button[data-iconvariant='square-blue'] {
    padding: 6px 18px 6px 9px;
  }

  button > wui-flex {
    flex: 1;
  }

  button > wui-image {
    width: 32px;
    height: 32px;
    box-shadow: 0 0 0 2px var(--wui-gray-glass-005);
    border-radius: var(--wui-border-radius-3xl);
  }

  button > wui-icon {
    width: 36px;
    height: 36px;
  }

  button > wui-icon-box[data-variant='blue'] {
    box-shadow: 0 0 0 2px var(--wui-accent-glass-005);
  }

  button > wui-icon-box[data-variant='overlay'] {
    box-shadow: 0 0 0 2px var(--wui-gray-glass-005);
  }

  button > wui-icon-box[data-variant='square-blue'] {
    border-radius: var(--wui-border-radius-3xs);
    position: relative;
    border: none;
    width: 36px;
    height: 36px;
  }

  button > wui-icon-box[data-variant='square-blue']::after {
    content: '';
    position: absolute;
    top: 0;
    bottom: 0;
    left: 0;
    right: 0;
    border-radius: inherit;
    border: 1px solid var(--wui-accent-glass-010);
    pointer-events: none;
  }

  button > wui-icon:last-child {
    width: 14px;
    height: 14px;
  }

  button:disabled {
    background-color: var(--wui-gray-glass-015);
    color: var(--wui-gray-glass-015);
  }

  button[data-loading='true'] > wui-icon {
    transition: opacity 200ms ease-in-out;
    opacity: 0;
  }

  wui-loading-spinner {
    position: absolute;
    right: 18px;
    top: 50%;
    transform: translateY(-50%);
  }
`;var pn=function(n,e,t,i){var o=arguments.length,r=o<3?e:i===null?i=Object.getOwnPropertyDescriptor(e,t):i,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")r=Reflect.decorate(n,e,t,i);else for(var a=n.length-1;a>=0;a--)(s=n[a])&&(r=(o<3?s(r):o>3?s(e,t,r):s(e,t))||r);return o>3&&r&&Object.defineProperty(e,t,r),r};let wt=class extends q{constructor(){super(...arguments),this.variant="icon",this.disabled=!1,this.imageSrc=void 0,this.alt=void 0,this.chevron=!1,this.loading=!1}render(){return P`
      <button
        ?disabled=${this.loading?!0:!!this.disabled}
        data-loading=${this.loading}
        data-iconvariant=${Et(this.iconVariant)}
        ontouchstart
      >
        ${this.loadingTemplate()} ${this.visualTemplate()}
        <wui-flex gap="3xs">
          <slot></slot>
        </wui-flex>
        ${this.chevronTemplate()}
      </button>
    `}visualTemplate(){if(this.variant==="image"&&this.imageSrc)return P`<wui-image src=${this.imageSrc} alt=${this.alt??"list item"}></wui-image>`;if(this.iconVariant==="square"&&this.icon&&this.variant==="icon")return P`<wui-icon name=${this.icon}></wui-icon>`;if(this.variant==="icon"&&this.icon&&this.iconVariant){const e=["blue","square-blue"].includes(this.iconVariant)?"accent-100":"fg-200",t=this.iconVariant==="square-blue"?"mdl":"md",i=this.iconSize?this.iconSize:t;return P`
        <wui-icon-box
          data-variant=${this.iconVariant}
          icon=${this.icon}
          iconSize=${i}
          background="transparent"
          iconColor=${e}
          backgroundColor=${e}
          size=${t}
        ></wui-icon-box>
      `}return null}loadingTemplate(){return this.loading?P`<wui-loading-spinner color="fg-300"></wui-loading-spinner>`:P``}chevronTemplate(){return this.chevron?P`<wui-icon size="inherit" color="fg-200" name="chevronRight"></wui-icon>`:null}};wt.styles=[Q,$e,J2];pn([v()],wt.prototype,"icon",void 0);pn([v()],wt.prototype,"iconSize",void 0);pn([v()],wt.prototype,"variant",void 0);pn([v()],wt.prototype,"iconVariant",void 0);pn([v({type:Boolean})],wt.prototype,"disabled",void 0);pn([v()],wt.prototype,"imageSrc",void 0);pn([v()],wt.prototype,"alt",void 0);pn([v({type:Boolean})],wt.prototype,"chevron",void 0);pn([v({type:Boolean})],wt.prototype,"loading",void 0);wt=pn([k("wui-list-item")],wt);var tl;(function(n){n.approve="approved",n.bought="bought",n.borrow="borrowed",n.burn="burnt",n.cancel="canceled",n.claim="claimed",n.deploy="deployed",n.deposit="deposited",n.execute="executed",n.mint="minted",n.receive="received",n.repay="repaid",n.send="sent",n.sell="sold",n.stake="staked",n.trade="swapped",n.unstake="unstaked",n.withdraw="withdrawn"})(tl||(tl={}));const Q2=Z`
  :host > wui-flex {
    display: flex;
    justify-content: center;
    align-items: center;
    position: relative;
    width: 40px;
    height: 40px;
    box-shadow: inset 0 0 0 1px var(--wui-gray-glass-005);
    background-color: var(--wui-gray-glass-005);
  }

  :host > wui-flex wui-image {
    display: block;
  }

  :host > wui-flex,
  :host > wui-flex wui-image,
  .swap-images-container,
  .swap-images-container.nft,
  wui-image.nft {
    border-top-left-radius: var(--local-left-border-radius);
    border-top-right-radius: var(--local-right-border-radius);
    border-bottom-left-radius: var(--local-left-border-radius);
    border-bottom-right-radius: var(--local-right-border-radius);
  }

  wui-icon {
    width: 20px;
    height: 20px;
  }

  wui-icon-box {
    position: absolute;
    right: 0;
    bottom: 0;
    transform: translate(20%, 20%);
  }

  .swap-images-container {
    position: relative;
    width: 40px;
    height: 40px;
    overflow: hidden;
  }

  .swap-images-container wui-image:first-child {
    position: absolute;
    width: 40px;
    height: 40px;
    top: 0;
    left: 0%;
    clip-path: inset(0px calc(50% + 2px) 0px 0%);
  }

  .swap-images-container wui-image:last-child {
    clip-path: inset(0px 0px 0px calc(50% + 2px));
  }
`;var Zi=function(n,e,t,i){var o=arguments.length,r=o<3?e:i===null?i=Object.getOwnPropertyDescriptor(e,t):i,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")r=Reflect.decorate(n,e,t,i);else for(var a=n.length-1;a>=0;a--)(s=n[a])&&(r=(o<3?s(r):o>3?s(e,t,r):s(e,t))||r);return o>3&&r&&Object.defineProperty(e,t,r),r};let on=class extends q{constructor(){super(...arguments),this.images=[],this.secondImage={type:void 0,url:""}}render(){const[e,t]=this.images,i=(e==null?void 0:e.type)==="NFT",o=t!=null&&t.url?t.type==="NFT":i,r=i?"var(--wui-border-radius-xxs)":"var(--wui-border-radius-s)",s=o?"var(--wui-border-radius-xxs)":"var(--wui-border-radius-s)";return this.style.cssText=`
    --local-left-border-radius: ${r};
    --local-right-border-radius: ${s};
    `,P`<wui-flex> ${this.templateVisual()} ${this.templateIcon()} </wui-flex>`}templateVisual(){const[e,t]=this.images,i=e==null?void 0:e.type;return this.images.length===2&&(e!=null&&e.url||t!=null&&t.url)?P`<div class="swap-images-container">
        ${e!=null&&e.url?P`<wui-image src=${e.url} alt="Transaction image"></wui-image>`:null}
        ${t!=null&&t.url?P`<wui-image src=${t.url} alt="Transaction image"></wui-image>`:null}
      </div>`:e!=null&&e.url?P`<wui-image src=${e.url} alt="Transaction image"></wui-image>`:i==="NFT"?P`<wui-icon size="inherit" color="fg-200" name="nftPlaceholder"></wui-icon>`:P`<wui-icon size="inherit" color="fg-200" name="coinPlaceholder"></wui-icon>`}templateIcon(){let e="accent-100",t;return t=this.getIcon(),this.status&&(e=this.getStatusColor()),t?P`
      <wui-icon-box
        size="xxs"
        iconColor=${e}
        backgroundColor=${e}
        background="opaque"
        icon=${t}
        ?border=${!0}
        borderColor="wui-color-bg-125"
      ></wui-icon-box>
    `:null}getDirectionIcon(){switch(this.direction){case"in":return"arrowBottom";case"out":return"arrowTop";default:return}}getIcon(){return this.onlyDirectionIcon?this.getDirectionIcon():this.type==="trade"?"swapHorizontalBold":this.type==="approve"?"checkmark":this.type==="cancel"?"close":this.getDirectionIcon()}getStatusColor(){switch(this.status){case"confirmed":return"success-100";case"failed":return"error-100";case"pending":return"inverse-100";default:return"accent-100"}}};on.styles=[Q2];Zi([v()],on.prototype,"type",void 0);Zi([v()],on.prototype,"status",void 0);Zi([v()],on.prototype,"direction",void 0);Zi([v({type:Boolean})],on.prototype,"onlyDirectionIcon",void 0);Zi([v({type:Array})],on.prototype,"images",void 0);Zi([v({type:Object})],on.prototype,"secondImage",void 0);on=Zi([k("wui-transaction-visual")],on);const X2=Z`
  :host > wui-flex:first-child {
    align-items: center;
    column-gap: var(--wui-spacing-s);
    padding: 6.5px var(--wui-spacing-xs) 6.5px var(--wui-spacing-xs);
    width: 100%;
  }

  :host > wui-flex:first-child wui-text:nth-child(1) {
    text-transform: capitalize;
  }

  wui-transaction-visual {
    width: 40px;
    height: 40px;
  }

  wui-flex {
    flex: 1;
  }

  :host wui-flex wui-flex {
    overflow: hidden;
  }

  :host .description-container wui-text span {
    word-break: break-all;
  }

  :host .description-container wui-text {
    overflow: hidden;
  }

  :host .description-separator-icon {
    margin: 0px 6px;
  }

  :host wui-text > span {
    overflow: hidden;
    display: -webkit-box;
    -webkit-box-orient: vertical;
    -webkit-line-clamp: 1;
  }
`;var zt=function(n,e,t,i){var o=arguments.length,r=o<3?e:i===null?i=Object.getOwnPropertyDescriptor(e,t):i,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")r=Reflect.decorate(n,e,t,i);else for(var a=n.length-1;a>=0;a--)(s=n[a])&&(r=(o<3?s(r):o>3?s(e,t,r):s(e,t))||r);return o>3&&r&&Object.defineProperty(e,t,r),r};let st=class extends q{constructor(){super(...arguments),this.type="approve",this.onlyDirectionIcon=!1,this.images=[],this.price=[],this.amount=[],this.symbol=[]}render(){return P`
      <wui-flex>
        <wui-transaction-visual
          .status=${this.status}
          direction=${Et(this.direction)}
          type=${this.type}
          onlyDirectionIcon=${Et(this.onlyDirectionIcon)}
          .images=${this.images}
        ></wui-transaction-visual>
        <wui-flex flexDirection="column" gap="3xs">
          <wui-text variant="paragraph-600" color="fg-100">
            ${tl[this.type]||this.type}
          </wui-text>
          <wui-flex class="description-container">
            ${this.templateDescription()} ${this.templateSecondDescription()}
          </wui-flex>
        </wui-flex>
        <wui-text variant="micro-700" color="fg-300"><span>${this.date}</span></wui-text>
      </wui-flex>
    `}templateDescription(){var t;const e=(t=this.descriptions)==null?void 0:t[0];return e?P`
          <wui-text variant="small-500" color="fg-200">
            <span>${e}</span>
          </wui-text>
        `:null}templateSecondDescription(){var t;const e=(t=this.descriptions)==null?void 0:t[1];return e?P`
          <wui-icon class="description-separator-icon" size="xxs" name="arrowRight"></wui-icon>
          <wui-text variant="small-400" color="fg-200">
            <span>${e}</span>
          </wui-text>
        `:null}};st.styles=[Q,X2];zt([v()],st.prototype,"type",void 0);zt([v({type:Array})],st.prototype,"descriptions",void 0);zt([v()],st.prototype,"date",void 0);zt([v({type:Boolean})],st.prototype,"onlyDirectionIcon",void 0);zt([v()],st.prototype,"status",void 0);zt([v()],st.prototype,"direction",void 0);zt([v({type:Array})],st.prototype,"images",void 0);zt([v({type:Array})],st.prototype,"price",void 0);zt([v({type:Array})],st.prototype,"amount",void 0);zt([v({type:Array})],st.prototype,"symbol",void 0);st=zt([k("wui-transaction-list-item")],st);const e3=Z`
  :host > wui-flex:first-child {
    column-gap: var(--wui-spacing-s);
    padding: 7px var(--wui-spacing-l) 7px var(--wui-spacing-xs);
    width: 100%;
  }

  wui-flex {
    display: flex;
    flex: 1;
  }
`;var t3=function(n,e,t,i){var o=arguments.length,r=o<3?e:i===null?i=Object.getOwnPropertyDescriptor(e,t):i,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")r=Reflect.decorate(n,e,t,i);else for(var a=n.length-1;a>=0;a--)(s=n[a])&&(r=(o<3?s(r):o>3?s(e,t,r):s(e,t))||r);return o>3&&r&&Object.defineProperty(e,t,r),r};let Zs=class extends q{render(){return P`
      <wui-flex alignItems="center">
        <wui-shimmer width="40px" height="40px"></wui-shimmer>
        <wui-flex flexDirection="column" gap="2xs">
          <wui-shimmer width="72px" height="16px" borderRadius="4xs"></wui-shimmer>
          <wui-shimmer width="148px" height="14px" borderRadius="4xs"></wui-shimmer>
        </wui-flex>
        <wui-shimmer width="24px" height="12px" borderRadius="5xs"></wui-shimmer>
      </wui-flex>
    `}};Zs.styles=[Q,e3];Zs=t3([k("wui-transaction-list-item-loader")],Zs);const n3=Z`
  :host {
    display: block;
    padding: 3.5px 5px !important;
    border-radius: var(--wui-border-radius-5xs);
  }

  :host([data-variant='main']) {
    background-color: var(--wui-accent-glass-015);
    color: var(--wui-color-accent-100);
  }

  :host([data-variant='shade']) {
    background-color: var(--wui-gray-glass-010);
    color: var(--wui-color-fg-200);
  }

  :host([data-variant='success']) {
    background-color: var(--wui-icon-box-bg-success-100);
    color: var(--wui-color-success-100);
  }

  :host([data-variant='error']) {
    background-color: var(--wui-icon-box-bg-error-100);
    color: var(--wui-color-error-100);
  }
`;var fh=function(n,e,t,i){var o=arguments.length,r=o<3?e:i===null?i=Object.getOwnPropertyDescriptor(e,t):i,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")r=Reflect.decorate(n,e,t,i);else for(var a=n.length-1;a>=0;a--)(s=n[a])&&(r=(o<3?s(r):o>3?s(e,t,r):s(e,t))||r);return o>3&&r&&Object.defineProperty(e,t,r),r};let Bo=class extends q{constructor(){super(...arguments),this.variant="main"}render(){return this.dataset.variant=this.variant,P`
      <wui-text data-variant=${this.variant} variant="micro-700" color="inherit">
        <slot></slot>
      </wui-text>
    `}};Bo.styles=[Q,n3];fh([v()],Bo.prototype,"variant",void 0);Bo=fh([k("wui-tag")],Bo);const i3=Z`
  button {
    column-gap: var(--wui-spacing-s);
    padding: 7px var(--wui-spacing-l) 7px var(--wui-spacing-xs);
    width: 100%;
    background-color: var(--wui-gray-glass-002);
    border-radius: var(--wui-border-radius-xs);
    color: var(--wui-color-fg-100);
  }

  button > wui-text:nth-child(2) {
    display: flex;
    flex: 1;
  }

  wui-icon {
    color: var(--wui-color-fg-200) !important;
  }

  button:disabled {
    background-color: var(--wui-gray-glass-015);
    color: var(--wui-gray-glass-015);
  }

  button:disabled > wui-tag {
    background-color: var(--wui-gray-glass-010);
    color: var(--wui-color-fg-300);
  }
`;var Ft=function(n,e,t,i){var o=arguments.length,r=o<3?e:i===null?i=Object.getOwnPropertyDescriptor(e,t):i,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")r=Reflect.decorate(n,e,t,i);else for(var a=n.length-1;a>=0;a--)(s=n[a])&&(r=(o<3?s(r):o>3?s(e,t,r):s(e,t))||r);return o>3&&r&&Object.defineProperty(e,t,r),r};let at=class extends q{constructor(){super(...arguments),this.walletImages=[],this.imageSrc="",this.name="",this.installed=!1,this.disabled=!1,this.showAllWallets=!1}render(){return P`
      <button ?disabled=${this.disabled} ontouchstart>
        ${this.templateAllWallets()} ${this.templateWalletImage()}
        <wui-text variant="paragraph-500" color="inherit">${this.name}</wui-text>
        ${this.templateStatus()}
      </button>
    `}templateAllWallets(){return this.showAllWallets&&this.imageSrc?P` <wui-all-wallets-image .imageeSrc=${this.imageSrc}> </wui-all-wallets-image> `:this.showAllWallets&&this.walletIcon?P` <wui-wallet-image .walletIcon=${this.walletIcon} size="sm"> </wui-wallet-image> `:null}templateWalletImage(){return!this.showAllWallets&&this.imageSrc?P`<wui-wallet-image
        size="sm"
        imageSrc=${this.imageSrc}
        name=${this.name}
        .installed=${this.installed}
      ></wui-wallet-image>`:!this.showAllWallets&&!this.imageSrc?P`<wui-wallet-image size="sm" name=${this.name}></wui-wallet-image>`:null}templateStatus(){return this.tagLabel&&this.tagVariant?P`<wui-tag variant=${this.tagVariant}>${this.tagLabel}</wui-tag>`:this.icon?P`<wui-icon color="inherit" size="sm" name=${this.icon}></wui-icon>`:null}};at.styles=[Q,$e,i3];Ft([v({type:Array})],at.prototype,"walletImages",void 0);Ft([v()],at.prototype,"imageSrc",void 0);Ft([v()],at.prototype,"name",void 0);Ft([v()],at.prototype,"tagLabel",void 0);Ft([v()],at.prototype,"tagVariant",void 0);Ft([v()],at.prototype,"icon",void 0);Ft([v()],at.prototype,"walletIcon",void 0);Ft([v({type:Boolean})],at.prototype,"installed",void 0);Ft([v({type:Boolean})],at.prototype,"disabled",void 0);Ft([v({type:Boolean})],at.prototype,"showAllWallets",void 0);at=Ft([k("wui-list-wallet")],at);const r3=Z`
  :host {
    display: block;
    width: 40px;
    height: 40px;
    border-radius: var(--wui-border-radius-3xl);
    border: 1px solid var(--wui-gray-glass-010);
    overflow: hidden;
  }

  wui-icon {
    width: 100%;
    height: 100%;
  }
`;var gh=function(n,e,t,i){var o=arguments.length,r=o<3?e:i===null?i=Object.getOwnPropertyDescriptor(e,t):i,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")r=Reflect.decorate(n,e,t,i);else for(var a=n.length-1;a>=0;a--)(s=n[a])&&(r=(o<3?s(r):o>3?s(e,t,r):s(e,t))||r);return o>3&&r&&Object.defineProperty(e,t,r),r};let jo=class extends q{constructor(){super(...arguments),this.logo="google"}render(){return P`<wui-icon color="inherit" size="inherit" name=${this.logo}></wui-icon> `}};jo.styles=[Q,r3];gh([v()],jo.prototype,"logo",void 0);jo=gh([k("wui-logo")],jo);const o3=Z`
  :host {
    display: block;
  }

  button {
    width: 50px;
    height: 50px;
    background: var(--wui-gray-glass-002);
    border-radius: var(--wui-border-radius-xs);
  }
`;var Zl=function(n,e,t,i){var o=arguments.length,r=o<3?e:i===null?i=Object.getOwnPropertyDescriptor(e,t):i,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")r=Reflect.decorate(n,e,t,i);else for(var a=n.length-1;a>=0;a--)(s=n[a])&&(r=(o<3?s(r):o>3?s(e,t,r):s(e,t))||r);return o>3&&r&&Object.defineProperty(e,t,r),r};let Er=class extends q{constructor(){super(...arguments),this.logo="google",this.disabled=!1}render(){return P`
      <button ?disabled=${this.disabled} ontouchstart>
        <wui-logo logo=${this.logo}></wui-logo>
      </button>
    `}};Er.styles=[Q,$e,o3];Zl([v()],Er.prototype,"logo",void 0);Zl([v({type:Boolean})],Er.prototype,"disabled",void 0);Er=Zl([k("wui-logo-select")],Er);const s3=Z`
  :host {
    display: block;
  }

  button {
    border-radius: var(--wui-border-radius-3xl);
    display: flex;
    gap: var(--wui-spacing-xs);
    padding: var(--wui-spacing-2xs) var(--wui-spacing-s) var(--wui-spacing-2xs)
      var(--wui-spacing-xs);
    border: 1px solid var(--wui-gray-glass-010);
    background-color: var(--wui-gray-glass-005);
    color: var(--wui-color-fg-100);
  }

  button:disabled {
    border: 1px solid var(--wui-gray-glass-005);
    background-color: var(--wui-gray-glass-015);
    color: var(--wui-gray-glass-015);
  }

  @media (hover: hover) and (pointer: fine) {
    button:hover:enabled {
      background-color: var(--wui-gray-glass-010);
    }

    button:active:enabled {
      background-color: var(--wui-gray-glass-015);
    }
  }

  wui-image,
  wui-icon-box {
    border-radius: var(--wui-border-radius-3xl);
    width: 24px;
    height: 24px;
    box-shadow: 0 0 0 2px var(--wui-gray-glass-005);
  }
`;var Na=function(n,e,t,i){var o=arguments.length,r=o<3?e:i===null?i=Object.getOwnPropertyDescriptor(e,t):i,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")r=Reflect.decorate(n,e,t,i);else for(var a=n.length-1;a>=0;a--)(s=n[a])&&(r=(o<3?s(r):o>3?s(e,t,r):s(e,t))||r);return o>3&&r&&Object.defineProperty(e,t,r),r};let Ii=class extends q{constructor(){super(...arguments),this.imageSrc=void 0,this.isUnsupportedChain=void 0,this.disabled=!1}render(){return P`
      <button ?disabled=${this.disabled}>
        ${this.visualTemplate()}
        <wui-text variant="paragraph-600" color="inherit">
          <slot></slot>
        </wui-text>
      </button>
    `}visualTemplate(){return this.isUnsupportedChain?P`
        <wui-icon-box
          size="sm"
          iconColor="error-100"
          backgroundColor="error-100"
          icon="warningCircle"
        ></wui-icon-box>
      `:this.imageSrc?P`<wui-image src=${this.imageSrc}></wui-image>`:P`
      <wui-icon-box
        size="sm"
        iconColor="inverse-100"
        backgroundColor="fg-100"
        icon="networkPlaceholder"
      ></wui-icon-box>
    `}};Ii.styles=[Q,$e,s3];Na([v()],Ii.prototype,"imageSrc",void 0);Na([v({type:Boolean})],Ii.prototype,"isUnsupportedChain",void 0);Na([v({type:Boolean})],Ii.prototype,"disabled",void 0);Ii=Na([k("wui-network-button")],Ii);const a3=Z`
  :host {
    position: relative;
    display: block;
  }
`;var Ma=function(n,e,t,i){var o=arguments.length,r=o<3?e:i===null?i=Object.getOwnPropertyDescriptor(e,t):i,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")r=Reflect.decorate(n,e,t,i);else for(var a=n.length-1;a>=0;a--)(s=n[a])&&(r=(o<3?s(r):o>3?s(e,t,r):s(e,t))||r);return o>3&&r&&Object.defineProperty(e,t,r),r};let Ri=class extends q{constructor(){super(...arguments),this.length=6,this.otp="",this.values=Array.from({length:this.length}).map(()=>""),this.numerics=[],this.shouldInputBeEnabled=e=>this.values.slice(0,e).every(i=>i!==""),this.handleKeyDown=(e,t)=>{const i=e.target,o=this.getInputElement(i),r=["ArrowLeft","ArrowRight","Shift","Delete"];if(!o)return;r.includes(e.key)&&e.preventDefault();const s=o.selectionStart;switch(e.key){case"ArrowLeft":s&&o.setSelectionRange(s+1,s+1),this.focusInputField("prev",t);break;case"ArrowRight":this.focusInputField("next",t);break;case"Shift":this.focusInputField("next",t);break;case"Delete":o.value===""?this.focusInputField("prev",t):this.updateInput(o,t,"");break;case"Backspace":o.value===""?this.focusInputField("prev",t):this.updateInput(o,t,"");break}},this.focusInputField=(e,t)=>{if(e==="next"){const i=t+1;if(!this.shouldInputBeEnabled(i))return;const o=this.numerics[i<this.length?i:t],r=o?this.getInputElement(o):void 0;r&&(r.disabled=!1,r.focus())}if(e==="prev"){const i=t-1,o=this.numerics[i>-1?i:t],r=o?this.getInputElement(o):void 0;r&&r.focus()}}}firstUpdated(){var t,i;this.otp&&(this.values=this.otp.split(""));const e=(t=this.shadowRoot)==null?void 0:t.querySelectorAll("wui-input-numeric");e&&(this.numerics=Array.from(e)),(i=this.numerics[0])==null||i.focus()}render(){return P`
      <wui-flex gap="xxs" data-testid="wui-otp-input">
        ${Array.from({length:this.length}).map((e,t)=>P`
            <wui-input-numeric
              @input=${i=>this.handleInput(i,t)}
              @click=${i=>this.selectInput(i)}
              @keydown=${i=>this.handleKeyDown(i,t)}
              .disabled=${!this.shouldInputBeEnabled(t)}
              .value=${this.values[t]||""}
            >
            </wui-input-numeric>
          `)}
      </wui-flex>
    `}updateInput(e,t,i){const o=this.numerics[t],r=e||(o?this.getInputElement(o):void 0);r&&(r.value=i,this.values=this.values.map((s,a)=>a===t?i:s))}selectInput(e){const t=e.target;if(t){const i=this.getInputElement(t);i==null||i.select()}}handleInput(e,t){const i=e.target,o=this.getInputElement(i);if(o){const r=o.value;e.inputType==="insertFromPaste"?this.handlePaste(o,r,t):ye.isNumber(r)&&e.data?(this.updateInput(o,t,e.data),this.focusInputField("next",t)):this.updateInput(o,t,"")}this.dispatchInputChangeEvent()}handlePaste(e,t,i){const o=t[0];if(o&&ye.isNumber(o)){this.updateInput(e,i,o);const s=t.substring(1);if(i+1<this.length&&s.length){const a=this.numerics[i+1],c=a?this.getInputElement(a):void 0;c&&this.handlePaste(c,s,i+1)}else this.focusInputField("next",i)}else this.updateInput(e,i,"")}getInputElement(e){var t;return(t=e.shadowRoot)!=null&&t.querySelector("input")?e.shadowRoot.querySelector("input"):null}dispatchInputChangeEvent(){const e=this.values.join("");this.dispatchEvent(new CustomEvent("inputChange",{detail:e,bubbles:!0,composed:!0}))}};Ri.styles=[Q,a3];Ma([v({type:Number})],Ri.prototype,"length",void 0);Ma([v({type:String})],Ri.prototype,"otp",void 0);Ma([Sa()],Ri.prototype,"values",void 0);Ri=Ma([k("wui-otp")],Ri);var ls={},c3=function(){return typeof Promise=="function"&&Promise.prototype&&Promise.prototype.then},mh={},xt={};let ql;const l3=[0,26,44,70,100,134,172,196,242,292,346,404,466,532,581,655,733,815,901,991,1085,1156,1258,1364,1474,1588,1706,1828,1921,2051,2185,2323,2465,2611,2761,2876,3034,3196,3362,3532,3706];xt.getSymbolSize=function(e){if(!e)throw new Error('"version" cannot be null or undefined');if(e<1||e>40)throw new Error('"version" should be in range from 1 to 40');return e*4+17};xt.getSymbolTotalCodewords=function(e){return l3[e]};xt.getBCHDigit=function(n){let e=0;for(;n!==0;)e++,n>>>=1;return e};xt.setToSJISFunction=function(e){if(typeof e!="function")throw new Error('"toSJISFunc" is not a valid function.');ql=e};xt.isKanjiModeEnabled=function(){return typeof ql<"u"};xt.toSJIS=function(e){return ql(e)};var La={};(function(n){n.L={bit:1},n.M={bit:0},n.Q={bit:3},n.H={bit:2};function e(t){if(typeof t!="string")throw new Error("Param is not a string");switch(t.toLowerCase()){case"l":case"low":return n.L;case"m":case"medium":return n.M;case"q":case"quartile":return n.Q;case"h":case"high":return n.H;default:throw new Error("Unknown EC Level: "+t)}}n.isValid=function(i){return i&&typeof i.bit<"u"&&i.bit>=0&&i.bit<4},n.from=function(i,o){if(n.isValid(i))return i;try{return e(i)}catch{return o}}})(La);function wh(){this.buffer=[],this.length=0}wh.prototype={get:function(n){const e=Math.floor(n/8);return(this.buffer[e]>>>7-n%8&1)===1},put:function(n,e){for(let t=0;t<e;t++)this.putBit((n>>>e-t-1&1)===1)},getLengthInBits:function(){return this.length},putBit:function(n){const e=Math.floor(this.length/8);this.buffer.length<=e&&this.buffer.push(0),n&&(this.buffer[e]|=128>>>this.length%8),this.length++}};var u3=wh;function us(n){if(!n||n<1)throw new Error("BitMatrix size must be defined and greater than 0");this.size=n,this.data=new Uint8Array(n*n),this.reservedBit=new Uint8Array(n*n)}us.prototype.set=function(n,e,t,i){const o=n*this.size+e;this.data[o]=t,i&&(this.reservedBit[o]=!0)};us.prototype.get=function(n,e){return this.data[n*this.size+e]};us.prototype.xor=function(n,e,t){this.data[n*this.size+e]^=t};us.prototype.isReserved=function(n,e){return this.reservedBit[n*this.size+e]};var d3=us,bh={};(function(n){const e=xt.getSymbolSize;n.getRowColCoords=function(i){if(i===1)return[];const o=Math.floor(i/7)+2,r=e(i),s=r===145?26:Math.ceil((r-13)/(2*o-2))*2,a=[r-7];for(let c=1;c<o-1;c++)a[c]=a[c-1]-s;return a.push(6),a.reverse()},n.getPositions=function(i){const o=[],r=n.getRowColCoords(i),s=r.length;for(let a=0;a<s;a++)for(let c=0;c<s;c++)a===0&&c===0||a===0&&c===s-1||a===s-1&&c===0||o.push([r[a],r[c]]);return o}})(bh);var vh={};const h3=xt.getSymbolSize,dd=7;vh.getPositions=function(e){const t=h3(e);return[[0,0],[t-dd,0],[0,t-dd]]};var yh={};(function(n){n.Patterns={PATTERN000:0,PATTERN001:1,PATTERN010:2,PATTERN011:3,PATTERN100:4,PATTERN101:5,PATTERN110:6,PATTERN111:7};const e={N1:3,N2:3,N3:40,N4:10};n.isValid=function(o){return o!=null&&o!==""&&!isNaN(o)&&o>=0&&o<=7},n.from=function(o){return n.isValid(o)?parseInt(o,10):void 0},n.getPenaltyN1=function(o){const r=o.size;let s=0,a=0,c=0,u=null,h=null;for(let p=0;p<r;p++){a=c=0,u=h=null;for(let g=0;g<r;g++){let b=o.get(p,g);b===u?a++:(a>=5&&(s+=e.N1+(a-5)),u=b,a=1),b=o.get(g,p),b===h?c++:(c>=5&&(s+=e.N1+(c-5)),h=b,c=1)}a>=5&&(s+=e.N1+(a-5)),c>=5&&(s+=e.N1+(c-5))}return s},n.getPenaltyN2=function(o){const r=o.size;let s=0;for(let a=0;a<r-1;a++)for(let c=0;c<r-1;c++){const u=o.get(a,c)+o.get(a,c+1)+o.get(a+1,c)+o.get(a+1,c+1);(u===4||u===0)&&s++}return s*e.N2},n.getPenaltyN3=function(o){const r=o.size;let s=0,a=0,c=0;for(let u=0;u<r;u++){a=c=0;for(let h=0;h<r;h++)a=a<<1&2047|o.get(u,h),h>=10&&(a===1488||a===93)&&s++,c=c<<1&2047|o.get(h,u),h>=10&&(c===1488||c===93)&&s++}return s*e.N3},n.getPenaltyN4=function(o){let r=0;const s=o.data.length;for(let c=0;c<s;c++)r+=o.data[c];return Math.abs(Math.ceil(r*100/s/5)-10)*e.N4};function t(i,o,r){switch(i){case n.Patterns.PATTERN000:return(o+r)%2===0;case n.Patterns.PATTERN001:return o%2===0;case n.Patterns.PATTERN010:return r%3===0;case n.Patterns.PATTERN011:return(o+r)%3===0;case n.Patterns.PATTERN100:return(Math.floor(o/2)+Math.floor(r/3))%2===0;case n.Patterns.PATTERN101:return o*r%2+o*r%3===0;case n.Patterns.PATTERN110:return(o*r%2+o*r%3)%2===0;case n.Patterns.PATTERN111:return(o*r%3+(o+r)%2)%2===0;default:throw new Error("bad maskPattern:"+i)}}n.applyMask=function(o,r){const s=r.size;for(let a=0;a<s;a++)for(let c=0;c<s;c++)r.isReserved(c,a)||r.xor(c,a,t(o,c,a))},n.getBestMask=function(o,r){const s=Object.keys(n.Patterns).length;let a=0,c=1/0;for(let u=0;u<s;u++){r(u),n.applyMask(u,o);const h=n.getPenaltyN1(o)+n.getPenaltyN2(o)+n.getPenaltyN3(o)+n.getPenaltyN4(o);n.applyMask(u,o),h<c&&(c=h,a=u)}return a}})(yh);var Ba={};const Mn=La,_s=[1,1,1,1,1,1,1,1,1,1,2,2,1,2,2,4,1,2,4,4,2,4,4,4,2,4,6,5,2,4,6,6,2,5,8,8,4,5,8,8,4,5,8,11,4,8,10,11,4,9,12,16,4,9,16,16,6,10,12,18,6,10,17,16,6,11,16,19,6,13,18,21,7,14,21,25,8,16,20,25,8,17,23,25,9,17,23,34,9,18,25,30,10,20,27,32,12,21,29,35,12,23,34,37,12,25,34,40,13,26,35,42,14,28,38,45,15,29,40,48,16,31,43,51,17,33,45,54,18,35,48,57,19,37,51,60,19,38,53,63,20,40,56,66,21,43,59,70,22,45,62,74,24,47,65,77,25,49,68,81],Es=[7,10,13,17,10,16,22,28,15,26,36,44,20,36,52,64,26,48,72,88,36,64,96,112,40,72,108,130,48,88,132,156,60,110,160,192,72,130,192,224,80,150,224,264,96,176,260,308,104,198,288,352,120,216,320,384,132,240,360,432,144,280,408,480,168,308,448,532,180,338,504,588,196,364,546,650,224,416,600,700,224,442,644,750,252,476,690,816,270,504,750,900,300,560,810,960,312,588,870,1050,336,644,952,1110,360,700,1020,1200,390,728,1050,1260,420,784,1140,1350,450,812,1200,1440,480,868,1290,1530,510,924,1350,1620,540,980,1440,1710,570,1036,1530,1800,570,1064,1590,1890,600,1120,1680,1980,630,1204,1770,2100,660,1260,1860,2220,720,1316,1950,2310,750,1372,2040,2430];Ba.getBlocksCount=function(e,t){switch(t){case Mn.L:return _s[(e-1)*4+0];case Mn.M:return _s[(e-1)*4+1];case Mn.Q:return _s[(e-1)*4+2];case Mn.H:return _s[(e-1)*4+3];default:return}};Ba.getTotalCodewordsCount=function(e,t){switch(t){case Mn.L:return Es[(e-1)*4+0];case Mn.M:return Es[(e-1)*4+1];case Mn.Q:return Es[(e-1)*4+2];case Mn.H:return Es[(e-1)*4+3];default:return}};var xh={},ja={};const ao=new Uint8Array(512),qs=new Uint8Array(256);(function(){let e=1;for(let t=0;t<255;t++)ao[t]=e,qs[e]=t,e<<=1,e&256&&(e^=285);for(let t=255;t<512;t++)ao[t]=ao[t-255]})();ja.log=function(e){if(e<1)throw new Error("log("+e+")");return qs[e]};ja.exp=function(e){return ao[e]};ja.mul=function(e,t){return e===0||t===0?0:ao[qs[e]+qs[t]]};(function(n){const e=ja;n.mul=function(i,o){const r=new Uint8Array(i.length+o.length-1);for(let s=0;s<i.length;s++)for(let a=0;a<o.length;a++)r[s+a]^=e.mul(i[s],o[a]);return r},n.mod=function(i,o){let r=new Uint8Array(i);for(;r.length-o.length>=0;){const s=r[0];for(let c=0;c<o.length;c++)r[c]^=e.mul(o[c],s);let a=0;for(;a<r.length&&r[a]===0;)a++;r=r.slice(a)}return r},n.generateECPolynomial=function(i){let o=new Uint8Array([1]);for(let r=0;r<i;r++)o=n.mul(o,new Uint8Array([1,e.exp(r)]));return o}})(xh);const Ch=xh;function Gl(n){this.genPoly=void 0,this.degree=n,this.degree&&this.initialize(this.degree)}Gl.prototype.initialize=function(e){this.degree=e,this.genPoly=Ch.generateECPolynomial(this.degree)};Gl.prototype.encode=function(e){if(!this.genPoly)throw new Error("Encoder not initialized");const t=new Uint8Array(e.length+this.degree);t.set(e);const i=Ch.mod(t,this.genPoly),o=this.degree-i.length;if(o>0){const r=new Uint8Array(this.degree);return r.set(i,o),r}return i};var p3=Gl,_h={},Qn={},Yl={};Yl.isValid=function(e){return!isNaN(e)&&e>=1&&e<=40};var fn={};const Eh="[0-9]+",f3="[A-Z $%*+\\-./:]+";let Do="(?:[u3000-u303F]|[u3040-u309F]|[u30A0-u30FF]|[uFF00-uFFEF]|[u4E00-u9FAF]|[u2605-u2606]|[u2190-u2195]|u203B|[u2010u2015u2018u2019u2025u2026u201Cu201Du2225u2260]|[u0391-u0451]|[u00A7u00A8u00B1u00B4u00D7u00F7])+";Do=Do.replace(/u/g,"\\u");const g3="(?:(?![A-Z0-9 $%*+\\-./:]|"+Do+`)(?:.|[\r
]))+`;fn.KANJI=new RegExp(Do,"g");fn.BYTE_KANJI=new RegExp("[^A-Z0-9 $%*+\\-./:]+","g");fn.BYTE=new RegExp(g3,"g");fn.NUMERIC=new RegExp(Eh,"g");fn.ALPHANUMERIC=new RegExp(f3,"g");const m3=new RegExp("^"+Do+"$"),w3=new RegExp("^"+Eh+"$"),b3=new RegExp("^[A-Z0-9 $%*+\\-./:]+$");fn.testKanji=function(e){return m3.test(e)};fn.testNumeric=function(e){return w3.test(e)};fn.testAlphanumeric=function(e){return b3.test(e)};(function(n){const e=Yl,t=fn;n.NUMERIC={id:"Numeric",bit:1,ccBits:[10,12,14]},n.ALPHANUMERIC={id:"Alphanumeric",bit:2,ccBits:[9,11,13]},n.BYTE={id:"Byte",bit:4,ccBits:[8,16,16]},n.KANJI={id:"Kanji",bit:8,ccBits:[8,10,12]},n.MIXED={bit:-1},n.getCharCountIndicator=function(r,s){if(!r.ccBits)throw new Error("Invalid mode: "+r);if(!e.isValid(s))throw new Error("Invalid version: "+s);return s>=1&&s<10?r.ccBits[0]:s<27?r.ccBits[1]:r.ccBits[2]},n.getBestModeForData=function(r){return t.testNumeric(r)?n.NUMERIC:t.testAlphanumeric(r)?n.ALPHANUMERIC:t.testKanji(r)?n.KANJI:n.BYTE},n.toString=function(r){if(r&&r.id)return r.id;throw new Error("Invalid mode")},n.isValid=function(r){return r&&r.bit&&r.ccBits};function i(o){if(typeof o!="string")throw new Error("Param is not a string");switch(o.toLowerCase()){case"numeric":return n.NUMERIC;case"alphanumeric":return n.ALPHANUMERIC;case"kanji":return n.KANJI;case"byte":return n.BYTE;default:throw new Error("Unknown mode: "+o)}}n.from=function(r,s){if(n.isValid(r))return r;try{return i(r)}catch{return s}}})(Qn);(function(n){const e=xt,t=Ba,i=La,o=Qn,r=Yl,s=7973,a=e.getBCHDigit(s);function c(g,b,_){for(let x=1;x<=40;x++)if(b<=n.getCapacity(x,_,g))return x}function u(g,b){return o.getCharCountIndicator(g,b)+4}function h(g,b){let _=0;return g.forEach(function(x){const C=u(x.mode,b);_+=C+x.getBitsLength()}),_}function p(g,b){for(let _=1;_<=40;_++)if(h(g,_)<=n.getCapacity(_,b,o.MIXED))return _}n.from=function(b,_){return r.isValid(b)?parseInt(b,10):_},n.getCapacity=function(b,_,x){if(!r.isValid(b))throw new Error("Invalid QR Code version");typeof x>"u"&&(x=o.BYTE);const C=e.getSymbolTotalCodewords(b),$=t.getTotalCodewordsCount(b,_),R=(C-$)*8;if(x===o.MIXED)return R;const T=R-u(x,b);switch(x){case o.NUMERIC:return Math.floor(T/10*3);case o.ALPHANUMERIC:return Math.floor(T/11*2);case o.KANJI:return Math.floor(T/13);case o.BYTE:default:return Math.floor(T/8)}},n.getBestVersionForData=function(b,_){let x;const C=i.from(_,i.M);if(Array.isArray(b)){if(b.length>1)return p(b,C);if(b.length===0)return 1;x=b[0]}else x=b;return c(x.mode,x.getLength(),C)},n.getEncodedBits=function(b){if(!r.isValid(b)||b<7)throw new Error("Invalid QR Code version");let _=b<<12;for(;e.getBCHDigit(_)-a>=0;)_^=s<<e.getBCHDigit(_)-a;return b<<12|_}})(_h);var $h={};const nl=xt,Ah=1335,v3=21522,hd=nl.getBCHDigit(Ah);$h.getEncodedBits=function(e,t){const i=e.bit<<3|t;let o=i<<10;for(;nl.getBCHDigit(o)-hd>=0;)o^=Ah<<nl.getBCHDigit(o)-hd;return(i<<10|o)^v3};var Sh={};const y3=Qn;function $r(n){this.mode=y3.NUMERIC,this.data=n.toString()}$r.getBitsLength=function(e){return 10*Math.floor(e/3)+(e%3?e%3*3+1:0)};$r.prototype.getLength=function(){return this.data.length};$r.prototype.getBitsLength=function(){return $r.getBitsLength(this.data.length)};$r.prototype.write=function(e){let t,i,o;for(t=0;t+3<=this.data.length;t+=3)i=this.data.substr(t,3),o=parseInt(i,10),e.put(o,10);const r=this.data.length-t;r>0&&(i=this.data.substr(t),o=parseInt(i,10),e.put(o,r*3+1))};var x3=$r;const C3=Qn,wc=["0","1","2","3","4","5","6","7","8","9","A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z"," ","$","%","*","+","-",".","/",":"];function Ar(n){this.mode=C3.ALPHANUMERIC,this.data=n}Ar.getBitsLength=function(e){return 11*Math.floor(e/2)+6*(e%2)};Ar.prototype.getLength=function(){return this.data.length};Ar.prototype.getBitsLength=function(){return Ar.getBitsLength(this.data.length)};Ar.prototype.write=function(e){let t;for(t=0;t+2<=this.data.length;t+=2){let i=wc.indexOf(this.data[t])*45;i+=wc.indexOf(this.data[t+1]),e.put(i,11)}this.data.length%2&&e.put(wc.indexOf(this.data[t]),6)};var _3=Ar,E3=function(e){for(var t=[],i=e.length,o=0;o<i;o++){var r=e.charCodeAt(o);if(r>=55296&&r<=56319&&i>o+1){var s=e.charCodeAt(o+1);s>=56320&&s<=57343&&(r=(r-55296)*1024+s-56320+65536,o+=1)}if(r<128){t.push(r);continue}if(r<2048){t.push(r>>6|192),t.push(r&63|128);continue}if(r<55296||r>=57344&&r<65536){t.push(r>>12|224),t.push(r>>6&63|128),t.push(r&63|128);continue}if(r>=65536&&r<=1114111){t.push(r>>18|240),t.push(r>>12&63|128),t.push(r>>6&63|128),t.push(r&63|128);continue}t.push(239,191,189)}return new Uint8Array(t).buffer};const $3=E3,A3=Qn;function Sr(n){this.mode=A3.BYTE,typeof n=="string"&&(n=$3(n)),this.data=new Uint8Array(n)}Sr.getBitsLength=function(e){return e*8};Sr.prototype.getLength=function(){return this.data.length};Sr.prototype.getBitsLength=function(){return Sr.getBitsLength(this.data.length)};Sr.prototype.write=function(n){for(let e=0,t=this.data.length;e<t;e++)n.put(this.data[e],8)};var S3=Sr;const I3=Qn,R3=xt;function Ir(n){this.mode=I3.KANJI,this.data=n}Ir.getBitsLength=function(e){return e*13};Ir.prototype.getLength=function(){return this.data.length};Ir.prototype.getBitsLength=function(){return Ir.getBitsLength(this.data.length)};Ir.prototype.write=function(n){let e;for(e=0;e<this.data.length;e++){let t=R3.toSJIS(this.data[e]);if(t>=33088&&t<=40956)t-=33088;else if(t>=57408&&t<=60351)t-=49472;else throw new Error("Invalid SJIS character: "+this.data[e]+`
Make sure your charset is UTF-8`);t=(t>>>8&255)*192+(t&255),n.put(t,13)}};var T3=Ir,Ih={exports:{}};(function(n){var e={single_source_shortest_paths:function(t,i,o){var r={},s={};s[i]=0;var a=e.PriorityQueue.make();a.push(i,0);for(var c,u,h,p,g,b,_,x,C;!a.empty();){c=a.pop(),u=c.value,p=c.cost,g=t[u]||{};for(h in g)g.hasOwnProperty(h)&&(b=g[h],_=p+b,x=s[h],C=typeof s[h]>"u",(C||x>_)&&(s[h]=_,a.push(h,_),r[h]=u))}if(typeof o<"u"&&typeof s[o]>"u"){var $=["Could not find a path from ",i," to ",o,"."].join("");throw new Error($)}return r},extract_shortest_path_from_predecessor_list:function(t,i){for(var o=[],r=i;r;)o.push(r),t[r],r=t[r];return o.reverse(),o},find_path:function(t,i,o){var r=e.single_source_shortest_paths(t,i,o);return e.extract_shortest_path_from_predecessor_list(r,o)},PriorityQueue:{make:function(t){var i=e.PriorityQueue,o={},r;t=t||{};for(r in i)i.hasOwnProperty(r)&&(o[r]=i[r]);return o.queue=[],o.sorter=t.sorter||i.default_sorter,o},default_sorter:function(t,i){return t.cost-i.cost},push:function(t,i){var o={value:t,cost:i};this.queue.push(o),this.queue.sort(this.sorter)},pop:function(){return this.queue.shift()},empty:function(){return this.queue.length===0}}};n.exports=e})(Ih);var P3=Ih.exports;(function(n){const e=Qn,t=x3,i=_3,o=S3,r=T3,s=fn,a=xt,c=P3;function u($){return unescape(encodeURIComponent($)).length}function h($,R,T){const y=[];let S;for(;(S=$.exec(T))!==null;)y.push({data:S[0],index:S.index,mode:R,length:S[0].length});return y}function p($){const R=h(s.NUMERIC,e.NUMERIC,$),T=h(s.ALPHANUMERIC,e.ALPHANUMERIC,$);let y,S;return a.isKanjiModeEnabled()?(y=h(s.BYTE,e.BYTE,$),S=h(s.KANJI,e.KANJI,$)):(y=h(s.BYTE_KANJI,e.BYTE,$),S=[]),R.concat(T,y,S).sort(function(D,ee){return D.index-ee.index}).map(function(D){return{data:D.data,mode:D.mode,length:D.length}})}function g($,R){switch(R){case e.NUMERIC:return t.getBitsLength($);case e.ALPHANUMERIC:return i.getBitsLength($);case e.KANJI:return r.getBitsLength($);case e.BYTE:return o.getBitsLength($)}}function b($){return $.reduce(function(R,T){const y=R.length-1>=0?R[R.length-1]:null;return y&&y.mode===T.mode?(R[R.length-1].data+=T.data,R):(R.push(T),R)},[])}function _($){const R=[];for(let T=0;T<$.length;T++){const y=$[T];switch(y.mode){case e.NUMERIC:R.push([y,{data:y.data,mode:e.ALPHANUMERIC,length:y.length},{data:y.data,mode:e.BYTE,length:y.length}]);break;case e.ALPHANUMERIC:R.push([y,{data:y.data,mode:e.BYTE,length:y.length}]);break;case e.KANJI:R.push([y,{data:y.data,mode:e.BYTE,length:u(y.data)}]);break;case e.BYTE:R.push([{data:y.data,mode:e.BYTE,length:u(y.data)}])}}return R}function x($,R){const T={},y={start:{}};let S=["start"];for(let M=0;M<$.length;M++){const D=$[M],ee=[];for(let K=0;K<D.length;K++){const H=D[K],V=""+M+K;ee.push(V),T[V]={node:H,lastCount:0},y[V]={};for(let re=0;re<S.length;re++){const me=S[re];T[me]&&T[me].node.mode===H.mode?(y[me][V]=g(T[me].lastCount+H.length,H.mode)-g(T[me].lastCount,H.mode),T[me].lastCount+=H.length):(T[me]&&(T[me].lastCount=H.length),y[me][V]=g(H.length,H.mode)+4+e.getCharCountIndicator(H.mode,R))}}S=ee}for(let M=0;M<S.length;M++)y[S[M]].end=0;return{map:y,table:T}}function C($,R){let T;const y=e.getBestModeForData($);if(T=e.from(R,y),T!==e.BYTE&&T.bit<y.bit)throw new Error('"'+$+'" cannot be encoded with mode '+e.toString(T)+`.
 Suggested mode is: `+e.toString(y));switch(T===e.KANJI&&!a.isKanjiModeEnabled()&&(T=e.BYTE),T){case e.NUMERIC:return new t($);case e.ALPHANUMERIC:return new i($);case e.KANJI:return new r($);case e.BYTE:return new o($)}}n.fromArray=function(R){return R.reduce(function(T,y){return typeof y=="string"?T.push(C(y,null)):y.data&&T.push(C(y.data,y.mode)),T},[])},n.fromString=function(R,T){const y=p(R,a.isKanjiModeEnabled()),S=_(y),M=x(S,T),D=c.find_path(M.map,"start","end"),ee=[];for(let K=1;K<D.length-1;K++)ee.push(M.table[D[K]].node);return n.fromArray(b(ee))},n.rawSplit=function(R){return n.fromArray(p(R,a.isKanjiModeEnabled()))}})(Sh);const Da=xt,bc=La,O3=u3,k3=d3,N3=bh,M3=vh,il=yh,rl=Ba,L3=p3,Gs=_h,B3=$h,j3=Qn,vc=Sh;function D3(n,e){const t=n.size,i=M3.getPositions(e);for(let o=0;o<i.length;o++){const r=i[o][0],s=i[o][1];for(let a=-1;a<=7;a++)if(!(r+a<=-1||t<=r+a))for(let c=-1;c<=7;c++)s+c<=-1||t<=s+c||(a>=0&&a<=6&&(c===0||c===6)||c>=0&&c<=6&&(a===0||a===6)||a>=2&&a<=4&&c>=2&&c<=4?n.set(r+a,s+c,!0,!0):n.set(r+a,s+c,!1,!0))}}function U3(n){const e=n.size;for(let t=8;t<e-8;t++){const i=t%2===0;n.set(t,6,i,!0),n.set(6,t,i,!0)}}function W3(n,e){const t=N3.getPositions(e);for(let i=0;i<t.length;i++){const o=t[i][0],r=t[i][1];for(let s=-2;s<=2;s++)for(let a=-2;a<=2;a++)s===-2||s===2||a===-2||a===2||s===0&&a===0?n.set(o+s,r+a,!0,!0):n.set(o+s,r+a,!1,!0)}}function z3(n,e){const t=n.size,i=Gs.getEncodedBits(e);let o,r,s;for(let a=0;a<18;a++)o=Math.floor(a/3),r=a%3+t-8-3,s=(i>>a&1)===1,n.set(o,r,s,!0),n.set(r,o,s,!0)}function yc(n,e,t){const i=n.size,o=B3.getEncodedBits(e,t);let r,s;for(r=0;r<15;r++)s=(o>>r&1)===1,r<6?n.set(r,8,s,!0):r<8?n.set(r+1,8,s,!0):n.set(i-15+r,8,s,!0),r<8?n.set(8,i-r-1,s,!0):r<9?n.set(8,15-r-1+1,s,!0):n.set(8,15-r-1,s,!0);n.set(i-8,8,1,!0)}function F3(n,e){const t=n.size;let i=-1,o=t-1,r=7,s=0;for(let a=t-1;a>0;a-=2)for(a===6&&a--;;){for(let c=0;c<2;c++)if(!n.isReserved(o,a-c)){let u=!1;s<e.length&&(u=(e[s]>>>r&1)===1),n.set(o,a-c,u),r--,r===-1&&(s++,r=7)}if(o+=i,o<0||t<=o){o-=i,i=-i;break}}}function H3(n,e,t){const i=new O3;t.forEach(function(c){i.put(c.mode.bit,4),i.put(c.getLength(),j3.getCharCountIndicator(c.mode,n)),c.write(i)});const o=Da.getSymbolTotalCodewords(n),r=rl.getTotalCodewordsCount(n,e),s=(o-r)*8;for(i.getLengthInBits()+4<=s&&i.put(0,4);i.getLengthInBits()%8!==0;)i.putBit(0);const a=(s-i.getLengthInBits())/8;for(let c=0;c<a;c++)i.put(c%2?17:236,8);return V3(i,n,e)}function V3(n,e,t){const i=Da.getSymbolTotalCodewords(e),o=rl.getTotalCodewordsCount(e,t),r=i-o,s=rl.getBlocksCount(e,t),a=i%s,c=s-a,u=Math.floor(i/s),h=Math.floor(r/s),p=h+1,g=u-h,b=new L3(g);let _=0;const x=new Array(s),C=new Array(s);let $=0;const R=new Uint8Array(n.buffer);for(let D=0;D<s;D++){const ee=D<c?h:p;x[D]=R.slice(_,_+ee),C[D]=b.encode(x[D]),_+=ee,$=Math.max($,ee)}const T=new Uint8Array(i);let y=0,S,M;for(S=0;S<$;S++)for(M=0;M<s;M++)S<x[M].length&&(T[y++]=x[M][S]);for(S=0;S<g;S++)for(M=0;M<s;M++)T[y++]=C[M][S];return T}function Z3(n,e,t,i){let o;if(Array.isArray(n))o=vc.fromArray(n);else if(typeof n=="string"){let u=e;if(!u){const h=vc.rawSplit(n);u=Gs.getBestVersionForData(h,t)}o=vc.fromString(n,u||40)}else throw new Error("Invalid data");const r=Gs.getBestVersionForData(o,t);if(!r)throw new Error("The amount of data is too big to be stored in a QR Code");if(!e)e=r;else if(e<r)throw new Error(`
The chosen QR Code version cannot contain this amount of data.
Minimum version required to store current data is: `+r+`.
`);const s=H3(e,t,o),a=Da.getSymbolSize(e),c=new k3(a);return D3(c,e),U3(c),W3(c,e),yc(c,t,0),e>=7&&z3(c,e),F3(c,s),isNaN(i)&&(i=il.getBestMask(c,yc.bind(null,c,t))),il.applyMask(i,c),yc(c,t,i),{modules:c,version:e,errorCorrectionLevel:t,maskPattern:i,segments:o}}mh.create=function(e,t){if(typeof e>"u"||e==="")throw new Error("No input text");let i=bc.M,o,r;return typeof t<"u"&&(i=bc.from(t.errorCorrectionLevel,bc.M),o=Gs.from(t.version),r=il.from(t.maskPattern),t.toSJISFunc&&Da.setToSJISFunction(t.toSJISFunc)),Z3(e,o,i,r)};var Rh={},Kl={};(function(n){function e(t){if(typeof t=="number"&&(t=t.toString()),typeof t!="string")throw new Error("Color should be defined as hex string");let i=t.slice().replace("#","").split("");if(i.length<3||i.length===5||i.length>8)throw new Error("Invalid hex color: "+t);(i.length===3||i.length===4)&&(i=Array.prototype.concat.apply([],i.map(function(r){return[r,r]}))),i.length===6&&i.push("F","F");const o=parseInt(i.join(""),16);return{r:o>>24&255,g:o>>16&255,b:o>>8&255,a:o&255,hex:"#"+i.slice(0,6).join("")}}n.getOptions=function(i){i||(i={}),i.color||(i.color={});const o=typeof i.margin>"u"||i.margin===null||i.margin<0?4:i.margin,r=i.width&&i.width>=21?i.width:void 0,s=i.scale||4;return{width:r,scale:r?4:s,margin:o,color:{dark:e(i.color.dark||"#000000ff"),light:e(i.color.light||"#ffffffff")},type:i.type,rendererOpts:i.rendererOpts||{}}},n.getScale=function(i,o){return o.width&&o.width>=i+o.margin*2?o.width/(i+o.margin*2):o.scale},n.getImageWidth=function(i,o){const r=n.getScale(i,o);return Math.floor((i+o.margin*2)*r)},n.qrToImageData=function(i,o,r){const s=o.modules.size,a=o.modules.data,c=n.getScale(s,r),u=Math.floor((s+r.margin*2)*c),h=r.margin*c,p=[r.color.light,r.color.dark];for(let g=0;g<u;g++)for(let b=0;b<u;b++){let _=(g*u+b)*4,x=r.color.light;if(g>=h&&b>=h&&g<u-h&&b<u-h){const C=Math.floor((g-h)/c),$=Math.floor((b-h)/c);x=p[a[C*s+$]?1:0]}i[_++]=x.r,i[_++]=x.g,i[_++]=x.b,i[_]=x.a}}})(Kl);(function(n){const e=Kl;function t(o,r,s){o.clearRect(0,0,r.width,r.height),r.style||(r.style={}),r.height=s,r.width=s,r.style.height=s+"px",r.style.width=s+"px"}function i(){try{return document.createElement("canvas")}catch{throw new Error("You need to specify a canvas element")}}n.render=function(r,s,a){let c=a,u=s;typeof c>"u"&&(!s||!s.getContext)&&(c=s,s=void 0),s||(u=i()),c=e.getOptions(c);const h=e.getImageWidth(r.modules.size,c),p=u.getContext("2d"),g=p.createImageData(h,h);return e.qrToImageData(g.data,r,c),t(p,u,h),p.putImageData(g,0,0),u},n.renderToDataURL=function(r,s,a){let c=a;typeof c>"u"&&(!s||!s.getContext)&&(c=s,s=void 0),c||(c={});const u=n.render(r,s,c),h=c.type||"image/png",p=c.rendererOpts||{};return u.toDataURL(h,p.quality)}})(Rh);var Th={};const q3=Kl;function pd(n,e){const t=n.a/255,i=e+'="'+n.hex+'"';return t<1?i+" "+e+'-opacity="'+t.toFixed(2).slice(1)+'"':i}function xc(n,e,t){let i=n+e;return typeof t<"u"&&(i+=" "+t),i}function G3(n,e,t){let i="",o=0,r=!1,s=0;for(let a=0;a<n.length;a++){const c=Math.floor(a%e),u=Math.floor(a/e);!c&&!r&&(r=!0),n[a]?(s++,a>0&&c>0&&n[a-1]||(i+=r?xc("M",c+t,.5+u+t):xc("m",o,0),o=0,r=!1),c+1<e&&n[a+1]||(i+=xc("h",s),s=0)):o++}return i}Th.render=function(e,t,i){const o=q3.getOptions(t),r=e.modules.size,s=e.modules.data,a=r+o.margin*2,c=o.color.light.a?"<path "+pd(o.color.light,"fill")+' d="M0 0h'+a+"v"+a+'H0z"/>':"",u="<path "+pd(o.color.dark,"stroke")+' d="'+G3(s,r,o.margin)+'"/>',h='viewBox="0 0 '+a+" "+a+'"',g='<svg xmlns="http://www.w3.org/2000/svg" '+(o.width?'width="'+o.width+'" height="'+o.width+'" ':"")+h+' shape-rendering="crispEdges">'+c+u+`</svg>
`;return typeof i=="function"&&i(null,g),g};const Y3=c3,ol=mh,Ph=Rh,K3=Th;function Jl(n,e,t,i,o){const r=[].slice.call(arguments,1),s=r.length,a=typeof r[s-1]=="function";if(!a&&!Y3())throw new Error("Callback required as last argument");if(a){if(s<2)throw new Error("Too few arguments provided");s===2?(o=t,t=e,e=i=void 0):s===3&&(e.getContext&&typeof o>"u"?(o=i,i=void 0):(o=i,i=t,t=e,e=void 0))}else{if(s<1)throw new Error("Too few arguments provided");return s===1?(t=e,e=i=void 0):s===2&&!e.getContext&&(i=t,t=e,e=void 0),new Promise(function(c,u){try{const h=ol.create(t,i);c(n(h,e,i))}catch(h){u(h)}})}try{const c=ol.create(t,i);o(null,n(c,e,i))}catch(c){o(c)}}ls.create=ol.create;ls.toCanvas=Jl.bind(null,Ph.render);ls.toDataURL=Jl.bind(null,Ph.renderToDataURL);ls.toString=Jl.bind(null,function(n,e,t){return K3.render(n,t)});const J3=.1,fd=2.5,bn=7;function Cc(n,e,t){return n===e?!1:(n-e<0?e-n:n-e)<=t+J3}function Q3(n,e){const t=Array.prototype.slice.call(ls.create(n,{errorCorrectionLevel:e}).modules.data,0),i=Math.sqrt(t.length);return t.reduce((o,r,s)=>(s%i===0?o.push([r]):o[o.length-1].push(r))&&o,[])}const X3={generate(n,e,t){const i="#141414",o="transparent",s=[],a=Q3(n,"Q"),c=e/a.length,u=[{x:0,y:0},{x:1,y:0},{x:0,y:1}];u.forEach(({x,y:C})=>{const $=(a.length-bn)*c*x,R=(a.length-bn)*c*C,T=.45;for(let y=0;y<u.length;y+=1){const S=c*(bn-y*2);s.push(B`
            <rect
              fill=${y===2?i:o}
              width=${y===0?S-5:S}
              rx= ${y===0?(S-5)*T:S*T}
              ry= ${y===0?(S-5)*T:S*T}
              stroke=${i}
              stroke-width=${y===0?5:0}
              height=${y===0?S-5:S}
              x= ${y===0?R+c*y+5/2:R+c*y}
              y= ${y===0?$+c*y+5/2:$+c*y}
            />
          `)}});const h=Math.floor((t+25)/c),p=a.length/2-h/2,g=a.length/2+h/2-1,b=[];a.forEach((x,C)=>{x.forEach(($,R)=>{if(a[C][R]&&!(C<bn&&R<bn||C>a.length-(bn+1)&&R<bn||C<bn&&R>a.length-(bn+1))&&!(C>p&&C<g&&R>p&&R<g)){const T=C*c+c/2,y=R*c+c/2;b.push([T,y])}})});const _={};return b.forEach(([x,C])=>{var $;_[x]?($=_[x])==null||$.push(C):_[x]=[C]}),Object.entries(_).map(([x,C])=>{const $=C.filter(R=>C.every(T=>!Cc(R,T,c)));return[Number(x),$]}).forEach(([x,C])=>{C.forEach($=>{s.push(B`<circle cx=${x} cy=${$} fill=${i} r=${c/fd} />`)})}),Object.entries(_).filter(([x,C])=>C.length>1).map(([x,C])=>{const $=C.filter(R=>C.some(T=>Cc(R,T,c)));return[Number(x),$]}).map(([x,C])=>{C.sort((R,T)=>R<T?-1:1);const $=[];for(const R of C){const T=$.find(y=>y.some(S=>Cc(R,S,c)));T?T.push(R):$.push([R])}return[x,$.map(R=>[R[0],R[R.length-1]])]}).forEach(([x,C])=>{C.forEach(([$,R])=>{s.push(B`
              <line
                x1=${x}
                x2=${x}
                y1=${$}
                y2=${R}
                stroke=${i}
                stroke-width=${c/(fd/2)}
                stroke-linecap="round"
              />
            `)})}),s}},e5=Z`
  :host {
    position: relative;
    user-select: none;
    display: block;
    overflow: hidden;
    aspect-ratio: 1 / 1;
    width: var(--local-size);
  }

  :host([data-theme='dark']) {
    border-radius: clamp(0px, var(--wui-border-radius-l), 40px);
    background-color: var(--wui-color-inverse-100);
    padding: var(--wui-spacing-l);
  }

  :host([data-theme='light']) {
    box-shadow: 0 0 0 1px var(--wui-color-bg-125);
    background-color: var(--wui-color-bg-125);
  }

  svg:first-child,
  wui-image,
  wui-icon {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translateY(-50%) translateX(-50%);
  }

  wui-image {
    width: 25%;
    height: 25%;
    border-radius: var(--wui-border-radius-xs);
  }

  wui-icon {
    width: 100%;
    height: 100%;
    color: #3396ff !important;
    transform: translateY(-50%) translateX(-50%) scale(0.25);
  }
`;var Wr=function(n,e,t,i){var o=arguments.length,r=o<3?e:i===null?i=Object.getOwnPropertyDescriptor(e,t):i,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")r=Reflect.decorate(n,e,t,i);else for(var a=n.length-1;a>=0;a--)(s=n[a])&&(r=(o<3?s(r):o>3?s(e,t,r):s(e,t))||r);return o>3&&r&&Object.defineProperty(e,t,r),r};let _n=class extends q{constructor(){super(...arguments),this.uri="",this.size=0,this.theme="dark",this.imageSrc=void 0,this.alt=void 0}render(){return this.dataset.theme=this.theme,this.style.cssText=`--local-size: ${this.size}px`,P`${this.templateVisual()} ${this.templateSvg()}`}templateSvg(){const e=this.theme==="light"?this.size:this.size-32;return B`
      <svg height=${e} width=${e}>
        ${X3.generate(this.uri,e,e/4)}
      </svg>
    `}templateVisual(){return this.imageSrc?P`<wui-image src=${this.imageSrc} alt=${this.alt??"logo"}></wui-image>`:P`<wui-icon size="inherit" color="inherit" name="walletConnect"></wui-icon>`}};_n.styles=[Q,e5];Wr([v()],_n.prototype,"uri",void 0);Wr([v({type:Number})],_n.prototype,"size",void 0);Wr([v()],_n.prototype,"theme",void 0);Wr([v()],_n.prototype,"imageSrc",void 0);Wr([v()],_n.prototype,"alt",void 0);_n=Wr([k("wui-qr-code")],_n);const t5=Z`
  :host {
    position: relative;
    display: inline-block;
    width: 100%;
  }
`;var n5=function(n,e,t,i){var o=arguments.length,r=o<3?e:i===null?i=Object.getOwnPropertyDescriptor(e,t):i,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")r=Reflect.decorate(n,e,t,i);else for(var a=n.length-1;a>=0;a--)(s=n[a])&&(r=(o<3?s(r):o>3?s(e,t,r):s(e,t))||r);return o>3&&r&&Object.defineProperty(e,t,r),r};let Ys=class extends q{constructor(){super(...arguments),this.inputComponentRef=dh()}render(){return P`
      <wui-input-text
        ${hh(this.inputComponentRef)}
        placeholder="Search wallet"
        icon="search"
        type="search"
        enterKeyHint="search"
        size="sm"
      >
        <wui-input-element @click=${this.clearValue} icon="close"></wui-input-element>
      </wui-input-text>
    `}clearValue(){const e=this.inputComponentRef.value,t=e==null?void 0:e.inputElementRef.value;t&&(t.value="",t.focus(),t.dispatchEvent(new Event("input")))}};Ys.styles=[Q,t5];Ys=n5([k("wui-search-bar")],Ys);const i5=Z`
  :host {
    display: flex;
    column-gap: var(--wui-spacing-xs);
    align-items: center;
    padding: var(--wui-spacing-xs) var(--wui-spacing-m) var(--wui-spacing-xs) var(--wui-spacing-xs);
    border-radius: var(--wui-border-radius-3xl);
    border: 1px solid var(--wui-gray-glass-005);
    box-sizing: border-box;
    max-height: 40px;
    background-color: var(--wui-color-bg-175);
    box-shadow:
      0px 14px 64px -4px rgba(0, 0, 0, 0.15),
      0px 8px 22px -6px rgba(0, 0, 0, 0.15);
  }
`;var ds=function(n,e,t,i){var o=arguments.length,r=o<3?e:i===null?i=Object.getOwnPropertyDescriptor(e,t):i,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")r=Reflect.decorate(n,e,t,i);else for(var a=n.length-1;a>=0;a--)(s=n[a])&&(r=(o<3?s(r):o>3?s(e,t,r):s(e,t))||r);return o>3&&r&&Object.defineProperty(e,t,r),r};let Vn=class extends q{constructor(){super(...arguments),this.backgroundColor="accent-100",this.iconColor="accent-100",this.icon="checkmark",this.message=""}render(){return P`
      <wui-icon-box
        size="sm"
        iconSize="xs"
        iconColor=${this.iconColor}
        backgroundColor=${this.backgroundColor}
        icon=${this.icon}
        background="opaque"
      ></wui-icon-box>
      <wui-text variant="paragraph-500" color="fg-100">${this.message}</wui-text>
    `}};Vn.styles=[Q,i5];ds([v()],Vn.prototype,"backgroundColor",void 0);ds([v()],Vn.prototype,"iconColor",void 0);ds([v()],Vn.prototype,"icon",void 0);ds([v()],Vn.prototype,"message",void 0);Vn=ds([k("wui-snackbar")],Vn);const r5=Z`
  :host {
    display: inline-flex;
    background-color: var(--wui-gray-glass-002);
    border-radius: var(--wui-border-radius-3xl);
    padding: var(--wui-spacing-3xs);
    position: relative;
    height: 36px;
    overflow: hidden;
  }

  :host::before {
    content: '';
    position: absolute;
    pointer-events: none;
    top: 4px;
    left: 4px;
    display: block;
    width: var(--local-tab-width);
    height: 28px;
    border-radius: var(--wui-border-radius-3xl);
    background-color: var(--wui-gray-glass-002);
    box-shadow: inset 0 0 0 1px var(--wui-gray-glass-002);
    transform: translateX(calc(var(--local-tab) * var(--local-tab-width)));
    transition: transform var(--wui-ease-out-power-2) var(--wui-duration-lg);
  }

  :host([data-type='flex'])::before {
    left: 3px;
    transform: translateX(calc((var(--local-tab) * 34px) + (var(--local-tab) * 4px)));
  }

  :host([data-type='flex']) {
    display: flex;
    padding: 0px 0px 0px 12px;
    gap: 4px;
  }

  :host([data-type='flex']) > button > wui-text {
    position: absolute;
    left: 18px;
    opacity: 0;
  }

  button[data-active='true'] > wui-icon,
  button[data-active='true'] > wui-text {
    color: var(--wui-color-fg-100);
  }

  button[data-active='false'] > wui-icon,
  button[data-active='false'] > wui-text {
    color: var(--wui-color-fg-200);
  }

  button[data-active='true']:disabled,
  button[data-active='false']:disabled {
    background-color: transparent;
    opacity: 0.5;
    cursor: not-allowed;
  }

  button[data-active='true']:disabled > wui-text {
    color: var(--wui-color-fg-200);
  }

  button[data-active='false']:disabled > wui-text {
    color: var(--wui-color-fg-300);
  }

  button > wui-icon,
  button > wui-text {
    pointer-events: none;
    transition: all var(--wui-ease-out-power-2) var(--wui-duration-lg);
  }

  button {
    width: var(--local-tab-width);
  }

  :host([data-type='flex']) > button {
    width: 34px;
    position: relative;
    display: flex;
    justify-content: flex-start;
  }

  button:hover:enabled,
  button:active:enabled {
    background-color: transparent !important;
  }

  button:hover:enabled > wui-icon,
  button:active:enabled > wui-icon {
    color: var(--wui-color-fg-125);
  }

  button:hover:enabled > wui-text,
  button:active:enabled > wui-text {
    color: var(--wui-color-fg-125);
  }

  button {
    border-radius: var(--wui-border-radius-3xl);
  }
`;var Xn=function(n,e,t,i){var o=arguments.length,r=o<3?e:i===null?i=Object.getOwnPropertyDescriptor(e,t):i,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")r=Reflect.decorate(n,e,t,i);else for(var a=n.length-1;a>=0;a--)(s=n[a])&&(r=(o<3?s(r):o>3?s(e,t,r):s(e,t))||r);return o>3&&r&&Object.defineProperty(e,t,r),r};let jt=class extends q{constructor(){super(...arguments),this.tabs=[],this.onTabChange=()=>null,this.buttons=[],this.disabled=!1,this.activeTab=0,this.localTabWidth="100px",this.isDense=!1}render(){return this.isDense=this.tabs.length>3,this.style.cssText=`
      --local-tab: ${this.activeTab};
      --local-tab-width: ${this.localTabWidth};
    `,this.dataset.type=this.isDense?"flex":"block",this.tabs.map((e,t)=>{const i=t===this.activeTab;return P`
        <button
          ?disabled=${this.disabled}
          @click=${()=>this.onTabClick(t)}
          data-active=${i}
        >
          <wui-icon size="xs" color="inherit" name=${e.icon}></wui-icon>
          <wui-text variant="small-600" color="inherit"> ${e.label} </wui-text>
        </button>
      `})}firstUpdated(){this.shadowRoot&&this.isDense&&(this.buttons=[...this.shadowRoot.querySelectorAll("button")],setTimeout(()=>{this.animateTabs(0,!0)},0))}onTabClick(e){this.buttons&&this.animateTabs(e,!1),this.activeTab=e,this.onTabChange(e)}animateTabs(e,t){const i=this.buttons[this.activeTab],o=this.buttons[e],r=i==null?void 0:i.querySelector("wui-text"),s=o==null?void 0:o.querySelector("wui-text"),a=o==null?void 0:o.getBoundingClientRect(),c=s==null?void 0:s.getBoundingClientRect();i&&r&&!t&&e!==this.activeTab&&(r.animate([{opacity:0}],{duration:50,easing:"ease",fill:"forwards"}),i.animate([{width:"34px"}],{duration:500,easing:"ease",fill:"forwards"})),o&&a&&c&&s&&(e!==this.activeTab||t)&&(this.localTabWidth=`${Math.round(a.width+c.width)+6}px`,o.animate([{width:`${a.width+c.width}px`}],{duration:t?0:500,fill:"forwards",easing:"ease"}),s.animate([{opacity:1}],{duration:t?0:125,delay:t?0:200,fill:"forwards",easing:"ease"}))}};jt.styles=[Q,$e,r5];Xn([v({type:Array})],jt.prototype,"tabs",void 0);Xn([v()],jt.prototype,"onTabChange",void 0);Xn([v({type:Array})],jt.prototype,"buttons",void 0);Xn([v({type:Boolean})],jt.prototype,"disabled",void 0);Xn([Sa()],jt.prototype,"activeTab",void 0);Xn([Sa()],jt.prototype,"localTabWidth",void 0);Xn([Sa()],jt.prototype,"isDense",void 0);jt=Xn([k("wui-tabs")],jt);const o5=Z`
  :host {
    display: block;
    padding: 9px var(--wui-spacing-s) 10px var(--wui-spacing-s);
    border-radius: var(--wui-border-radius-xxs);
    background-color: var(--wui-color-fg-100);
    color: var(--wui-color-bg-100);
    position: relative;
  }

  wui-icon {
    position: absolute;
    width: 12px !important;
    height: 4px !important;
  }

  wui-icon[data-placement='top'] {
    bottom: 0;
    left: 50%;
    transform: translate(-50%, 95%);
  }

  wui-icon[data-placement='bottom'] {
    top: 0;
    left: 50%;
    transform: translate(-50%, -95%) rotate(180deg);
  }

  wui-icon[data-placement='right'] {
    top: 50%;
    left: 0;
    transform: translate(-65%, -50%) rotate(90deg);
  }

  wui-icon[data-placement='left'] {
    top: 50%;
    right: 0%;
    transform: translate(65%, -50%) rotate(270deg);
  }
`;var Ql=function(n,e,t,i){var o=arguments.length,r=o<3?e:i===null?i=Object.getOwnPropertyDescriptor(e,t):i,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")r=Reflect.decorate(n,e,t,i);else for(var a=n.length-1;a>=0;a--)(s=n[a])&&(r=(o<3?s(r):o>3?s(e,t,r):s(e,t))||r);return o>3&&r&&Object.defineProperty(e,t,r),r};let Rr=class extends q{constructor(){super(...arguments),this.placement="top",this.message=""}render(){return P`<wui-icon
        data-placement=${this.placement}
        color="fg-100"
        size="inherit"
        name="cursor"
      ></wui-icon>
      <wui-text color="inherit" variant="small-500">${this.message}</wui-text>`}};Rr.styles=[Q,$e,o5];Ql([v()],Rr.prototype,"placement",void 0);Ql([v()],Rr.prototype,"message",void 0);Rr=Ql([k("wui-tooltip")],Rr);const s5=Z`
  :host {
    display: flex;
    justify-content: center;
    align-items: center;
    width: var(--wui-icon-box-size-xl);
    height: var(--wui-icon-box-size-xl);
    box-shadow: 0 0 0 8px var(--wui-thumbnail-border);
    border-radius: var(--local-border-radius);
    overflow: hidden;
  }

  wui-icon {
    width: 32px;
    height: 32px;
  }
`;var Ua=function(n,e,t,i){var o=arguments.length,r=o<3?e:i===null?i=Object.getOwnPropertyDescriptor(e,t):i,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")r=Reflect.decorate(n,e,t,i);else for(var a=n.length-1;a>=0;a--)(s=n[a])&&(r=(o<3?s(r):o>3?s(e,t,r):s(e,t))||r);return o>3&&r&&Object.defineProperty(e,t,r),r};let Ti=class extends q{render(){return this.style.cssText=`--local-border-radius: ${this.borderRadiusFull?"1000px":"20px"};`,P`${this.templateVisual()}`}templateVisual(){return this.imageSrc?P`<wui-image src=${this.imageSrc} alt=${this.alt??""}></wui-image>`:P`<wui-icon
      data-parent-size="md"
      size="inherit"
      color="inherit"
      name="walletPlaceholder"
    ></wui-icon>`}};Ti.styles=[Q,s5];Ua([v()],Ti.prototype,"imageSrc",void 0);Ua([v()],Ti.prototype,"alt",void 0);Ua([v({type:Boolean})],Ti.prototype,"borderRadiusFull",void 0);Ti=Ua([k("wui-visual-thumbnail")],Ti);const a5=Z`
  :host {
    display: block;
  }

  button {
    width: 100%;
    display: block;
    padding-top: var(--wui-spacing-l);
    padding-bottom: var(--wui-spacing-l);
    padding-left: var(--wui-spacing-s);
    padding-right: var(--wui-spacing-2l);
    border-radius: var(--wui-border-radius-s);
    background-color: var(--wui-accent-glass-015);
  }

  button:hover {
    background-color: var(--wui-accent-glass-010) !important;
  }

  button:active {
    background-color: var(--wui-accent-glass-020) !important;
  }
`;var Wa=function(n,e,t,i){var o=arguments.length,r=o<3?e:i===null?i=Object.getOwnPropertyDescriptor(e,t):i,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")r=Reflect.decorate(n,e,t,i);else for(var a=n.length-1;a>=0;a--)(s=n[a])&&(r=(o<3?s(r):o>3?s(e,t,r):s(e,t))||r);return o>3&&r&&Object.defineProperty(e,t,r),r};let Pi=class extends q{constructor(){super(...arguments),this.label="",this.description="",this.icon="wallet"}render(){return P`
      <button>
        <wui-flex gap="m" alignItems="center" justifyContent="space-between">
          <wui-icon-box
            size="lg"
            iconcolor="accent-100"
            backgroundcolor="accent-100"
            icon=${this.icon}
            background="transparent"
          ></wui-icon-box>

          <wui-flex flexDirection="column" gap="3xs">
            <wui-text variant="paragraph-500" color="fg-100">${this.label}</wui-text>
            <wui-text variant="small-400" color="fg-200">${this.description}</wui-text>
          </wui-flex>

          <wui-icon size="md" color="fg-200" name="chevronRight"></wui-icon>
        </wui-flex>
      </button>
    `}};Pi.styles=[Q,$e,a5];Wa([v()],Pi.prototype,"label",void 0);Wa([v()],Pi.prototype,"description",void 0);Wa([v()],Pi.prototype,"icon",void 0);Pi=Wa([k("wui-notice-card")],Pi);const c5=Z`
  button {
    height: auto;
    position: relative;
    flex-direction: column;
    gap: var(--wui-spacing-s);
    padding: 17px 18px 17px var(--wui-spacing-m);
    width: 100%;
    background-color: var(--wui-gray-glass-002);
    border-radius: var(--wui-border-radius-xs);
    color: var(--wui-color-fg-250);
  }

  .overflowedContent {
    width: 100%;
    overflow: hidden;
  }

  .overflowedContent[data-active='false']:after {
    content: '';
    position: absolute;
    top: 50%;
    left: 0;
    right: 0;
    bottom: 0;
    background: linear-gradient(to top, var(--wui-color-bg-200), transparent);
    border-bottom-left-radius: var(--wui-border-radius-xs);
    border-bottom-right-radius: var(--wui-border-radius-xs);
  }

  .heightContent {
    max-height: 100px;
  }

  pre {
    text-align: left;
    white-space: pre-wrap;
    height: auto;
    overflow-x: auto;
    overflow-wrap: anywhere;
  }
`;var Xl=function(n,e,t,i){var o=arguments.length,r=o<3?e:i===null?i=Object.getOwnPropertyDescriptor(e,t):i,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")r=Reflect.decorate(n,e,t,i);else for(var a=n.length-1;a>=0;a--)(s=n[a])&&(r=(o<3?s(r):o>3?s(e,t,r):s(e,t))||r);return o>3&&r&&Object.defineProperty(e,t,r),r};const _c=100;let Tr=class extends q{constructor(){super(...arguments),this.textTitle="",this.overflowedContent="",this.toggled=!1,this.enableAccordion=!1,this.scrollElement=void 0,this.scrollHeightElement=0}updated(e){super.updated(e),(e.has("textTitle")||e.has("overflowedContent"))&&setTimeout(()=>{this.checkHeight()},1)}checkHeight(){this.updateComplete.then(()=>{var i,o;const e=(i=this.shadowRoot)==null?void 0:i.querySelector(".heightContent"),t=(o=this.shadowRoot)==null?void 0:o.querySelector(".textContent");if(e&&t){this.scrollElement=e;const r=t==null?void 0:t.scrollHeight;r&&r>_c&&(this.enableAccordion=!0,this.scrollHeightElement=r,this.requestUpdate())}})}render(){return P`
      <button ontouchstart @click=${()=>this.onClick()}>
        <wui-flex justifyContent="space-between" alignItems="center">
          <wui-text variant="paragraph-500" color="fg-100">${this.textTitle}</wui-text>
          ${this.chevronTemplate()}
        </wui-flex>
        <div
          data-active=${this.enableAccordion?!!this.toggled:!0}
          class="overflowedContent"
        >
          <div class="heightContent">
            <wui-text class="textContent" variant="paragraph-400" color="fg-200">
              <pre>${this.overflowedContent}</pre>
            </wui-text>
          </div>
        </div>
      </button>
    `}onClick(){var t;const e=(t=this.shadowRoot)==null?void 0:t.querySelector("wui-icon");this.enableAccordion&&(this.toggled=!this.toggled,this.requestUpdate(),this.scrollElement&&this.scrollElement.animate([{maxHeight:this.toggled?`${_c}px`:`${this.scrollHeightElement}px`},{maxHeight:this.toggled?`${this.scrollHeightElement}px`:`${_c}px`}],{duration:300,fill:"forwards",easing:"ease"}),e&&e.animate([{transform:this.toggled?"rotate(0deg)":"rotate(180deg)"},{transform:this.toggled?"rotate(180deg)":"rotate(0deg)"}],{duration:300,fill:"forwards",easing:"ease"}))}chevronTemplate(){return this.enableAccordion?P` <wui-icon color="fg-100" size="sm" name="chevronBottom"></wui-icon>`:null}};Tr.styles=[Q,$e,c5];Xl([v()],Tr.prototype,"textTitle",void 0);Xl([v()],Tr.prototype,"overflowedContent",void 0);Tr=Xl([k("wui-list-accordion")],Tr);const l5=Z`
  :host {
    display: flex;
    column-gap: var(--wui-spacing-s);
    padding: 17px 18px 17px var(--wui-spacing-m);
    width: 100%;
    background-color: var(--wui-gray-glass-002);
    border-radius: var(--wui-border-radius-xs);
    color: var(--wui-color-fg-250);
  }

  wui-image {
    width: var(--wui-icon-size-lg);
    height: var(--wui-icon-size-lg);
    border-radius: var(--wui-border-radius-3xl);
  }

  wui-icon {
    width: var(--wui-icon-size-lg);
    height: var(--wui-icon-size-lg);
  }
`;var za=function(n,e,t,i){var o=arguments.length,r=o<3?e:i===null?i=Object.getOwnPropertyDescriptor(e,t):i,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")r=Reflect.decorate(n,e,t,i);else for(var a=n.length-1;a>=0;a--)(s=n[a])&&(r=(o<3?s(r):o>3?s(e,t,r):s(e,t))||r);return o>3&&r&&Object.defineProperty(e,t,r),r};let Oi=class extends q{constructor(){super(...arguments),this.imageSrc=void 0,this.textTitle="",this.textValue=void 0}render(){return P`
      <wui-flex justifyContent="space-between" alignItems="center">
        <wui-text variant="paragraph-500" color=${this.textValue?"fg-200":"fg-100"}>
          ${this.textTitle}
        </wui-text>
        ${this.templateContent()}
      </wui-flex>
    `}templateContent(){return this.imageSrc?P`<wui-image src=${this.imageSrc} alt=${this.textTitle}></wui-image>`:this.textValue?P` <wui-text variant="paragraph-400" color="fg-100"> ${this.textValue} </wui-text>`:P`<wui-icon size="inherit" color="fg-200" name="networkPlaceholder"></wui-icon>`}};Oi.styles=[Q,$e,l5];za([v()],Oi.prototype,"imageSrc",void 0);za([v()],Oi.prototype,"textTitle",void 0);za([v()],Oi.prototype,"textValue",void 0);Oi=za([k("wui-list-content")],Oi);const u5=Z`
  button {
    column-gap: var(--wui-spacing-s);
    padding: 7px var(--wui-spacing-l) 7px var(--wui-spacing-xs);
    width: 100%;
    background-color: var(--wui-gray-glass-002);
    border-radius: var(--wui-border-radius-xs);
    color: var(--wui-color-fg-100);
  }

  button > wui-text:nth-child(2) {
    display: flex;
    flex: 1;
  }

  wui-icon {
    color: var(--wui-color-fg-200) !important;
  }

  button:disabled {
    background-color: var(--wui-gray-glass-015);
    color: var(--wui-gray-glass-015);
  }

  button:disabled > wui-tag {
    background-color: var(--wui-gray-glass-010);
    color: var(--wui-color-fg-300);
  }
`;var Fa=function(n,e,t,i){var o=arguments.length,r=o<3?e:i===null?i=Object.getOwnPropertyDescriptor(e,t):i,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")r=Reflect.decorate(n,e,t,i);else for(var a=n.length-1;a>=0;a--)(s=n[a])&&(r=(o<3?s(r):o>3?s(e,t,r):s(e,t))||r);return o>3&&r&&Object.defineProperty(e,t,r),r};let ki=class extends q{constructor(){super(...arguments),this.imageSrc="",this.name="",this.disabled=!1}render(){return P`
      <button ?disabled=${this.disabled} ontouchstart>
        ${this.templateNetworkImage()}
        <wui-text variant="paragraph-500" color="inherit">${this.name}</wui-text>
      </button>
    `}templateNetworkImage(){return this.imageSrc?P`<wui-network-image
        size="sm"
        imageSrc=${this.imageSrc}
        name=${this.name}
      ></wui-network-image>`:this.imageSrc?null:P`<wui-network-image size="sm" name=${this.name}></wui-network-image>`}};ki.styles=[Q,$e,u5];Fa([v()],ki.prototype,"imageSrc",void 0);Fa([v()],ki.prototype,"name",void 0);Fa([v({type:Boolean})],ki.prototype,"disabled",void 0);ki=Fa([k("wui-list-network")],ki);const d5=Z`
  :host {
    display: flex;
    flex-direction: column;
    gap: var(--wui-spacing-l);
    padding: 17px 18px 17px var(--wui-spacing-m);
    width: 100%;
    background-color: var(--wui-gray-glass-002);
    border-radius: var(--wui-border-radius-xs);
    color: var(--wui-color-fg-250);
  }

  wui-image {
    width: var(--wui-icon-size-lg);
    height: var(--wui-icon-size-lg);
    border-radius: var(--wui-border-radius-3xl);
  }

  wui-icon {
    width: var(--wui-icon-size-lg);
    height: var(--wui-icon-size-lg);
  }
`;var zr=function(n,e,t,i){var o=arguments.length,r=o<3?e:i===null?i=Object.getOwnPropertyDescriptor(e,t):i,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")r=Reflect.decorate(n,e,t,i);else for(var a=n.length-1;a>=0;a--)(s=n[a])&&(r=(o<3?s(r):o>3?s(e,t,r):s(e,t))||r);return o>3&&r&&Object.defineProperty(e,t,r),r};let En=class extends q{constructor(){super(...arguments),this.amount="",this.networkCurreny="",this.networkImageUrl="",this.receiverAddress="",this.addressExplorerUrl=""}render(){return P`
      <wui-flex justifyContent="space-between" alignItems="center">
        <wui-text variant="paragraph-500" color="fg-200">Sending</wui-text>
        <wui-flex gap="xs" alignItems="center">
          <wui-text variant="paragraph-400" color="fg-100">
            ${this.amount} ${this.networkCurreny}
          </wui-text>
          ${this.templateNetworkVisual()}
        </wui-flex>
      </wui-flex>
      <wui-flex justifyContent="space-between" alignItems="center">
        <wui-text variant="paragraph-500" color="fg-200">To</wui-text>
        <wui-chip
          icon="externalLink"
          variant="shadeSmall"
          href=${this.addressExplorerUrl}
          title=${this.receiverAddress}
        ></wui-chip>
      </wui-flex>
    `}templateNetworkVisual(){return this.networkImageUrl?P`<wui-image src=${this.networkImageUrl} alt="Network Image"></wui-image>`:P`<wui-icon size="inherit" color="fg-200" name="networkPlaceholder"></wui-icon>`}};En.styles=[Q,$e,d5];zr([v()],En.prototype,"amount",void 0);zr([v()],En.prototype,"networkCurreny",void 0);zr([v()],En.prototype,"networkImageUrl",void 0);zr([v()],En.prototype,"receiverAddress",void 0);zr([v()],En.prototype,"addressExplorerUrl",void 0);En=zr([k("wui-list-wallet-transaction")],En);const h5=Z`
  :host {
    width: 100%;
  }

  :host > wui-flex {
    width: 100%;
    padding: var(--wui-spacing-s);
    border-radius: var(--wui-border-radius-xs);
    width: 100%;
    display: flex;
    align-items: center;
    justify-content: flex-start;
    gap: var(--wui-spacing-s);
  }

  :host > wui-flex:hover {
    background-color: var(--wui-gray-glass-002);
  }

  .purchase-image-container {
    display: flex;
    justify-content: center;
    align-items: center;
    position: relative;
    width: var(--wui-icon-box-size-lg);
    height: var(--wui-icon-box-size-lg);
  }

  .purchase-image-container wui-image {
    width: 100%;
    height: 100%;
    position: relative;
    border-radius: calc(var(--wui-icon-box-size-lg) / 2);
  }

  .purchase-image-container wui-image::after {
    content: '';
    display: block;
    width: 100%;
    height: 100%;
    position: absolute;
    inset: 0;
    border-radius: calc(var(--wui-icon-box-size-lg) / 2);
    box-shadow: inset 0 0 0 1px var(--wui-gray-glass-005);
  }

  .purchase-image-container wui-icon-box {
    position: absolute;
    right: 0;
    bottom: 0;
    transform: translate(20%, 20%);
  }
`;var Ct=function(n,e,t,i){var o=arguments.length,r=o<3?e:i===null?i=Object.getOwnPropertyDescriptor(e,t):i,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")r=Reflect.decorate(n,e,t,i);else for(var a=n.length-1;a>=0;a--)(s=n[a])&&(r=(o<3?s(r):o>3?s(e,t,r):s(e,t))||r);return o>3&&r&&Object.defineProperty(e,t,r),r};let Ge=class extends q{constructor(){super(...arguments),this.disabled=!1,this.color="inherit",this.label="Bought",this.purchaseValue="",this.purchaseCurrency="",this.date="",this.completed=!1,this.inProgress=!1,this.failed=!1,this.onClick=null,this.symbol=""}firstUpdated(){this.icon||this.fetchTokenImage()}render(){return P`
      <wui-flex>
        ${this.imageTemplate()}
        <wui-flex flexDirection="column" gap="4xs" flexGrow="1">
          <wui-flex gap="xxs" alignItems="center" justifyContent="flex-start">
            ${this.statusIconTemplate()}
            <wui-text variant="paragraph-500" color="fg-100"> ${this.label}</wui-text>
          </wui-flex>
          <wui-text variant="small-400" color="fg-200">
            + ${this.purchaseValue} ${this.purchaseCurrency}
          </wui-text>
        </wui-flex>
        ${this.inProgress?P`<wui-loading-spinner color="fg-200" size="md"></wui-loading-spinner>`:P`<wui-text variant="micro-700" color="fg-300"><span>${this.date}</span></wui-text>`}
      </wui-flex>
    `}async fetchTokenImage(){await ie._fetchTokenImage(this.purchaseCurrency)}statusIconTemplate(){return this.inProgress?null:this.completed?this.boughtIconTemplate():this.errorIconTemplate()}errorIconTemplate(){return P`<wui-icon-box
      size="xxs"
      iconColor="error-100"
      backgroundColor="error-100"
      background="opaque"
      icon="close"
      borderColor="wui-color-bg-125"
    ></wui-icon-box>`}imageTemplate(){const e=this.icon||`https://avatar.vercel.sh/andrew.svg?size=50&text=${this.symbol}`;return P`<wui-flex class="purchase-image-container">
      <wui-image src=${e}></wui-image>
    </wui-flex>`}boughtIconTemplate(){return P`<wui-icon-box
      size="xxs"
      iconColor="success-100"
      backgroundColor="success-100"
      background="opaque"
      icon="arrowBottom"
      borderColor="wui-color-bg-125"
    ></wui-icon-box>`}};Ge.styles=[Q,$e,h5];Ct([v({type:Boolean})],Ge.prototype,"disabled",void 0);Ct([v()],Ge.prototype,"color",void 0);Ct([v()],Ge.prototype,"label",void 0);Ct([v()],Ge.prototype,"purchaseValue",void 0);Ct([v()],Ge.prototype,"purchaseCurrency",void 0);Ct([v()],Ge.prototype,"date",void 0);Ct([v({type:Boolean})],Ge.prototype,"completed",void 0);Ct([v({type:Boolean})],Ge.prototype,"inProgress",void 0);Ct([v({type:Boolean})],Ge.prototype,"failed",void 0);Ct([v()],Ge.prototype,"onClick",void 0);Ct([v()],Ge.prototype,"symbol",void 0);Ct([v()],Ge.prototype,"icon",void 0);Ge=Ct([k("wui-onramp-activity-item")],Ge);const p5=Z`
  button {
    padding: var(--wui-spacing-s);
    border-radius: var(--wui-border-radius-xs);
    background-color: var(--wui-gray-glass-002);
    width: 100%;
    display: flex;
    align-items: center;
    justify-content: flex-start;
    gap: var(--wui-spacing-s);
    transition: background-color 0.2s linear;
  }

  button:hover {
    background-color: var(--wui-gray-glass-005);
  }

  .provider-image {
    width: var(--wui-spacing-3xl);
    min-width: var(--wui-spacing-3xl);
    height: var(--wui-spacing-3xl);
    border-radius: calc(var(--wui-border-radius-xs) - calc(var(--wui-spacing-s) / 2));
    position: relative;
    overflow: hidden;
  }

  .provider-image::after {
    content: '';
    display: block;
    width: 100%;
    height: 100%;
    position: absolute;
    inset: 0;
    border-radius: calc(var(--wui-border-radius-xs) - calc(var(--wui-spacing-s) / 2));
    box-shadow: inset 0 0 0 1px var(--wui-gray-glass-005);
  }

  .network-icon {
    width: var(--wui-spacing-m);
    height: var(--wui-spacing-m);
    border-radius: calc(var(--wui-spacing-m) / 2);
    overflow: hidden;
    box-shadow:
      0 0 0 3px var(--wui-gray-glass-002),
      0 0 0 3px var(--wui-color-modal-bg);
    transition: box-shadow 0.2s linear;
  }

  button:hover .network-icon {
    box-shadow:
      0 0 0 3px var(--wui-gray-glass-005),
      0 0 0 3px var(--wui-color-modal-bg);
  }
`;var ei=function(n,e,t,i){var o=arguments.length,r=o<3?e:i===null?i=Object.getOwnPropertyDescriptor(e,t):i,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")r=Reflect.decorate(n,e,t,i);else for(var a=n.length-1;a>=0;a--)(s=n[a])&&(r=(o<3?s(r):o>3?s(e,t,r):s(e,t))||r);return o>3&&r&&Object.defineProperty(e,t,r),r};let Dt=class extends q{constructor(){super(...arguments),this.disabled=!1,this.color="inherit",this.label="",this.feeRange="",this.loading=!1,this.onClick=null}render(){return P`
      <button ?disabled=${this.disabled} ontouchstart>
        <wui-visual name=${Et(this.name)} class="provider-image"></wui-visual>
        <wui-flex flexDirection="column" gap="4xs">
          <wui-text variant="paragraph-500" color="fg-100">${this.label}</wui-text>
          <wui-flex alignItems="center" justifyContent="flex-start" gap="l">
            <wui-text variant="tiny-500" color="fg-100">
              <wui-text variant="tiny-400" color="fg-200">Fees</wui-text>
              ${this.feeRange}
            </wui-text>
            <wui-flex gap="xxs">
              <wui-icon name="bank" size="xs" color="fg-150"></wui-icon>
              <wui-icon name="card" size="xs" color="fg-150"></wui-icon>
            </wui-flex>
            ${this.networksTemplate()}
          </wui-flex>
        </wui-flex>
        ${this.loading?P`<wui-loading-spinner color="fg-200" size="md"></wui-loading-spinner>`:P`<wui-icon name="chevronRight" color="fg-200" size="sm"></wui-icon>`}
      </button>
    `}networksTemplate(){var i;const e=ge.getRequestedCaipNetworks(),t=(i=e==null?void 0:e.filter(o=>o==null?void 0:o.imageId))==null?void 0:i.slice(0,5);return P`
      <wui-flex class="networks">
        ${t==null?void 0:t.map(o=>P`
            <wui-flex class="network-icon">
              <wui-image src=${Et(Se.getNetworkImage(o))}></wui-image>
            </wui-flex>
          `)}
      </wui-flex>
    `}};Dt.styles=[Q,$e,p5];ei([v({type:Boolean})],Dt.prototype,"disabled",void 0);ei([v()],Dt.prototype,"color",void 0);ei([v()],Dt.prototype,"name",void 0);ei([v()],Dt.prototype,"label",void 0);ei([v()],Dt.prototype,"feeRange",void 0);ei([v({type:Boolean})],Dt.prototype,"loading",void 0);ei([v()],Dt.prototype,"onClick",void 0);Dt=ei([k("wui-onramp-provider-item")],Dt);const f5=Z`
  :host {
    display: grid;
    width: inherit;
    height: inherit;
  }
`;var St=function(n,e,t,i){var o=arguments.length,r=o<3?e:i===null?i=Object.getOwnPropertyDescriptor(e,t):i,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")r=Reflect.decorate(n,e,t,i);else for(var a=n.length-1;a>=0;a--)(s=n[a])&&(r=(o<3?s(r):o>3?s(e,t,r):s(e,t))||r);return o>3&&r&&Object.defineProperty(e,t,r),r};let et=class extends q{render(){return this.style.cssText=`
      grid-template-rows: ${this.gridTemplateRows};
      grid-template-columns: ${this.gridTemplateColumns};
      justify-items: ${this.justifyItems};
      align-items: ${this.alignItems};
      justify-content: ${this.justifyContent};
      align-content: ${this.alignContent};
      column-gap: ${this.columnGap&&`var(--wui-spacing-${this.columnGap})`};
      row-gap: ${this.rowGap&&`var(--wui-spacing-${this.rowGap})`};
      gap: ${this.gap&&`var(--wui-spacing-${this.gap})`};
      padding-top: ${this.padding&&ye.getSpacingStyles(this.padding,0)};
      padding-right: ${this.padding&&ye.getSpacingStyles(this.padding,1)};
      padding-bottom: ${this.padding&&ye.getSpacingStyles(this.padding,2)};
      padding-left: ${this.padding&&ye.getSpacingStyles(this.padding,3)};
      margin-top: ${this.margin&&ye.getSpacingStyles(this.margin,0)};
      margin-right: ${this.margin&&ye.getSpacingStyles(this.margin,1)};
      margin-bottom: ${this.margin&&ye.getSpacingStyles(this.margin,2)};
      margin-left: ${this.margin&&ye.getSpacingStyles(this.margin,3)};
    `,P`<slot></slot>`}};et.styles=[Q,f5];St([v()],et.prototype,"gridTemplateRows",void 0);St([v()],et.prototype,"gridTemplateColumns",void 0);St([v()],et.prototype,"justifyItems",void 0);St([v()],et.prototype,"alignItems",void 0);St([v()],et.prototype,"justifyContent",void 0);St([v()],et.prototype,"alignContent",void 0);St([v()],et.prototype,"columnGap",void 0);St([v()],et.prototype,"rowGap",void 0);St([v()],et.prototype,"gap",void 0);St([v()],et.prototype,"padding",void 0);St([v()],et.prototype,"margin",void 0);et=St([k("wui-grid")],et);const g5=Z`
  :host {
    position: relative;
    display: flex;
    width: 100%;
    height: 1px;
    background-color: var(--wui-gray-glass-005);
    justify-content: center;
    align-items: center;
  }

  :host > wui-text {
    position: absolute;
    padding: 0px 10px;
    background-color: var(--wui-color-modal-bg);
  }
`;var Oh=function(n,e,t,i){var o=arguments.length,r=o<3?e:i===null?i=Object.getOwnPropertyDescriptor(e,t):i,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")r=Reflect.decorate(n,e,t,i);else for(var a=n.length-1;a>=0;a--)(s=n[a])&&(r=(o<3?s(r):o>3?s(e,t,r):s(e,t))||r);return o>3&&r&&Object.defineProperty(e,t,r),r};let Uo=class extends q{constructor(){super(...arguments),this.text=""}render(){return P`${this.template()}`}template(){return this.text?P`<wui-text variant="small-500" color="fg-200">${this.text}</wui-text>`:null}};Uo.styles=[Q,g5];Oh([v()],Uo.prototype,"text",void 0);Uo=Oh([k("wui-separator")],Uo);var kh={exports:{}};(function(n,e){(function(t,i){n.exports=i()})(L1,function(){return function(t,i,o){o.updateLocale=function(r,s){var a=o.Ls[r];if(a)return(s?Object.keys(s):[]).forEach(function(c){a[c]=s[c]}),a}}})})(kh);var m5=kh.exports;const w5=r0(m5);ar.extend(K1);ar.extend(w5);ar.updateLocale("en",{relativeTime:{future:"in %s",past:"%s ago",s:"%s sec",m:"1 min",mm:"%d min",h:"1 hr",hh:"%d hrs",d:"1 d",dd:"%d d",M:"1 mo",MM:"%d mo",y:"1 yr",yy:"%d yr"}});const eu={getYear(n=new Date().toISOString()){return ar(n).year()},getRelativeDateFromNow(n){return ar(n).fromNow(!0)},formatDate(n,e="DD MMM"){return ar(n).format(e)}},b5=3,v5=["receive","deposit","borrow","claim"],y5=["withdraw","repay","burn"],Ln={getMonthName(n){const e=new Date;return e.setMonth(n),e.toLocaleString("en-US",{month:"long"})},getTransactionGroupTitle(n,e){const t=eu.getYear(),i=this.getMonthName(e);return n===t?i:`${i} ${n}`},getTransactionImages(n){const[e,t]=n,i=!!e&&(n==null?void 0:n.every(s=>!!s.nft_info)),o=(n==null?void 0:n.length)>1;return(n==null?void 0:n.length)===2&&!i?[this.getTransactionImage(e),this.getTransactionImage(t)]:o?n.map(s=>this.getTransactionImage(s)):[this.getTransactionImage(e)]},getTransactionImage(n){return{type:Ln.getTransactionTransferTokenType(n),url:Ln.getTransactionImageURL(n)}},getTransactionImageURL(n){var o,r,s,a,c;let e;const t=!!(n!=null&&n.nft_info),i=!!(n!=null&&n.fungible_info);return n&&t?e=(s=(r=(o=n==null?void 0:n.nft_info)==null?void 0:o.content)==null?void 0:r.preview)==null?void 0:s.url:n&&i&&(e=(c=(a=n==null?void 0:n.fungible_info)==null?void 0:a.icon)==null?void 0:c.url),e},getTransactionTransferTokenType(n){if(n!=null&&n.fungible_info)return"FUNGIBLE";if(n!=null&&n.nft_info)return"NFT"},getTransactionDescriptions(n){var p,g,b;const e=(p=n==null?void 0:n.metadata)==null?void 0:p.operationType,t=n==null?void 0:n.transfers,i=((g=n==null?void 0:n.transfers)==null?void 0:g.length)>0,o=((b=n==null?void 0:n.transfers)==null?void 0:b.length)>1,r=i&&(t==null?void 0:t.every(_=>!!(_!=null&&_.fungible_info))),[s,a]=t;let c=this.getTransferDescription(s),u=this.getTransferDescription(a);if(!i)return(e==="send"||e==="receive")&&r?(c=ye.getTruncateString({string:n==null?void 0:n.metadata.sentFrom,charsStart:4,charsEnd:6,truncate:"middle"}),u=ye.getTruncateString({string:n==null?void 0:n.metadata.sentTo,charsStart:4,charsEnd:6,truncate:"middle"}),[c,u]):[n.metadata.status];if(o)return t.map(_=>this.getTransferDescription(_));let h="";return v5.includes(e)?h="+":y5.includes(e)&&(h="-"),c=h.concat(c),[c]},getTransferDescription(n){var t;let e="";return n&&(n!=null&&n.nft_info?e=((t=n==null?void 0:n.nft_info)==null?void 0:t.name)||"-":n!=null&&n.fungible_info&&(e=this.getFungibleTransferDescription(n)||"-")),e},getFungibleTransferDescription(n){var i;return n?[this.getQuantityFixedValue(n==null?void 0:n.quantity.numeric),(i=n==null?void 0:n.fungible_info)==null?void 0:i.symbol].join(" ").trim():null},getQuantityFixedValue(n){return n?parseFloat(n).toFixed(b5):null}},x5=Object.freeze(Object.defineProperty({__proto__:null,TransactionUtil:Ln,UiHelperUtil:ye,get WuiAccountButton(){return gt},get WuiAllWalletsImage(){return No},get WuiAvatar(){return $i},get WuiButton(){return mt},get WuiCard(){return Fs},get WuiCardSelect(){return nn},get WuiCardSelectLoader(){return Mo},get WuiChip(){return rn},get WuiConnectButton(){return xr},get WuiCtaButton(){return Ai},get WuiEmailInput(){return Si},get WuiFlex(){return qe},get WuiGrid(){return et},get WuiIcon(){return Ci},get WuiIconBox(){return $t},get WuiIconLink(){return Hn},get WuiImage(){return br},get WuiInputElement(){return Lo},get WuiInputNumeric(){return Cr},get WuiInputText(){return Bt},get WuiLink(){return _r},get WuiListAccordion(){return Tr},get WuiListContent(){return Oi},get WuiListItem(){return wt},get WuiListNetwork(){return ki},get WuiListWallet(){return at},get WuiListWalletTransaction(){return En},get WuiLoadingHexagon(){return Hs},get WuiLoadingSpinner(){return vr},get WuiLoadingThumbnail(){return ko},get WuiLogo(){return jo},get WuiLogoSelect(){return Er},get WuiNetworkButton(){return Ii},get WuiNetworkImage(){return Fn},get WuiNoticeCard(){return Pi},get WuiOnRampActivityItem(){return Ge},get WuiOnRampProviderItem(){return Dt},get WuiOtp(){return Ri},get WuiQrCode(){return _n},get WuiSearchBar(){return Ys},get WuiSeparator(){return Uo},get WuiShimmer(){return _i},get WuiSnackbar(){return Vn},get WuiTabs(){return jt},get WuiTag(){return Bo},get WuiText(){return Ei},get WuiTooltip(){return Rr},get WuiTransactionListItem(){return st},get WuiTransactionListItemLoader(){return Zs},get WuiTransactionVisual(){return on},get WuiVisual(){return yr},get WuiVisualThumbnail(){return Ti},get WuiWalletImage(){return tn},customElement:k,initializeTheming:th,setColorTheme:jl,setThemeVariables:nh},Symbol.toStringTag,{value:"Module"}));/**
 * @license
 * Copyright 2019 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const Ps=globalThis,tu=Ps.ShadowRoot&&(Ps.ShadyCSS===void 0||Ps.ShadyCSS.nativeShadow)&&"adoptedStyleSheets"in Document.prototype&&"replace"in CSSStyleSheet.prototype,nu=Symbol(),gd=new WeakMap;let Nh=class{constructor(e,t,i){if(this._$cssResult$=!0,i!==nu)throw Error("CSSResult is not constructable. Use `unsafeCSS` or `css` instead.");this.cssText=e,this.t=t}get styleSheet(){let e=this.o;const t=this.t;if(tu&&e===void 0){const i=t!==void 0&&t.length===1;i&&(e=gd.get(t)),e===void 0&&((this.o=e=new CSSStyleSheet).replaceSync(this.cssText),i&&gd.set(t,e))}return e}toString(){return this.cssText}};const C5=n=>new Nh(typeof n=="string"?n:n+"",void 0,nu),be=(n,...e)=>{const t=n.length===1?n[0]:e.reduce((i,o,r)=>i+(s=>{if(s._$cssResult$===!0)return s.cssText;if(typeof s=="number")return s;throw Error("Value passed to 'css' function must be a 'css' function result: "+s+". Use 'unsafeCSS' to pass non-literal values, but take care to ensure page security.")})(o)+n[r+1],n[0]);return new Nh(t,n,nu)},_5=(n,e)=>{if(tu)n.adoptedStyleSheets=e.map(t=>t instanceof CSSStyleSheet?t:t.styleSheet);else for(const t of e){const i=document.createElement("style"),o=Ps.litNonce;o!==void 0&&i.setAttribute("nonce",o),i.textContent=t.cssText,n.appendChild(i)}},md=tu?n=>n:n=>n instanceof CSSStyleSheet?(e=>{let t="";for(const i of e.cssRules)t+=i.cssText;return C5(t)})(n):n;/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const{is:E5,defineProperty:$5,getOwnPropertyDescriptor:A5,getOwnPropertyNames:S5,getOwnPropertySymbols:I5,getPrototypeOf:R5}=Object,Wn=globalThis,wd=Wn.trustedTypes,T5=wd?wd.emptyScript:"",Ec=Wn.reactiveElementPolyfillSupport,co=(n,e)=>n,Ks={toAttribute(n,e){switch(e){case Boolean:n=n?T5:null;break;case Object:case Array:n=n==null?n:JSON.stringify(n)}return n},fromAttribute(n,e){let t=n;switch(e){case Boolean:t=n!==null;break;case Number:t=n===null?null:Number(n);break;case Object:case Array:try{t=JSON.parse(n)}catch{t=null}}return t}},iu=(n,e)=>!E5(n,e),bd={attribute:!0,type:String,converter:Ks,reflect:!1,hasChanged:iu};Symbol.metadata??(Symbol.metadata=Symbol("metadata")),Wn.litPropertyMetadata??(Wn.litPropertyMetadata=new WeakMap);class ir extends HTMLElement{static addInitializer(e){this._$Ei(),(this.l??(this.l=[])).push(e)}static get observedAttributes(){return this.finalize(),this._$Eh&&[...this._$Eh.keys()]}static createProperty(e,t=bd){if(t.state&&(t.attribute=!1),this._$Ei(),this.elementProperties.set(e,t),!t.noAccessor){const i=Symbol(),o=this.getPropertyDescriptor(e,i,t);o!==void 0&&$5(this.prototype,e,o)}}static getPropertyDescriptor(e,t,i){const{get:o,set:r}=A5(this.prototype,e)??{get(){return this[t]},set(s){this[t]=s}};return{get(){return o==null?void 0:o.call(this)},set(s){const a=o==null?void 0:o.call(this);r.call(this,s),this.requestUpdate(e,a,i)},configurable:!0,enumerable:!0}}static getPropertyOptions(e){return this.elementProperties.get(e)??bd}static _$Ei(){if(this.hasOwnProperty(co("elementProperties")))return;const e=R5(this);e.finalize(),e.l!==void 0&&(this.l=[...e.l]),this.elementProperties=new Map(e.elementProperties)}static finalize(){if(this.hasOwnProperty(co("finalized")))return;if(this.finalized=!0,this._$Ei(),this.hasOwnProperty(co("properties"))){const t=this.properties,i=[...S5(t),...I5(t)];for(const o of i)this.createProperty(o,t[o])}const e=this[Symbol.metadata];if(e!==null){const t=litPropertyMetadata.get(e);if(t!==void 0)for(const[i,o]of t)this.elementProperties.set(i,o)}this._$Eh=new Map;for(const[t,i]of this.elementProperties){const o=this._$Eu(t,i);o!==void 0&&this._$Eh.set(o,t)}this.elementStyles=this.finalizeStyles(this.styles)}static finalizeStyles(e){const t=[];if(Array.isArray(e)){const i=new Set(e.flat(1/0).reverse());for(const o of i)t.unshift(md(o))}else e!==void 0&&t.push(md(e));return t}static _$Eu(e,t){const i=t.attribute;return i===!1?void 0:typeof i=="string"?i:typeof e=="string"?e.toLowerCase():void 0}constructor(){super(),this._$Ep=void 0,this.isUpdatePending=!1,this.hasUpdated=!1,this._$Em=null,this._$Ev()}_$Ev(){var e;this._$ES=new Promise(t=>this.enableUpdating=t),this._$AL=new Map,this._$E_(),this.requestUpdate(),(e=this.constructor.l)==null||e.forEach(t=>t(this))}addController(e){var t;(this._$EO??(this._$EO=new Set)).add(e),this.renderRoot!==void 0&&this.isConnected&&((t=e.hostConnected)==null||t.call(e))}removeController(e){var t;(t=this._$EO)==null||t.delete(e)}_$E_(){const e=new Map,t=this.constructor.elementProperties;for(const i of t.keys())this.hasOwnProperty(i)&&(e.set(i,this[i]),delete this[i]);e.size>0&&(this._$Ep=e)}createRenderRoot(){const e=this.shadowRoot??this.attachShadow(this.constructor.shadowRootOptions);return _5(e,this.constructor.elementStyles),e}connectedCallback(){var e;this.renderRoot??(this.renderRoot=this.createRenderRoot()),this.enableUpdating(!0),(e=this._$EO)==null||e.forEach(t=>{var i;return(i=t.hostConnected)==null?void 0:i.call(t)})}enableUpdating(e){}disconnectedCallback(){var e;(e=this._$EO)==null||e.forEach(t=>{var i;return(i=t.hostDisconnected)==null?void 0:i.call(t)})}attributeChangedCallback(e,t,i){this._$AK(e,i)}_$EC(e,t){var r;const i=this.constructor.elementProperties.get(e),o=this.constructor._$Eu(e,i);if(o!==void 0&&i.reflect===!0){const s=(((r=i.converter)==null?void 0:r.toAttribute)!==void 0?i.converter:Ks).toAttribute(t,i.type);this._$Em=e,s==null?this.removeAttribute(o):this.setAttribute(o,s),this._$Em=null}}_$AK(e,t){var r;const i=this.constructor,o=i._$Eh.get(e);if(o!==void 0&&this._$Em!==o){const s=i.getPropertyOptions(o),a=typeof s.converter=="function"?{fromAttribute:s.converter}:((r=s.converter)==null?void 0:r.fromAttribute)!==void 0?s.converter:Ks;this._$Em=o,this[o]=a.fromAttribute(t,s.type),this._$Em=null}}requestUpdate(e,t,i){if(e!==void 0){if(i??(i=this.constructor.getPropertyOptions(e)),!(i.hasChanged??iu)(this[e],t))return;this.P(e,t,i)}this.isUpdatePending===!1&&(this._$ES=this._$ET())}P(e,t,i){this._$AL.has(e)||this._$AL.set(e,t),i.reflect===!0&&this._$Em!==e&&(this._$Ej??(this._$Ej=new Set)).add(e)}async _$ET(){this.isUpdatePending=!0;try{await this._$ES}catch(t){Promise.reject(t)}const e=this.scheduleUpdate();return e!=null&&await e,!this.isUpdatePending}scheduleUpdate(){return this.performUpdate()}performUpdate(){var i;if(!this.isUpdatePending)return;if(!this.hasUpdated){if(this.renderRoot??(this.renderRoot=this.createRenderRoot()),this._$Ep){for(const[r,s]of this._$Ep)this[r]=s;this._$Ep=void 0}const o=this.constructor.elementProperties;if(o.size>0)for(const[r,s]of o)s.wrapped!==!0||this._$AL.has(r)||this[r]===void 0||this.P(r,this[r],s)}let e=!1;const t=this._$AL;try{e=this.shouldUpdate(t),e?(this.willUpdate(t),(i=this._$EO)==null||i.forEach(o=>{var r;return(r=o.hostUpdate)==null?void 0:r.call(o)}),this.update(t)):this._$EU()}catch(o){throw e=!1,this._$EU(),o}e&&this._$AE(t)}willUpdate(e){}_$AE(e){var t;(t=this._$EO)==null||t.forEach(i=>{var o;return(o=i.hostUpdated)==null?void 0:o.call(i)}),this.hasUpdated||(this.hasUpdated=!0,this.firstUpdated(e)),this.updated(e)}_$EU(){this._$AL=new Map,this.isUpdatePending=!1}get updateComplete(){return this.getUpdateComplete()}getUpdateComplete(){return this._$ES}shouldUpdate(e){return!0}update(e){this._$Ej&&(this._$Ej=this._$Ej.forEach(t=>this._$EC(t,this[t]))),this._$EU()}updated(e){}firstUpdated(e){}}ir.elementStyles=[],ir.shadowRootOptions={mode:"open"},ir[co("elementProperties")]=new Map,ir[co("finalized")]=new Map,Ec==null||Ec({ReactiveElement:ir}),(Wn.reactiveElementVersions??(Wn.reactiveElementVersions=[])).push("2.0.4");/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const lo=globalThis,Js=lo.trustedTypes,vd=Js?Js.createPolicy("lit-html",{createHTML:n=>n}):void 0,Mh="$lit$",kn=`lit$${(Math.random()+"").slice(9)}$`,Lh="?"+kn,P5=`<${Lh}>`,Ni=document,Wo=()=>Ni.createComment(""),zo=n=>n===null||typeof n!="object"&&typeof n!="function",Bh=Array.isArray,O5=n=>Bh(n)||typeof(n==null?void 0:n[Symbol.iterator])=="function",$c=`[ 	
\f\r]`,eo=/<(?:(!--|\/[^a-zA-Z])|(\/?[a-zA-Z][^>\s]*)|(\/?$))/g,yd=/-->/g,xd=/>/g,ci=RegExp(`>|${$c}(?:([^\\s"'>=/]+)(${$c}*=${$c}*(?:[^ 	
\f\r"'\`<>=]|("|')|))|$)`,"g"),Cd=/'/g,_d=/"/g,jh=/^(?:script|style|textarea|title)$/i,k5=n=>(e,...t)=>({_$litType$:n,strings:e,values:t}),A=k5(1),Pr=Symbol.for("lit-noChange"),Be=Symbol.for("lit-nothing"),Ed=new WeakMap,hi=Ni.createTreeWalker(Ni,129);function Dh(n,e){if(!Array.isArray(n)||!n.hasOwnProperty("raw"))throw Error("invalid template strings array");return vd!==void 0?vd.createHTML(e):e}const N5=(n,e)=>{const t=n.length-1,i=[];let o,r=e===2?"<svg>":"",s=eo;for(let a=0;a<t;a++){const c=n[a];let u,h,p=-1,g=0;for(;g<c.length&&(s.lastIndex=g,h=s.exec(c),h!==null);)g=s.lastIndex,s===eo?h[1]==="!--"?s=yd:h[1]!==void 0?s=xd:h[2]!==void 0?(jh.test(h[2])&&(o=RegExp("</"+h[2],"g")),s=ci):h[3]!==void 0&&(s=ci):s===ci?h[0]===">"?(s=o??eo,p=-1):h[1]===void 0?p=-2:(p=s.lastIndex-h[2].length,u=h[1],s=h[3]===void 0?ci:h[3]==='"'?_d:Cd):s===_d||s===Cd?s=ci:s===yd||s===xd?s=eo:(s=ci,o=void 0);const b=s===ci&&n[a+1].startsWith("/>")?" ":"";r+=s===eo?c+P5:p>=0?(i.push(u),c.slice(0,p)+Mh+c.slice(p)+kn+b):c+kn+(p===-2?a:b)}return[Dh(n,r+(n[t]||"<?>")+(e===2?"</svg>":"")),i]};class Fo{constructor({strings:e,_$litType$:t},i){let o;this.parts=[];let r=0,s=0;const a=e.length-1,c=this.parts,[u,h]=N5(e,t);if(this.el=Fo.createElement(u,i),hi.currentNode=this.el.content,t===2){const p=this.el.content.firstChild;p.replaceWith(...p.childNodes)}for(;(o=hi.nextNode())!==null&&c.length<a;){if(o.nodeType===1){if(o.hasAttributes())for(const p of o.getAttributeNames())if(p.endsWith(Mh)){const g=h[s++],b=o.getAttribute(p).split(kn),_=/([.?@])?(.*)/.exec(g);c.push({type:1,index:r,name:_[2],strings:b,ctor:_[1]==="."?L5:_[1]==="?"?B5:_[1]==="@"?j5:Ha}),o.removeAttribute(p)}else p.startsWith(kn)&&(c.push({type:6,index:r}),o.removeAttribute(p));if(jh.test(o.tagName)){const p=o.textContent.split(kn),g=p.length-1;if(g>0){o.textContent=Js?Js.emptyScript:"";for(let b=0;b<g;b++)o.append(p[b],Wo()),hi.nextNode(),c.push({type:2,index:++r});o.append(p[g],Wo())}}}else if(o.nodeType===8)if(o.data===Lh)c.push({type:2,index:r});else{let p=-1;for(;(p=o.data.indexOf(kn,p+1))!==-1;)c.push({type:7,index:r}),p+=kn.length-1}r++}}static createElement(e,t){const i=Ni.createElement("template");return i.innerHTML=e,i}}function Or(n,e,t=n,i){var s,a;if(e===Pr)return e;let o=i!==void 0?(s=t._$Co)==null?void 0:s[i]:t._$Cl;const r=zo(e)?void 0:e._$litDirective$;return(o==null?void 0:o.constructor)!==r&&((a=o==null?void 0:o._$AO)==null||a.call(o,!1),r===void 0?o=void 0:(o=new r(n),o._$AT(n,t,i)),i!==void 0?(t._$Co??(t._$Co=[]))[i]=o:t._$Cl=o),o!==void 0&&(e=Or(n,o._$AS(n,e.values),o,i)),e}class M5{constructor(e,t){this._$AV=[],this._$AN=void 0,this._$AD=e,this._$AM=t}get parentNode(){return this._$AM.parentNode}get _$AU(){return this._$AM._$AU}u(e){const{el:{content:t},parts:i}=this._$AD,o=((e==null?void 0:e.creationScope)??Ni).importNode(t,!0);hi.currentNode=o;let r=hi.nextNode(),s=0,a=0,c=i[0];for(;c!==void 0;){if(s===c.index){let u;c.type===2?u=new hs(r,r.nextSibling,this,e):c.type===1?u=new c.ctor(r,c.name,c.strings,this,e):c.type===6&&(u=new D5(r,this,e)),this._$AV.push(u),c=i[++a]}s!==(c==null?void 0:c.index)&&(r=hi.nextNode(),s++)}return hi.currentNode=Ni,o}p(e){let t=0;for(const i of this._$AV)i!==void 0&&(i.strings!==void 0?(i._$AI(e,i,t),t+=i.strings.length-2):i._$AI(e[t])),t++}}class hs{get _$AU(){var e;return((e=this._$AM)==null?void 0:e._$AU)??this._$Cv}constructor(e,t,i,o){this.type=2,this._$AH=Be,this._$AN=void 0,this._$AA=e,this._$AB=t,this._$AM=i,this.options=o,this._$Cv=(o==null?void 0:o.isConnected)??!0}get parentNode(){let e=this._$AA.parentNode;const t=this._$AM;return t!==void 0&&(e==null?void 0:e.nodeType)===11&&(e=t.parentNode),e}get startNode(){return this._$AA}get endNode(){return this._$AB}_$AI(e,t=this){e=Or(this,e,t),zo(e)?e===Be||e==null||e===""?(this._$AH!==Be&&this._$AR(),this._$AH=Be):e!==this._$AH&&e!==Pr&&this._(e):e._$litType$!==void 0?this.$(e):e.nodeType!==void 0?this.T(e):O5(e)?this.k(e):this._(e)}S(e){return this._$AA.parentNode.insertBefore(e,this._$AB)}T(e){this._$AH!==e&&(this._$AR(),this._$AH=this.S(e))}_(e){this._$AH!==Be&&zo(this._$AH)?this._$AA.nextSibling.data=e:this.T(Ni.createTextNode(e)),this._$AH=e}$(e){var r;const{values:t,_$litType$:i}=e,o=typeof i=="number"?this._$AC(e):(i.el===void 0&&(i.el=Fo.createElement(Dh(i.h,i.h[0]),this.options)),i);if(((r=this._$AH)==null?void 0:r._$AD)===o)this._$AH.p(t);else{const s=new M5(o,this),a=s.u(this.options);s.p(t),this.T(a),this._$AH=s}}_$AC(e){let t=Ed.get(e.strings);return t===void 0&&Ed.set(e.strings,t=new Fo(e)),t}k(e){Bh(this._$AH)||(this._$AH=[],this._$AR());const t=this._$AH;let i,o=0;for(const r of e)o===t.length?t.push(i=new hs(this.S(Wo()),this.S(Wo()),this,this.options)):i=t[o],i._$AI(r),o++;o<t.length&&(this._$AR(i&&i._$AB.nextSibling,o),t.length=o)}_$AR(e=this._$AA.nextSibling,t){var i;for((i=this._$AP)==null?void 0:i.call(this,!1,!0,t);e&&e!==this._$AB;){const o=e.nextSibling;e.remove(),e=o}}setConnected(e){var t;this._$AM===void 0&&(this._$Cv=e,(t=this._$AP)==null||t.call(this,e))}}class Ha{get tagName(){return this.element.tagName}get _$AU(){return this._$AM._$AU}constructor(e,t,i,o,r){this.type=1,this._$AH=Be,this._$AN=void 0,this.element=e,this.name=t,this._$AM=o,this.options=r,i.length>2||i[0]!==""||i[1]!==""?(this._$AH=Array(i.length-1).fill(new String),this.strings=i):this._$AH=Be}_$AI(e,t=this,i,o){const r=this.strings;let s=!1;if(r===void 0)e=Or(this,e,t,0),s=!zo(e)||e!==this._$AH&&e!==Pr,s&&(this._$AH=e);else{const a=e;let c,u;for(e=r[0],c=0;c<r.length-1;c++)u=Or(this,a[i+c],t,c),u===Pr&&(u=this._$AH[c]),s||(s=!zo(u)||u!==this._$AH[c]),u===Be?e=Be:e!==Be&&(e+=(u??"")+r[c+1]),this._$AH[c]=u}s&&!o&&this.j(e)}j(e){e===Be?this.element.removeAttribute(this.name):this.element.setAttribute(this.name,e??"")}}class L5 extends Ha{constructor(){super(...arguments),this.type=3}j(e){this.element[this.name]=e===Be?void 0:e}}class B5 extends Ha{constructor(){super(...arguments),this.type=4}j(e){this.element.toggleAttribute(this.name,!!e&&e!==Be)}}class j5 extends Ha{constructor(e,t,i,o,r){super(e,t,i,o,r),this.type=5}_$AI(e,t=this){if((e=Or(this,e,t,0)??Be)===Pr)return;const i=this._$AH,o=e===Be&&i!==Be||e.capture!==i.capture||e.once!==i.once||e.passive!==i.passive,r=e!==Be&&(i===Be||o);o&&this.element.removeEventListener(this.name,this,i),r&&this.element.addEventListener(this.name,this,e),this._$AH=e}handleEvent(e){var t;typeof this._$AH=="function"?this._$AH.call(((t=this.options)==null?void 0:t.host)??this.element,e):this._$AH.handleEvent(e)}}class D5{constructor(e,t,i){this.element=e,this.type=6,this._$AN=void 0,this._$AM=t,this.options=i}get _$AU(){return this._$AM._$AU}_$AI(e){Or(this,e)}}const Ac=lo.litHtmlPolyfillSupport;Ac==null||Ac(Fo,hs),(lo.litHtmlVersions??(lo.litHtmlVersions=[])).push("3.1.2");const U5=(n,e,t)=>{const i=(t==null?void 0:t.renderBefore)??e;let o=i._$litPart$;if(o===void 0){const r=(t==null?void 0:t.renderBefore)??null;i._$litPart$=o=new hs(e.insertBefore(Wo(),r),r,void 0,t??{})}return o._$AI(n),o};/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */let X=class extends ir{constructor(){super(...arguments),this.renderOptions={host:this},this._$Do=void 0}createRenderRoot(){var t;const e=super.createRenderRoot();return(t=this.renderOptions).renderBefore??(t.renderBefore=e.firstChild),e}update(e){const t=this.render();this.hasUpdated||(this.renderOptions.isConnected=this.isConnected),super.update(e),this._$Do=U5(t,this.renderRoot,this.renderOptions)}connectedCallback(){var e;super.connectedCallback(),(e=this._$Do)==null||e.setConnected(!0)}disconnectedCallback(){var e;super.disconnectedCallback(),(e=this._$Do)==null||e.setConnected(!1)}render(){return Pr}};var Kd;X._$litElement$=!0,X.finalized=!0,(Kd=globalThis.litElementHydrateSupport)==null||Kd.call(globalThis,{LitElement:X});const Sc=globalThis.litElementPolyfillSupport;Sc==null||Sc({LitElement:X});(globalThis.litElementVersions??(globalThis.litElementVersions=[])).push("4.0.4");/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const W5={attribute:!0,type:String,converter:Ks,reflect:!1,hasChanged:iu},z5=(n=W5,e,t)=>{const{kind:i,metadata:o}=t;let r=globalThis.litPropertyMetadata.get(o);if(r===void 0&&globalThis.litPropertyMetadata.set(o,r=new Map),r.set(t.name,n),i==="accessor"){const{name:s}=t;return{set(a){const c=e.get.call(this);e.set.call(this,a),this.requestUpdate(s,c,n)},init(a){return a!==void 0&&this.P(s,void 0,n),a}}}if(i==="setter"){const{name:s}=t;return function(a){const c=this[s];e.call(this,a),this.requestUpdate(s,c,n)}}throw Error("Unsupported decorator location: "+i)};function Ce(n){return(e,t)=>typeof t=="object"?z5(n,e,t):((i,o,r)=>{const s=o.hasOwnProperty(r);return o.constructor.createProperty(r,s?{...i,wrapped:!0}:i),s?Object.getOwnPropertyDescriptor(o,r):void 0})(n,e,t)}/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */function N(n){return Ce({...n,state:!0,attribute:!1})}/**
 * @license
 * Copyright 2018 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const le=n=>n??Be;var It=function(n,e,t,i){var o=arguments.length,r=o<3?e:i===null?i=Object.getOwnPropertyDescriptor(e,t):i,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")r=Reflect.decorate(n,e,t,i);else for(var a=n.length-1;a>=0;a--)(s=n[a])&&(r=(o<3?s(r):o>3?s(e,t,r):s(e,t))||r);return o>3&&r&&Object.defineProperty(e,t,r),r};let bt=class extends X{constructor(){super(),this.unsubscribe=[],this.disabled=!1,this.balance="show",this.charsStart=4,this.charsEnd=6,this.address=ne.state.address,this.balanceVal=ne.state.balance,this.balanceSymbol=ne.state.balanceSymbol,this.profileName=ne.state.profileName,this.profileImage=ne.state.profileImage,this.network=ge.state.caipNetwork,this.isUnsupportedChain=ge.state.isUnsupportedChain,this.unsubscribe.push(ne.subscribe(e=>{e.isConnected?(this.address=e.address,this.balanceVal=e.balance,this.profileName=e.profileName,this.profileImage=e.profileImage,this.balanceSymbol=e.balanceSymbol):(this.address="",this.balanceVal="",this.profileName="",this.profileImage="",this.balanceSymbol="")}),ge.subscribeKey("caipNetwork",e=>this.network=e),ge.subscribeKey("isUnsupportedChain",e=>this.isUnsupportedChain=e))}disconnectedCallback(){this.unsubscribe.forEach(e=>e())}render(){const e=Se.getNetworkImage(this.network),t=this.balance==="show";return A`
      <wui-account-button
        .disabled=${!!this.disabled}
        .isUnsupportedChain=${this.isUnsupportedChain}
        address=${le(this.profileName??this.address)}
        ?isProfileName=${!!this.profileName}
        networkSrc=${le(e)}
        avatarSrc=${le(this.profileImage)}
        balance=${t?F.formatBalance(this.balanceVal,this.balanceSymbol):""}
        @click=${this.onClick.bind(this)}
        data-testid="account-button"
        .charsStart=${this.charsStart}
        .charsEnd=${this.charsEnd}
      >
      </wui-account-button>
    `}onClick(){this.isUnsupportedChain?he.open({view:"UnsupportedChain"}):he.open()}};It([Ce({type:Boolean})],bt.prototype,"disabled",void 0);It([Ce()],bt.prototype,"balance",void 0);It([Ce()],bt.prototype,"charsStart",void 0);It([Ce()],bt.prototype,"charsEnd",void 0);It([N()],bt.prototype,"address",void 0);It([N()],bt.prototype,"balanceVal",void 0);It([N()],bt.prototype,"balanceSymbol",void 0);It([N()],bt.prototype,"profileName",void 0);It([N()],bt.prototype,"profileImage",void 0);It([N()],bt.prototype,"network",void 0);It([N()],bt.prototype,"isUnsupportedChain",void 0);bt=It([k("w3m-account-button")],bt);const F5=be`
  :host {
    display: block;
    width: max-content;
  }
`;var Rn=function(n,e,t,i){var o=arguments.length,r=o<3?e:i===null?i=Object.getOwnPropertyDescriptor(e,t):i,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")r=Reflect.decorate(n,e,t,i);else for(var a=n.length-1;a>=0;a--)(s=n[a])&&(r=(o<3?s(r):o>3?s(e,t,r):s(e,t))||r);return o>3&&r&&Object.defineProperty(e,t,r),r};let Ut=class extends X{constructor(){super(),this.unsubscribe=[],this.disabled=!1,this.balance=void 0,this.size=void 0,this.label=void 0,this.loadingLabel=void 0,this.charsStart=4,this.charsEnd=6,this.isAccount=ne.state.isConnected,this.unsubscribe.push(ne.subscribeKey("isConnected",e=>{this.isAccount=e}))}disconnectedCallback(){this.unsubscribe.forEach(e=>e())}render(){return this.isAccount?A`
          <w3m-account-button
            .disabled=${!!this.disabled}
            balance=${le(this.balance)}
            .charsStart=${le(this.charsStart)}
            .charsEnd=${le(this.charsEnd)}
          >
          </w3m-account-button>
        `:A`
          <w3m-connect-button
            size=${le(this.size)}
            label=${le(this.label)}
            loadingLabel=${le(this.loadingLabel)}
          ></w3m-connect-button>
        `}};Ut.styles=F5;Rn([Ce({type:Boolean})],Ut.prototype,"disabled",void 0);Rn([Ce()],Ut.prototype,"balance",void 0);Rn([Ce()],Ut.prototype,"size",void 0);Rn([Ce()],Ut.prototype,"label",void 0);Rn([Ce()],Ut.prototype,"loadingLabel",void 0);Rn([Ce()],Ut.prototype,"charsStart",void 0);Rn([Ce()],Ut.prototype,"charsEnd",void 0);Rn([N()],Ut.prototype,"isAccount",void 0);Ut=Rn([k("w3m-button")],Ut);var Fr=function(n,e,t,i){var o=arguments.length,r=o<3?e:i===null?i=Object.getOwnPropertyDescriptor(e,t):i,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")r=Reflect.decorate(n,e,t,i);else for(var a=n.length-1;a>=0;a--)(s=n[a])&&(r=(o<3?s(r):o>3?s(e,t,r):s(e,t))||r);return o>3&&r&&Object.defineProperty(e,t,r),r};let Mi=class extends X{constructor(){super(),this.unsubscribe=[],this.size="md",this.label="Connect Wallet",this.loadingLabel="Connecting...",this.open=he.state.open,this.loading=he.state.loading,this.unsubscribe.push(he.subscribe(e=>{this.open=e.open,this.loading=e.loading}))}disconnectedCallback(){this.unsubscribe.forEach(e=>e())}render(){const e=this.loading||this.open;return A`
      <wui-connect-button
        size=${le(this.size)}
        .loading=${e}
        @click=${this.onClick.bind(this)}
        data-testid="connect-button"
      >
        ${e?this.loadingLabel:this.label}
      </wui-connect-button>
    `}onClick(){this.open?he.close():this.loading||he.open()}};Fr([Ce()],Mi.prototype,"size",void 0);Fr([Ce()],Mi.prototype,"label",void 0);Fr([Ce()],Mi.prototype,"loadingLabel",void 0);Fr([N()],Mi.prototype,"open",void 0);Fr([N()],Mi.prototype,"loading",void 0);Mi=Fr([k("w3m-connect-button")],Mi);const H5=be`
  :host {
    z-index: var(--w3m-z-index);
    display: block;
    backface-visibility: hidden;
    will-change: opacity;
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    pointer-events: none;
    opacity: 0;
    background-color: var(--wui-cover);
  }

  @keyframes zoom-in {
    0% {
      transform: scale(0.95) translateY(0);
    }
    100% {
      transform: scale(1) translateY(0);
    }
  }

  @keyframes slide-in {
    0% {
      transform: scale(1) translateY(50px);
    }
    100% {
      transform: scale(1) translateY(0);
    }
  }

  wui-card {
    max-width: 360px;
    width: 100%;
    position: relative;
    animation-delay: 0.3s;
    animation-duration: 0.2s;
    animation-name: zoom-in;
    animation-fill-mode: backwards;
    animation-timing-function: var(--wui-ease-out-power-2);
    outline: none;
  }

  wui-flex {
    overflow-x: hidden;
    overflow-y: auto;
    display: flex;
    align-items: center;
    justify-content: center;
    width: 100%;
    height: 100%;
  }

  @media (max-height: 700px) and (min-width: 431px) {
    wui-flex {
      align-items: flex-start;
    }

    wui-card {
      margin: var(--wui-spacing-xxl) 0px;
    }
  }

  @media (max-width: 430px) {
    wui-flex {
      align-items: flex-end;
    }

    wui-card {
      max-width: 100%;
      border-bottom-left-radius: 0;
      border-bottom-right-radius: 0;
      border-bottom: none;
      animation-name: slide-in;
    }
  }
`;var Va=function(n,e,t,i){var o=arguments.length,r=o<3?e:i===null?i=Object.getOwnPropertyDescriptor(e,t):i,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")r=Reflect.decorate(n,e,t,i);else for(var a=n.length-1;a>=0;a--)(s=n[a])&&(r=(o<3?s(r):o>3?s(e,t,r):s(e,t))||r);return o>3&&r&&Object.defineProperty(e,t,r),r};const $d="scroll-lock";let Li=class extends X{constructor(){super(),this.unsubscribe=[],this.abortController=void 0,this.open=he.state.open,this.caipAddress=ne.state.caipAddress,this.isSiweEnabled=Me.state.isSiweEnabled,this.initializeTheming(),ie.prefetch(),this.unsubscribe.push(he.subscribeKey("open",e=>e?this.onOpen():this.onClose()),Me.subscribeKey("isSiweEnabled",e=>{this.isSiweEnabled=e}),ne.subscribe(e=>this.onNewAccountState(e))),Y.sendEvent({type:"track",event:"MODAL_LOADED"})}disconnectedCallback(){this.unsubscribe.forEach(e=>e()),this.onRemoveKeyboardListener()}render(){return this.open?A`
          <wui-flex @click=${this.onOverlayClick.bind(this)}>
            <wui-card role="alertdialog" aria-modal="true" tabindex="0">
              <w3m-header></w3m-header>
              <w3m-router></w3m-router>
              <w3m-snackbar></w3m-snackbar>
            </wui-card>
          </wui-flex>
        `:null}async onOverlayClick(e){e.target===e.currentTarget&&await this.handleClose()}async handleClose(){this.isSiweEnabled&&Me.state.status!=="success"&&await fe.disconnect(),he.close()}initializeTheming(){const{themeVariables:e,themeMode:t}=Fe.state,i=ye.getColorTheme(t);th(e,i)}async onClose(){this.onScrollUnlock(),await this.animate([{opacity:1},{opacity:0}],{duration:200,easing:"ease",fill:"forwards"}).finished,xe.hide(),this.open=!1,this.onRemoveKeyboardListener()}async onOpen(){this.onScrollLock(),this.open=!0,await this.animate([{opacity:0},{opacity:1}],{duration:200,easing:"ease",fill:"forwards",delay:300}).finished,this.onAddKeyboardListener()}onScrollLock(){const e=document.createElement("style");e.dataset.w3m=$d,e.textContent=`
      html, body {
        touch-action: none;
        overflow: hidden;
        overscroll-behavior: contain;
      }
      w3m-modal {
        pointer-events: auto;
      }
    `,document.head.appendChild(e)}onScrollUnlock(){const e=document.head.querySelector(`style[data-w3m="${$d}"]`);e&&e.remove()}onAddKeyboardListener(){var t;this.abortController=new AbortController;const e=(t=this.shadowRoot)==null?void 0:t.querySelector("wui-card");e==null||e.focus(),window.addEventListener("keydown",i=>{if(i.key==="Escape")this.handleClose();else if(i.key==="Tab"){const{tagName:o}=i.target;o&&!o.includes("W3M-")&&!o.includes("WUI-")&&(e==null||e.focus())}},this.abortController)}onRemoveKeyboardListener(){var e;(e=this.abortController)==null||e.abort(),this.abortController=void 0}async onNewAccountState(e){const{isConnected:t,caipAddress:i}=e;if(this.isSiweEnabled){t&&!this.caipAddress&&(this.caipAddress=i),t&&i&&this.caipAddress!==i&&(await Me.signOut(),this.onSiweNavigation(),this.caipAddress=i);try{const o=await Me.getSession();o&&!t?await Me.signOut():t&&!o&&this.onSiweNavigation()}catch{t&&this.onSiweNavigation()}}}onSiweNavigation(){this.open?j.push("ConnectingSiwe"):he.open({view:"ConnectingSiwe"})}};Li.styles=H5;Va([N()],Li.prototype,"open",void 0);Va([N()],Li.prototype,"caipAddress",void 0);Va([N()],Li.prototype,"isSiweEnabled",void 0);Li=Va([k("w3m-modal")],Li);const V5=Object.freeze(Object.defineProperty({__proto__:null,get W3mModal(){return Li}},Symbol.toStringTag,{value:"Module"})),Z5=be`
  :host {
    display: block;
    width: max-content;
  }
`;var Hr=function(n,e,t,i){var o=arguments.length,r=o<3?e:i===null?i=Object.getOwnPropertyDescriptor(e,t):i,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")r=Reflect.decorate(n,e,t,i);else for(var a=n.length-1;a>=0;a--)(s=n[a])&&(r=(o<3?s(r):o>3?s(e,t,r):s(e,t))||r);return o>3&&r&&Object.defineProperty(e,t,r),r};let Zn=class extends X{constructor(){super(),this.unsubscribe=[],this.disabled=!1,this.network=ge.state.caipNetwork,this.connected=ne.state.isConnected,this.loading=he.state.loading,this.isUnsupportedChain=ge.state.isUnsupportedChain,this.unsubscribe.push(ge.subscribeKey("caipNetwork",e=>this.network=e),ne.subscribeKey("isConnected",e=>this.connected=e),he.subscribeKey("loading",e=>this.loading=e),ge.subscribeKey("isUnsupportedChain",e=>this.isUnsupportedChain=e))}disconnectedCallback(){this.unsubscribe.forEach(e=>e())}render(){var e;return A`
      <wui-network-button
        .disabled=${!!(this.disabled||this.loading)}
        .isUnsupportedChain=${this.isUnsupportedChain}
        imageSrc=${le(Se.getNetworkImage(this.network))}
        @click=${this.onClick.bind(this)}
      >
        ${this.isUnsupportedChain?"Switch Network":((e=this.network)==null?void 0:e.name)??(this.connected?"Unknown Network":"Select Network")}
      </wui-network-button>
    `}onClick(){this.loading||(Y.sendEvent({type:"track",event:"CLICK_NETWORKS"}),he.open({view:"Networks"}))}};Zn.styles=Z5;Hr([Ce({type:Boolean})],Zn.prototype,"disabled",void 0);Hr([N()],Zn.prototype,"network",void 0);Hr([N()],Zn.prototype,"connected",void 0);Hr([N()],Zn.prototype,"loading",void 0);Hr([N()],Zn.prototype,"isUnsupportedChain",void 0);Zn=Hr([k("w3m-network-button")],Zn);const q5=be`
  :host {
    display: block;
    will-change: transform, opacity;
  }
`;var Uh=function(n,e,t,i){var o=arguments.length,r=o<3?e:i===null?i=Object.getOwnPropertyDescriptor(e,t):i,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")r=Reflect.decorate(n,e,t,i);else for(var a=n.length-1;a>=0;a--)(s=n[a])&&(r=(o<3?s(r):o>3?s(e,t,r):s(e,t))||r);return o>3&&r&&Object.defineProperty(e,t,r),r};let Qs=class extends X{constructor(){super(),this.resizeObserver=void 0,this.prevHeight="0px",this.prevHistoryLength=1,this.unsubscribe=[],this.view=j.state.view,this.unsubscribe.push(j.subscribeKey("view",e=>this.onViewChange(e)))}firstUpdated(){this.resizeObserver=new ResizeObserver(async([e])=>{const t=`${e==null?void 0:e.contentRect.height}px`;this.prevHeight!=="0px"&&(await this.animate([{height:this.prevHeight},{height:t}],{duration:150,easing:"ease",fill:"forwards"}).finished,this.style.height="auto"),this.prevHeight=t}),this.resizeObserver.observe(this.getWrapper())}disconnectedCallback(){var e;(e=this.resizeObserver)==null||e.unobserve(this.getWrapper()),this.unsubscribe.forEach(t=>t())}render(){return A`<div>${this.viewTemplate()}</div>`}viewTemplate(){switch(this.view){case"Connect":return A`<w3m-connect-view></w3m-connect-view>`;case"ConnectingWalletConnect":return A`<w3m-connecting-wc-view></w3m-connecting-wc-view>`;case"ConnectingExternal":return A`<w3m-connecting-external-view></w3m-connecting-external-view>`;case"ConnectingSiwe":return A`<w3m-connecting-siwe-view></w3m-connecting-siwe-view>`;case"AllWallets":return A`<w3m-all-wallets-view></w3m-all-wallets-view>`;case"Networks":return A`<w3m-networks-view></w3m-networks-view>`;case"SwitchNetwork":return A`<w3m-network-switch-view></w3m-network-switch-view>`;case"Account":return A`<w3m-account-view></w3m-account-view>`;case"AccountSettings":return A`<w3m-account-settings-view></w3m-account-settings-view>`;case"WhatIsAWallet":return A`<w3m-what-is-a-wallet-view></w3m-what-is-a-wallet-view>`;case"WhatIsANetwork":return A`<w3m-what-is-a-network-view></w3m-what-is-a-network-view>`;case"GetWallet":return A`<w3m-get-wallet-view></w3m-get-wallet-view>`;case"Downloads":return A`<w3m-downloads-view></w3m-downloads-view>`;case"EmailVerifyOtp":return A`<w3m-email-verify-otp-view></w3m-email-verify-otp-view>`;case"EmailVerifyDevice":return A`<w3m-email-verify-device-view></w3m-email-verify-device-view>`;case"ApproveTransaction":return A`<w3m-approve-transaction-view></w3m-approve-transaction-view>`;case"Transactions":return A`<w3m-transactions-view></w3m-transactions-view>`;case"UpgradeEmailWallet":return A`<w3m-upgrade-wallet-view></w3m-upgrade-wallet-view>`;case"UpdateEmailWallet":return A`<w3m-update-email-wallet-view></w3m-update-email-wallet-view>`;case"UpdateEmailPrimaryOtp":return A`<w3m-update-email-primary-otp-view></w3m-update-email-primary-otp-view>`;case"UpdateEmailSecondaryOtp":return A`<w3m-update-email-secondary-otp-view></w3m-update-email-secondary-otp-view>`;case"UnsupportedChain":return A`<w3m-unsupported-chain-view></w3m-unsupported-chain-view>`;case"OnRampProviders":return A`<w3m-onramp-providers-view></w3m-onramp-providers-view>`;case"OnRampActivity":return A`<w3m-onramp-activity-view></w3m-onramp-activity-view>`;case"OnRampTokenSelect":return A`<w3m-onramp-token-select-view></w3m-onramp-token-select-view>`;case"OnRampFiatSelect":return A`<w3m-onramp-fiat-select-view></w3m-onramp-fiat-select-view>`;case"WhatIsABuy":return A`<w3m-what-is-a-buy-view></w3m-what-is-a-buy-view>`;case"BuyInProgress":return A`<w3m-buy-in-progress-view></w3m-buy-in-progress-view>`;default:return A`<w3m-connect-view></w3m-connect-view>`}}async onViewChange(e){const{history:t}=j.state;let i=-10,o=10;t.length<this.prevHistoryLength&&(i=10,o=-10),this.prevHistoryLength=t.length,await this.animate([{opacity:1,transform:"translateX(0px)"},{opacity:0,transform:`translateX(${i}px)`}],{duration:150,easing:"ease",fill:"forwards"}).finished,this.view=e,await this.animate([{opacity:0,transform:`translateX(${o}px)`},{opacity:1,transform:"translateX(0px)"}],{duration:150,easing:"ease",fill:"forwards",delay:50}).finished}getWrapper(){var e;return(e=this.shadowRoot)==null?void 0:e.querySelector("div")}};Qs.styles=q5;Uh([N()],Qs.prototype,"view",void 0);Qs=Uh([k("w3m-router")],Qs);const G5=be`
  :host > wui-flex {
    width: 100%;
    max-width: 360px;
  }

  :host > wui-flex > wui-flex {
    border-radius: var(--wui-border-radius-l);
    width: 100%;
  }

  .amounts-container {
    width: 100%;
  }
`;var ti=function(n,e,t,i){var o=arguments.length,r=o<3?e:i===null?i=Object.getOwnPropertyDescriptor(e,t):i,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")r=Reflect.decorate(n,e,t,i);else for(var a=n.length-1;a>=0;a--)(s=n[a])&&(r=(o<3?s(r):o>3?s(e,t,r):s(e,t))||r);return o>3&&r&&Object.defineProperty(e,t,r),r};const Y5={USD:"$",EUR:"€",GBP:"£"},K5=[100,250,500,1e3];let sn=class extends X{constructor(){super(),this.unsubscribe=[],this.disabled=!1,this.connected=ne.state.isConnected,this.loading=he.state.loading,this.paymentCurrency=ve.state.paymentCurrency,this.paymentAmount=ve.state.paymentAmount,this.purchaseAmount=ve.state.purchaseAmount,this.quoteLoading=ve.state.quotesLoading,this.unsubscribe.push(ne.subscribeKey("isConnected",e=>{this.connected=e}),he.subscribeKey("loading",e=>{this.loading=e}),ve.subscribe(e=>{this.paymentCurrency=e.paymentCurrency,this.paymentAmount=e.paymentAmount,this.purchaseAmount=e.purchaseAmount,this.quoteLoading=e.quotesLoading}))}disconnectedCallback(){this.unsubscribe.forEach(e=>e())}render(){return A`
      <wui-flex flexDirection="column" justifyContent="center" alignItems="center">
        <wui-flex flexDirection="column" alignItems="center" gap="xs">
          <w3m-swap-input
            type="Fiat"
            @inputChange=${this.onPaymentAmountChange.bind(this)}
            .value=${this.paymentAmount||0}
          ></w3m-swap-input>
          <w3m-swap-input
            type="Token"
            .value=${this.purchaseAmount||0}
            .loading=${this.quoteLoading}
          ></w3m-swap-input>
          <wui-flex justifyContent="space-evenly" class="amounts-container" gap="xs">
            ${K5.map(e=>{var t;return A`<wui-button
                  variant=${this.paymentAmount===e?"accentBg":"shade"}
                  size="xs"
                  textVariant="paragraph-600"
                  fullWidth
                  @click=${()=>this.selectPresetAmount(e)}
                  >${`${Y5[((t=this.paymentCurrency)==null?void 0:t.id)||"USD"]} ${e}`}</wui-button
                >`})}
          </wui-flex>
          ${this.templateButton()}
        </wui-flex>
      </wui-flex>
    `}templateButton(){return this.connected?A`<wui-button
          @click=${this.getQuotes.bind(this)}
          variant="fill"
          fullWidth
          size="lg"
          borderRadius="xs"
        >
          Get quotes
        </wui-button>`:A`<wui-button
          @click=${this.openModal.bind(this)}
          variant="accentBg"
          fullWidth
          size="lg"
          borderRadius="xs"
        >
          Connect wallet
        </wui-button>`}getQuotes(){this.loading||he.open({view:"OnRampProviders"})}openModal(){he.open({view:"Connect"})}async onPaymentAmountChange(e){ve.setPaymentAmount(Number(e.detail)),await ve.getQuote()}async selectPresetAmount(e){ve.setPaymentAmount(e),await ve.getQuote()}};sn.styles=G5;ti([Ce({type:Boolean})],sn.prototype,"disabled",void 0);ti([N()],sn.prototype,"connected",void 0);ti([N()],sn.prototype,"loading",void 0);ti([N()],sn.prototype,"paymentCurrency",void 0);ti([N()],sn.prototype,"paymentAmount",void 0);ti([N()],sn.prototype,"purchaseAmount",void 0);ti([N()],sn.prototype,"quoteLoading",void 0);sn=ti([k("w3m-onramp-widget")],sn);const J5=be`
  wui-flex {
    width: 100%;
  }

  wui-icon-link {
    margin-right: calc(var(--wui-icon-box-size-md) * -1);
  }

  .account-links {
    display: flex;
    justify-content: space-between;
    align-items: center;
  }

  .account-links wui-flex {
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    flex: 1;
    background: red;
    align-items: center;
    justify-content: center;
    height: 48px;
    padding: 10px;
    flex: 1 0 0;

    border-radius: var(--XS, 16px);
    border: 1px solid var(--dark-accent-glass-010, rgba(71, 161, 255, 0.1));
    background: var(--dark-accent-glass-010, rgba(71, 161, 255, 0.1));
    transition: background 0.2s linear;
  }

  .account-links wui-flex:hover {
    background: var(--dark-accent-glass-015, rgba(71, 161, 255, 0.15));
  }

  .account-links wui-flex wui-icon {
    width: var(--S, 20px);
    height: var(--S, 20px);
  }

  .account-links wui-flex wui-icon svg path {
    stroke: #47a1ff;
  }
`;var ni=function(n,e,t,i){var o=arguments.length,r=o<3?e:i===null?i=Object.getOwnPropertyDescriptor(e,t):i,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")r=Reflect.decorate(n,e,t,i);else for(var a=n.length-1;a>=0;a--)(s=n[a])&&(r=(o<3?s(r):o>3?s(e,t,r):s(e,t))||r);return o>3&&r&&Object.defineProperty(e,t,r),r};let an=class extends X{constructor(){super(),this.usubscribe=[],this.networkImages=He.state.networkImages,this.address=ne.state.address,this.profileImage=ne.state.profileImage,this.profileName=ne.state.profileName,this.balance=ne.state.balance,this.balanceSymbol=ne.state.balanceSymbol,this.network=ge.state.caipNetwork,this.disconnecting=!1,this.usubscribe.push(ne.subscribe(e=>{e.address?(this.address=e.address,this.profileImage=e.profileImage,this.profileName=e.profileName,this.balance=e.balance,this.balanceSymbol=e.balanceSymbol):he.close()}),ge.subscribeKey("caipNetwork",e=>{e!=null&&e.id&&(this.network=e)}))}disconnectedCallback(){this.usubscribe.forEach(e=>e())}render(){var t,i;if(!this.address)throw new Error("w3m-account-settings-view: No account provided");const e=this.networkImages[((t=this.network)==null?void 0:t.imageId)??""];return A`
      <wui-flex
        flexDirection="column"
        .padding=${["0","xl","m","xl"]}
        alignItems="center"
        gap="l"
      >
        <wui-avatar
          alt=${this.address}
          address=${this.address}
          imageSrc=${le(this.profileImage)}
        ></wui-avatar>
        <wui-flex flexDirection="column" alignItems="center">
          <wui-flex gap="3xs" alignItems="center" justifyContent="center">
            <wui-text variant="large-600" color="fg-100">
              ${this.profileName?ye.getTruncateString({string:this.profileName,charsStart:20,charsEnd:0,truncate:"end"}):ye.getTruncateString({string:this.address,charsStart:4,charsEnd:6,truncate:"middle"})}
            </wui-text>
            <wui-icon-link
              size="md"
              icon="copy"
              iconColor="fg-200"
              @click=${this.onCopyAddress}
            ></wui-icon-link>
          </wui-flex>
          <wui-flex gap="s" flexDirection="column" alignItems="center">
            <wui-text variant="paragraph-500" color="fg-200">
              ${F.formatBalance(this.balance,this.balanceSymbol)}
            </wui-text>
            ${this.explorerBtnTemplate()}
          </wui-flex>
        </wui-flex>
      </wui-flex>

      <wui-flex flexDirection="column" gap="m">
        <wui-flex flexDirection="column" gap="xs" .padding=${["0","xl","xl","xl"]}>
          <wui-list-item
            .variant=${e?"image":"icon"}
            iconVariant="overlay"
            icon="networkPlaceholder"
            imageSrc=${le(e)}
            ?chevron=${this.isAllowedNetworkSwitch()}
            @click=${this.onNetworks.bind(this)}
          >
            <wui-text variant="paragraph-500" color="fg-100">
              ${((i=this.network)==null?void 0:i.name)??"Unknown"}
            </wui-text>
          </wui-list-item>

          <wui-list-item
            iconVariant="blue"
            icon="swapHorizontalBold"
            iconSize="sm"
            ?chevron=${!0}
            @click=${this.onTransactions.bind(this)}
          >
            <wui-text variant="paragraph-500" color="fg-100">Activity</wui-text>
          </wui-list-item>
          <wui-list-item
            variant="icon"
            iconVariant="overlay"
            icon="disconnect"
            ?chevron=${!1}
            .loading=${this.disconnecting}
            @click=${this.onDisconnect.bind(this)}
            data-testid="disconnect-button"
          >
            <wui-text variant="paragraph-500" color="fg-200">Disconnect</wui-text>
          </wui-list-item>
        </wui-flex>
      </wui-flex>
    `}onTransactions(){Y.sendEvent({type:"track",event:"CLICK_TRANSACTIONS"}),j.push("Transactions")}explorerBtnTemplate(){const{addressExplorerUrl:e}=ne.state;return e?A`
      <wui-button size="sm" variant="shade" @click=${this.onExplorer.bind(this)}>
        <wui-icon size="sm" color="inherit" slot="iconLeft" name="compass"></wui-icon>
        Block Explorer
        <wui-icon size="sm" color="inherit" slot="iconRight" name="externalLink"></wui-icon>
      </wui-button>
    `:null}isAllowedNetworkSwitch(){const{requestedCaipNetworks:e}=ge.state,t=e?e.length>1:!1,i=e==null?void 0:e.find(({id:o})=>{var r;return o===((r=this.network)==null?void 0:r.id)});return t||!i}onCopyAddress(){try{this.address&&(F.copyToClopboard(this.address),xe.showSuccess("Address copied"))}catch{xe.showError("Failed to copy")}}onNetworks(){this.isAllowedNetworkSwitch()&&j.push("Networks")}async onDisconnect(){try{this.disconnecting=!0,await fe.disconnect(),Y.sendEvent({type:"track",event:"DISCONNECT_SUCCESS"}),he.close()}catch{Y.sendEvent({type:"track",event:"DISCONNECT_ERROR"}),xe.showError("Failed to disconnect")}finally{this.disconnecting=!1}}onExplorer(){const{addressExplorerUrl:e}=ne.state;e&&F.openHref(e,"_blank")}};an.styles=J5;ni([N()],an.prototype,"address",void 0);ni([N()],an.prototype,"profileImage",void 0);ni([N()],an.prototype,"profileName",void 0);ni([N()],an.prototype,"balance",void 0);ni([N()],an.prototype,"balanceSymbol",void 0);ni([N()],an.prototype,"network",void 0);ni([N()],an.prototype,"disconnecting",void 0);an=ni([k("w3m-account-settings-view")],an);const Q5=be`
  wui-flex {
    width: 100%;
  }

  :host > wui-flex:first-child {
    transform: translateY(calc(var(--wui-spacing-xxs) * -1));
  }

  wui-icon-link {
    margin-right: calc(var(--wui-icon-box-size-md) * -1);
  }

  wui-notice-card {
    margin-bottom: var(--wui-spacing-3xs);
  }

  w3m-transactions-view {
    max-height: 200px;
  }

  .tab-content-container {
    height: 300px;
    overflow-y: auto;
    overflow-x: hidden;
    scrollbar-width: none;
  }

  .account-button {
    width: auto;
    border: none;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: var(--wui-spacing-s);
    height: 48px;
    padding: var(--wui-spacing-xs);
    padding-right: var(--wui-spacing-s);
    box-shadow: inset 0 0 0 1px var(--wui-gray-glass-002);
    background-color: var(--wui-gray-glass-002);
    border-radius: 24px;
    transaction: background-color 0.2s linear;
  }

  .account-button:hover {
    background-color: var(--wui-gray-glass-005);
  }

  .avatar-container {
    position: relative;
  }

  wui-avatar.avatar {
    width: 32px;
    height: 32px;
    box-shadow: 0 0 0 2px var(--wui-gray-glass-005);
  }

  wui-avatar.network-avatar {
    width: 16px;
    height: 16px;
    position: absolute;
    left: 100%;
    top: 100%;
    transform: translate(-75%, -75%);
    box-shadow: 0 0 0 2px var(--wui-gray-glass-005);
  }

  .account-links {
    display: flex;
    justify-content: space-between;
    align-items: center;
  }

  .account-links wui-flex {
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    flex: 1;
    background: red;
    align-items: center;
    justify-content: center;
    height: 48px;
    padding: 10px;
    flex: 1 0 0;

    border-radius: var(--XS, 16px);
    border: 1px solid var(--dark-accent-glass-010, rgba(71, 161, 255, 0.1));
    background: var(--dark-accent-glass-010, rgba(71, 161, 255, 0.1));
    transition: background 0.2s linear;
  }

  .account-links wui-flex:hover {
    background: var(--dark-accent-glass-015, rgba(71, 161, 255, 0.15));
  }

  .account-links wui-flex wui-icon {
    width: var(--S, 20px);
    height: var(--S, 20px);
  }

  .account-links wui-flex wui-icon svg path {
    stroke: #47a1ff;
  }
`;var ii=function(n,e,t,i){var o=arguments.length,r=o<3?e:i===null?i=Object.getOwnPropertyDescriptor(e,t):i,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")r=Reflect.decorate(n,e,t,i);else for(var a=n.length-1;a>=0;a--)(s=n[a])&&(r=(o<3?s(r):o>3?s(e,t,r):s(e,t))||r);return o>3&&r&&Object.defineProperty(e,t,r),r};let cn=class extends X{constructor(){super(),this.unsubscribe=[],this.address=ne.state.address,this.profileImage=ne.state.profileImage,this.profileName=ne.state.profileName,this.network=ge.state.caipNetwork,this.disconnecting=!1,this.balance=ne.state.balance,this.balanceSymbol=ne.state.balanceSymbol,this.unsubscribe.push(ne.subscribe(e=>{e.address?(this.address=e.address,this.profileImage=e.profileImage,this.profileName=e.profileName,this.balance=e.balance,this.balanceSymbol=e.balanceSymbol):he.close()}),ge.subscribeKey("caipNetwork",e=>{e!=null&&e.id&&(this.network=e)}))}disconnectedCallback(){this.unsubscribe.forEach(e=>e())}render(){var t;if(!this.address)throw new Error("w3m-account-view: No account provided");const e=Se.getNetworkImage(this.network);return A`
      <wui-flex
        flexDirection="column"
        .padding=${["0","xl","m","xl"]}
        alignItems="center"
        gap="l"
      >
        <wui-avatar
          alt=${this.address}
          address=${this.address}
          imageSrc=${le(this.profileImage===null?void 0:this.profileImage)}
        ></wui-avatar>
        <wui-flex flexDirection="column" alignItems="center">
          <wui-flex gap="3xs" alignItems="center" justifyContent="center">
            <wui-text variant="medium-title-600" color="fg-100">
              ${this.profileName?ye.getTruncateString({string:this.profileName,charsStart:20,charsEnd:0,truncate:"end"}):ye.getTruncateString({string:this.address,charsStart:4,charsEnd:4,truncate:"middle"})}
            </wui-text>
            <wui-icon-link
              size="md"
              icon="copy"
              iconColor="fg-200"
              @click=${this.onCopyAddress}
            ></wui-icon-link>
          </wui-flex>
          <wui-text variant="paragraph-500" color="fg-200"
            >${F.formatBalance(this.balance,this.balanceSymbol)}</wui-text
          >
        </wui-flex>
        ${this.explorerBtnTemplate()}
      </wui-flex>

      <wui-flex flexDirection="column" gap="xs" .padding=${["0","s","s","s"]}>
        ${this.emailCardTemplate()} ${this.emailBtnTemplate()}

        <wui-list-item
          .variant=${e?"image":"icon"}
          iconVariant="overlay"
          icon="networkPlaceholder"
          imageSrc=${le(e)}
          ?chevron=${this.isAllowedNetworkSwitch()}
          @click=${this.onNetworks.bind(this)}
          data-testid="w3m-account-select-network"
        >
          <wui-text variant="paragraph-500" color="fg-100">
            ${((t=this.network)==null?void 0:t.name)??"Unknown"}
          </wui-text>
        </wui-list-item>
        ${this.onrampTemplate()}
        <wui-list-item
          iconVariant="blue"
          icon="swapHorizontalMedium"
          iconSize="sm"
          ?chevron=${!0}
          @click=${this.onTransactions.bind(this)}
        >
          <wui-text variant="paragraph-500" color="fg-100">Activity</wui-text>
        </wui-list-item>
        <wui-list-item
          variant="icon"
          iconVariant="overlay"
          icon="disconnect"
          ?chevron=${!1}
          .loading=${this.disconnecting}
          @click=${this.onDisconnect.bind(this)}
          data-testid="disconnect-button"
        >
          <wui-text variant="paragraph-500" color="fg-200">Disconnect</wui-text>
        </wui-list-item>
      </wui-flex>
    `}onrampTemplate(){const{enableOnramp:e}=ce.state;return e?A`
      <wui-list-item
        iconVariant="blue"
        icon="card"
        ?chevron=${!0}
        @click=${this.handleClickPay.bind(this)}
      >
        <wui-text variant="paragraph-500" color="fg-100">Buy crypto</wui-text>
      </wui-list-item>
    `:null}emailCardTemplate(){const e=Ze.getConnectedConnector(),t=Ee.getEmailConnector(),{origin:i}=location;return!t||e!=="EMAIL"||i.includes(pt.SECURE_SITE)?null:A`
      <wui-notice-card
        @click=${this.onGoToUpgradeView.bind(this)}
        label="Upgrade your wallet"
        description="Transition to a self-custodial wallet"
        icon="wallet"
      ></wui-notice-card>
    `}handleClickPay(){j.push("OnRampProviders")}explorerBtnTemplate(){const{addressExplorerUrl:e}=ne.state;return e?A`
      <wui-button size="sm" variant="shade" @click=${this.onExplorer.bind(this)}>
        <wui-icon size="sm" color="inherit" slot="iconLeft" name="compass"></wui-icon>
        Block Explorer
        <wui-icon size="sm" color="inherit" slot="iconRight" name="externalLink"></wui-icon>
      </wui-button>
    `:null}emailBtnTemplate(){const e=Ze.getConnectedConnector(),t=Ee.getEmailConnector();if(!t||e!=="EMAIL")return null;const i=t.provider.getEmail()??"";return A`
      <wui-list-item
        variant="icon"
        iconVariant="overlay"
        icon="mail"
        iconSize="sm"
        ?chevron=${!0}
        @click=${()=>this.onGoToUpdateEmail(i)}
      >
        <wui-text variant="paragraph-500" color="fg-100">${i}</wui-text>
      </wui-list-item>
    `}isAllowedNetworkSwitch(){const{requestedCaipNetworks:e}=ge.state,t=e?e.length>1:!1,i=e==null?void 0:e.find(({id:o})=>{var r;return o===((r=this.network)==null?void 0:r.id)});return t||!i}onCopyAddress(){try{this.address&&(F.copyToClopboard(this.address),xe.showSuccess("Address copied"))}catch{xe.showError("Failed to copy")}}onNetworks(){this.isAllowedNetworkSwitch()&&(Y.sendEvent({type:"track",event:"CLICK_NETWORKS"}),j.push("Networks"))}onTransactions(){Y.sendEvent({type:"track",event:"CLICK_TRANSACTIONS"}),j.push("Transactions")}async onDisconnect(){try{this.disconnecting=!0,await fe.disconnect(),Y.sendEvent({type:"track",event:"DISCONNECT_SUCCESS"}),he.close()}catch{Y.sendEvent({type:"track",event:"DISCONNECT_ERROR"}),xe.showError("Failed to disconnect")}finally{this.disconnecting=!1}}onExplorer(){const{addressExplorerUrl:e}=ne.state;e&&F.openHref(e,"_blank")}onGoToUpgradeView(){Y.sendEvent({type:"track",event:"EMAIL_UPGRADE_FROM_MODAL"}),j.push("UpgradeEmailWallet")}onGoToUpdateEmail(e){j.push("UpdateEmailWallet",{email:e})}};cn.styles=Q5;ii([N()],cn.prototype,"address",void 0);ii([N()],cn.prototype,"profileImage",void 0);ii([N()],cn.prototype,"profileName",void 0);ii([N()],cn.prototype,"network",void 0);ii([N()],cn.prototype,"disconnecting",void 0);ii([N()],cn.prototype,"balance",void 0);ii([N()],cn.prototype,"balanceSymbol",void 0);cn=ii([k("w3m-account-view")],cn);var Wh=function(n,e,t,i){var o=arguments.length,r=o<3?e:i===null?i=Object.getOwnPropertyDescriptor(e,t):i,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")r=Reflect.decorate(n,e,t,i);else for(var a=n.length-1;a>=0;a--)(s=n[a])&&(r=(o<3?s(r):o>3?s(e,t,r):s(e,t))||r);return o>3&&r&&Object.defineProperty(e,t,r),r};let sl=class extends X{constructor(){super(...arguments),this.search="",this.onDebouncedSearch=F.debounce(e=>{this.search=e})}render(){const e=this.search.length>=2;return A`
      <wui-flex padding="s" gap="s">
        <wui-search-bar @inputChange=${this.onInputChange.bind(this)}></wui-search-bar>
        ${this.qrButtonTemplate()}
      </wui-flex>
      ${e?A`<w3m-all-wallets-search query=${this.search}></w3m-all-wallets-search>`:A`<w3m-all-wallets-list></w3m-all-wallets-list>`}
    `}onInputChange(e){this.onDebouncedSearch(e.detail)}qrButtonTemplate(){return F.isMobile()?A`
        <wui-icon-box
          size="lg"
          iconSize="xl"
          iconColor="accent-100"
          backgroundColor="accent-100"
          icon="qrCode"
          background="transparent"
          border
          borderColor="wui-accent-glass-010"
          @click=${this.onWalletConnectQr.bind(this)}
        ></wui-icon-box>
      `:null}onWalletConnectQr(){j.push("ConnectingWalletConnect")}};Wh([N()],sl.prototype,"search",void 0);sl=Wh([k("w3m-all-wallets-view")],sl);const X5=be`
  @keyframes shake {
    0% {
      transform: translateX(0);
    }
    25% {
      transform: translateX(3px);
    }
    50% {
      transform: translateX(-3px);
    }
    75% {
      transform: translateX(3px);
    }
    100% {
      transform: translateX(0);
    }
  }

  wui-flex:first-child:not(:only-child) {
    position: relative;
  }

  wui-loading-thumbnail {
    position: absolute;
  }

  wui-visual {
    width: var(--wui-wallet-image-size-lg);
    height: var(--wui-wallet-image-size-lg);
    border-radius: calc(var(--wui-border-radius-5xs) * 9 - var(--wui-border-radius-xxs));
    position: relative;
    overflow: hidden;
  }

  wui-visual::after {
    content: '';
    display: block;
    width: 100%;
    height: 100%;
    position: absolute;
    inset: 0;
    border-radius: calc(var(--wui-border-radius-5xs) * 9 - var(--wui-border-radius-xxs));
    box-shadow: inset 0 0 0 1px var(--wui-gray-glass-005);
  }

  wui-icon-box {
    position: absolute;
    right: calc(var(--wui-spacing-3xs) * -1);
    bottom: calc(var(--wui-spacing-3xs) * -1);
    opacity: 0;
    transform: scale(0.5);
    transition: all var(--wui-ease-out-power-2) var(--wui-duration-lg);
  }

  wui-text[align='center'] {
    width: 100%;
    padding: 0px var(--wui-spacing-l);
  }

  [data-error='true'] wui-icon-box {
    opacity: 1;
    transform: scale(1);
  }

  [data-error='true'] > wui-flex:first-child {
    animation: shake 250ms cubic-bezier(0.36, 0.07, 0.19, 0.97) both;
  }

  [data-retry='false'] wui-link {
    display: none;
  }

  [data-retry='true'] wui-link {
    display: block;
    opacity: 1;
  }

  wui-link {
    padding: var(--wui-spacing-4xs) var(--wui-spacing-xxs);
  }
`;var Ht=function(n,e,t,i){var o=arguments.length,r=o<3?e:i===null?i=Object.getOwnPropertyDescriptor(e,t):i,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")r=Reflect.decorate(n,e,t,i);else for(var a=n.length-1;a>=0;a--)(s=n[a])&&(r=(o<3?s(r):o>3?s(e,t,r):s(e,t))||r);return o>3&&r&&Object.defineProperty(e,t,r),r};let vt=class extends X{constructor(){super(),this.unsubscribe=[],this.selectedOnRampProvider=ve.state.selectedProvider,this.uri=fe.state.wcUri,this.ready=!1,this.showRetry=!1,this.buffering=!1,this.error=!1,this.startTime=null,this.isMobile=!1,this.onRetry=void 0,this.unsubscribe.push(ve.subscribeKey("selectedProvider",e=>{this.selectedOnRampProvider=e})),this.watchTransactions()}disconnectedCallback(){this.intervalId&&clearInterval(this.intervalId)}render(){var i,o;let e="Continue in external window";this.error?e="Buy failed":this.selectedOnRampProvider&&(e=`Buy in ${(i=this.selectedOnRampProvider)==null?void 0:i.label}`);const t=this.error?"Buy can be declined from your side or due to and error on the provider app":"We’ll notify you once your Buy is processed";return A`
      <wui-flex
        data-error=${le(this.error)}
        data-retry=${this.showRetry}
        flexDirection="column"
        alignItems="center"
        .padding=${["3xl","xl","xl","xl"]}
        gap="xl"
      >
        <wui-flex justifyContent="center" alignItems="center">
          <wui-visual
            name=${le((o=this.selectedOnRampProvider)==null?void 0:o.name)}
            size="lg"
            class="provider-image"
          >
          </wui-visual>

          ${this.error?null:this.loaderTemplate()}

          <wui-icon-box
            backgroundColor="error-100"
            background="opaque"
            iconColor="error-100"
            icon="close"
            size="sm"
            border
            borderColor="wui-color-bg-125"
          ></wui-icon-box>
        </wui-flex>

        <wui-flex flexDirection="column" alignItems="center" gap="xs">
          <wui-text variant="paragraph-500" color=${this.error?"error-100":"fg-100"}>
            ${e}
          </wui-text>
          <wui-text align="center" variant="small-500" color="fg-200">${t}</wui-text>
        </wui-flex>

        ${this.error?this.tryAgainTemplate():null}
      </wui-flex>

      <wui-flex .padding=${["0","xl","xl","xl"]} justifyContent="center">
        <wui-link @click=${this.onCopyUri} color="fg-200">
          <wui-icon size="xs" color="fg-200" slot="iconLeft" name="copy"></wui-icon>
          Copy link
        </wui-link>
      </wui-flex>
    `}watchTransactions(){if(this.selectedOnRampProvider)switch(this.selectedOnRampProvider.name){case"coinbase":this.startTime=Date.now(),this.initializeCoinbaseTransactions();break}}async initializeCoinbaseTransactions(){await this.watchCoinbaseTransactions(),this.intervalId=setInterval(()=>this.watchCoinbaseTransactions(),4e3)}async watchCoinbaseTransactions(){try{const e=ne.state.address,t=ce.state.projectId;if(!e)throw new Error("No address found");(await mr.fetchTransactions({account:e,onramp:"coinbase",projectId:t})).data.filter(r=>new Date(r.metadata.minedAt)>new Date(this.startTime)||r.metadata.status==="ONRAMP_TRANSACTION_STATUS_IN_PROGRESS").length?(clearInterval(this.intervalId),j.replace("OnRampActivity")):this.startTime&&Date.now()-this.startTime>=18e4&&(clearInterval(this.intervalId),this.error=!0)}catch(e){xe.showError(e)}}onTryAgain(){this.selectedOnRampProvider&&(this.error=!1,F.openHref(this.selectedOnRampProvider.url,"popupWindow","width=600,height=800,scrollbars=yes"))}tryAgainTemplate(){var e;return(e=this.selectedOnRampProvider)!=null&&e.url?A`<wui-button variant="accent" @click=${this.onTryAgain.bind(this)}>
      <wui-icon color="inherit" slot="iconLeft" name="refresh"></wui-icon>
      Try again
    </wui-button>`:null}loaderTemplate(){const e=Fe.state.themeVariables["--w3m-border-radius-master"],t=e?parseInt(e.replace("px",""),10):4;return A`<wui-loading-thumbnail radius=${t*9}></wui-loading-thumbnail>`}onCopyUri(){var e;if(!((e=this.selectedOnRampProvider)!=null&&e.url)){xe.showError("No link found"),j.goBack();return}try{F.copyToClopboard(this.selectedOnRampProvider.url),xe.showSuccess("Link copied")}catch{xe.showError("Failed to copy")}}};vt.styles=X5;Ht([N()],vt.prototype,"selectedOnRampProvider",void 0);Ht([N()],vt.prototype,"uri",void 0);Ht([N()],vt.prototype,"ready",void 0);Ht([N()],vt.prototype,"showRetry",void 0);Ht([N()],vt.prototype,"buffering",void 0);Ht([N()],vt.prototype,"error",void 0);Ht([N()],vt.prototype,"intervalId",void 0);Ht([N()],vt.prototype,"startTime",void 0);Ht([Ce({type:Boolean})],vt.prototype,"isMobile",void 0);Ht([Ce()],vt.prototype,"onRetry",void 0);vt=Ht([k("w3m-buy-in-progress-view")],vt);const e4=be`
  wui-flex {
    max-height: clamp(360px, 540px, 80vh);
    overflow: scroll;
    scrollbar-width: none;
  }

  wui-flex::-webkit-scrollbar {
    display: none;
  }
`;var zh=function(n,e,t,i){var o=arguments.length,r=o<3?e:i===null?i=Object.getOwnPropertyDescriptor(e,t):i,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")r=Reflect.decorate(n,e,t,i);else for(var a=n.length-1;a>=0;a--)(s=n[a])&&(r=(o<3?s(r):o>3?s(e,t,r):s(e,t))||r);return o>3&&r&&Object.defineProperty(e,t,r),r};let Xs=class extends X{constructor(){super(),this.unsubscribe=[],this.connectors=Ee.state.connectors,this.unsubscribe.push(Ee.subscribeKey("connectors",e=>this.connectors=e))}disconnectedCallback(){this.unsubscribe.forEach(e=>e())}render(){return A`
      <wui-flex flexDirection="column" padding="s" gap="xs">
        <w3m-email-login-widget></w3m-email-login-widget>

        ${this.walletConnectConnectorTemplate()} ${this.recentTemplate()}
        ${this.announcedTemplate()} ${this.injectedTemplate()} ${this.featuredTemplate()}
        ${this.customTemplate()} ${this.recommendedTemplate()} ${this.externalTemplate()}
        ${this.allWalletsTemplate()}
      </wui-flex>
      <w3m-legal-footer></w3m-legal-footer>
    `}walletConnectConnectorTemplate(){if(F.isMobile())return null;const e=this.connectors.find(t=>t.type==="WALLET_CONNECT");return e?A`
      <wui-list-wallet
        imageSrc=${le(Se.getConnectorImage(e))}
        name=${e.name??"Unknown"}
        @click=${()=>this.onConnector(e)}
        tagLabel="qr code"
        tagVariant="main"
        data-testid="wallet-selector-walletconnect"
      >
      </wui-list-wallet>
    `:null}customTemplate(){const{customWallets:e}=ce.state;return e!=null&&e.length?this.filterOutDuplicateWallets(e).map(i=>A`
        <wui-list-wallet
          imageSrc=${le(Se.getWalletImage(i))}
          name=${i.name??"Unknown"}
          @click=${()=>this.onConnectWallet(i)}
        >
        </wui-list-wallet>
      `):null}featuredTemplate(){if(!this.connectors.find(o=>o.type==="WALLET_CONNECT"))return null;const{featured:t}=ie.state;return t.length?this.filterOutDuplicateWallets(t).map(o=>A`
        <wui-list-wallet
          imageSrc=${le(Se.getWalletImage(o))}
          name=${o.name??"Unknown"}
          @click=${()=>this.onConnectWallet(o)}
        >
        </wui-list-wallet>
      `):null}recentTemplate(){return Ze.getRecentWallets().map(t=>A`
        <wui-list-wallet
          imageSrc=${le(Se.getWalletImage(t))}
          name=${t.name??"Unknown"}
          @click=${()=>this.onConnectWallet(t)}
          tagLabel="recent"
          tagVariant="shade"
        >
        </wui-list-wallet>
      `)}announcedTemplate(){return this.connectors.map(e=>e.type!=="ANNOUNCED"?null:A`
        <wui-list-wallet
          imageSrc=${le(Se.getConnectorImage(e))}
          name=${e.name??"Unknown"}
          @click=${()=>this.onConnector(e)}
          tagVariant="success"
          .installed=${!0}
        >
        </wui-list-wallet>
      `)}injectedTemplate(){return this.connectors.map(e=>e.type!=="INJECTED"||!fe.checkInstalled()?null:A`
        <wui-list-wallet
          imageSrc=${le(Se.getConnectorImage(e))}
          .installed=${!0}
          name=${e.name??"Unknown"}
          @click=${()=>this.onConnector(e)}
        >
        </wui-list-wallet>
      `)}externalTemplate(){const e=Ee.getAnnouncedConnectorRdns();return this.connectors.map(t=>["WALLET_CONNECT","INJECTED","ANNOUNCED","EMAIL"].includes(t.type)||e.includes(pt.CONNECTOR_RDNS_MAP[t.id])?null:A`
        <wui-list-wallet
          imageSrc=${le(Se.getConnectorImage(t))}
          name=${t.name??"Unknown"}
          @click=${()=>this.onConnector(t)}
        >
        </wui-list-wallet>
      `)}allWalletsTemplate(){const e=this.connectors.find(c=>c.type==="WALLET_CONNECT"),{allWallets:t}=ce.state;if(!e||t==="HIDE"||t==="ONLY_MOBILE"&&!F.isMobile())return null;const i=ie.state.count,o=ie.state.featured.length,r=i+o,s=r<10?r:Math.floor(r/10)*10,a=s<r?`${s}+`:`${s}`;return A`
      <wui-list-wallet
        name="All Wallets"
        walletIcon="allWallets"
        showAllWallets
        @click=${this.onAllWallets.bind(this)}
        tagLabel=${a}
        tagVariant="shade"
        data-testid="all-wallets"
      ></wui-list-wallet>
    `}recommendedTemplate(){if(!this.connectors.find(g=>g.type==="WALLET_CONNECT"))return null;const{recommended:t}=ie.state,{customWallets:i,featuredWalletIds:o}=ce.state,{connectors:r}=Ee.state,s=Ze.getRecentWallets(),c=r.filter(g=>g.type==="INJECTED").filter(g=>g.name!=="Browser Wallet");if(o||i||!t.length)return null;const u=c.length+s.length,h=Math.max(0,2-u);return this.filterOutDuplicateWallets(t).slice(0,h).map(g=>A`
        <wui-list-wallet
          imageSrc=${le(Se.getWalletImage(g))}
          name=${(g==null?void 0:g.name)??"Unknown"}
          @click=${()=>this.onConnectWallet(g)}
        >
        </wui-list-wallet>
      `)}onConnector(e){e.type==="WALLET_CONNECT"?F.isMobile()?j.push("AllWallets"):j.push("ConnectingWalletConnect"):j.push("ConnectingExternal",{connector:e})}filterOutDuplicateWallets(e){const i=Ze.getRecentWallets().map(r=>r.id);return e.filter(r=>!i.includes(r.id))}onAllWallets(){Y.sendEvent({type:"track",event:"CLICK_ALL_WALLETS"}),j.push("AllWallets")}onConnectWallet(e){j.push("ConnectingWalletConnect",{wallet:e})}};Xs.styles=e4;zh([N()],Xs.prototype,"connectors",void 0);Xs=zh([k("w3m-connect-view")],Xs);const t4=be`
  @keyframes shake {
    0% {
      transform: translateX(0);
    }
    25% {
      transform: translateX(3px);
    }
    50% {
      transform: translateX(-3px);
    }
    75% {
      transform: translateX(3px);
    }
    100% {
      transform: translateX(0);
    }
  }

  wui-flex:first-child:not(:only-child) {
    position: relative;
  }

  wui-loading-thumbnail {
    position: absolute;
  }

  wui-icon-box {
    position: absolute;
    right: calc(var(--wui-spacing-3xs) * -1);
    bottom: calc(var(--wui-spacing-3xs) * -1);
    opacity: 0;
    transform: scale(0.5);
    transition: all var(--wui-ease-out-power-2) var(--wui-duration-lg);
  }

  wui-text[align='center'] {
    width: 100%;
    padding: 0px var(--wui-spacing-l);
  }

  [data-error='true'] wui-icon-box {
    opacity: 1;
    transform: scale(1);
  }

  [data-error='true'] > wui-flex:first-child {
    animation: shake 250ms cubic-bezier(0.36, 0.07, 0.19, 0.97) both;
  }

  [data-retry='false'] wui-link {
    display: none;
  }

  [data-retry='true'] wui-link {
    display: block;
    opacity: 1;
  }
`;var qi=function(n,e,t,i){var o=arguments.length,r=o<3?e:i===null?i=Object.getOwnPropertyDescriptor(e,t):i,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")r=Reflect.decorate(n,e,t,i);else for(var a=n.length-1;a>=0;a--)(s=n[a])&&(r=(o<3?s(r):o>3?s(e,t,r):s(e,t))||r);return o>3&&r&&Object.defineProperty(e,t,r),r};class lt extends X{constructor(){var e,t,i,o;super(),this.wallet=(e=j.state.data)==null?void 0:e.wallet,this.connector=(t=j.state.data)==null?void 0:t.connector,this.timeout=void 0,this.secondaryBtnLabel="Try again",this.secondaryBtnIcon="refresh",this.secondaryLabel="Accept connection request in the wallet",this.onConnect=void 0,this.onRender=void 0,this.onAutoConnect=void 0,this.isWalletConnect=!0,this.unsubscribe=[],this.imageSrc=Se.getWalletImage(this.wallet)??Se.getConnectorImage(this.connector),this.name=((i=this.wallet)==null?void 0:i.name)??((o=this.connector)==null?void 0:o.name)??"Wallet",this.isRetrying=!1,this.uri=fe.state.wcUri,this.error=fe.state.wcError,this.ready=!1,this.showRetry=!1,this.buffering=!1,this.isMobile=!1,this.onRetry=void 0,this.unsubscribe.push(fe.subscribeKey("wcUri",r=>{var s;this.uri=r,this.isRetrying&&this.onRetry&&(this.isRetrying=!1,(s=this.onConnect)==null||s.call(this))}),fe.subscribeKey("wcError",r=>this.error=r),fe.subscribeKey("buffering",r=>this.buffering=r))}firstUpdated(){var e;(e=this.onAutoConnect)==null||e.call(this),this.showRetry=!this.onAutoConnect}disconnectedCallback(){this.unsubscribe.forEach(e=>e()),clearTimeout(this.timeout)}render(){var i;(i=this.onRender)==null||i.call(this),this.onShowRetry();const e=this.error?"Connection can be declined if a previous request is still active":this.secondaryLabel;let t=`Continue in ${this.name}`;return this.buffering&&(t="Connecting..."),this.error&&(t="Connection declined"),A`
      <wui-flex
        data-error=${le(this.error)}
        data-retry=${this.showRetry}
        flexDirection="column"
        alignItems="center"
        .padding=${["3xl","xl","xl","xl"]}
        gap="xl"
      >
        <wui-flex justifyContent="center" alignItems="center">
          <wui-wallet-image size="lg" imageSrc=${le(this.imageSrc)}></wui-wallet-image>

          ${this.error?null:this.loaderTemplate()}

          <wui-icon-box
            backgroundColor="error-100"
            background="opaque"
            iconColor="error-100"
            icon="close"
            size="sm"
            border
            borderColor="wui-color-bg-125"
          ></wui-icon-box>
        </wui-flex>

        <wui-flex flexDirection="column" alignItems="center" gap="xs">
          <wui-text variant="paragraph-500" color=${this.error?"error-100":"fg-100"}>
            ${t}
          </wui-text>
          <wui-text align="center" variant="small-500" color="fg-200">${e}</wui-text>
        </wui-flex>

        <wui-button
          variant="accent"
          ?disabled=${!this.error&&this.buffering}
          @click=${this.onTryAgain.bind(this)}
        >
          <wui-icon color="inherit" slot="iconLeft" name=${this.secondaryBtnIcon}></wui-icon>
          ${this.secondaryBtnLabel}
        </wui-button>
      </wui-flex>

      ${this.isWalletConnect?A`
            <wui-flex .padding=${["0","xl","xl","xl"]} justifyContent="center">
              <wui-link @click=${this.onCopyUri} color="fg-200">
                <wui-icon size="xs" color="fg-200" slot="iconLeft" name="copy"></wui-icon>
                Copy link
              </wui-link>
            </wui-flex>
          `:null}

      <w3m-mobile-download-links .wallet=${this.wallet}></w3m-mobile-download-links>
    `}onShowRetry(){var e;if(this.error&&!this.showRetry){this.showRetry=!0;const t=(e=this.shadowRoot)==null?void 0:e.querySelector("wui-button");t==null||t.animate([{opacity:0},{opacity:1}],{fill:"forwards",easing:"ease"})}}onTryAgain(){var e,t;this.buffering||(fe.setWcError(!1),this.onRetry?(this.isRetrying=!0,(e=this.onRetry)==null||e.call(this)):(t=this.onConnect)==null||t.call(this))}loaderTemplate(){const e=Fe.state.themeVariables["--w3m-border-radius-master"],t=e?parseInt(e.replace("px",""),10):4;return A`<wui-loading-thumbnail radius=${t*9}></wui-loading-thumbnail>`}onCopyUri(){try{this.uri&&(F.copyToClopboard(this.uri),xe.showSuccess("Link copied"))}catch{xe.showError("Failed to copy")}}}lt.styles=t4;qi([N()],lt.prototype,"uri",void 0);qi([N()],lt.prototype,"error",void 0);qi([N()],lt.prototype,"ready",void 0);qi([N()],lt.prototype,"showRetry",void 0);qi([N()],lt.prototype,"buffering",void 0);qi([Ce({type:Boolean})],lt.prototype,"isMobile",void 0);qi([Ce()],lt.prototype,"onRetry",void 0);var n4=function(n,e,t,i){var o=arguments.length,r=o<3?e:i===null?i=Object.getOwnPropertyDescriptor(e,t):i,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")r=Reflect.decorate(n,e,t,i);else for(var a=n.length-1;a>=0;a--)(s=n[a])&&(r=(o<3?s(r):o>3?s(e,t,r):s(e,t))||r);return o>3&&r&&Object.defineProperty(e,t,r),r};const i4={INJECTED:"browser",ANNOUNCED:"browser"};let Ad=class extends lt{constructor(){if(super(),!this.connector)throw new Error("w3m-connecting-view: No connector provided");Y.sendEvent({type:"track",event:"SELECT_WALLET",properties:{name:this.connector.name??"Unknown",platform:i4[this.connector.type]??"external"}}),this.onConnect=this.onConnectProxy.bind(this),this.onAutoConnect=this.onConnectProxy.bind(this),this.isWalletConnect=!1}async onConnectProxy(){try{this.error=!1,this.connector&&(this.connector.imageUrl&&Ze.setConnectedWalletImageUrl(this.connector.imageUrl),await fe.connectExternal(this.connector),Me.state.isSiweEnabled?j.push("ConnectingSiwe"):he.close(),Y.sendEvent({type:"track",event:"CONNECT_SUCCESS",properties:{method:"external"}}))}catch(e){Y.sendEvent({type:"track",event:"CONNECT_ERROR",properties:{message:(e==null?void 0:e.message)??"Unknown"}}),this.error=!0}}};Ad=n4([k("w3m-connecting-external-view")],Ad);var Fh=function(n,e,t,i){var o=arguments.length,r=o<3?e:i===null?i=Object.getOwnPropertyDescriptor(e,t):i,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")r=Reflect.decorate(n,e,t,i);else for(var a=n.length-1;a>=0;a--)(s=n[a])&&(r=(o<3?s(r):o>3?s(e,t,r):s(e,t))||r);return o>3&&r&&Object.defineProperty(e,t,r),r};let al=class extends X{constructor(){var e;super(...arguments),this.dappName=(e=ce.state.metadata)==null?void 0:e.name,this.isSigning=!1}render(){return A`
      <wui-flex justifyContent="center" .padding=${["2xl","0","xxl","0"]}>
        <w3m-connecting-siwe></w3m-connecting-siwe>
      </wui-flex>
      <wui-flex
        .padding=${["0","4xl","l","4xl"]}
        gap="s"
        justifyContent="space-between"
      >
        <wui-text variant="paragraph-500" align="center" color="fg-100"
          >${this.dappName??"Dapp"} needs to connect to your wallet</wui-text
        >
      </wui-flex>
      <wui-flex
        .padding=${["0","3xl","l","3xl"]}
        gap="s"
        justifyContent="space-between"
      >
        <wui-text variant="small-400" align="center" color="fg-200"
          >Sign this message to prove you own this wallet and proceed. Canceling will disconnect
          you.</wui-text
        >
      </wui-flex>
      <wui-flex .padding=${["l","xl","xl","xl"]} gap="s" justifyContent="space-between">
        <wui-button
          size="md"
          ?fullwidth=${!0}
          variant="shade"
          @click=${this.onCancel.bind(this)}
          data-testid="w3m-connecting-siwe-cancel"
        >
          Cancel
        </wui-button>
        <wui-button
          size="md"
          ?fullwidth=${!0}
          variant="fill"
          @click=${this.onSign.bind(this)}
          ?loading=${this.isSigning}
          data-testid="w3m-connecting-siwe-sign"
        >
          ${this.isSigning?"Signing...":"Sign"}
        </wui-button>
      </wui-flex>
    `}async onSign(){this.isSigning=!0,Y.sendEvent({event:"CLICK_SIGN_SIWE_MESSAGE",type:"track"});try{Me.setStatus("loading");const e=await Me.signIn();return Me.setStatus("success"),Y.sendEvent({event:"SIWE_AUTH_SUCCESS",type:"track"}),e}catch{return xe.showError("Signature declined"),Me.setStatus("error"),Y.sendEvent({event:"SIWE_AUTH_ERROR",type:"track"})}finally{this.isSigning=!1}}async onCancel(){const{isConnected:e}=ne.state;e?(await fe.disconnect(),he.close()):j.push("Connect"),Y.sendEvent({event:"CLICK_CANCEL_SIWE",type:"track"})}};Fh([N()],al.prototype,"isSigning",void 0);al=Fh([k("w3m-connecting-siwe-view")],al);var ru=function(n,e,t,i){var o=arguments.length,r=o<3?e:i===null?i=Object.getOwnPropertyDescriptor(e,t):i,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")r=Reflect.decorate(n,e,t,i);else for(var a=n.length-1;a>=0;a--)(s=n[a])&&(r=(o<3?s(r):o>3?s(e,t,r):s(e,t))||r);return o>3&&r&&Object.defineProperty(e,t,r),r};let ea=class extends X{constructor(){var e;super(),this.interval=void 0,this.lastRetry=Date.now(),this.wallet=(e=j.state.data)==null?void 0:e.wallet,this.platform=void 0,this.platforms=[],this.initializeConnection(),this.interval=setInterval(this.initializeConnection.bind(this),pt.TEN_SEC_MS)}disconnectedCallback(){clearTimeout(this.interval)}render(){return this.wallet?(this.determinePlatforms(),A`
      ${this.headerTemplate()}
      <div>${this.platformTemplate()}</div>
    `):A`<w3m-connecting-wc-qrcode></w3m-connecting-wc-qrcode>`}async initializeConnection(e=!1){try{const{wcPairingExpiry:t}=fe.state;if(e||F.isPairingExpired(t)){if(fe.connectWalletConnect(),this.wallet){const i=Se.getWalletImage(this.wallet);i&&Ze.setConnectedWalletImageUrl(i)}else{const o=Ee.state.connectors.find(s=>s.type==="WALLET_CONNECT"),r=Se.getConnectorImage(o);r&&Ze.setConnectedWalletImageUrl(r)}await fe.state.wcPromise,this.finalizeConnection(),Me.state.isSiweEnabled?j.push("ConnectingSiwe"):he.close()}}catch(t){Y.sendEvent({type:"track",event:"CONNECT_ERROR",properties:{message:(t==null?void 0:t.message)??"Unknown"}}),fe.setWcError(!0),F.isAllowedRetry(this.lastRetry)&&(xe.showError("Declined"),this.lastRetry=Date.now(),this.initializeConnection(!0))}}finalizeConnection(){const{wcLinking:e,recentWallet:t}=fe.state;e&&Ze.setWalletConnectDeepLink(e),t&&Ze.setWeb3ModalRecent(t),Y.sendEvent({type:"track",event:"CONNECT_SUCCESS",properties:{method:e?"mobile":"qrcode"}})}determinePlatforms(){if(!this.wallet)throw new Error("w3m-connecting-wc-view:determinePlatforms No wallet");if(this.platform)return;const{mobile_link:e,desktop_link:t,webapp_link:i,injected:o,rdns:r}=this.wallet,s=o==null?void 0:o.map(({injected_id:_})=>_).filter(Boolean),a=r?[r]:s??[],c=a.length,u=e,h=i,p=fe.checkInstalled(a),g=c&&p,b=t&&!F.isMobile();g&&this.platforms.push("browser"),u&&this.platforms.push(F.isMobile()?"mobile":"qrcode"),h&&this.platforms.push("web"),b&&this.platforms.push("desktop"),!g&&c&&this.platforms.push("unsupported"),this.platform=this.platforms[0]}platformTemplate(){switch(this.platform){case"browser":return A`<w3m-connecting-wc-browser></w3m-connecting-wc-browser>`;case"desktop":return A`
          <w3m-connecting-wc-desktop .onRetry=${()=>this.initializeConnection(!0)}>
          </w3m-connecting-wc-desktop>
        `;case"web":return A`
          <w3m-connecting-wc-web .onRetry=${()=>this.initializeConnection(!0)}>
          </w3m-connecting-wc-web>
        `;case"mobile":return A`
          <w3m-connecting-wc-mobile isMobile .onRetry=${()=>this.initializeConnection(!0)}>
          </w3m-connecting-wc-mobile>
        `;case"qrcode":return A`<w3m-connecting-wc-qrcode></w3m-connecting-wc-qrcode>`;default:return A`<w3m-connecting-wc-unsupported></w3m-connecting-wc-unsupported>`}}headerTemplate(){return this.platforms.length>1?A`
      <w3m-connecting-header
        .platforms=${this.platforms}
        .onSelectPlatfrom=${this.onSelectPlatform.bind(this)}
      >
      </w3m-connecting-header>
    `:null}async onSelectPlatform(e){var i;const t=(i=this.shadowRoot)==null?void 0:i.querySelector("div");t&&(await t.animate([{opacity:1},{opacity:0}],{duration:200,fill:"forwards",easing:"ease"}).finished,this.platform=e,t.animate([{opacity:0},{opacity:1}],{duration:200,fill:"forwards",easing:"ease"}))}};ru([N()],ea.prototype,"platform",void 0);ru([N()],ea.prototype,"platforms",void 0);ea=ru([k("w3m-connecting-wc-view")],ea);var r4=function(n,e,t,i){var o=arguments.length,r=o<3?e:i===null?i=Object.getOwnPropertyDescriptor(e,t):i,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")r=Reflect.decorate(n,e,t,i);else for(var a=n.length-1;a>=0;a--)(s=n[a])&&(r=(o<3?s(r):o>3?s(e,t,r):s(e,t))||r);return o>3&&r&&Object.defineProperty(e,t,r),r};let Sd=class extends X{constructor(){var e;super(...arguments),this.wallet=(e=j.state.data)==null?void 0:e.wallet}render(){if(!this.wallet)throw new Error("w3m-downloads-view");return A`
      <wui-flex gap="xs" flexDirection="column" .padding=${["s","s","l","s"]}>
        ${this.chromeTemplate()} ${this.iosTemplate()} ${this.androidTemplate()}
        ${this.homepageTemplate()}
      </wui-flex>
    `}chromeTemplate(){var e;return(e=this.wallet)!=null&&e.chrome_store?A`<wui-list-item
      variant="icon"
      icon="chromeStore"
      iconVariant="square"
      @click=${this.onChromeStore.bind(this)}
      chevron
    >
      <wui-text variant="paragraph-500" color="fg-100">Chrome Extension</wui-text>
    </wui-list-item>`:null}iosTemplate(){var e;return(e=this.wallet)!=null&&e.app_store?A`<wui-list-item
      variant="icon"
      icon="appStore"
      iconVariant="square"
      @click=${this.onAppStore.bind(this)}
      chevron
    >
      <wui-text variant="paragraph-500" color="fg-100">iOS App</wui-text>
    </wui-list-item>`:null}androidTemplate(){var e;return(e=this.wallet)!=null&&e.play_store?A`<wui-list-item
      variant="icon"
      icon="playStore"
      iconVariant="square"
      @click=${this.onPlayStore.bind(this)}
      chevron
    >
      <wui-text variant="paragraph-500" color="fg-100">Android App</wui-text>
    </wui-list-item>`:null}homepageTemplate(){var e;return(e=this.wallet)!=null&&e.homepage?A`
      <wui-list-item
        variant="icon"
        icon="browser"
        iconVariant="square-blue"
        @click=${this.onHomePage.bind(this)}
        chevron
      >
        <wui-text variant="paragraph-500" color="fg-100">Website</wui-text>
      </wui-list-item>
    `:null}onChromeStore(){var e;(e=this.wallet)!=null&&e.chrome_store&&F.openHref(this.wallet.chrome_store,"_blank")}onAppStore(){var e;(e=this.wallet)!=null&&e.app_store&&F.openHref(this.wallet.app_store,"_blank")}onPlayStore(){var e;(e=this.wallet)!=null&&e.play_store&&F.openHref(this.wallet.play_store,"_blank")}onHomePage(){var e;(e=this.wallet)!=null&&e.homepage&&F.openHref(this.wallet.homepage,"_blank")}};Sd=r4([k("w3m-downloads-view")],Sd);var o4=function(n,e,t,i){var o=arguments.length,r=o<3?e:i===null?i=Object.getOwnPropertyDescriptor(e,t):i,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")r=Reflect.decorate(n,e,t,i);else for(var a=n.length-1;a>=0;a--)(s=n[a])&&(r=(o<3?s(r):o>3?s(e,t,r):s(e,t))||r);return o>3&&r&&Object.defineProperty(e,t,r),r};const s4="https://walletconnect.com/explorer";let Id=class extends X{render(){return A`
      <wui-flex flexDirection="column" padding="s" gap="xs">
        ${this.recommendedWalletsTemplate()}
        <wui-list-wallet
          name="Explore all"
          showAllWallets
          walletIcon="allWallets"
          icon="externalLink"
          @click=${()=>{F.openHref("https://walletconnect.com/explorer?type=wallet","_blank")}}
        ></wui-list-wallet>
      </wui-flex>
    `}recommendedWalletsTemplate(){const{recommended:e,featured:t}=ie.state,{customWallets:i}=ce.state;return[...t,...i??[],...e].slice(0,4).map(r=>A`
        <wui-list-wallet
          name=${r.name??"Unknown"}
          tagVariant="main"
          imageSrc=${le(Se.getWalletImage(r))}
          @click=${()=>{F.openHref(r.homepage??s4,"_blank")}}
        ></wui-list-wallet>
      `)}};Id=o4([k("w3m-get-wallet-view")],Id);const a4=be`
  @keyframes shake {
    0% {
      transform: translateX(0);
    }
    25% {
      transform: translateX(3px);
    }
    50% {
      transform: translateX(-3px);
    }
    75% {
      transform: translateX(3px);
    }
    100% {
      transform: translateX(0);
    }
  }

  wui-flex:first-child:not(:only-child) {
    position: relative;
  }

  wui-loading-hexagon {
    position: absolute;
  }

  wui-icon-box {
    position: absolute;
    right: 4px;
    bottom: 0;
    opacity: 0;
    transform: scale(0.5);
    z-index: 1;
    transition: all var(--wui-ease-out-power-2) var(--wui-duration-lg);
  }

  wui-button {
    display: none;
  }

  [data-error='true'] wui-icon-box {
    opacity: 1;
    transform: scale(1);
  }

  [data-error='true'] > wui-flex:first-child {
    animation: shake 250ms cubic-bezier(0.36, 0.07, 0.19, 0.97) both;
  }

  wui-button[data-retry='true'] {
    display: block;
    opacity: 1;
  }
`;var ou=function(n,e,t,i){var o=arguments.length,r=o<3?e:i===null?i=Object.getOwnPropertyDescriptor(e,t):i,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")r=Reflect.decorate(n,e,t,i);else for(var a=n.length-1;a>=0;a--)(s=n[a])&&(r=(o<3?s(r):o>3?s(e,t,r):s(e,t))||r);return o>3&&r&&Object.defineProperty(e,t,r),r};let Ho=class extends X{constructor(){var e;super(),this.network=(e=j.state.data)==null?void 0:e.network,this.unsubscribe=[],this.showRetry=!1,this.error=!1}disconnectedCallback(){this.unsubscribe.forEach(e=>e())}firstUpdated(){this.onSwitchNetwork()}render(){if(!this.network)throw new Error("w3m-network-switch-view: No network provided");this.onShowRetry();const e=this.error?"Switch declined":"Approve in wallet",t=this.error?"Switch can be declined if chain is not supported by a wallet or previous request is still active":"Accept connection request in your wallet";return A`
      <wui-flex
        data-error=${this.error}
        flexDirection="column"
        alignItems="center"
        .padding=${["3xl","xl","3xl","xl"]}
        gap="xl"
      >
        <wui-flex justifyContent="center" alignItems="center">
          <wui-network-image
            size="lg"
            imageSrc=${le(Se.getNetworkImage(this.network))}
          ></wui-network-image>

          ${this.error?null:A`<wui-loading-hexagon></wui-loading-hexagon>`}

          <wui-icon-box
            backgroundColor="error-100"
            background="opaque"
            iconColor="error-100"
            icon="close"
            size="sm"
            ?border=${!0}
            borderColor="wui-color-bg-125"
          ></wui-icon-box>
        </wui-flex>

        <wui-flex flexDirection="column" alignItems="center" gap="xs">
          <wui-text align="center" variant="paragraph-500" color="fg-100">${e}</wui-text>
          <wui-text align="center" variant="small-500" color="fg-200">${t}</wui-text>
        </wui-flex>

        <wui-button
          data-retry=${this.showRetry}
          variant="fill"
          .disabled=${!this.error}
          @click=${this.onSwitchNetwork.bind(this)}
        >
          <wui-icon color="inherit" slot="iconLeft" name="refresh"></wui-icon>
          Try again
        </wui-button>
      </wui-flex>
    `}onShowRetry(){var e;if(this.error&&!this.showRetry){this.showRetry=!0;const t=(e=this.shadowRoot)==null?void 0:e.querySelector("wui-button");t==null||t.animate([{opacity:0},{opacity:1}],{fill:"forwards",easing:"ease"})}}async onSwitchNetwork(){try{this.error=!1,this.network&&(await ge.switchActiveNetwork(this.network),Me.state.isSiweEnabled||kl.navigateAfterNetworkSwitch())}catch{this.error=!0}}};Ho.styles=a4;ou([N()],Ho.prototype,"showRetry",void 0);ou([N()],Ho.prototype,"error",void 0);Ho=ou([k("w3m-network-switch-view")],Ho);const c4=be`
  :host > wui-grid {
    max-height: 360px;
    overflow: auto;
  }

  wui-grid::-webkit-scrollbar {
    display: none;
  }
`;var Hh=function(n,e,t,i){var o=arguments.length,r=o<3?e:i===null?i=Object.getOwnPropertyDescriptor(e,t):i,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")r=Reflect.decorate(n,e,t,i);else for(var a=n.length-1;a>=0;a--)(s=n[a])&&(r=(o<3?s(r):o>3?s(e,t,r):s(e,t))||r);return o>3&&r&&Object.defineProperty(e,t,r),r};let ta=class extends X{constructor(){super(),this.unsubscribe=[],this.caipNetwork=ge.state.caipNetwork,this.unsubscribe.push(ge.subscribeKey("caipNetwork",e=>this.caipNetwork=e))}disconnectedCallback(){this.unsubscribe.forEach(e=>e())}render(){return A`
      <wui-grid padding="s" gridTemplateColumns="repeat(4, 1fr)" rowGap="l" columnGap="xs">
        ${this.networksTemplate()}
      </wui-grid>

      <wui-separator></wui-separator>

      <wui-flex padding="s" flexDirection="column" gap="m" alignItems="center">
        <wui-text variant="small-400" color="fg-300" align="center">
          Your connected wallet may not support some of the networks available for this dApp
        </wui-text>
        <wui-link @click=${this.onNetworkHelp.bind(this)}>
          <wui-icon size="xs" color="accent-100" slot="iconLeft" name="helpCircle"></wui-icon>
          What is a network
        </wui-link>
      </wui-flex>
    `}onNetworkHelp(){Y.sendEvent({type:"track",event:"CLICK_NETWORK_HELP"}),j.push("WhatIsANetwork")}networksTemplate(){const{approvedCaipNetworkIds:e,requestedCaipNetworks:t,supportsAllNetworks:i}=ge.state,o=F.sortRequestedNetworks(e,t);return o==null?void 0:o.map(r=>{var s;return A`
        <wui-card-select
          .selected=${((s=this.caipNetwork)==null?void 0:s.id)===r.id}
          imageSrc=${le(Se.getNetworkImage(r))}
          type="network"
          name=${r.name??r.id}
          @click=${()=>this.onSwitchNetwork(r)}
          .disabled=${!i&&!(e!=null&&e.includes(r.id))}
          data-testid=${`w3m-network-switch-${r.name??r.id}`}
        ></wui-card-select>
      `})}async onSwitchNetwork(e){const{isConnected:t}=ne.state,{approvedCaipNetworkIds:i,supportsAllNetworks:o,caipNetwork:r}=ge.state,{data:s}=j.state;t&&(r==null?void 0:r.id)!==e.id?i!=null&&i.includes(e.id)?(await ge.switchActiveNetwork(e),kl.navigateAfterNetworkSwitch()):o&&j.push("SwitchNetwork",{...s,network:e}):t||(ge.setCaipNetwork(e),j.push("Connect"))}};ta.styles=c4;Hh([N()],ta.prototype,"caipNetwork",void 0);ta=Hh([k("w3m-networks-view")],ta);const l4=be`
  :host > wui-flex {
    height: 500px;
    overflow-y: auto;
    overflow-x: hidden;
    scrollbar-width: none;
    padding: var(--wui-spacing-m);
    box-sizing: border-box;
    display: flex;
    align-items: center;
    justify-content: flex-start;
  }

  :host > wui-flex > wui-flex {
    width: 100%;
  }

  wui-transaction-list-item-loader {
    width: 100%;
  }
`;var ps=function(n,e,t,i){var o=arguments.length,r=o<3?e:i===null?i=Object.getOwnPropertyDescriptor(e,t):i,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")r=Reflect.decorate(n,e,t,i);else for(var a=n.length-1;a>=0;a--)(s=n[a])&&(r=(o<3?s(r):o>3?s(e,t,r):s(e,t))||r);return o>3&&r&&Object.defineProperty(e,t,r),r};const u4=7;let Bi=class extends X{constructor(){super(),this.unsubscribe=[],this.refetchTimeout=void 0,this.selectedOnRampProvider=ve.state.selectedProvider,this.loading=!1,this.coinbaseTransactions=rt.state.coinbaseTransactions,this.tokenImages=He.state.tokenImages,this.unsubscribe.push(ve.subscribeKey("selectedProvider",e=>{this.selectedOnRampProvider=e}),He.subscribeKey("tokenImages",e=>this.tokenImages=e),()=>{clearTimeout(this.refetchTimeout)},rt.subscribe(e=>{this.coinbaseTransactions={...e.coinbaseTransactions}})),this.fetchTransactions()}render(){return A`
      <wui-flex flexDirection="column" padding="s" gap="xs">
        ${this.loading?this.templateLoading():this.templateTransactionsByYear()}
      </wui-flex>
    `}templateTransactions(e){return e==null?void 0:e.map(t=>{var a,c,u;const i=eu.formatDate((a=t==null?void 0:t.metadata)==null?void 0:a.minedAt),o=t.transfers[0],r=o==null?void 0:o.fungible_info;if(!r)return null;const s=((c=r==null?void 0:r.icon)==null?void 0:c.url)||((u=this.tokenImages)==null?void 0:u[r.symbol||""]);return A`
        <wui-onramp-activity-item
          label="Bought"
          .completed=${t.metadata.status==="ONRAMP_TRANSACTION_STATUS_SUCCESS"}
          .inProgress=${t.metadata.status==="ONRAMP_TRANSACTION_STATUS_IN_PROGRESS"}
          .failed=${t.metadata.status==="ONRAMP_TRANSACTION_STATUS_FAILED"}
          purchaseCurrency=${le(r.symbol)}
          purchaseValue=${o.quantity.numeric}
          date=${i}
          icon=${le(s)}
          symbol=${le(r.symbol)}
        ></wui-onramp-activity-item>
      `})}templateTransactionsByYear(){return Object.keys(this.coinbaseTransactions).sort().reverse().map(t=>{const i=parseInt(t,10);return new Array(12).fill(null).map((r,s)=>s).reverse().map(r=>{var c;const s=Ln.getTransactionGroupTitle(i,r),a=(c=this.coinbaseTransactions[i])==null?void 0:c[r];return a?A`
          <wui-flex flexDirection="column">
            <wui-flex
              alignItems="center"
              flexDirection="row"
              .padding=${["xs","s","s","s"]}
            >
              <wui-text variant="paragraph-500" color="fg-200">${s}</wui-text>
            </wui-flex>
            <wui-flex flexDirection="column" gap="xs">
              ${this.templateTransactions(a)}
            </wui-flex>
          </wui-flex>
        `:null})})}async fetchTransactions(){await this.fetchCoinbaseTransactions()}async fetchCoinbaseTransactions(){const e=ne.state.address,t=ce.state.projectId;if(!e)throw new Error("No address found");if(!t)throw new Error("No projectId found");this.loading=!0,await rt.fetchTransactions(e,"coinbase"),this.loading=!1,this.refetchLoadingTransactions()}refetchLoadingTransactions(){var o;const e=new Date;if((((o=this.coinbaseTransactions[e.getFullYear()])==null?void 0:o[e.getMonth()])||[]).filter(r=>r.metadata.status==="ONRAMP_TRANSACTION_STATUS_IN_PROGRESS").length===0){clearTimeout(this.refetchTimeout);return}this.refetchTimeout=setTimeout(async()=>{const r=ne.state.address;await rt.fetchTransactions(r,"coinbase"),this.refetchLoadingTransactions()},3e3)}templateLoading(){return Array(u4).fill(A` <wui-transaction-list-item-loader></wui-transaction-list-item-loader> `).map(e=>e)}};Bi.styles=l4;ps([N()],Bi.prototype,"selectedOnRampProvider",void 0);ps([N()],Bi.prototype,"loading",void 0);ps([N()],Bi.prototype,"coinbaseTransactions",void 0);ps([N()],Bi.prototype,"tokenImages",void 0);Bi=ps([k("w3m-onramp-activity-view")],Bi);const d4=be`
  :host > wui-grid {
    max-height: 360px;
    overflow: auto;
  }

  wui-grid::-webkit-scrollbar {
    display: none;
  }
`;var Za=function(n,e,t,i){var o=arguments.length,r=o<3?e:i===null?i=Object.getOwnPropertyDescriptor(e,t):i,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")r=Reflect.decorate(n,e,t,i);else for(var a=n.length-1;a>=0;a--)(s=n[a])&&(r=(o<3?s(r):o>3?s(e,t,r):s(e,t))||r);return o>3&&r&&Object.defineProperty(e,t,r),r};let kr=class extends X{constructor(){super(),this.unsubscribe=[],this.selectedCurrency=ve.state.paymentCurrency,this.currencies=ve.state.paymentCurrencies,this.currencyImages=He.state.currencyImages,this.unsubscribe.push(ve.subscribe(e=>{this.selectedCurrency=e.paymentCurrency,this.currencies=e.paymentCurrencies}),He.subscribeKey("currencyImages",e=>this.currencyImages=e))}disconnectedCallback(){this.unsubscribe.forEach(e=>e())}render(){return A`
      <wui-flex flexDirection="column" padding="s" gap="xs">
        ${this.currenciesTemplate()}
      </wui-flex>
      <w3m-legal-footer></w3m-legal-footer>
    `}currenciesTemplate(){return this.currencies.map(e=>{var t;return A`
        <wui-list-item
          imageSrc=${le((t=this.currencyImages)==null?void 0:t[e.id])}
          @click=${()=>this.selectCurrency(e)}
          variant="image"
        >
          <wui-text variant="paragraph-500" color="fg-100">${e.id}</wui-text>
        </wui-list-item>
      `})}selectCurrency(e){e&&(ve.setPaymentCurrency(e),he.close())}};kr.styles=d4;Za([N()],kr.prototype,"selectedCurrency",void 0);Za([N()],kr.prototype,"currencies",void 0);Za([N()],kr.prototype,"currencyImages",void 0);kr=Za([k("w3m-onramp-fiat-select-view")],kr);var Vh=function(n,e,t,i){var o=arguments.length,r=o<3?e:i===null?i=Object.getOwnPropertyDescriptor(e,t):i,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")r=Reflect.decorate(n,e,t,i);else for(var a=n.length-1;a>=0;a--)(s=n[a])&&(r=(o<3?s(r):o>3?s(e,t,r):s(e,t))||r);return o>3&&r&&Object.defineProperty(e,t,r),r};let cl=class extends X{constructor(){super(),this.unsubscribe=[],this.providers=ve.state.providers,this.unsubscribe.push(ve.subscribeKey("providers",e=>{this.providers=e}))}firstUpdated(){const e=this.providers.map(async t=>t.name==="coinbase"?await this.getCoinbaseOnRampURL():Promise.resolve(t==null?void 0:t.url));Promise.all(e).then(t=>{this.providers=this.providers.map((i,o)=>({...i,url:t[o]||""}))})}render(){return A`
      <wui-flex flexDirection="column" padding="s" gap="xs">
        ${this.onRampProvidersTemplate()}
      </wui-flex>
      <w3m-onramp-providers-footer></w3m-onramp-providers-footer>
    `}onRampProvidersTemplate(){return this.providers.map(e=>A`
        <wui-onramp-provider-item
          label=${e.label}
          name=${e.name}
          feeRange=${e.feeRange}
          @click=${()=>{this.onClickProvider(e)}}
          ?disabled=${!e.url}
        ></wui-onramp-provider-item>
      `)}onClickProvider(e){ve.setSelectedProvider(e),j.push("BuyInProgress"),F.openHref(e.url,"popupWindow","width=600,height=800,scrollbars=yes")}async getCoinbaseOnRampURL(){const e=ne.state.address,t=ge.state.caipNetwork;if(!e)throw new Error("No address found");if(!(t!=null&&t.name))throw new Error("No network found");const i=pt.WC_COINBASE_PAY_SDK_CHAIN_NAME_MAP[t.name]??pt.WC_COINBASE_PAY_SDK_FALLBACK_CHAIN,o=ve.state.purchaseCurrency,r=o?[o.symbol]:ve.state.purchaseCurrencies.map(s=>s.symbol);return await mr.generateOnRampURL({defaultNetwork:i,destinationWallets:[{address:e,blockchains:pt.WC_COINBASE_PAY_SDK_CHAINS,assets:r}],partnerUserId:e,purchaseAmount:ve.state.purchaseAmount})}};Vh([N()],cl.prototype,"providers",void 0);cl=Vh([k("w3m-onramp-providers-view")],cl);const h4=be`
  :host > wui-grid {
    max-height: 360px;
    overflow: auto;
  }

  wui-grid::-webkit-scrollbar {
    display: none;
  }
`;var qa=function(n,e,t,i){var o=arguments.length,r=o<3?e:i===null?i=Object.getOwnPropertyDescriptor(e,t):i,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")r=Reflect.decorate(n,e,t,i);else for(var a=n.length-1;a>=0;a--)(s=n[a])&&(r=(o<3?s(r):o>3?s(e,t,r):s(e,t))||r);return o>3&&r&&Object.defineProperty(e,t,r),r};let Nr=class extends X{constructor(){super(),this.unsubscribe=[],this.selectedCurrency=ve.state.purchaseCurrencies,this.tokens=ve.state.purchaseCurrencies,this.tokenImages=He.state.tokenImages,this.unsubscribe.push(ve.subscribe(e=>{this.selectedCurrency=e.purchaseCurrencies,this.tokens=e.purchaseCurrencies}),He.subscribeKey("tokenImages",e=>this.tokenImages=e))}disconnectedCallback(){this.unsubscribe.forEach(e=>e())}render(){return A`
      <wui-flex flexDirection="column" padding="s" gap="xs">
        ${this.currenciesTemplate()}
      </wui-flex>
      <w3m-legal-footer></w3m-legal-footer>
    `}currenciesTemplate(){return this.tokens.map(e=>{var t;return A`
        <wui-list-item
          imageSrc=${le((t=this.tokenImages)==null?void 0:t[e.symbol])}
          @click=${()=>this.selectToken(e)}
          variant="image"
        >
          <wui-flex gap="3xs" alignItems="center">
            <wui-text variant="paragraph-500" color="fg-100">${e.name}</wui-text>
            <wui-text variant="small-400" color="fg-200">${e.symbol}</wui-text>
          </wui-flex>
        </wui-list-item>
      `})}selectToken(e){e&&(ve.setPurchaseCurrency(e),he.close())}};Nr.styles=h4;qa([N()],Nr.prototype,"selectedCurrency",void 0);qa([N()],Nr.prototype,"tokens",void 0);qa([N()],Nr.prototype,"tokenImages",void 0);Nr=qa([k("w3m-onramp-token-select-view")],Nr);const p4=be`
  :host > wui-flex:first-child {
    height: 500px;
    overflow-y: auto;
    overflow-x: hidden;
    scrollbar-width: none;
    padding: var(--wui-spacing-m);
  }

  :host > wui-flex:first-child::-webkit-scrollbar {
    display: none;
  }
`;var Vr=function(n,e,t,i){var o=arguments.length,r=o<3?e:i===null?i=Object.getOwnPropertyDescriptor(e,t):i,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")r=Reflect.decorate(n,e,t,i);else for(var a=n.length-1;a>=0;a--)(s=n[a])&&(r=(o<3?s(r):o>3?s(e,t,r):s(e,t))||r);return o>3&&r&&Object.defineProperty(e,t,r),r};const $s="last-transaction",f4=7;let qn=class extends X{constructor(){super(),this.unsubscribe=[],this.paginationObserver=void 0,this.address=ne.state.address,this.transactionsByYear=rt.state.transactionsByYear,this.loading=rt.state.loading,this.empty=rt.state.empty,this.next=rt.state.next,this.unsubscribe.push(ne.subscribe(e=>{e.isConnected&&this.address!==e.address&&(this.address=e.address,rt.resetTransactions(),rt.fetchTransactions(e.address))}),rt.subscribe(e=>{this.transactionsByYear=e.transactionsByYear,this.loading=e.loading,this.empty=e.empty,this.next=e.next}))}firstUpdated(){rt.fetchTransactions(this.address),this.createPaginationObserver()}updated(){this.setPaginationObserver()}disconnectedCallback(){this.unsubscribe.forEach(e=>e())}render(){return A`
      <wui-flex flexDirection="column" gap="s">
        ${this.empty?null:this.templateTransactionsByYear()}
        ${this.loading?this.templateLoading():null}
        ${!this.loading&&this.empty?this.templateEmpty():null}
      </wui-flex>
    `}templateTransactionsByYear(){const e=Object.keys(this.transactionsByYear).sort().reverse();return e.map((t,i)=>{const o=i===e.length-1,r=parseInt(t,10);return new Array(12).fill(null).map((a,c)=>c).reverse().map(a=>{var h;const c=Ln.getTransactionGroupTitle(r,a),u=(h=this.transactionsByYear[r])==null?void 0:h[a];return u?A`
          <wui-flex flexDirection="column">
            <wui-flex
              alignItems="center"
              flexDirection="row"
              .padding=${["xs","s","s","s"]}
            >
              <wui-text variant="paragraph-500" color="fg-200">${c}</wui-text>
            </wui-flex>
            <wui-flex flexDirection="column" gap="xs">
              ${this.templateTransactions(u,o)}
            </wui-flex>
          </wui-flex>
        `:null})})}templateRenderTransaction(e,t){const{date:i,descriptions:o,direction:r,isAllNFT:s,images:a,status:c,transfers:u,type:h}=this.getTransactionListItemProps(e),p=(u==null?void 0:u.length)>1;return(u==null?void 0:u.length)===2&&!s?A`
        <wui-transaction-list-item
          date=${i}
          .direction=${r}
          id=${t&&this.next?$s:""}
          status=${c}
          type=${h}
          .images=${a}
          .descriptions=${o}
        ></wui-transaction-list-item>
      `:p?u.map((b,_)=>{const x=Ln.getTransferDescription(b),C=t&&_===u.length-1;return A` <wui-transaction-list-item
          date=${i}
          direction=${b.direction}
          id=${C&&this.next?$s:""}
          status=${c}
          type=${h}
          .onlyDirectionIcon=${!0}
          .images=${[a[_]]}
          .descriptions=${[x]}
        ></wui-transaction-list-item>`}):A`
      <wui-transaction-list-item
        date=${i}
        .direction=${r}
        id=${t&&this.next?$s:""}
        status=${c}
        type=${h}
        .images=${a}
        .descriptions=${o}
      ></wui-transaction-list-item>
    `}templateTransactions(e,t){return e.map((i,o)=>{const r=t&&o===e.length-1;return A`${this.templateRenderTransaction(i,r)}`})}templateEmpty(){return A`
      <wui-flex
        flexGrow="1"
        flexDirection="column"
        justifyContent="center"
        alignItems="center"
        .padding=${["3xl","xl","3xl","xl"]}
        gap="xl"
      >
        <wui-icon-box
          backgroundColor="glass-005"
          background="gray"
          iconColor="fg-200"
          icon="wallet"
          size="lg"
          ?border=${!0}
          borderColor="wui-color-bg-125"
        ></wui-icon-box>
        <wui-flex flexDirection="column" alignItems="center" gap="xs">
          <wui-text align="center" variant="paragraph-500" color="fg-100"
            >No Transactions yet</wui-text
          >
          <wui-text align="center" variant="small-500" color="fg-200"
            >Start trading on dApps <br />
            to grow your wallet!</wui-text
          >
        </wui-flex>
      </wui-flex>
    `}templateLoading(){return Array(f4).fill(A` <wui-transaction-list-item-loader></wui-transaction-list-item-loader> `).map(e=>e)}createPaginationObserver(){const{projectId:e}=ce.state;this.paginationObserver=new IntersectionObserver(([t])=>{t!=null&&t.isIntersecting&&!this.loading&&(rt.fetchTransactions(this.address),Y.sendEvent({type:"track",event:"LOAD_MORE_TRANSACTIONS",properties:{address:this.address,projectId:e,cursor:this.next}}))},{}),this.setPaginationObserver()}setPaginationObserver(){var t,i,o;(t=this.paginationObserver)==null||t.disconnect();const e=(i=this.shadowRoot)==null?void 0:i.querySelector(`#${$s}`);e&&((o=this.paginationObserver)==null||o.observe(e))}getTransactionListItemProps(e){var c,u,h,p,g;const t=eu.formatDate((c=e==null?void 0:e.metadata)==null?void 0:c.minedAt),i=Ln.getTransactionDescriptions(e),o=e==null?void 0:e.transfers,r=(u=e==null?void 0:e.transfers)==null?void 0:u[0],s=!!r&&((h=e==null?void 0:e.transfers)==null?void 0:h.every(b=>!!b.nft_info)),a=Ln.getTransactionImages(o);return{date:t,direction:r==null?void 0:r.direction,descriptions:i,isAllNFT:s,images:a,status:(p=e.metadata)==null?void 0:p.status,transfers:o,type:(g=e.metadata)==null?void 0:g.operationType}}};qn.styles=p4;Vr([N()],qn.prototype,"address",void 0);Vr([N()],qn.prototype,"transactionsByYear",void 0);Vr([N()],qn.prototype,"loading",void 0);Vr([N()],qn.prototype,"empty",void 0);Vr([N()],qn.prototype,"next",void 0);qn=Vr([k("w3m-transactions-view")],qn);var g4=function(n,e,t,i){var o=arguments.length,r=o<3?e:i===null?i=Object.getOwnPropertyDescriptor(e,t):i,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")r=Reflect.decorate(n,e,t,i);else for(var a=n.length-1;a>=0;a--)(s=n[a])&&(r=(o<3?s(r):o>3?s(e,t,r):s(e,t))||r);return o>3&&r&&Object.defineProperty(e,t,r),r};const m4=[{images:["network","layers","system"],title:"The system’s nuts and bolts",text:"A network is what brings the blockchain to life, as this technical infrastructure allows apps to access the ledger and smart contract services."},{images:["noun","defiAlt","dao"],title:"Designed for different uses",text:"Each network is designed differently, and may therefore suit certain apps and experiences."}];let Rd=class extends X{render(){return A`
      <wui-flex
        flexDirection="column"
        .padding=${["xxl","xl","xl","xl"]}
        alignItems="center"
        gap="xl"
      >
        <w3m-help-widget .data=${m4}></w3m-help-widget>
        <wui-button
          variant="fill"
          size="sm"
          @click=${()=>{F.openHref("https://ethereum.org/en/developers/docs/networks/","_blank")}}
        >
          Learn more
          <wui-icon color="inherit" slot="iconRight" name="externalLink"></wui-icon>
        </wui-button>
      </wui-flex>
    `}};Rd=g4([k("w3m-what-is-a-network-view")],Rd);var w4=function(n,e,t,i){var o=arguments.length,r=o<3?e:i===null?i=Object.getOwnPropertyDescriptor(e,t):i,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")r=Reflect.decorate(n,e,t,i);else for(var a=n.length-1;a>=0;a--)(s=n[a])&&(r=(o<3?s(r):o>3?s(e,t,r):s(e,t))||r);return o>3&&r&&Object.defineProperty(e,t,r),r};const b4=[{images:["login","profile","lock"],title:"One login for all of web3",text:"Log in to any app by connecting your wallet. Say goodbye to countless passwords!"},{images:["defi","nft","eth"],title:"A home for your digital assets",text:"A wallet lets you store, send and receive digital assets like cryptocurrencies and NFTs."},{images:["browser","noun","dao"],title:"Your gateway to a new web",text:"With your wallet, you can explore and interact with DeFi, NFTs, DAOs, and much more."}];let Td=class extends X{render(){return A`
      <wui-flex
        flexDirection="column"
        .padding=${["xxl","xl","xl","xl"]}
        alignItems="center"
        gap="xl"
      >
        <w3m-help-widget .data=${b4}></w3m-help-widget>
        <wui-button variant="fill" size="sm" @click=${this.onGetWallet.bind(this)}>
          <wui-icon color="inherit" slot="iconLeft" name="wallet"></wui-icon>
          Get a wallet
        </wui-button>
      </wui-flex>
    `}onGetWallet(){Y.sendEvent({type:"track",event:"CLICK_GET_WALLET"}),j.push("GetWallet")}};Td=w4([k("w3m-what-is-a-wallet-view")],Td);var v4=function(n,e,t,i){var o=arguments.length,r=o<3?e:i===null?i=Object.getOwnPropertyDescriptor(e,t):i,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")r=Reflect.decorate(n,e,t,i);else for(var a=n.length-1;a>=0;a--)(s=n[a])&&(r=(o<3?s(r):o>3?s(e,t,r):s(e,t))||r);return o>3&&r&&Object.defineProperty(e,t,r),r};let Pd=class extends X{render(){return A`
      <wui-flex
        flexDirection="column"
        .padding=${["xxl","3xl","xl","3xl"]}
        alignItems="center"
        gap="xl"
      >
        <wui-visual name="onrampCard"></wui-visual>
        <wui-flex flexDirection="column" gap="xs" alignItems="center">
          <wui-text align="center" variant="paragraph-500" color="fg-100">
            Quickly and easily buy digital assets!
          </wui-text>
          <wui-text align="center" variant="small-400" color="fg-200">
            Simply select your preferred onramp provider and add digital assets to your account
            using your credit card or bank transfer
          </wui-text>
        </wui-flex>
        <wui-button @click=${j.goBack}>
          <wui-icon size="sm" color="inherit" name="add" slot="iconLeft"></wui-icon>
          Buy
        </wui-button>
      </wui-flex>
    `}};Pd=v4([k("w3m-what-is-a-buy-view")],Pd);const y4=be`
  wui-loading-spinner {
    margin: 9px auto;
  }
`,W={SECURE_SITE_SDK:"https://secure.walletconnect.com/sdk",APP_EVENT_KEY:"@w3m-app/",FRAME_EVENT_KEY:"@w3m-frame/",RPC_METHOD_KEY:"RPC_",STORAGE_KEY:"@w3m-storage/",SESSION_TOKEN_KEY:"SESSION_TOKEN_KEY",EMAIL_LOGIN_USED_KEY:"EMAIL_LOGIN_USED_KEY",LAST_USED_CHAIN_KEY:"LAST_USED_CHAIN_KEY",LAST_EMAIL_LOGIN_TIME:"LAST_EMAIL_LOGIN_TIME",EMAIL:"EMAIL",APP_SWITCH_NETWORK:"@w3m-app/SWITCH_NETWORK",APP_CONNECT_EMAIL:"@w3m-app/CONNECT_EMAIL",APP_CONNECT_DEVICE:"@w3m-app/CONNECT_DEVICE",APP_CONNECT_OTP:"@w3m-app/CONNECT_OTP",APP_GET_USER:"@w3m-app/GET_USER",APP_SIGN_OUT:"@w3m-app/SIGN_OUT",APP_IS_CONNECTED:"@w3m-app/IS_CONNECTED",APP_GET_CHAIN_ID:"@w3m-app/GET_CHAIN_ID",APP_RPC_REQUEST:"@w3m-app/RPC_REQUEST",APP_UPDATE_EMAIL:"@w3m-app/UPDATE_EMAIL",APP_UPDATE_EMAIL_PRIMARY_OTP:"@w3m-app/UPDATE_EMAIL_PRIMARY_OTP",APP_UPDATE_EMAIL_SECONDARY_OTP:"@w3m-app/UPDATE_EMAIL_SECONDARY_OTP",APP_AWAIT_UPDATE_EMAIL:"@w3m-app/AWAIT_UPDATE_EMAIL",APP_SYNC_THEME:"@w3m-app/SYNC_THEME",APP_SYNC_DAPP_DATA:"@w3m-app/SYNC_DAPP_DATA",FRAME_SWITCH_NETWORK_ERROR:"@w3m-frame/SWITCH_NETWORK_ERROR",FRAME_SWITCH_NETWORK_SUCCESS:"@w3m-frame/SWITCH_NETWORK_SUCCESS",FRAME_CONNECT_EMAIL_ERROR:"@w3m-frame/CONNECT_EMAIL_ERROR",FRAME_CONNECT_EMAIL_SUCCESS:"@w3m-frame/CONNECT_EMAIL_SUCCESS",FRAME_CONNECT_DEVICE_ERROR:"@w3m-frame/CONNECT_DEVICE_ERROR",FRAME_CONNECT_DEVICE_SUCCESS:"@w3m-frame/CONNECT_DEVICE_SUCCESS",FRAME_CONNECT_OTP_SUCCESS:"@w3m-frame/CONNECT_OTP_SUCCESS",FRAME_CONNECT_OTP_ERROR:"@w3m-frame/CONNECT_OTP_ERROR",FRAME_GET_USER_SUCCESS:"@w3m-frame/GET_USER_SUCCESS",FRAME_GET_USER_ERROR:"@w3m-frame/GET_USER_ERROR",FRAME_SIGN_OUT_SUCCESS:"@w3m-frame/SIGN_OUT_SUCCESS",FRAME_SIGN_OUT_ERROR:"@w3m-frame/SIGN_OUT_ERROR",FRAME_IS_CONNECTED_SUCCESS:"@w3m-frame/IS_CONNECTED_SUCCESS",FRAME_IS_CONNECTED_ERROR:"@w3m-frame/IS_CONNECTED_ERROR",FRAME_GET_CHAIN_ID_SUCCESS:"@w3m-frame/GET_CHAIN_ID_SUCCESS",FRAME_GET_CHAIN_ID_ERROR:"@w3m-frame/GET_CHAIN_ID_ERROR",FRAME_RPC_REQUEST_SUCCESS:"@w3m-frame/RPC_REQUEST_SUCCESS",FRAME_RPC_REQUEST_ERROR:"@w3m-frame/RPC_REQUEST_ERROR",FRAME_SESSION_UPDATE:"@w3m-frame/SESSION_UPDATE",FRAME_UPDATE_EMAIL_SUCCESS:"@w3m-frame/UPDATE_EMAIL_SUCCESS",FRAME_UPDATE_EMAIL_ERROR:"@w3m-frame/UPDATE_EMAIL_ERROR",FRAME_UPDATE_EMAIL_PRIMARY_OTP_SUCCESS:"@w3m-frame/UPDATE_EMAIL_PRIMARY_OTP_SUCCESS",FRAME_UPDATE_EMAIL_PRIMARY_OTP_ERROR:"@w3m-frame/UPDATE_EMAIL_PRIMARY_OTP_ERROR",FRAME_UPDATE_EMAIL_SECONDARY_OTP_SUCCESS:"@w3m-frame/UPDATE_EMAIL_SECONDARY_OTP_SUCCESS",FRAME_UPDATE_EMAIL_SECONDARY_OTP_ERROR:"@w3m-frame/UPDATE_EMAIL_SECONDARY_OTP_ERROR",FRAME_SYNC_THEME_SUCCESS:"@w3m-frame/SYNC_THEME_SUCCESS",FRAME_SYNC_THEME_ERROR:"@w3m-frame/SYNC_THEME_ERROR",FRAME_SYNC_DAPP_DATA_SUCCESS:"@w3m-frame/SYNC_DAPP_DATA_SUCCESS",FRAME_SYNC_DAPP_DATA_ERROR:"@w3m-frame/SYNC_DAPP_DATA_ERROR"},Os={SAFE_RPC_METHODS:["eth_accounts","eth_blockNumber","eth_call","eth_chainId","eth_estimateGas","eth_feeHistory","eth_gasPrice","eth_getAccount","eth_getBalance","eth_getBlockByHash","eth_getBlockByNumber","eth_getBlockReceipts","eth_getBlockTransactionCountByHash","eth_getBlockTransactionCountByNumber","eth_getCode","eth_getFilterChanges","eth_getFilterLogs","eth_getLogs","eth_getProof","eth_getStorageAt","eth_getTransactionByBlockHashAndIndex","eth_getTransactionByBlockNumberAndIndex","eth_getTransactionByHash","eth_getTransactionCount","eth_getTransactionReceipt","eth_getUncleCountByBlockHash","eth_getUncleCountByBlockNumber","eth_maxPriorityFeePerGas","eth_newBlockFilter","eth_newFilter","eth_newPendingTransactionFilter","eth_sendRawTransaction","eth_syncing","eth_uninstallFilter"],NOT_SAFE_RPC_METHODS:["personal_sign","eth_signTypedData_v4","eth_sendTransaction"],GET_CHAIN_ID:"eth_chainId"};var we;(function(n){n.assertEqual=o=>o;function e(o){}n.assertIs=e;function t(o){throw new Error}n.assertNever=t,n.arrayToEnum=o=>{const r={};for(const s of o)r[s]=s;return r},n.getValidEnumValues=o=>{const r=n.objectKeys(o).filter(a=>typeof o[o[a]]!="number"),s={};for(const a of r)s[a]=o[a];return n.objectValues(s)},n.objectValues=o=>n.objectKeys(o).map(function(r){return o[r]}),n.objectKeys=typeof Object.keys=="function"?o=>Object.keys(o):o=>{const r=[];for(const s in o)Object.prototype.hasOwnProperty.call(o,s)&&r.push(s);return r},n.find=(o,r)=>{for(const s of o)if(r(s))return s},n.isInteger=typeof Number.isInteger=="function"?o=>Number.isInteger(o):o=>typeof o=="number"&&isFinite(o)&&Math.floor(o)===o;function i(o,r=" | "){return o.map(s=>typeof s=="string"?`'${s}'`:s).join(r)}n.joinValues=i,n.jsonStringifyReplacer=(o,r)=>typeof r=="bigint"?r.toString():r})(we||(we={}));var ll;(function(n){n.mergeShapes=(e,t)=>({...e,...t})})(ll||(ll={}));const U=we.arrayToEnum(["string","nan","number","integer","float","boolean","date","bigint","symbol","function","undefined","null","array","object","unknown","promise","void","never","map","set"]),Nn=n=>{switch(typeof n){case"undefined":return U.undefined;case"string":return U.string;case"number":return isNaN(n)?U.nan:U.number;case"boolean":return U.boolean;case"function":return U.function;case"bigint":return U.bigint;case"symbol":return U.symbol;case"object":return Array.isArray(n)?U.array:n===null?U.null:n.then&&typeof n.then=="function"&&n.catch&&typeof n.catch=="function"?U.promise:typeof Map<"u"&&n instanceof Map?U.map:typeof Set<"u"&&n instanceof Set?U.set:typeof Date<"u"&&n instanceof Date?U.date:U.object;default:return U.unknown}},L=we.arrayToEnum(["invalid_type","invalid_literal","custom","invalid_union","invalid_union_discriminator","invalid_enum_value","unrecognized_keys","invalid_arguments","invalid_return_type","invalid_date","invalid_string","too_small","too_big","invalid_intersection_types","not_multiple_of","not_finite"]),x4=n=>JSON.stringify(n,null,2).replace(/"([^"]+)":/g,"$1:");class Nt extends Error{constructor(e){super(),this.issues=[],this.addIssue=i=>{this.issues=[...this.issues,i]},this.addIssues=(i=[])=>{this.issues=[...this.issues,...i]};const t=new.target.prototype;Object.setPrototypeOf?Object.setPrototypeOf(this,t):this.__proto__=t,this.name="ZodError",this.issues=e}get errors(){return this.issues}format(e){const t=e||function(r){return r.message},i={_errors:[]},o=r=>{for(const s of r.issues)if(s.code==="invalid_union")s.unionErrors.map(o);else if(s.code==="invalid_return_type")o(s.returnTypeError);else if(s.code==="invalid_arguments")o(s.argumentsError);else if(s.path.length===0)i._errors.push(t(s));else{let a=i,c=0;for(;c<s.path.length;){const u=s.path[c];c===s.path.length-1?(a[u]=a[u]||{_errors:[]},a[u]._errors.push(t(s))):a[u]=a[u]||{_errors:[]},a=a[u],c++}}};return o(this),i}toString(){return this.message}get message(){return JSON.stringify(this.issues,we.jsonStringifyReplacer,2)}get isEmpty(){return this.issues.length===0}flatten(e=t=>t.message){const t={},i=[];for(const o of this.issues)o.path.length>0?(t[o.path[0]]=t[o.path[0]]||[],t[o.path[0]].push(e(o))):i.push(e(o));return{formErrors:i,fieldErrors:t}}get formErrors(){return this.flatten()}}Nt.create=n=>new Nt(n);const Vo=(n,e)=>{let t;switch(n.code){case L.invalid_type:n.received===U.undefined?t="Required":t=`Expected ${n.expected}, received ${n.received}`;break;case L.invalid_literal:t=`Invalid literal value, expected ${JSON.stringify(n.expected,we.jsonStringifyReplacer)}`;break;case L.unrecognized_keys:t=`Unrecognized key(s) in object: ${we.joinValues(n.keys,", ")}`;break;case L.invalid_union:t="Invalid input";break;case L.invalid_union_discriminator:t=`Invalid discriminator value. Expected ${we.joinValues(n.options)}`;break;case L.invalid_enum_value:t=`Invalid enum value. Expected ${we.joinValues(n.options)}, received '${n.received}'`;break;case L.invalid_arguments:t="Invalid function arguments";break;case L.invalid_return_type:t="Invalid function return type";break;case L.invalid_date:t="Invalid date";break;case L.invalid_string:typeof n.validation=="object"?"includes"in n.validation?(t=`Invalid input: must include "${n.validation.includes}"`,typeof n.validation.position=="number"&&(t=`${t} at one or more positions greater than or equal to ${n.validation.position}`)):"startsWith"in n.validation?t=`Invalid input: must start with "${n.validation.startsWith}"`:"endsWith"in n.validation?t=`Invalid input: must end with "${n.validation.endsWith}"`:we.assertNever(n.validation):n.validation!=="regex"?t=`Invalid ${n.validation}`:t="Invalid";break;case L.too_small:n.type==="array"?t=`Array must contain ${n.exact?"exactly":n.inclusive?"at least":"more than"} ${n.minimum} element(s)`:n.type==="string"?t=`String must contain ${n.exact?"exactly":n.inclusive?"at least":"over"} ${n.minimum} character(s)`:n.type==="number"?t=`Number must be ${n.exact?"exactly equal to ":n.inclusive?"greater than or equal to ":"greater than "}${n.minimum}`:n.type==="date"?t=`Date must be ${n.exact?"exactly equal to ":n.inclusive?"greater than or equal to ":"greater than "}${new Date(Number(n.minimum))}`:t="Invalid input";break;case L.too_big:n.type==="array"?t=`Array must contain ${n.exact?"exactly":n.inclusive?"at most":"less than"} ${n.maximum} element(s)`:n.type==="string"?t=`String must contain ${n.exact?"exactly":n.inclusive?"at most":"under"} ${n.maximum} character(s)`:n.type==="number"?t=`Number must be ${n.exact?"exactly":n.inclusive?"less than or equal to":"less than"} ${n.maximum}`:n.type==="bigint"?t=`BigInt must be ${n.exact?"exactly":n.inclusive?"less than or equal to":"less than"} ${n.maximum}`:n.type==="date"?t=`Date must be ${n.exact?"exactly":n.inclusive?"smaller than or equal to":"smaller than"} ${new Date(Number(n.maximum))}`:t="Invalid input";break;case L.custom:t="Invalid input";break;case L.invalid_intersection_types:t="Intersection results could not be merged";break;case L.not_multiple_of:t=`Number must be a multiple of ${n.multipleOf}`;break;case L.not_finite:t="Number must be finite";break;default:t=e.defaultError,we.assertNever(n)}return{message:t}};let Zh=Vo;function C4(n){Zh=n}function na(){return Zh}const ia=n=>{const{data:e,path:t,errorMaps:i,issueData:o}=n,r=[...t,...o.path||[]],s={...o,path:r};let a="";const c=i.filter(u=>!!u).slice().reverse();for(const u of c)a=u(s,{data:e,defaultError:a}).message;return{...o,path:r,message:o.message||a}},_4=[];function z(n,e){const t=ia({issueData:e,data:n.data,path:n.path,errorMaps:[n.common.contextualErrorMap,n.schemaErrorMap,na(),Vo].filter(i=>!!i)});n.common.issues.push(t)}class Ye{constructor(){this.value="valid"}dirty(){this.value==="valid"&&(this.value="dirty")}abort(){this.value!=="aborted"&&(this.value="aborted")}static mergeArray(e,t){const i=[];for(const o of t){if(o.status==="aborted")return oe;o.status==="dirty"&&e.dirty(),i.push(o.value)}return{status:e.value,value:i}}static async mergeObjectAsync(e,t){const i=[];for(const o of t)i.push({key:await o.key,value:await o.value});return Ye.mergeObjectSync(e,i)}static mergeObjectSync(e,t){const i={};for(const o of t){const{key:r,value:s}=o;if(r.status==="aborted"||s.status==="aborted")return oe;r.status==="dirty"&&e.dirty(),s.status==="dirty"&&e.dirty(),r.value!=="__proto__"&&(typeof s.value<"u"||o.alwaysSet)&&(i[r.value]=s.value)}return{status:e.value,value:i}}}const oe=Object.freeze({status:"aborted"}),qh=n=>({status:"dirty",value:n}),tt=n=>({status:"valid",value:n}),ul=n=>n.status==="aborted",dl=n=>n.status==="dirty",Zo=n=>n.status==="valid",ra=n=>typeof Promise<"u"&&n instanceof Promise;var J;(function(n){n.errToObj=e=>typeof e=="string"?{message:e}:e||{},n.toString=e=>typeof e=="string"?e:e==null?void 0:e.message})(J||(J={}));class ln{constructor(e,t,i,o){this._cachedPath=[],this.parent=e,this.data=t,this._path=i,this._key=o}get path(){return this._cachedPath.length||(this._key instanceof Array?this._cachedPath.push(...this._path,...this._key):this._cachedPath.push(...this._path,this._key)),this._cachedPath}}const Od=(n,e)=>{if(Zo(e))return{success:!0,data:e.value};if(!n.common.issues.length)throw new Error("Validation failed but no issues detected.");return{success:!1,get error(){if(this._error)return this._error;const t=new Nt(n.common.issues);return this._error=t,this._error}}};function ue(n){if(!n)return{};const{errorMap:e,invalid_type_error:t,required_error:i,description:o}=n;if(e&&(t||i))throw new Error(`Can't use "invalid_type_error" or "required_error" in conjunction with custom error map.`);return e?{errorMap:e,description:o}:{errorMap:(s,a)=>s.code!=="invalid_type"?{message:a.defaultError}:typeof a.data>"u"?{message:i??a.defaultError}:{message:t??a.defaultError},description:o}}class de{constructor(e){this.spa=this.safeParseAsync,this._def=e,this.parse=this.parse.bind(this),this.safeParse=this.safeParse.bind(this),this.parseAsync=this.parseAsync.bind(this),this.safeParseAsync=this.safeParseAsync.bind(this),this.spa=this.spa.bind(this),this.refine=this.refine.bind(this),this.refinement=this.refinement.bind(this),this.superRefine=this.superRefine.bind(this),this.optional=this.optional.bind(this),this.nullable=this.nullable.bind(this),this.nullish=this.nullish.bind(this),this.array=this.array.bind(this),this.promise=this.promise.bind(this),this.or=this.or.bind(this),this.and=this.and.bind(this),this.transform=this.transform.bind(this),this.brand=this.brand.bind(this),this.default=this.default.bind(this),this.catch=this.catch.bind(this),this.describe=this.describe.bind(this),this.pipe=this.pipe.bind(this),this.readonly=this.readonly.bind(this),this.isNullable=this.isNullable.bind(this),this.isOptional=this.isOptional.bind(this)}get description(){return this._def.description}_getType(e){return Nn(e.data)}_getOrReturnCtx(e,t){return t||{common:e.parent.common,data:e.data,parsedType:Nn(e.data),schemaErrorMap:this._def.errorMap,path:e.path,parent:e.parent}}_processInputParams(e){return{status:new Ye,ctx:{common:e.parent.common,data:e.data,parsedType:Nn(e.data),schemaErrorMap:this._def.errorMap,path:e.path,parent:e.parent}}}_parseSync(e){const t=this._parse(e);if(ra(t))throw new Error("Synchronous parse encountered promise.");return t}_parseAsync(e){const t=this._parse(e);return Promise.resolve(t)}parse(e,t){const i=this.safeParse(e,t);if(i.success)return i.data;throw i.error}safeParse(e,t){var i;const o={common:{issues:[],async:(i=t==null?void 0:t.async)!==null&&i!==void 0?i:!1,contextualErrorMap:t==null?void 0:t.errorMap},path:(t==null?void 0:t.path)||[],schemaErrorMap:this._def.errorMap,parent:null,data:e,parsedType:Nn(e)},r=this._parseSync({data:e,path:o.path,parent:o});return Od(o,r)}async parseAsync(e,t){const i=await this.safeParseAsync(e,t);if(i.success)return i.data;throw i.error}async safeParseAsync(e,t){const i={common:{issues:[],contextualErrorMap:t==null?void 0:t.errorMap,async:!0},path:(t==null?void 0:t.path)||[],schemaErrorMap:this._def.errorMap,parent:null,data:e,parsedType:Nn(e)},o=this._parse({data:e,path:i.path,parent:i}),r=await(ra(o)?o:Promise.resolve(o));return Od(i,r)}refine(e,t){const i=o=>typeof t=="string"||typeof t>"u"?{message:t}:typeof t=="function"?t(o):t;return this._refinement((o,r)=>{const s=e(o),a=()=>r.addIssue({code:L.custom,...i(o)});return typeof Promise<"u"&&s instanceof Promise?s.then(c=>c?!0:(a(),!1)):s?!0:(a(),!1)})}refinement(e,t){return this._refinement((i,o)=>e(i)?!0:(o.addIssue(typeof t=="function"?t(i,o):t),!1))}_refinement(e){return new Wt({schema:this,typeName:te.ZodEffects,effect:{type:"refinement",refinement:e}})}superRefine(e){return this._refinement(e)}optional(){return xn.create(this,this._def)}nullable(){return Ui.create(this,this._def)}nullish(){return this.nullable().optional()}array(){return Mt.create(this,this._def)}promise(){return Lr.create(this,this._def)}or(e){return Ko.create([this,e],this._def)}and(e){return Jo.create(this,e,this._def)}transform(e){return new Wt({...ue(this._def),schema:this,typeName:te.ZodEffects,effect:{type:"transform",transform:e}})}default(e){const t=typeof e=="function"?e:()=>e;return new ns({...ue(this._def),innerType:this,defaultValue:t,typeName:te.ZodDefault})}brand(){return new Yh({typeName:te.ZodBranded,type:this,...ue(this._def)})}catch(e){const t=typeof e=="function"?e:()=>e;return new ca({...ue(this._def),innerType:this,catchValue:t,typeName:te.ZodCatch})}describe(e){const t=this.constructor;return new t({...this._def,description:e})}pipe(e){return fs.create(this,e)}readonly(){return ua.create(this)}isOptional(){return this.safeParse(void 0).success}isNullable(){return this.safeParse(null).success}}const E4=/^c[^\s-]{8,}$/i,$4=/^[a-z][a-z0-9]*$/,A4=/^[0-9A-HJKMNP-TV-Z]{26}$/,S4=/^[0-9a-fA-F]{8}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{12}$/i,I4=/^(?!\.)(?!.*\.\.)([A-Z0-9_+-\.]*)[A-Z0-9_+-]@([A-Z0-9][A-Z0-9\-]*\.)+[A-Z]{2,}$/i,R4="^(\\p{Extended_Pictographic}|\\p{Emoji_Component})+$";let Ic;const T4=/^(((25[0-5])|(2[0-4][0-9])|(1[0-9]{2})|([0-9]{1,2}))\.){3}((25[0-5])|(2[0-4][0-9])|(1[0-9]{2})|([0-9]{1,2}))$/,P4=/^(([a-f0-9]{1,4}:){7}|::([a-f0-9]{1,4}:){0,6}|([a-f0-9]{1,4}:){1}:([a-f0-9]{1,4}:){0,5}|([a-f0-9]{1,4}:){2}:([a-f0-9]{1,4}:){0,4}|([a-f0-9]{1,4}:){3}:([a-f0-9]{1,4}:){0,3}|([a-f0-9]{1,4}:){4}:([a-f0-9]{1,4}:){0,2}|([a-f0-9]{1,4}:){5}:([a-f0-9]{1,4}:){0,1})([a-f0-9]{1,4}|(((25[0-5])|(2[0-4][0-9])|(1[0-9]{2})|([0-9]{1,2}))\.){3}((25[0-5])|(2[0-4][0-9])|(1[0-9]{2})|([0-9]{1,2})))$/,O4=n=>n.precision?n.offset?new RegExp(`^\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}:\\d{2}\\.\\d{${n.precision}}(([+-]\\d{2}(:?\\d{2})?)|Z)$`):new RegExp(`^\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}:\\d{2}\\.\\d{${n.precision}}Z$`):n.precision===0?n.offset?new RegExp("^\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}:\\d{2}(([+-]\\d{2}(:?\\d{2})?)|Z)$"):new RegExp("^\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}:\\d{2}Z$"):n.offset?new RegExp("^\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}:\\d{2}(\\.\\d+)?(([+-]\\d{2}(:?\\d{2})?)|Z)$"):new RegExp("^\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}:\\d{2}(\\.\\d+)?Z$");function k4(n,e){return!!((e==="v4"||!e)&&T4.test(n)||(e==="v6"||!e)&&P4.test(n))}class kt extends de{_parse(e){if(this._def.coerce&&(e.data=String(e.data)),this._getType(e)!==U.string){const r=this._getOrReturnCtx(e);return z(r,{code:L.invalid_type,expected:U.string,received:r.parsedType}),oe}const i=new Ye;let o;for(const r of this._def.checks)if(r.kind==="min")e.data.length<r.value&&(o=this._getOrReturnCtx(e,o),z(o,{code:L.too_small,minimum:r.value,type:"string",inclusive:!0,exact:!1,message:r.message}),i.dirty());else if(r.kind==="max")e.data.length>r.value&&(o=this._getOrReturnCtx(e,o),z(o,{code:L.too_big,maximum:r.value,type:"string",inclusive:!0,exact:!1,message:r.message}),i.dirty());else if(r.kind==="length"){const s=e.data.length>r.value,a=e.data.length<r.value;(s||a)&&(o=this._getOrReturnCtx(e,o),s?z(o,{code:L.too_big,maximum:r.value,type:"string",inclusive:!0,exact:!0,message:r.message}):a&&z(o,{code:L.too_small,minimum:r.value,type:"string",inclusive:!0,exact:!0,message:r.message}),i.dirty())}else if(r.kind==="email")I4.test(e.data)||(o=this._getOrReturnCtx(e,o),z(o,{validation:"email",code:L.invalid_string,message:r.message}),i.dirty());else if(r.kind==="emoji")Ic||(Ic=new RegExp(R4,"u")),Ic.test(e.data)||(o=this._getOrReturnCtx(e,o),z(o,{validation:"emoji",code:L.invalid_string,message:r.message}),i.dirty());else if(r.kind==="uuid")S4.test(e.data)||(o=this._getOrReturnCtx(e,o),z(o,{validation:"uuid",code:L.invalid_string,message:r.message}),i.dirty());else if(r.kind==="cuid")E4.test(e.data)||(o=this._getOrReturnCtx(e,o),z(o,{validation:"cuid",code:L.invalid_string,message:r.message}),i.dirty());else if(r.kind==="cuid2")$4.test(e.data)||(o=this._getOrReturnCtx(e,o),z(o,{validation:"cuid2",code:L.invalid_string,message:r.message}),i.dirty());else if(r.kind==="ulid")A4.test(e.data)||(o=this._getOrReturnCtx(e,o),z(o,{validation:"ulid",code:L.invalid_string,message:r.message}),i.dirty());else if(r.kind==="url")try{new URL(e.data)}catch{o=this._getOrReturnCtx(e,o),z(o,{validation:"url",code:L.invalid_string,message:r.message}),i.dirty()}else r.kind==="regex"?(r.regex.lastIndex=0,r.regex.test(e.data)||(o=this._getOrReturnCtx(e,o),z(o,{validation:"regex",code:L.invalid_string,message:r.message}),i.dirty())):r.kind==="trim"?e.data=e.data.trim():r.kind==="includes"?e.data.includes(r.value,r.position)||(o=this._getOrReturnCtx(e,o),z(o,{code:L.invalid_string,validation:{includes:r.value,position:r.position},message:r.message}),i.dirty()):r.kind==="toLowerCase"?e.data=e.data.toLowerCase():r.kind==="toUpperCase"?e.data=e.data.toUpperCase():r.kind==="startsWith"?e.data.startsWith(r.value)||(o=this._getOrReturnCtx(e,o),z(o,{code:L.invalid_string,validation:{startsWith:r.value},message:r.message}),i.dirty()):r.kind==="endsWith"?e.data.endsWith(r.value)||(o=this._getOrReturnCtx(e,o),z(o,{code:L.invalid_string,validation:{endsWith:r.value},message:r.message}),i.dirty()):r.kind==="datetime"?O4(r).test(e.data)||(o=this._getOrReturnCtx(e,o),z(o,{code:L.invalid_string,validation:"datetime",message:r.message}),i.dirty()):r.kind==="ip"?k4(e.data,r.version)||(o=this._getOrReturnCtx(e,o),z(o,{validation:"ip",code:L.invalid_string,message:r.message}),i.dirty()):we.assertNever(r);return{status:i.value,value:e.data}}_regex(e,t,i){return this.refinement(o=>e.test(o),{validation:t,code:L.invalid_string,...J.errToObj(i)})}_addCheck(e){return new kt({...this._def,checks:[...this._def.checks,e]})}email(e){return this._addCheck({kind:"email",...J.errToObj(e)})}url(e){return this._addCheck({kind:"url",...J.errToObj(e)})}emoji(e){return this._addCheck({kind:"emoji",...J.errToObj(e)})}uuid(e){return this._addCheck({kind:"uuid",...J.errToObj(e)})}cuid(e){return this._addCheck({kind:"cuid",...J.errToObj(e)})}cuid2(e){return this._addCheck({kind:"cuid2",...J.errToObj(e)})}ulid(e){return this._addCheck({kind:"ulid",...J.errToObj(e)})}ip(e){return this._addCheck({kind:"ip",...J.errToObj(e)})}datetime(e){var t;return typeof e=="string"?this._addCheck({kind:"datetime",precision:null,offset:!1,message:e}):this._addCheck({kind:"datetime",precision:typeof(e==null?void 0:e.precision)>"u"?null:e==null?void 0:e.precision,offset:(t=e==null?void 0:e.offset)!==null&&t!==void 0?t:!1,...J.errToObj(e==null?void 0:e.message)})}regex(e,t){return this._addCheck({kind:"regex",regex:e,...J.errToObj(t)})}includes(e,t){return this._addCheck({kind:"includes",value:e,position:t==null?void 0:t.position,...J.errToObj(t==null?void 0:t.message)})}startsWith(e,t){return this._addCheck({kind:"startsWith",value:e,...J.errToObj(t)})}endsWith(e,t){return this._addCheck({kind:"endsWith",value:e,...J.errToObj(t)})}min(e,t){return this._addCheck({kind:"min",value:e,...J.errToObj(t)})}max(e,t){return this._addCheck({kind:"max",value:e,...J.errToObj(t)})}length(e,t){return this._addCheck({kind:"length",value:e,...J.errToObj(t)})}nonempty(e){return this.min(1,J.errToObj(e))}trim(){return new kt({...this._def,checks:[...this._def.checks,{kind:"trim"}]})}toLowerCase(){return new kt({...this._def,checks:[...this._def.checks,{kind:"toLowerCase"}]})}toUpperCase(){return new kt({...this._def,checks:[...this._def.checks,{kind:"toUpperCase"}]})}get isDatetime(){return!!this._def.checks.find(e=>e.kind==="datetime")}get isEmail(){return!!this._def.checks.find(e=>e.kind==="email")}get isURL(){return!!this._def.checks.find(e=>e.kind==="url")}get isEmoji(){return!!this._def.checks.find(e=>e.kind==="emoji")}get isUUID(){return!!this._def.checks.find(e=>e.kind==="uuid")}get isCUID(){return!!this._def.checks.find(e=>e.kind==="cuid")}get isCUID2(){return!!this._def.checks.find(e=>e.kind==="cuid2")}get isULID(){return!!this._def.checks.find(e=>e.kind==="ulid")}get isIP(){return!!this._def.checks.find(e=>e.kind==="ip")}get minLength(){let e=null;for(const t of this._def.checks)t.kind==="min"&&(e===null||t.value>e)&&(e=t.value);return e}get maxLength(){let e=null;for(const t of this._def.checks)t.kind==="max"&&(e===null||t.value<e)&&(e=t.value);return e}}kt.create=n=>{var e;return new kt({checks:[],typeName:te.ZodString,coerce:(e=n==null?void 0:n.coerce)!==null&&e!==void 0?e:!1,...ue(n)})};function N4(n,e){const t=(n.toString().split(".")[1]||"").length,i=(e.toString().split(".")[1]||"").length,o=t>i?t:i,r=parseInt(n.toFixed(o).replace(".","")),s=parseInt(e.toFixed(o).replace(".",""));return r%s/Math.pow(10,o)}class Gn extends de{constructor(){super(...arguments),this.min=this.gte,this.max=this.lte,this.step=this.multipleOf}_parse(e){if(this._def.coerce&&(e.data=Number(e.data)),this._getType(e)!==U.number){const r=this._getOrReturnCtx(e);return z(r,{code:L.invalid_type,expected:U.number,received:r.parsedType}),oe}let i;const o=new Ye;for(const r of this._def.checks)r.kind==="int"?we.isInteger(e.data)||(i=this._getOrReturnCtx(e,i),z(i,{code:L.invalid_type,expected:"integer",received:"float",message:r.message}),o.dirty()):r.kind==="min"?(r.inclusive?e.data<r.value:e.data<=r.value)&&(i=this._getOrReturnCtx(e,i),z(i,{code:L.too_small,minimum:r.value,type:"number",inclusive:r.inclusive,exact:!1,message:r.message}),o.dirty()):r.kind==="max"?(r.inclusive?e.data>r.value:e.data>=r.value)&&(i=this._getOrReturnCtx(e,i),z(i,{code:L.too_big,maximum:r.value,type:"number",inclusive:r.inclusive,exact:!1,message:r.message}),o.dirty()):r.kind==="multipleOf"?N4(e.data,r.value)!==0&&(i=this._getOrReturnCtx(e,i),z(i,{code:L.not_multiple_of,multipleOf:r.value,message:r.message}),o.dirty()):r.kind==="finite"?Number.isFinite(e.data)||(i=this._getOrReturnCtx(e,i),z(i,{code:L.not_finite,message:r.message}),o.dirty()):we.assertNever(r);return{status:o.value,value:e.data}}gte(e,t){return this.setLimit("min",e,!0,J.toString(t))}gt(e,t){return this.setLimit("min",e,!1,J.toString(t))}lte(e,t){return this.setLimit("max",e,!0,J.toString(t))}lt(e,t){return this.setLimit("max",e,!1,J.toString(t))}setLimit(e,t,i,o){return new Gn({...this._def,checks:[...this._def.checks,{kind:e,value:t,inclusive:i,message:J.toString(o)}]})}_addCheck(e){return new Gn({...this._def,checks:[...this._def.checks,e]})}int(e){return this._addCheck({kind:"int",message:J.toString(e)})}positive(e){return this._addCheck({kind:"min",value:0,inclusive:!1,message:J.toString(e)})}negative(e){return this._addCheck({kind:"max",value:0,inclusive:!1,message:J.toString(e)})}nonpositive(e){return this._addCheck({kind:"max",value:0,inclusive:!0,message:J.toString(e)})}nonnegative(e){return this._addCheck({kind:"min",value:0,inclusive:!0,message:J.toString(e)})}multipleOf(e,t){return this._addCheck({kind:"multipleOf",value:e,message:J.toString(t)})}finite(e){return this._addCheck({kind:"finite",message:J.toString(e)})}safe(e){return this._addCheck({kind:"min",inclusive:!0,value:Number.MIN_SAFE_INTEGER,message:J.toString(e)})._addCheck({kind:"max",inclusive:!0,value:Number.MAX_SAFE_INTEGER,message:J.toString(e)})}get minValue(){let e=null;for(const t of this._def.checks)t.kind==="min"&&(e===null||t.value>e)&&(e=t.value);return e}get maxValue(){let e=null;for(const t of this._def.checks)t.kind==="max"&&(e===null||t.value<e)&&(e=t.value);return e}get isInt(){return!!this._def.checks.find(e=>e.kind==="int"||e.kind==="multipleOf"&&we.isInteger(e.value))}get isFinite(){let e=null,t=null;for(const i of this._def.checks){if(i.kind==="finite"||i.kind==="int"||i.kind==="multipleOf")return!0;i.kind==="min"?(t===null||i.value>t)&&(t=i.value):i.kind==="max"&&(e===null||i.value<e)&&(e=i.value)}return Number.isFinite(t)&&Number.isFinite(e)}}Gn.create=n=>new Gn({checks:[],typeName:te.ZodNumber,coerce:(n==null?void 0:n.coerce)||!1,...ue(n)});class Yn extends de{constructor(){super(...arguments),this.min=this.gte,this.max=this.lte}_parse(e){if(this._def.coerce&&(e.data=BigInt(e.data)),this._getType(e)!==U.bigint){const r=this._getOrReturnCtx(e);return z(r,{code:L.invalid_type,expected:U.bigint,received:r.parsedType}),oe}let i;const o=new Ye;for(const r of this._def.checks)r.kind==="min"?(r.inclusive?e.data<r.value:e.data<=r.value)&&(i=this._getOrReturnCtx(e,i),z(i,{code:L.too_small,type:"bigint",minimum:r.value,inclusive:r.inclusive,message:r.message}),o.dirty()):r.kind==="max"?(r.inclusive?e.data>r.value:e.data>=r.value)&&(i=this._getOrReturnCtx(e,i),z(i,{code:L.too_big,type:"bigint",maximum:r.value,inclusive:r.inclusive,message:r.message}),o.dirty()):r.kind==="multipleOf"?e.data%r.value!==BigInt(0)&&(i=this._getOrReturnCtx(e,i),z(i,{code:L.not_multiple_of,multipleOf:r.value,message:r.message}),o.dirty()):we.assertNever(r);return{status:o.value,value:e.data}}gte(e,t){return this.setLimit("min",e,!0,J.toString(t))}gt(e,t){return this.setLimit("min",e,!1,J.toString(t))}lte(e,t){return this.setLimit("max",e,!0,J.toString(t))}lt(e,t){return this.setLimit("max",e,!1,J.toString(t))}setLimit(e,t,i,o){return new Yn({...this._def,checks:[...this._def.checks,{kind:e,value:t,inclusive:i,message:J.toString(o)}]})}_addCheck(e){return new Yn({...this._def,checks:[...this._def.checks,e]})}positive(e){return this._addCheck({kind:"min",value:BigInt(0),inclusive:!1,message:J.toString(e)})}negative(e){return this._addCheck({kind:"max",value:BigInt(0),inclusive:!1,message:J.toString(e)})}nonpositive(e){return this._addCheck({kind:"max",value:BigInt(0),inclusive:!0,message:J.toString(e)})}nonnegative(e){return this._addCheck({kind:"min",value:BigInt(0),inclusive:!0,message:J.toString(e)})}multipleOf(e,t){return this._addCheck({kind:"multipleOf",value:e,message:J.toString(t)})}get minValue(){let e=null;for(const t of this._def.checks)t.kind==="min"&&(e===null||t.value>e)&&(e=t.value);return e}get maxValue(){let e=null;for(const t of this._def.checks)t.kind==="max"&&(e===null||t.value<e)&&(e=t.value);return e}}Yn.create=n=>{var e;return new Yn({checks:[],typeName:te.ZodBigInt,coerce:(e=n==null?void 0:n.coerce)!==null&&e!==void 0?e:!1,...ue(n)})};class qo extends de{_parse(e){if(this._def.coerce&&(e.data=!!e.data),this._getType(e)!==U.boolean){const i=this._getOrReturnCtx(e);return z(i,{code:L.invalid_type,expected:U.boolean,received:i.parsedType}),oe}return tt(e.data)}}qo.create=n=>new qo({typeName:te.ZodBoolean,coerce:(n==null?void 0:n.coerce)||!1,...ue(n)});class ji extends de{_parse(e){if(this._def.coerce&&(e.data=new Date(e.data)),this._getType(e)!==U.date){const r=this._getOrReturnCtx(e);return z(r,{code:L.invalid_type,expected:U.date,received:r.parsedType}),oe}if(isNaN(e.data.getTime())){const r=this._getOrReturnCtx(e);return z(r,{code:L.invalid_date}),oe}const i=new Ye;let o;for(const r of this._def.checks)r.kind==="min"?e.data.getTime()<r.value&&(o=this._getOrReturnCtx(e,o),z(o,{code:L.too_small,message:r.message,inclusive:!0,exact:!1,minimum:r.value,type:"date"}),i.dirty()):r.kind==="max"?e.data.getTime()>r.value&&(o=this._getOrReturnCtx(e,o),z(o,{code:L.too_big,message:r.message,inclusive:!0,exact:!1,maximum:r.value,type:"date"}),i.dirty()):we.assertNever(r);return{status:i.value,value:new Date(e.data.getTime())}}_addCheck(e){return new ji({...this._def,checks:[...this._def.checks,e]})}min(e,t){return this._addCheck({kind:"min",value:e.getTime(),message:J.toString(t)})}max(e,t){return this._addCheck({kind:"max",value:e.getTime(),message:J.toString(t)})}get minDate(){let e=null;for(const t of this._def.checks)t.kind==="min"&&(e===null||t.value>e)&&(e=t.value);return e!=null?new Date(e):null}get maxDate(){let e=null;for(const t of this._def.checks)t.kind==="max"&&(e===null||t.value<e)&&(e=t.value);return e!=null?new Date(e):null}}ji.create=n=>new ji({checks:[],coerce:(n==null?void 0:n.coerce)||!1,typeName:te.ZodDate,...ue(n)});class oa extends de{_parse(e){if(this._getType(e)!==U.symbol){const i=this._getOrReturnCtx(e);return z(i,{code:L.invalid_type,expected:U.symbol,received:i.parsedType}),oe}return tt(e.data)}}oa.create=n=>new oa({typeName:te.ZodSymbol,...ue(n)});class Go extends de{_parse(e){if(this._getType(e)!==U.undefined){const i=this._getOrReturnCtx(e);return z(i,{code:L.invalid_type,expected:U.undefined,received:i.parsedType}),oe}return tt(e.data)}}Go.create=n=>new Go({typeName:te.ZodUndefined,...ue(n)});class Yo extends de{_parse(e){if(this._getType(e)!==U.null){const i=this._getOrReturnCtx(e);return z(i,{code:L.invalid_type,expected:U.null,received:i.parsedType}),oe}return tt(e.data)}}Yo.create=n=>new Yo({typeName:te.ZodNull,...ue(n)});class Mr extends de{constructor(){super(...arguments),this._any=!0}_parse(e){return tt(e.data)}}Mr.create=n=>new Mr({typeName:te.ZodAny,...ue(n)});class mi extends de{constructor(){super(...arguments),this._unknown=!0}_parse(e){return tt(e.data)}}mi.create=n=>new mi({typeName:te.ZodUnknown,...ue(n)});class $n extends de{_parse(e){const t=this._getOrReturnCtx(e);return z(t,{code:L.invalid_type,expected:U.never,received:t.parsedType}),oe}}$n.create=n=>new $n({typeName:te.ZodNever,...ue(n)});class sa extends de{_parse(e){if(this._getType(e)!==U.undefined){const i=this._getOrReturnCtx(e);return z(i,{code:L.invalid_type,expected:U.void,received:i.parsedType}),oe}return tt(e.data)}}sa.create=n=>new sa({typeName:te.ZodVoid,...ue(n)});class Mt extends de{_parse(e){const{ctx:t,status:i}=this._processInputParams(e),o=this._def;if(t.parsedType!==U.array)return z(t,{code:L.invalid_type,expected:U.array,received:t.parsedType}),oe;if(o.exactLength!==null){const s=t.data.length>o.exactLength.value,a=t.data.length<o.exactLength.value;(s||a)&&(z(t,{code:s?L.too_big:L.too_small,minimum:a?o.exactLength.value:void 0,maximum:s?o.exactLength.value:void 0,type:"array",inclusive:!0,exact:!0,message:o.exactLength.message}),i.dirty())}if(o.minLength!==null&&t.data.length<o.minLength.value&&(z(t,{code:L.too_small,minimum:o.minLength.value,type:"array",inclusive:!0,exact:!1,message:o.minLength.message}),i.dirty()),o.maxLength!==null&&t.data.length>o.maxLength.value&&(z(t,{code:L.too_big,maximum:o.maxLength.value,type:"array",inclusive:!0,exact:!1,message:o.maxLength.message}),i.dirty()),t.common.async)return Promise.all([...t.data].map((s,a)=>o.type._parseAsync(new ln(t,s,t.path,a)))).then(s=>Ye.mergeArray(i,s));const r=[...t.data].map((s,a)=>o.type._parseSync(new ln(t,s,t.path,a)));return Ye.mergeArray(i,r)}get element(){return this._def.type}min(e,t){return new Mt({...this._def,minLength:{value:e,message:J.toString(t)}})}max(e,t){return new Mt({...this._def,maxLength:{value:e,message:J.toString(t)}})}length(e,t){return new Mt({...this._def,exactLength:{value:e,message:J.toString(t)}})}nonempty(e){return this.min(1,e)}}Mt.create=(n,e)=>new Mt({type:n,minLength:null,maxLength:null,exactLength:null,typeName:te.ZodArray,...ue(e)});function rr(n){if(n instanceof Re){const e={};for(const t in n.shape){const i=n.shape[t];e[t]=xn.create(rr(i))}return new Re({...n._def,shape:()=>e})}else return n instanceof Mt?new Mt({...n._def,type:rr(n.element)}):n instanceof xn?xn.create(rr(n.unwrap())):n instanceof Ui?Ui.create(rr(n.unwrap())):n instanceof un?un.create(n.items.map(e=>rr(e))):n}class Re extends de{constructor(){super(...arguments),this._cached=null,this.nonstrict=this.passthrough,this.augment=this.extend}_getCached(){if(this._cached!==null)return this._cached;const e=this._def.shape(),t=we.objectKeys(e);return this._cached={shape:e,keys:t}}_parse(e){if(this._getType(e)!==U.object){const u=this._getOrReturnCtx(e);return z(u,{code:L.invalid_type,expected:U.object,received:u.parsedType}),oe}const{status:i,ctx:o}=this._processInputParams(e),{shape:r,keys:s}=this._getCached(),a=[];if(!(this._def.catchall instanceof $n&&this._def.unknownKeys==="strip"))for(const u in o.data)s.includes(u)||a.push(u);const c=[];for(const u of s){const h=r[u],p=o.data[u];c.push({key:{status:"valid",value:u},value:h._parse(new ln(o,p,o.path,u)),alwaysSet:u in o.data})}if(this._def.catchall instanceof $n){const u=this._def.unknownKeys;if(u==="passthrough")for(const h of a)c.push({key:{status:"valid",value:h},value:{status:"valid",value:o.data[h]}});else if(u==="strict")a.length>0&&(z(o,{code:L.unrecognized_keys,keys:a}),i.dirty());else if(u!=="strip")throw new Error("Internal ZodObject error: invalid unknownKeys value.")}else{const u=this._def.catchall;for(const h of a){const p=o.data[h];c.push({key:{status:"valid",value:h},value:u._parse(new ln(o,p,o.path,h)),alwaysSet:h in o.data})}}return o.common.async?Promise.resolve().then(async()=>{const u=[];for(const h of c){const p=await h.key;u.push({key:p,value:await h.value,alwaysSet:h.alwaysSet})}return u}).then(u=>Ye.mergeObjectSync(i,u)):Ye.mergeObjectSync(i,c)}get shape(){return this._def.shape()}strict(e){return J.errToObj,new Re({...this._def,unknownKeys:"strict",...e!==void 0?{errorMap:(t,i)=>{var o,r,s,a;const c=(s=(r=(o=this._def).errorMap)===null||r===void 0?void 0:r.call(o,t,i).message)!==null&&s!==void 0?s:i.defaultError;return t.code==="unrecognized_keys"?{message:(a=J.errToObj(e).message)!==null&&a!==void 0?a:c}:{message:c}}}:{}})}strip(){return new Re({...this._def,unknownKeys:"strip"})}passthrough(){return new Re({...this._def,unknownKeys:"passthrough"})}extend(e){return new Re({...this._def,shape:()=>({...this._def.shape(),...e})})}merge(e){return new Re({unknownKeys:e._def.unknownKeys,catchall:e._def.catchall,shape:()=>({...this._def.shape(),...e._def.shape()}),typeName:te.ZodObject})}setKey(e,t){return this.augment({[e]:t})}catchall(e){return new Re({...this._def,catchall:e})}pick(e){const t={};return we.objectKeys(e).forEach(i=>{e[i]&&this.shape[i]&&(t[i]=this.shape[i])}),new Re({...this._def,shape:()=>t})}omit(e){const t={};return we.objectKeys(this.shape).forEach(i=>{e[i]||(t[i]=this.shape[i])}),new Re({...this._def,shape:()=>t})}deepPartial(){return rr(this)}partial(e){const t={};return we.objectKeys(this.shape).forEach(i=>{const o=this.shape[i];e&&!e[i]?t[i]=o:t[i]=o.optional()}),new Re({...this._def,shape:()=>t})}required(e){const t={};return we.objectKeys(this.shape).forEach(i=>{if(e&&!e[i])t[i]=this.shape[i];else{let r=this.shape[i];for(;r instanceof xn;)r=r._def.innerType;t[i]=r}}),new Re({...this._def,shape:()=>t})}keyof(){return Gh(we.objectKeys(this.shape))}}Re.create=(n,e)=>new Re({shape:()=>n,unknownKeys:"strip",catchall:$n.create(),typeName:te.ZodObject,...ue(e)});Re.strictCreate=(n,e)=>new Re({shape:()=>n,unknownKeys:"strict",catchall:$n.create(),typeName:te.ZodObject,...ue(e)});Re.lazycreate=(n,e)=>new Re({shape:n,unknownKeys:"strip",catchall:$n.create(),typeName:te.ZodObject,...ue(e)});class Ko extends de{_parse(e){const{ctx:t}=this._processInputParams(e),i=this._def.options;function o(r){for(const a of r)if(a.result.status==="valid")return a.result;for(const a of r)if(a.result.status==="dirty")return t.common.issues.push(...a.ctx.common.issues),a.result;const s=r.map(a=>new Nt(a.ctx.common.issues));return z(t,{code:L.invalid_union,unionErrors:s}),oe}if(t.common.async)return Promise.all(i.map(async r=>{const s={...t,common:{...t.common,issues:[]},parent:null};return{result:await r._parseAsync({data:t.data,path:t.path,parent:s}),ctx:s}})).then(o);{let r;const s=[];for(const c of i){const u={...t,common:{...t.common,issues:[]},parent:null},h=c._parseSync({data:t.data,path:t.path,parent:u});if(h.status==="valid")return h;h.status==="dirty"&&!r&&(r={result:h,ctx:u}),u.common.issues.length&&s.push(u.common.issues)}if(r)return t.common.issues.push(...r.ctx.common.issues),r.result;const a=s.map(c=>new Nt(c));return z(t,{code:L.invalid_union,unionErrors:a}),oe}}get options(){return this._def.options}}Ko.create=(n,e)=>new Ko({options:n,typeName:te.ZodUnion,...ue(e)});const ks=n=>n instanceof Xo?ks(n.schema):n instanceof Wt?ks(n.innerType()):n instanceof es?[n.value]:n instanceof Kn?n.options:n instanceof ts?Object.keys(n.enum):n instanceof ns?ks(n._def.innerType):n instanceof Go?[void 0]:n instanceof Yo?[null]:null;class Ga extends de{_parse(e){const{ctx:t}=this._processInputParams(e);if(t.parsedType!==U.object)return z(t,{code:L.invalid_type,expected:U.object,received:t.parsedType}),oe;const i=this.discriminator,o=t.data[i],r=this.optionsMap.get(o);return r?t.common.async?r._parseAsync({data:t.data,path:t.path,parent:t}):r._parseSync({data:t.data,path:t.path,parent:t}):(z(t,{code:L.invalid_union_discriminator,options:Array.from(this.optionsMap.keys()),path:[i]}),oe)}get discriminator(){return this._def.discriminator}get options(){return this._def.options}get optionsMap(){return this._def.optionsMap}static create(e,t,i){const o=new Map;for(const r of t){const s=ks(r.shape[e]);if(!s)throw new Error(`A discriminator value for key \`${e}\` could not be extracted from all schema options`);for(const a of s){if(o.has(a))throw new Error(`Discriminator property ${String(e)} has duplicate value ${String(a)}`);o.set(a,r)}}return new Ga({typeName:te.ZodDiscriminatedUnion,discriminator:e,options:t,optionsMap:o,...ue(i)})}}function hl(n,e){const t=Nn(n),i=Nn(e);if(n===e)return{valid:!0,data:n};if(t===U.object&&i===U.object){const o=we.objectKeys(e),r=we.objectKeys(n).filter(a=>o.indexOf(a)!==-1),s={...n,...e};for(const a of r){const c=hl(n[a],e[a]);if(!c.valid)return{valid:!1};s[a]=c.data}return{valid:!0,data:s}}else if(t===U.array&&i===U.array){if(n.length!==e.length)return{valid:!1};const o=[];for(let r=0;r<n.length;r++){const s=n[r],a=e[r],c=hl(s,a);if(!c.valid)return{valid:!1};o.push(c.data)}return{valid:!0,data:o}}else return t===U.date&&i===U.date&&+n==+e?{valid:!0,data:n}:{valid:!1}}class Jo extends de{_parse(e){const{status:t,ctx:i}=this._processInputParams(e),o=(r,s)=>{if(ul(r)||ul(s))return oe;const a=hl(r.value,s.value);return a.valid?((dl(r)||dl(s))&&t.dirty(),{status:t.value,value:a.data}):(z(i,{code:L.invalid_intersection_types}),oe)};return i.common.async?Promise.all([this._def.left._parseAsync({data:i.data,path:i.path,parent:i}),this._def.right._parseAsync({data:i.data,path:i.path,parent:i})]).then(([r,s])=>o(r,s)):o(this._def.left._parseSync({data:i.data,path:i.path,parent:i}),this._def.right._parseSync({data:i.data,path:i.path,parent:i}))}}Jo.create=(n,e,t)=>new Jo({left:n,right:e,typeName:te.ZodIntersection,...ue(t)});class un extends de{_parse(e){const{status:t,ctx:i}=this._processInputParams(e);if(i.parsedType!==U.array)return z(i,{code:L.invalid_type,expected:U.array,received:i.parsedType}),oe;if(i.data.length<this._def.items.length)return z(i,{code:L.too_small,minimum:this._def.items.length,inclusive:!0,exact:!1,type:"array"}),oe;!this._def.rest&&i.data.length>this._def.items.length&&(z(i,{code:L.too_big,maximum:this._def.items.length,inclusive:!0,exact:!1,type:"array"}),t.dirty());const r=[...i.data].map((s,a)=>{const c=this._def.items[a]||this._def.rest;return c?c._parse(new ln(i,s,i.path,a)):null}).filter(s=>!!s);return i.common.async?Promise.all(r).then(s=>Ye.mergeArray(t,s)):Ye.mergeArray(t,r)}get items(){return this._def.items}rest(e){return new un({...this._def,rest:e})}}un.create=(n,e)=>{if(!Array.isArray(n))throw new Error("You must pass an array of schemas to z.tuple([ ... ])");return new un({items:n,typeName:te.ZodTuple,rest:null,...ue(e)})};class Qo extends de{get keySchema(){return this._def.keyType}get valueSchema(){return this._def.valueType}_parse(e){const{status:t,ctx:i}=this._processInputParams(e);if(i.parsedType!==U.object)return z(i,{code:L.invalid_type,expected:U.object,received:i.parsedType}),oe;const o=[],r=this._def.keyType,s=this._def.valueType;for(const a in i.data)o.push({key:r._parse(new ln(i,a,i.path,a)),value:s._parse(new ln(i,i.data[a],i.path,a))});return i.common.async?Ye.mergeObjectAsync(t,o):Ye.mergeObjectSync(t,o)}get element(){return this._def.valueType}static create(e,t,i){return t instanceof de?new Qo({keyType:e,valueType:t,typeName:te.ZodRecord,...ue(i)}):new Qo({keyType:kt.create(),valueType:e,typeName:te.ZodRecord,...ue(t)})}}class aa extends de{get keySchema(){return this._def.keyType}get valueSchema(){return this._def.valueType}_parse(e){const{status:t,ctx:i}=this._processInputParams(e);if(i.parsedType!==U.map)return z(i,{code:L.invalid_type,expected:U.map,received:i.parsedType}),oe;const o=this._def.keyType,r=this._def.valueType,s=[...i.data.entries()].map(([a,c],u)=>({key:o._parse(new ln(i,a,i.path,[u,"key"])),value:r._parse(new ln(i,c,i.path,[u,"value"]))}));if(i.common.async){const a=new Map;return Promise.resolve().then(async()=>{for(const c of s){const u=await c.key,h=await c.value;if(u.status==="aborted"||h.status==="aborted")return oe;(u.status==="dirty"||h.status==="dirty")&&t.dirty(),a.set(u.value,h.value)}return{status:t.value,value:a}})}else{const a=new Map;for(const c of s){const u=c.key,h=c.value;if(u.status==="aborted"||h.status==="aborted")return oe;(u.status==="dirty"||h.status==="dirty")&&t.dirty(),a.set(u.value,h.value)}return{status:t.value,value:a}}}}aa.create=(n,e,t)=>new aa({valueType:e,keyType:n,typeName:te.ZodMap,...ue(t)});class Di extends de{_parse(e){const{status:t,ctx:i}=this._processInputParams(e);if(i.parsedType!==U.set)return z(i,{code:L.invalid_type,expected:U.set,received:i.parsedType}),oe;const o=this._def;o.minSize!==null&&i.data.size<o.minSize.value&&(z(i,{code:L.too_small,minimum:o.minSize.value,type:"set",inclusive:!0,exact:!1,message:o.minSize.message}),t.dirty()),o.maxSize!==null&&i.data.size>o.maxSize.value&&(z(i,{code:L.too_big,maximum:o.maxSize.value,type:"set",inclusive:!0,exact:!1,message:o.maxSize.message}),t.dirty());const r=this._def.valueType;function s(c){const u=new Set;for(const h of c){if(h.status==="aborted")return oe;h.status==="dirty"&&t.dirty(),u.add(h.value)}return{status:t.value,value:u}}const a=[...i.data.values()].map((c,u)=>r._parse(new ln(i,c,i.path,u)));return i.common.async?Promise.all(a).then(c=>s(c)):s(a)}min(e,t){return new Di({...this._def,minSize:{value:e,message:J.toString(t)}})}max(e,t){return new Di({...this._def,maxSize:{value:e,message:J.toString(t)}})}size(e,t){return this.min(e,t).max(e,t)}nonempty(e){return this.min(1,e)}}Di.create=(n,e)=>new Di({valueType:n,minSize:null,maxSize:null,typeName:te.ZodSet,...ue(e)});class ur extends de{constructor(){super(...arguments),this.validate=this.implement}_parse(e){const{ctx:t}=this._processInputParams(e);if(t.parsedType!==U.function)return z(t,{code:L.invalid_type,expected:U.function,received:t.parsedType}),oe;function i(a,c){return ia({data:a,path:t.path,errorMaps:[t.common.contextualErrorMap,t.schemaErrorMap,na(),Vo].filter(u=>!!u),issueData:{code:L.invalid_arguments,argumentsError:c}})}function o(a,c){return ia({data:a,path:t.path,errorMaps:[t.common.contextualErrorMap,t.schemaErrorMap,na(),Vo].filter(u=>!!u),issueData:{code:L.invalid_return_type,returnTypeError:c}})}const r={errorMap:t.common.contextualErrorMap},s=t.data;if(this._def.returns instanceof Lr){const a=this;return tt(async function(...c){const u=new Nt([]),h=await a._def.args.parseAsync(c,r).catch(b=>{throw u.addIssue(i(c,b)),u}),p=await Reflect.apply(s,this,h);return await a._def.returns._def.type.parseAsync(p,r).catch(b=>{throw u.addIssue(o(p,b)),u})})}else{const a=this;return tt(function(...c){const u=a._def.args.safeParse(c,r);if(!u.success)throw new Nt([i(c,u.error)]);const h=Reflect.apply(s,this,u.data),p=a._def.returns.safeParse(h,r);if(!p.success)throw new Nt([o(h,p.error)]);return p.data})}}parameters(){return this._def.args}returnType(){return this._def.returns}args(...e){return new ur({...this._def,args:un.create(e).rest(mi.create())})}returns(e){return new ur({...this._def,returns:e})}implement(e){return this.parse(e)}strictImplement(e){return this.parse(e)}static create(e,t,i){return new ur({args:e||un.create([]).rest(mi.create()),returns:t||mi.create(),typeName:te.ZodFunction,...ue(i)})}}class Xo extends de{get schema(){return this._def.getter()}_parse(e){const{ctx:t}=this._processInputParams(e);return this._def.getter()._parse({data:t.data,path:t.path,parent:t})}}Xo.create=(n,e)=>new Xo({getter:n,typeName:te.ZodLazy,...ue(e)});class es extends de{_parse(e){if(e.data!==this._def.value){const t=this._getOrReturnCtx(e);return z(t,{received:t.data,code:L.invalid_literal,expected:this._def.value}),oe}return{status:"valid",value:e.data}}get value(){return this._def.value}}es.create=(n,e)=>new es({value:n,typeName:te.ZodLiteral,...ue(e)});function Gh(n,e){return new Kn({values:n,typeName:te.ZodEnum,...ue(e)})}class Kn extends de{_parse(e){if(typeof e.data!="string"){const t=this._getOrReturnCtx(e),i=this._def.values;return z(t,{expected:we.joinValues(i),received:t.parsedType,code:L.invalid_type}),oe}if(this._def.values.indexOf(e.data)===-1){const t=this._getOrReturnCtx(e),i=this._def.values;return z(t,{received:t.data,code:L.invalid_enum_value,options:i}),oe}return tt(e.data)}get options(){return this._def.values}get enum(){const e={};for(const t of this._def.values)e[t]=t;return e}get Values(){const e={};for(const t of this._def.values)e[t]=t;return e}get Enum(){const e={};for(const t of this._def.values)e[t]=t;return e}extract(e){return Kn.create(e)}exclude(e){return Kn.create(this.options.filter(t=>!e.includes(t)))}}Kn.create=Gh;class ts extends de{_parse(e){const t=we.getValidEnumValues(this._def.values),i=this._getOrReturnCtx(e);if(i.parsedType!==U.string&&i.parsedType!==U.number){const o=we.objectValues(t);return z(i,{expected:we.joinValues(o),received:i.parsedType,code:L.invalid_type}),oe}if(t.indexOf(e.data)===-1){const o=we.objectValues(t);return z(i,{received:i.data,code:L.invalid_enum_value,options:o}),oe}return tt(e.data)}get enum(){return this._def.values}}ts.create=(n,e)=>new ts({values:n,typeName:te.ZodNativeEnum,...ue(e)});class Lr extends de{unwrap(){return this._def.type}_parse(e){const{ctx:t}=this._processInputParams(e);if(t.parsedType!==U.promise&&t.common.async===!1)return z(t,{code:L.invalid_type,expected:U.promise,received:t.parsedType}),oe;const i=t.parsedType===U.promise?t.data:Promise.resolve(t.data);return tt(i.then(o=>this._def.type.parseAsync(o,{path:t.path,errorMap:t.common.contextualErrorMap})))}}Lr.create=(n,e)=>new Lr({type:n,typeName:te.ZodPromise,...ue(e)});class Wt extends de{innerType(){return this._def.schema}sourceType(){return this._def.schema._def.typeName===te.ZodEffects?this._def.schema.sourceType():this._def.schema}_parse(e){const{status:t,ctx:i}=this._processInputParams(e),o=this._def.effect||null,r={addIssue:s=>{z(i,s),s.fatal?t.abort():t.dirty()},get path(){return i.path}};if(r.addIssue=r.addIssue.bind(r),o.type==="preprocess"){const s=o.transform(i.data,r);return i.common.issues.length?{status:"dirty",value:i.data}:i.common.async?Promise.resolve(s).then(a=>this._def.schema._parseAsync({data:a,path:i.path,parent:i})):this._def.schema._parseSync({data:s,path:i.path,parent:i})}if(o.type==="refinement"){const s=a=>{const c=o.refinement(a,r);if(i.common.async)return Promise.resolve(c);if(c instanceof Promise)throw new Error("Async refinement encountered during synchronous parse operation. Use .parseAsync instead.");return a};if(i.common.async===!1){const a=this._def.schema._parseSync({data:i.data,path:i.path,parent:i});return a.status==="aborted"?oe:(a.status==="dirty"&&t.dirty(),s(a.value),{status:t.value,value:a.value})}else return this._def.schema._parseAsync({data:i.data,path:i.path,parent:i}).then(a=>a.status==="aborted"?oe:(a.status==="dirty"&&t.dirty(),s(a.value).then(()=>({status:t.value,value:a.value}))))}if(o.type==="transform")if(i.common.async===!1){const s=this._def.schema._parseSync({data:i.data,path:i.path,parent:i});if(!Zo(s))return s;const a=o.transform(s.value,r);if(a instanceof Promise)throw new Error("Asynchronous transform encountered during synchronous parse operation. Use .parseAsync instead.");return{status:t.value,value:a}}else return this._def.schema._parseAsync({data:i.data,path:i.path,parent:i}).then(s=>Zo(s)?Promise.resolve(o.transform(s.value,r)).then(a=>({status:t.value,value:a})):s);we.assertNever(o)}}Wt.create=(n,e,t)=>new Wt({schema:n,typeName:te.ZodEffects,effect:e,...ue(t)});Wt.createWithPreprocess=(n,e,t)=>new Wt({schema:e,effect:{type:"preprocess",transform:n},typeName:te.ZodEffects,...ue(t)});class xn extends de{_parse(e){return this._getType(e)===U.undefined?tt(void 0):this._def.innerType._parse(e)}unwrap(){return this._def.innerType}}xn.create=(n,e)=>new xn({innerType:n,typeName:te.ZodOptional,...ue(e)});class Ui extends de{_parse(e){return this._getType(e)===U.null?tt(null):this._def.innerType._parse(e)}unwrap(){return this._def.innerType}}Ui.create=(n,e)=>new Ui({innerType:n,typeName:te.ZodNullable,...ue(e)});class ns extends de{_parse(e){const{ctx:t}=this._processInputParams(e);let i=t.data;return t.parsedType===U.undefined&&(i=this._def.defaultValue()),this._def.innerType._parse({data:i,path:t.path,parent:t})}removeDefault(){return this._def.innerType}}ns.create=(n,e)=>new ns({innerType:n,typeName:te.ZodDefault,defaultValue:typeof e.default=="function"?e.default:()=>e.default,...ue(e)});class ca extends de{_parse(e){const{ctx:t}=this._processInputParams(e),i={...t,common:{...t.common,issues:[]}},o=this._def.innerType._parse({data:i.data,path:i.path,parent:{...i}});return ra(o)?o.then(r=>({status:"valid",value:r.status==="valid"?r.value:this._def.catchValue({get error(){return new Nt(i.common.issues)},input:i.data})})):{status:"valid",value:o.status==="valid"?o.value:this._def.catchValue({get error(){return new Nt(i.common.issues)},input:i.data})}}removeCatch(){return this._def.innerType}}ca.create=(n,e)=>new ca({innerType:n,typeName:te.ZodCatch,catchValue:typeof e.catch=="function"?e.catch:()=>e.catch,...ue(e)});class la extends de{_parse(e){if(this._getType(e)!==U.nan){const i=this._getOrReturnCtx(e);return z(i,{code:L.invalid_type,expected:U.nan,received:i.parsedType}),oe}return{status:"valid",value:e.data}}}la.create=n=>new la({typeName:te.ZodNaN,...ue(n)});const M4=Symbol("zod_brand");class Yh extends de{_parse(e){const{ctx:t}=this._processInputParams(e),i=t.data;return this._def.type._parse({data:i,path:t.path,parent:t})}unwrap(){return this._def.type}}class fs extends de{_parse(e){const{status:t,ctx:i}=this._processInputParams(e);if(i.common.async)return(async()=>{const r=await this._def.in._parseAsync({data:i.data,path:i.path,parent:i});return r.status==="aborted"?oe:r.status==="dirty"?(t.dirty(),qh(r.value)):this._def.out._parseAsync({data:r.value,path:i.path,parent:i})})();{const o=this._def.in._parseSync({data:i.data,path:i.path,parent:i});return o.status==="aborted"?oe:o.status==="dirty"?(t.dirty(),{status:"dirty",value:o.value}):this._def.out._parseSync({data:o.value,path:i.path,parent:i})}}static create(e,t){return new fs({in:e,out:t,typeName:te.ZodPipeline})}}class ua extends de{_parse(e){const t=this._def.innerType._parse(e);return Zo(t)&&(t.value=Object.freeze(t.value)),t}}ua.create=(n,e)=>new ua({innerType:n,typeName:te.ZodReadonly,...ue(e)});const Kh=(n,e={},t)=>n?Mr.create().superRefine((i,o)=>{var r,s;if(!n(i)){const a=typeof e=="function"?e(i):typeof e=="string"?{message:e}:e,c=(s=(r=a.fatal)!==null&&r!==void 0?r:t)!==null&&s!==void 0?s:!0,u=typeof a=="string"?{message:a}:a;o.addIssue({code:"custom",...u,fatal:c})}}):Mr.create(),L4={object:Re.lazycreate};var te;(function(n){n.ZodString="ZodString",n.ZodNumber="ZodNumber",n.ZodNaN="ZodNaN",n.ZodBigInt="ZodBigInt",n.ZodBoolean="ZodBoolean",n.ZodDate="ZodDate",n.ZodSymbol="ZodSymbol",n.ZodUndefined="ZodUndefined",n.ZodNull="ZodNull",n.ZodAny="ZodAny",n.ZodUnknown="ZodUnknown",n.ZodNever="ZodNever",n.ZodVoid="ZodVoid",n.ZodArray="ZodArray",n.ZodObject="ZodObject",n.ZodUnion="ZodUnion",n.ZodDiscriminatedUnion="ZodDiscriminatedUnion",n.ZodIntersection="ZodIntersection",n.ZodTuple="ZodTuple",n.ZodRecord="ZodRecord",n.ZodMap="ZodMap",n.ZodSet="ZodSet",n.ZodFunction="ZodFunction",n.ZodLazy="ZodLazy",n.ZodLiteral="ZodLiteral",n.ZodEnum="ZodEnum",n.ZodEffects="ZodEffects",n.ZodNativeEnum="ZodNativeEnum",n.ZodOptional="ZodOptional",n.ZodNullable="ZodNullable",n.ZodDefault="ZodDefault",n.ZodCatch="ZodCatch",n.ZodPromise="ZodPromise",n.ZodBranded="ZodBranded",n.ZodPipeline="ZodPipeline",n.ZodReadonly="ZodReadonly"})(te||(te={}));const B4=(n,e={message:`Input not instance of ${n.name}`})=>Kh(t=>t instanceof n,e),Jh=kt.create,Qh=Gn.create,j4=la.create,D4=Yn.create,Xh=qo.create,U4=ji.create,W4=oa.create,z4=Go.create,F4=Yo.create,H4=Mr.create,V4=mi.create,Z4=$n.create,q4=sa.create,G4=Mt.create,Y4=Re.create,K4=Re.strictCreate,J4=Ko.create,Q4=Ga.create,X4=Jo.create,eb=un.create,tb=Qo.create,nb=aa.create,ib=Di.create,rb=ur.create,ob=Xo.create,sb=es.create,ab=Kn.create,cb=ts.create,lb=Lr.create,kd=Wt.create,ub=xn.create,db=Ui.create,hb=Wt.createWithPreprocess,pb=fs.create,fb=()=>Jh().optional(),gb=()=>Qh().optional(),mb=()=>Xh().optional(),wb={string:n=>kt.create({...n,coerce:!0}),number:n=>Gn.create({...n,coerce:!0}),boolean:n=>qo.create({...n,coerce:!0}),bigint:n=>Yn.create({...n,coerce:!0}),date:n=>ji.create({...n,coerce:!0})},bb=oe;var w=Object.freeze({__proto__:null,defaultErrorMap:Vo,setErrorMap:C4,getErrorMap:na,makeIssue:ia,EMPTY_PATH:_4,addIssueToContext:z,ParseStatus:Ye,INVALID:oe,DIRTY:qh,OK:tt,isAborted:ul,isDirty:dl,isValid:Zo,isAsync:ra,get util(){return we},get objectUtil(){return ll},ZodParsedType:U,getParsedType:Nn,ZodType:de,ZodString:kt,ZodNumber:Gn,ZodBigInt:Yn,ZodBoolean:qo,ZodDate:ji,ZodSymbol:oa,ZodUndefined:Go,ZodNull:Yo,ZodAny:Mr,ZodUnknown:mi,ZodNever:$n,ZodVoid:sa,ZodArray:Mt,ZodObject:Re,ZodUnion:Ko,ZodDiscriminatedUnion:Ga,ZodIntersection:Jo,ZodTuple:un,ZodRecord:Qo,ZodMap:aa,ZodSet:Di,ZodFunction:ur,ZodLazy:Xo,ZodLiteral:es,ZodEnum:Kn,ZodNativeEnum:ts,ZodPromise:Lr,ZodEffects:Wt,ZodTransformer:Wt,ZodOptional:xn,ZodNullable:Ui,ZodDefault:ns,ZodCatch:ca,ZodNaN:la,BRAND:M4,ZodBranded:Yh,ZodPipeline:fs,ZodReadonly:ua,custom:Kh,Schema:de,ZodSchema:de,late:L4,get ZodFirstPartyTypeKind(){return te},coerce:wb,any:H4,array:G4,bigint:D4,boolean:Xh,date:U4,discriminatedUnion:Q4,effect:kd,enum:ab,function:rb,instanceof:B4,intersection:X4,lazy:ob,literal:sb,map:nb,nan:j4,nativeEnum:cb,never:Z4,null:F4,nullable:db,number:Qh,object:Y4,oboolean:mb,onumber:gb,optional:ub,ostring:fb,pipeline:pb,preprocess:hb,promise:lb,record:tb,set:ib,strictObject:K4,string:Jh,symbol:W4,transformer:kd,tuple:eb,undefined:z4,union:J4,unknown:V4,void:q4,NEVER:bb,ZodIssueCode:L,quotelessJson:x4,ZodError:Nt});const it=w.object({message:w.string()});function se(n){return w.literal(W[n])}w.object({accessList:w.array(w.string()),blockHash:w.string().nullable(),blockNumber:w.string().nullable(),chainId:w.string(),from:w.string(),gas:w.string(),hash:w.string(),input:w.string().nullable(),maxFeePerGas:w.string(),maxPriorityFeePerGas:w.string(),nonce:w.string(),r:w.string(),s:w.string(),to:w.string(),transactionIndex:w.string().nullable(),type:w.string(),v:w.string(),value:w.string()});const vb=w.object({chainId:w.number()}),yb=w.object({email:w.string().email()}),xb=w.object({otp:w.string()}),Cb=w.object({chainId:w.optional(w.number())}),_b=w.object({email:w.string().email()}),Eb=w.object({otp:w.string()}),$b=w.object({otp:w.string()}),Ab=w.object({themeMode:w.optional(w.enum(["light","dark"])),themeVariables:w.optional(w.record(w.string(),w.string().or(w.number())))}),Sb=w.object({metadata:w.object({name:w.string(),description:w.string(),url:w.string(),icons:w.array(w.string())}).optional(),sdkVersion:w.string(),projectId:w.string()}),Ib=w.object({action:w.enum(["VERIFY_DEVICE","VERIFY_OTP"])}),Rb=w.object({email:w.string().email(),address:w.string(),chainId:w.number()}),Tb=w.object({isConnected:w.boolean()}),Pb=w.object({chainId:w.number()}),Ob=w.object({chainId:w.number()}),kb=w.object({newEmail:w.string().email()}),Nb=w.any(),Mb=w.object({method:w.literal("eth_accounts")}),Lb=w.object({method:w.literal("eth_blockNumber")}),Bb=w.object({method:w.literal("eth_call"),params:w.array(w.any())}),jb=w.object({method:w.literal("eth_chainId")}),Db=w.object({method:w.literal("eth_estimateGas"),params:w.array(w.any())}),Ub=w.object({method:w.literal("eth_feeHistory"),params:w.array(w.any())}),Wb=w.object({method:w.literal("eth_gasPrice")}),zb=w.object({method:w.literal("eth_getAccount"),params:w.array(w.any())}),Fb=w.object({method:w.literal("eth_getBalance"),params:w.array(w.any())}),Hb=w.object({method:w.literal("eth_getBlockByHash"),params:w.array(w.any())}),Vb=w.object({method:w.literal("eth_getBlockByNumber"),params:w.array(w.any())}),Zb=w.object({method:w.literal("eth_getBlockReceipts"),params:w.array(w.any())}),qb=w.object({method:w.literal("eth_getBlockTransactionCountByHash"),params:w.array(w.any())}),Gb=w.object({method:w.literal("eth_getBlockTransactionCountByNumber"),params:w.array(w.any())}),Yb=w.object({method:w.literal("eth_getCode"),params:w.array(w.any())}),Kb=w.object({method:w.literal("eth_getFilterChanges"),params:w.array(w.any())}),Jb=w.object({method:w.literal("eth_getFilterLogs"),params:w.array(w.any())}),Qb=w.object({method:w.literal("eth_getLogs"),params:w.array(w.any())}),Xb=w.object({method:w.literal("eth_getProof"),params:w.array(w.any())}),ev=w.object({method:w.literal("eth_getStorageAt"),params:w.array(w.any())}),tv=w.object({method:w.literal("eth_getTransactionByBlockHashAndIndex"),params:w.array(w.any())}),nv=w.object({method:w.literal("eth_getTransactionByBlockNumberAndIndex"),params:w.array(w.any())}),iv=w.object({method:w.literal("eth_getTransactionByHash"),params:w.array(w.any())}),rv=w.object({method:w.literal("eth_getTransactionCount"),params:w.array(w.any())}),ov=w.object({method:w.literal("eth_getTransactionReceipt"),params:w.array(w.any())}),sv=w.object({method:w.literal("eth_getUncleCountByBlockHash"),params:w.array(w.any())}),av=w.object({method:w.literal("eth_getUncleCountByBlockNumber"),params:w.array(w.any())}),cv=w.object({method:w.literal("eth_maxPriorityFeePerGas")}),lv=w.object({method:w.literal("eth_newBlockFilter")}),uv=w.object({method:w.literal("eth_newFilter"),params:w.array(w.any())}),dv=w.object({method:w.literal("eth_newPendingTransactionFilter")}),hv=w.object({method:w.literal("eth_sendRawTransaction"),params:w.array(w.any())}),pv=w.object({method:w.literal("eth_syncing"),params:w.array(w.any())}),fv=w.object({method:w.literal("eth_uninstallFilter"),params:w.array(w.any())}),Nd=w.object({method:w.literal("personal_sign"),params:w.array(w.any())}),gv=w.object({method:w.literal("eth_signTypedData_v4"),params:w.array(w.any())}),Md=w.object({method:w.literal("eth_sendTransaction"),params:w.array(w.any())}),Ld=w.object({token:w.string()}),As={appEvent:w.object({type:se("APP_SWITCH_NETWORK"),payload:vb}).or(w.object({type:se("APP_CONNECT_EMAIL"),payload:yb})).or(w.object({type:se("APP_CONNECT_DEVICE")})).or(w.object({type:se("APP_CONNECT_OTP"),payload:xb})).or(w.object({type:se("APP_GET_USER"),payload:w.optional(Cb)})).or(w.object({type:se("APP_SIGN_OUT")})).or(w.object({type:se("APP_IS_CONNECTED"),payload:w.optional(Ld)})).or(w.object({type:se("APP_GET_CHAIN_ID")})).or(w.object({type:se("APP_RPC_REQUEST"),payload:Nd.or(Md).or(Mb).or(Lb).or(Bb).or(jb).or(Db).or(Ub).or(Wb).or(zb).or(Fb).or(Hb).or(Vb).or(Zb).or(qb).or(Gb).or(Yb).or(Kb).or(Jb).or(Qb).or(Xb).or(ev).or(tv).or(nv).or(iv).or(rv).or(ov).or(sv).or(av).or(cv).or(lv).or(uv).or(dv).or(hv).or(pv).or(fv).or(Nd).or(gv).or(Md)})).or(w.object({type:se("APP_UPDATE_EMAIL"),payload:_b})).or(w.object({type:se("APP_UPDATE_EMAIL_PRIMARY_OTP"),payload:Eb})).or(w.object({type:se("APP_UPDATE_EMAIL_SECONDARY_OTP"),payload:$b})).or(w.object({type:se("APP_SYNC_THEME"),payload:Ab})).or(w.object({type:se("APP_SYNC_DAPP_DATA"),payload:Sb})),frameEvent:w.object({type:se("FRAME_SWITCH_NETWORK_ERROR"),payload:it}).or(w.object({type:se("FRAME_SWITCH_NETWORK_SUCCESS"),payload:Ob})).or(w.object({type:se("FRAME_CONNECT_EMAIL_ERROR"),payload:it})).or(w.object({type:se("FRAME_CONNECT_EMAIL_SUCCESS"),payload:Ib})).or(w.object({type:se("FRAME_CONNECT_OTP_ERROR"),payload:it})).or(w.object({type:se("FRAME_CONNECT_OTP_SUCCESS")})).or(w.object({type:se("FRAME_CONNECT_DEVICE_ERROR"),payload:it})).or(w.object({type:se("FRAME_CONNECT_DEVICE_SUCCESS")})).or(w.object({type:se("FRAME_GET_USER_ERROR"),payload:it})).or(w.object({type:se("FRAME_GET_USER_SUCCESS"),payload:Rb})).or(w.object({type:se("FRAME_SIGN_OUT_ERROR"),payload:it})).or(w.object({type:se("FRAME_SIGN_OUT_SUCCESS")})).or(w.object({type:se("FRAME_IS_CONNECTED_ERROR"),payload:it})).or(w.object({type:se("FRAME_IS_CONNECTED_SUCCESS"),payload:Tb})).or(w.object({type:se("FRAME_GET_CHAIN_ID_ERROR"),payload:it})).or(w.object({type:se("FRAME_GET_CHAIN_ID_SUCCESS"),payload:Pb})).or(w.object({type:se("FRAME_RPC_REQUEST_ERROR"),payload:it})).or(w.object({type:se("FRAME_RPC_REQUEST_SUCCESS"),payload:Nb})).or(w.object({type:se("FRAME_SESSION_UPDATE"),payload:Ld})).or(w.object({type:se("FRAME_UPDATE_EMAIL_ERROR"),payload:it})).or(w.object({type:se("FRAME_UPDATE_EMAIL_SUCCESS")})).or(w.object({type:se("FRAME_UPDATE_EMAIL_PRIMARY_OTP_ERROR"),payload:it})).or(w.object({type:se("FRAME_UPDATE_EMAIL_PRIMARY_OTP_SUCCESS")})).or(w.object({type:se("FRAME_UPDATE_EMAIL_SECONDARY_OTP_ERROR"),payload:it})).or(w.object({type:se("FRAME_UPDATE_EMAIL_SECONDARY_OTP_SUCCESS"),payload:kb})).or(w.object({type:se("FRAME_SYNC_THEME_ERROR"),payload:it})).or(w.object({type:se("FRAME_SYNC_THEME_SUCCESS")})).or(w.object({type:se("FRAME_SYNC_DAPP_DATA_ERROR"),payload:it})).or(w.object({type:se("FRAME_SYNC_DAPP_DATA_SUCCESS")}))},dt={set(n,e){Ve.isClient&&localStorage.setItem(`${W.STORAGE_KEY}${n}`,e)},get(n){return Ve.isClient?localStorage.getItem(`${W.STORAGE_KEY}${n}`):null},delete(n){Ve.isClient&&localStorage.removeItem(`${W.STORAGE_KEY}${n}`)}},mv=["ASIA/SHANGHAI","ASIA/URUMQI","ASIA/CHONGQING","ASIA/HARBIN","ASIA/KASHGAR","ASIA/MACAU","ASIA/HONG_KONG","ASIA/MACAO","ASIA/BEIJING","ASIA/HARBIN"],Ss=30*1e3,Ve={getBlockchainApiUrl(){try{const{timeZone:n}=new Intl.DateTimeFormat().resolvedOptions(),e=n.toUpperCase();return mv.includes(e)?"https://rpc.walletconnect.org":"https://rpc.walletconnect.com"}catch{return!1}},checkIfAllowedToTriggerEmail(){const n=dt.get(W.LAST_EMAIL_LOGIN_TIME);if(n){const e=Date.now()-Number(n);if(e<Ss){const t=Math.ceil((Ss-e)/1e3);throw new Error(`Please try again after ${t} seconds`)}}},getTimeToNextEmailLogin(){const n=dt.get(W.LAST_EMAIL_LOGIN_TIME);if(n){const e=Date.now()-Number(n);if(e<Ss)return Math.ceil((Ss-e)/1e3)}return 0},checkIfRequestExists(n){var t;const e=(t=n==null?void 0:n.payload)==null?void 0:t.method;return Os.NOT_SAFE_RPC_METHODS.includes(e)||Os.SAFE_RPC_METHODS.includes(e)},checkIfRequestIsAllowed(n){var t;const e=(t=n==null?void 0:n.payload)==null?void 0:t.method;return Os.SAFE_RPC_METHODS.includes(e)},isClient:typeof window<"u"};class wv{constructor(e,t=!1){if(this.iframe=null,this.rpcUrl=Ve.getBlockchainApiUrl(),this.events={onFrameEvent:i=>{Ve.isClient&&window.addEventListener("message",({data:o})=>{var s;if(!((s=o.type)!=null&&s.includes(W.FRAME_EVENT_KEY)))return;const r=As.frameEvent.parse(o);i(r)})},onAppEvent:i=>{Ve.isClient&&window.addEventListener("message",({data:o})=>{var s;if(!((s=o.type)!=null&&s.includes(W.APP_EVENT_KEY)))return;const r=As.appEvent.parse(o);i(r)})},postAppEvent:i=>{var o;if(Ve.isClient){if(!((o=this.iframe)!=null&&o.contentWindow))throw new Error("W3mFrame: iframe is not set");As.appEvent.parse(i),window.postMessage(i),this.iframe.contentWindow.postMessage(i,"*")}},postFrameEvent:i=>{if(Ve.isClient){if(!parent)throw new Error("W3mFrame: parent is not set");As.frameEvent.parse(i),parent.postMessage(i,"*")}}},this.projectId=e,this.frameLoadPromise=new Promise((i,o)=>{this.frameLoadPromiseResolver={resolve:i,reject:o}}),t&&(this.frameLoadPromise=new Promise((i,o)=>{this.frameLoadPromiseResolver={resolve:i,reject:o}}),Ve.isClient)){const i=document.createElement("iframe");i.id="w3m-iframe",i.src=`${W.SECURE_SITE_SDK}?projectId=${e}`,i.style.position="fixed",i.style.zIndex="999999",i.style.display="none",i.style.opacity="0",i.style.borderRadius="clamp(0px, var(--wui-border-radius-l), 44px)",document.body.appendChild(i),this.iframe=i,this.iframe.onload=()=>{var o;(o=this.frameLoadPromiseResolver)==null||o.resolve(void 0)},this.iframe.onerror=()=>{var o;(o=this.frameLoadPromiseResolver)==null||o.reject("Unable to load email login dependency")}}}get networks(){const e=[1,5,11155111,10,420,42161,421613,137,80001,42220,1313161554,1313161555,56,97,43114,43113,324,280,100,8453,84531,7777777,999].map(t=>({[t]:{rpcUrl:`${this.rpcUrl}/v1/?chainId=eip155:${t}&projectId=${this.projectId}`,chainId:t}}));return Object.assign({},...e)}}class bv{constructor(e){this.connectEmailResolver=void 0,this.connectDeviceResolver=void 0,this.connectOtpResolver=void 0,this.connectResolver=void 0,this.disconnectResolver=void 0,this.isConnectedResolver=void 0,this.getChainIdResolver=void 0,this.switchChainResolver=void 0,this.rpcRequestResolver=void 0,this.updateEmailResolver=void 0,this.updateEmailPrimaryOtpResolver=void 0,this.updateEmailSecondaryOtpResolver=void 0,this.syncThemeResolver=void 0,this.syncDappDataResolver=void 0,this.w3mFrame=new wv(e,!0),this.w3mFrame.events.onFrameEvent(t=>{switch(console.log("💻 received",t),t.type){case W.FRAME_CONNECT_EMAIL_SUCCESS:return this.onConnectEmailSuccess(t);case W.FRAME_CONNECT_EMAIL_ERROR:return this.onConnectEmailError(t);case W.FRAME_CONNECT_DEVICE_SUCCESS:return this.onConnectDeviceSuccess();case W.FRAME_CONNECT_DEVICE_ERROR:return this.onConnectDeviceError(t);case W.FRAME_CONNECT_OTP_SUCCESS:return this.onConnectOtpSuccess();case W.FRAME_CONNECT_OTP_ERROR:return this.onConnectOtpError(t);case W.FRAME_GET_USER_SUCCESS:return this.onConnectSuccess(t);case W.FRAME_GET_USER_ERROR:return this.onConnectError(t);case W.FRAME_IS_CONNECTED_SUCCESS:return this.onIsConnectedSuccess(t);case W.FRAME_IS_CONNECTED_ERROR:return this.onIsConnectedError(t);case W.FRAME_GET_CHAIN_ID_SUCCESS:return this.onGetChainIdSuccess(t);case W.FRAME_GET_CHAIN_ID_ERROR:return this.onGetChainIdError(t);case W.FRAME_SIGN_OUT_SUCCESS:return this.onSignOutSuccess();case W.FRAME_SIGN_OUT_ERROR:return this.onSignOutError(t);case W.FRAME_SWITCH_NETWORK_SUCCESS:return this.onSwitchChainSuccess(t);case W.FRAME_SWITCH_NETWORK_ERROR:return this.onSwitchChainError(t);case W.FRAME_RPC_REQUEST_SUCCESS:return this.onRpcRequestSuccess(t);case W.FRAME_RPC_REQUEST_ERROR:return this.onRpcRequestError(t);case W.FRAME_SESSION_UPDATE:return this.onSessionUpdate(t);case W.FRAME_UPDATE_EMAIL_SUCCESS:return this.onUpdateEmailSuccess();case W.FRAME_UPDATE_EMAIL_ERROR:return this.onUpdateEmailError(t);case W.FRAME_UPDATE_EMAIL_PRIMARY_OTP_SUCCESS:return this.onUpdateEmailPrimaryOtpSuccess();case W.FRAME_UPDATE_EMAIL_PRIMARY_OTP_ERROR:return this.onUpdateEmailPrimaryOtpError(t);case W.FRAME_UPDATE_EMAIL_SECONDARY_OTP_SUCCESS:return this.onUpdateEmailSecondaryOtpSuccess(t);case W.FRAME_UPDATE_EMAIL_SECONDARY_OTP_ERROR:return this.onUpdateEmailSecondaryOtpError(t);case W.FRAME_SYNC_THEME_SUCCESS:return this.onSyncThemeSuccess();case W.FRAME_SYNC_THEME_ERROR:return this.onSyncThemeError(t);case W.FRAME_SYNC_DAPP_DATA_SUCCESS:return this.onSyncDappDataSuccess();case W.FRAME_SYNC_DAPP_DATA_ERROR:return this.onSyncDappDataError(t);default:return null}})}getLoginEmailUsed(){return!!dt.get(W.EMAIL_LOGIN_USED_KEY)}getEmail(){return dt.get(W.EMAIL)}rejectRpcRequest(){var e;(e=this.rpcRequestResolver)==null||e.reject()}async connectEmail(e){return await this.w3mFrame.frameLoadPromise,Ve.checkIfAllowedToTriggerEmail(),this.w3mFrame.events.postAppEvent({type:W.APP_CONNECT_EMAIL,payload:e}),new Promise((t,i)=>{this.connectEmailResolver={resolve:t,reject:i}})}async connectDevice(){return await this.w3mFrame.frameLoadPromise,this.w3mFrame.events.postAppEvent({type:W.APP_CONNECT_DEVICE}),new Promise((e,t)=>{this.connectDeviceResolver={resolve:e,reject:t}})}async connectOtp(e){return await this.w3mFrame.frameLoadPromise,this.w3mFrame.events.postAppEvent({type:W.APP_CONNECT_OTP,payload:e}),new Promise((t,i)=>{this.connectOtpResolver={resolve:t,reject:i}})}async isConnected(){return await this.w3mFrame.frameLoadPromise,this.w3mFrame.events.postAppEvent({type:W.APP_IS_CONNECTED,payload:void 0}),new Promise((e,t)=>{this.isConnectedResolver={resolve:e,reject:t}})}async getChainId(){return await this.w3mFrame.frameLoadPromise,this.w3mFrame.events.postAppEvent({type:W.APP_GET_CHAIN_ID}),new Promise((e,t)=>{this.getChainIdResolver={resolve:e,reject:t}})}async updateEmail(e){return await this.w3mFrame.frameLoadPromise,Ve.checkIfAllowedToTriggerEmail(),this.w3mFrame.events.postAppEvent({type:W.APP_UPDATE_EMAIL,payload:e}),new Promise((t,i)=>{this.updateEmailResolver={resolve:t,reject:i}})}async updateEmailPrimaryOtp(e){return await this.w3mFrame.frameLoadPromise,this.w3mFrame.events.postAppEvent({type:W.APP_UPDATE_EMAIL_PRIMARY_OTP,payload:e}),new Promise((t,i)=>{this.updateEmailPrimaryOtpResolver={resolve:t,reject:i}})}async updateEmailSecondaryOtp(e){return await this.w3mFrame.frameLoadPromise,this.w3mFrame.events.postAppEvent({type:W.APP_UPDATE_EMAIL_SECONDARY_OTP,payload:e}),new Promise((t,i)=>{this.updateEmailSecondaryOtpResolver={resolve:t,reject:i}})}async syncTheme(e){return await this.w3mFrame.frameLoadPromise,this.w3mFrame.events.postAppEvent({type:W.APP_SYNC_THEME,payload:e}),new Promise((t,i)=>{this.syncThemeResolver={resolve:t,reject:i}})}async syncDappData(e){return await this.w3mFrame.frameLoadPromise,this.w3mFrame.events.postAppEvent({type:W.APP_SYNC_DAPP_DATA,payload:e}),new Promise((t,i)=>{this.syncDappDataResolver={resolve:t,reject:i}})}async connect(e){const t=(e==null?void 0:e.chainId)??this.getLastUsedChainId()??1;return await this.w3mFrame.frameLoadPromise,this.w3mFrame.events.postAppEvent({type:W.APP_GET_USER,payload:{chainId:t}}),new Promise((i,o)=>{this.connectResolver={resolve:i,reject:o}})}async switchNetwork(e){return await this.w3mFrame.frameLoadPromise,this.w3mFrame.events.postAppEvent({type:W.APP_SWITCH_NETWORK,payload:{chainId:e}}),new Promise((t,i)=>{this.switchChainResolver={resolve:t,reject:i}})}async disconnect(){return await this.w3mFrame.frameLoadPromise,this.w3mFrame.events.postAppEvent({type:W.APP_SIGN_OUT}),new Promise((e,t)=>{this.disconnectResolver={resolve:e,reject:t}})}async request(e){return await this.w3mFrame.frameLoadPromise,Os.GET_CHAIN_ID===e.method?this.getLastUsedChainId():(this.w3mFrame.events.postAppEvent({type:W.APP_RPC_REQUEST,payload:e}),new Promise((t,i)=>{this.rpcRequestResolver={resolve:t,reject:i}}))}onRpcRequest(e){this.w3mFrame.events.onAppEvent(t=>{t.type.includes(W.RPC_METHOD_KEY)&&e(t)})}onRpcResponse(e){this.w3mFrame.events.onFrameEvent(t=>{t.type.includes(W.RPC_METHOD_KEY)&&e(t)})}onIsConnected(e){this.w3mFrame.events.onFrameEvent(t=>{t.type===W.FRAME_GET_USER_SUCCESS&&e()})}onNotConnected(e){this.w3mFrame.events.onFrameEvent(t=>{t.type===W.FRAME_IS_CONNECTED_ERROR&&e(),t.type===W.FRAME_IS_CONNECTED_SUCCESS&&!t.payload.isConnected&&e()})}onConnectEmailSuccess(e){var t;(t=this.connectEmailResolver)==null||t.resolve(e.payload),this.setNewLastEmailLoginTime()}onConnectEmailError(e){var t;(t=this.connectEmailResolver)==null||t.reject(e.payload.message)}onConnectDeviceSuccess(){var e;(e=this.connectDeviceResolver)==null||e.resolve(void 0)}onConnectDeviceError(e){var t;(t=this.connectDeviceResolver)==null||t.reject(e.payload.message)}onConnectOtpSuccess(){var e;(e=this.connectOtpResolver)==null||e.resolve(void 0)}onConnectOtpError(e){var t;(t=this.connectOtpResolver)==null||t.reject(e.payload.message)}onConnectSuccess(e){var t;this.setEmailLoginSuccess(e.payload.email),this.setLastUsedChainId(e.payload.chainId),(t=this.connectResolver)==null||t.resolve(e.payload)}onConnectError(e){var t;(t=this.connectResolver)==null||t.reject(e.payload.message)}onIsConnectedSuccess(e){var t;e.payload.isConnected||this.deleteEmailLoginCache(),(t=this.isConnectedResolver)==null||t.resolve(e.payload)}onIsConnectedError(e){var t;(t=this.isConnectedResolver)==null||t.reject(e.payload.message)}onGetChainIdSuccess(e){var t;this.setLastUsedChainId(e.payload.chainId),(t=this.getChainIdResolver)==null||t.resolve(e.payload)}onGetChainIdError(e){var t;(t=this.getChainIdResolver)==null||t.reject(e.payload.message)}onSignOutSuccess(){var e;(e=this.disconnectResolver)==null||e.resolve(void 0),this.deleteEmailLoginCache()}onSignOutError(e){var t;(t=this.disconnectResolver)==null||t.reject(e.payload.message)}onSwitchChainSuccess(e){var t;this.setLastUsedChainId(e.payload.chainId),(t=this.switchChainResolver)==null||t.resolve(e.payload)}onSwitchChainError(e){var t;(t=this.switchChainResolver)==null||t.reject(e.payload.message)}onRpcRequestSuccess(e){var t;(t=this.rpcRequestResolver)==null||t.resolve(e.payload)}onRpcRequestError(e){var t;(t=this.rpcRequestResolver)==null||t.reject(e.payload.message)}onSessionUpdate(e){}onUpdateEmailSuccess(){var e;(e=this.updateEmailResolver)==null||e.resolve(void 0),this.setNewLastEmailLoginTime()}onUpdateEmailError(e){var t;(t=this.updateEmailResolver)==null||t.reject(e.payload.message)}onUpdateEmailPrimaryOtpSuccess(){var e;(e=this.updateEmailPrimaryOtpResolver)==null||e.resolve(void 0)}onUpdateEmailPrimaryOtpError(e){var t;(t=this.updateEmailPrimaryOtpResolver)==null||t.reject(e.payload.message)}onUpdateEmailSecondaryOtpSuccess(e){var i;const{newEmail:t}=e.payload;this.setEmailLoginSuccess(t),(i=this.updateEmailSecondaryOtpResolver)==null||i.resolve({newEmail:t})}onUpdateEmailSecondaryOtpError(e){var t;(t=this.updateEmailSecondaryOtpResolver)==null||t.reject(e.payload.message)}onSyncThemeSuccess(){var e;(e=this.syncThemeResolver)==null||e.resolve(void 0)}onSyncThemeError(e){var t;(t=this.syncThemeResolver)==null||t.reject(e.payload.message)}onSyncDappDataSuccess(){var e;(e=this.syncDappDataResolver)==null||e.resolve(void 0)}onSyncDappDataError(e){var t;(t=this.syncDappDataResolver)==null||t.reject(e.payload.message)}setNewLastEmailLoginTime(){dt.set(W.LAST_EMAIL_LOGIN_TIME,Date.now().toString())}setEmailLoginSuccess(e){dt.set(W.EMAIL,e),dt.set(W.EMAIL_LOGIN_USED_KEY,"true"),dt.delete(W.LAST_EMAIL_LOGIN_TIME)}deleteEmailLoginCache(){dt.delete(W.EMAIL_LOGIN_USED_KEY),dt.delete(W.EMAIL),dt.delete(W.LAST_USED_CHAIN_KEY)}setLastUsedChainId(e){dt.set(W.LAST_USED_CHAIN_KEY,`${e}`)}getLastUsedChainId(){return Number(dt.get(W.LAST_USED_CHAIN_KEY))}}var Ya=function(n,e,t,i){var o=arguments.length,r=o<3?e:i===null?i=Object.getOwnPropertyDescriptor(e,t):i,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")r=Reflect.decorate(n,e,t,i);else for(var a=n.length-1;a>=0;a--)(s=n[a])&&(r=(o<3?s(r):o>3?s(e,t,r):s(e,t))||r);return o>3&&r&&Object.defineProperty(e,t,r),r};const vv=6;let An=class extends X{firstUpdated(){this.startOTPTimeout()}disconnectedCallback(){clearTimeout(this.OTPTimeout)}constructor(){var e;super(),this.loading=!1,this.timeoutTimeLeft=Ve.getTimeToNextEmailLogin(),this.error="",this.otp="",this.email=(e=j.state.data)==null?void 0:e.email,this.emailConnector=Ee.getEmailConnector()}render(){if(!this.email)throw new Error("w3m-email-otp-widget: No email provided");const e=!!this.timeoutTimeLeft,t=this.getFooterLabels(e);return A`
      <wui-flex
        flexDirection="column"
        alignItems="center"
        .padding=${["l","0","l","0"]}
        gap="l"
      >
        <wui-flex flexDirection="column" alignItems="center">
          <wui-text variant="paragraph-400" color="fg-100">Enter the code we sent to</wui-text>
          <wui-text variant="paragraph-500" color="fg-100">${this.email}</wui-text>
        </wui-flex>

        <wui-text variant="small-400" color="fg-200">The code expires in 10 minutes</wui-text>

        ${this.loading?A`<wui-loading-spinner size="xl" color="accent-100"></wui-loading-spinner>`:A` <wui-flex flexDirection="column" alignItems="center" gap="xs">
              <wui-otp
                dissabled
                length="6"
                @inputChange=${this.onOtpInputChange.bind(this)}
                .otp=${this.otp}
              ></wui-otp>
              ${this.error?A`
                    <wui-text variant="small-400" align="center" color="error-100">
                      ${this.error}. Try Again
                    </wui-text>
                  `:null}
            </wui-flex>`}

        <wui-flex alignItems="center">
          <wui-text variant="small-400" color="fg-200">${t.title}</wui-text>
          <wui-link @click=${this.onResendCode.bind(this)} .disabled=${e}>
            ${t.action}
          </wui-link>
        </wui-flex>
      </wui-flex>
    `}startOTPTimeout(){this.timeoutTimeLeft=Ve.getTimeToNextEmailLogin(),this.OTPTimeout=setInterval(()=>{this.timeoutTimeLeft>0?this.timeoutTimeLeft=Ve.getTimeToNextEmailLogin():clearInterval(this.OTPTimeout)},1e3)}async onOtpInputChange(e){var t;try{this.loading||(this.otp=e.detail,this.emailConnector&&this.otp.length===vv&&(this.loading=!0,await((t=this.onOtpSubmit)==null?void 0:t.call(this,this.otp))))}catch(i){this.error=F.parseError(i),this.loading=!1}}async onResendCode(){try{if(this.onOtpResend){if(!this.loading&&!this.timeoutTimeLeft){if(this.error="",this.otp="",!Ee.getEmailConnector()||!this.email)throw new Error("w3m-email-otp-widget: Unable to resend email");this.loading=!0,await this.onOtpResend(this.email),this.startOTPTimeout(),xe.showSuccess("Code email resent")}}else this.onStartOver&&this.onStartOver()}catch(e){xe.showError(e)}finally{this.loading=!1}}getFooterLabels(e){return this.onStartOver?{title:"Something wrong?",action:`Try again ${e?`in ${this.timeoutTimeLeft}s`:""}`}:{title:"Didn't receive it?",action:`Resend ${e?`in ${this.timeoutTimeLeft}s`:"Code"}`}}};An.styles=y4;Ya([N()],An.prototype,"loading",void 0);Ya([N()],An.prototype,"timeoutTimeLeft",void 0);Ya([N()],An.prototype,"error",void 0);An=Ya([k("w3m-email-otp-widget")],An);var yv=function(n,e,t,i){var o=arguments.length,r=o<3?e:i===null?i=Object.getOwnPropertyDescriptor(e,t):i,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")r=Reflect.decorate(n,e,t,i);else for(var a=n.length-1;a>=0;a--)(s=n[a])&&(r=(o<3?s(r):o>3?s(e,t,r):s(e,t))||r);return o>3&&r&&Object.defineProperty(e,t,r),r};let Bd=class extends An{constructor(){super(),this.onOtpSubmit=async e=>{try{this.emailConnector&&(await this.emailConnector.provider.connectOtp({otp:e}),Y.sendEvent({type:"track",event:"EMAIL_VERIFICATION_CODE_PASS"}),await fe.connectExternal(this.emailConnector),he.close(),Y.sendEvent({type:"track",event:"CONNECT_SUCCESS",properties:{method:"email"}}))}catch(t){throw Y.sendEvent({type:"track",event:"EMAIL_VERIFICATION_CODE_FAIL"}),t}},this.onOtpResend=async e=>{this.emailConnector&&(await this.emailConnector.provider.connectEmail({email:e}),Y.sendEvent({type:"track",event:"EMAIL_VERIFICATION_CODE_SENT"}))}}};Bd=yv([k("w3m-email-verify-otp-view")],Bd);const xv=be`
  wui-icon-box {
    height: var(--wui-icon-box-size-xl);
    width: var(--wui-icon-box-size-xl);
  }
`;var e1=function(n,e,t,i){var o=arguments.length,r=o<3?e:i===null?i=Object.getOwnPropertyDescriptor(e,t):i,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")r=Reflect.decorate(n,e,t,i);else for(var a=n.length-1;a>=0;a--)(s=n[a])&&(r=(o<3?s(r):o>3?s(e,t,r):s(e,t))||r);return o>3&&r&&Object.defineProperty(e,t,r),r};let da=class extends X{constructor(){var e;super(),this.email=(e=j.state.data)==null?void 0:e.email,this.emailConnector=Ee.getEmailConnector(),this.loading=!1,this.listenForDeviceApproval()}render(){if(!this.email)throw new Error("w3m-email-verify-device-view: No email provided");if(!this.emailConnector)throw new Error("w3m-email-verify-device-view: No email connector provided");return A`
      <wui-flex
        flexDirection="column"
        alignItems="center"
        .padding=${["xxl","s","xxl","s"]}
        gap="l"
      >
        <wui-icon-box
          size="xl"
          iconcolor="accent-100"
          backgroundcolor="accent-100"
          icon="verify"
          background="opaque"
        ></wui-icon-box>

        <wui-flex flexDirection="column" alignItems="center" gap="s">
          <wui-flex flexDirection="column" alignItems="center">
            <wui-text variant="paragraph-400" color="fg-100">
              Approve the login link we sent to
            </wui-text>
            <wui-text variant="paragraph-400" color="fg-100"><b>${this.email}</b></wui-text>
          </wui-flex>

          <wui-text variant="small-400" color="fg-200" align="center">
            The code expires in 10 minutes
          </wui-text>

          <wui-flex alignItems="center" id="w3m-resend-section">
            <wui-text variant="small-400" color="fg-100" align="center">
              Didn't receive it?
            </wui-text>
            <wui-link @click=${this.onResendCode.bind(this)} .disabled=${this.loading}>
              Resend email
            </wui-link>
          </wui-flex>
        </wui-flex>
      </wui-flex>
    `}async listenForDeviceApproval(){if(this.emailConnector)try{await this.emailConnector.provider.connectDevice(),Y.sendEvent({type:"track",event:"DEVICE_REGISTERED_FOR_EMAIL"}),Y.sendEvent({type:"track",event:"EMAIL_VERIFICATION_CODE_SENT"}),j.replace("EmailVerifyOtp",{email:this.email})}catch{j.goBack()}}async onResendCode(){try{if(!this.loading){if(!this.emailConnector||!this.email)throw new Error("w3m-email-login-widget: Unable to resend email");this.loading=!0,await this.emailConnector.provider.connectEmail({email:this.email}),xe.showSuccess("Code email resent")}}catch(e){xe.showError(e)}finally{this.loading=!1}}};da.styles=xv;e1([N()],da.prototype,"loading",void 0);da=e1([k("w3m-email-verify-device-view")],da);const Cv=be`
  div {
    width: 100%;
    height: 400px;
  }

  [data-ready='false'] {
    transform: scale(1.05);
  }

  @media (max-width: 430px) {
    [data-ready='false'] {
      transform: translateY(-50px);
    }
  }
`;var t1=function(n,e,t,i){var o=arguments.length,r=o<3?e:i===null?i=Object.getOwnPropertyDescriptor(e,t):i,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")r=Reflect.decorate(n,e,t,i);else for(var a=n.length-1;a>=0;a--)(s=n[a])&&(r=(o<3?s(r):o>3?s(e,t,r):s(e,t))||r);return o>3&&r&&Object.defineProperty(e,t,r),r};let ha=class extends X{constructor(){super(),this.bodyObserver=void 0,this.unsubscribe=[],this.iframe=document.getElementById("w3m-iframe"),this.ready=!1,this.unsubscribe.push(he.subscribeKey("open",e=>{e||this.onHideIframe()}))}disconnectedCallback(){var e;this.unsubscribe.forEach(t=>t()),(e=this.bodyObserver)==null||e.unobserve(window.document.body)}async firstUpdated(){await this.syncTheme(),this.iframe.style.display="block";const t=this.renderRoot.querySelector("div");this.bodyObserver=new ResizeObserver(()=>{const o=(t==null?void 0:t.getBoundingClientRect())??{left:0,top:0,width:0,height:0};this.iframe.style.width=`${o.width}px`,this.iframe.style.height=`${o.height-10}px`,this.iframe.style.left=`${o.left}px`,this.iframe.style.top=`${o.top+10/2}px`,this.ready=!0}),this.bodyObserver.observe(window.document.body)}render(){return this.ready&&this.onShowIframe(),A`<div data-ready=${this.ready}></div>`}onShowIframe(){const e=window.innerWidth<=430;this.iframe.animate([{opacity:0,transform:e?"translateY(50px)":"scale(.95)"},{opacity:1,transform:e?"translateY(0)":"scale(1)"}],{duration:200,easing:"ease",fill:"forwards",delay:300})}async onHideIframe(){await this.iframe.animate([{opacity:1},{opacity:0}],{duration:200,easing:"ease",fill:"forwards"}).finished,this.iframe.style.display="none"}async syncTheme(){const e=Ee.getEmailConnector();e&&await e.provider.syncTheme({themeVariables:Fe.getSnapshot().themeVariables})}};ha.styles=Cv;t1([N()],ha.prototype,"ready",void 0);ha=t1([k("w3m-approve-transaction-view")],ha);var _v=function(n,e,t,i){var o=arguments.length,r=o<3?e:i===null?i=Object.getOwnPropertyDescriptor(e,t):i,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")r=Reflect.decorate(n,e,t,i);else for(var a=n.length-1;a>=0;a--)(s=n[a])&&(r=(o<3?s(r):o>3?s(e,t,r):s(e,t))||r);return o>3&&r&&Object.defineProperty(e,t,r),r};let jd=class extends X{render(){return A`
      <wui-flex flexDirection="column" alignItems="center" gap="xl" padding="xl">
        <wui-text variant="paragraph-400" color="fg-100">Follow the instructions on</wui-text>
        <wui-chip
          icon="externalLink"
          variant="fill"
          href=${pt.SECURE_SITE_DASHBOARD}
          imageSrc=${pt.SECURE_SITE_FAVICON}
        >
        </wui-chip>
        <wui-text variant="small-400" color="fg-200">
          You will have to reconnect for security reasons
        </wui-text>
      </wui-flex>
    `}};jd=_v([k("w3m-upgrade-wallet-view")],jd);/**
 * @license
 * Copyright 2020 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const Ev=n=>n.strings===void 0;/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const $v={ATTRIBUTE:1,CHILD:2,PROPERTY:3,BOOLEAN_ATTRIBUTE:4,EVENT:5,ELEMENT:6},Av=n=>(...e)=>({_$litDirective$:n,values:e});let Sv=class{constructor(e){}get _$AU(){return this._$AM._$AU}_$AT(e,t,i){this._$Ct=e,this._$AM=t,this._$Ci=i}_$AS(e,t){return this.update(e,t)}update(e,t){return this.render(...t)}};/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const uo=(n,e)=>{var i;const t=n._$AN;if(t===void 0)return!1;for(const o of t)(i=o._$AO)==null||i.call(o,e,!1),uo(o,e);return!0},pa=n=>{let e,t;do{if((e=n._$AM)===void 0)break;t=e._$AN,t.delete(n),n=e}while((t==null?void 0:t.size)===0)},n1=n=>{for(let e;e=n._$AM;n=e){let t=e._$AN;if(t===void 0)e._$AN=t=new Set;else if(t.has(n))break;t.add(n),Tv(e)}};function Iv(n){this._$AN!==void 0?(pa(this),this._$AM=n,n1(this)):this._$AM=n}function Rv(n,e=!1,t=0){const i=this._$AH,o=this._$AN;if(o!==void 0&&o.size!==0)if(e)if(Array.isArray(i))for(let r=t;r<i.length;r++)uo(i[r],!1),pa(i[r]);else i!=null&&(uo(i,!1),pa(i));else uo(this,n)}const Tv=n=>{n.type==$v.CHILD&&(n._$AP??(n._$AP=Rv),n._$AQ??(n._$AQ=Iv))};class Pv extends Sv{constructor(){super(...arguments),this._$AN=void 0}_$AT(e,t,i){super._$AT(e,t,i),n1(this),this.isConnected=e._$AU}_$AO(e,t=!0){var i,o;e!==this.isConnected&&(this.isConnected=e,e?(i=this.reconnected)==null||i.call(this):(o=this.disconnected)==null||o.call(this)),t&&(uo(this,e),pa(this))}setValue(e){if(Ev(this._$Ct))this._$Ct._$AI(e,this);else{const t=[...this._$Ct._$AH];t[this._$Ci]=e,this._$Ct._$AI(t,this,0)}}disconnected(){}reconnected(){}}/**
 * @license
 * Copyright 2020 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const i1=()=>new Ov;class Ov{}const Rc=new WeakMap,r1=Av(class extends Pv{render(n){return Be}update(n,[e]){var i;const t=e!==this.Y;return t&&this.Y!==void 0&&this.rt(void 0),(t||this.lt!==this.ct)&&(this.Y=e,this.ht=(i=n.options)==null?void 0:i.host,this.rt(this.ct=n.element)),Be}rt(n){if(typeof this.Y=="function"){const e=this.ht??globalThis;let t=Rc.get(e);t===void 0&&(t=new WeakMap,Rc.set(e,t)),t.get(this.Y)!==void 0&&this.Y.call(this.ht,void 0),t.set(this.Y,n),n!==void 0&&this.Y.call(this.ht,n)}else this.Y.value=n}get lt(){var n,e;return typeof this.Y=="function"?(n=Rc.get(this.ht??globalThis))==null?void 0:n.get(this.Y):(e=this.Y)==null?void 0:e.value}disconnected(){this.lt===this.ct&&this.rt(void 0)}reconnected(){this.rt(this.ct)}}),kv=be`
  wui-email-input {
    width: 100%;
  }

  form {
    width: 100%;
    display: block;
    position: relative;
  }
`;var su=function(n,e,t,i){var o=arguments.length,r=o<3?e:i===null?i=Object.getOwnPropertyDescriptor(e,t):i,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")r=Reflect.decorate(n,e,t,i);else for(var a=n.length-1;a>=0;a--)(s=n[a])&&(r=(o<3?s(r):o>3?s(e,t,r):s(e,t))||r);return o>3&&r&&Object.defineProperty(e,t,r),r};let is=class extends X{constructor(){var e;super(...arguments),this.formRef=i1(),this.initialEmail=((e=j.state.data)==null?void 0:e.email)??"",this.email="",this.loading=!1}firstUpdated(){var e;(e=this.formRef.value)==null||e.addEventListener("keydown",t=>{t.key==="Enter"&&this.onSubmitEmail(t)})}render(){const e=!this.loading&&this.email.length>3&&this.email!==this.initialEmail;return A`
      <wui-flex flexDirection="column" padding="m" gap="m">
        <form ${r1(this.formRef)} @submit=${this.onSubmitEmail.bind(this)}>
          <wui-email-input
            value=${this.initialEmail}
            .disabled=${this.loading}
            @inputChange=${this.onEmailInputChange.bind(this)}
          >
          </wui-email-input>
          <input type="submit" hidden />
        </form>

        <wui-flex gap="s">
          <wui-button size="md" variant="shade" fullWidth @click=${j.goBack}>
            Cancel
          </wui-button>

          <wui-button
            size="md"
            variant="fill"
            fullWidth
            @click=${this.onSubmitEmail.bind(this)}
            .disabled=${!e}
            .loading=${this.loading}
          >
            Save
          </wui-button>
        </wui-flex>
      </wui-flex>
    `}onEmailInputChange(e){this.email=e.detail}async onSubmitEmail(e){try{if(this.loading)return;this.loading=!0,e.preventDefault();const t=Ee.getEmailConnector();if(!t)throw new Error("w3m-update-email-wallet: Email connector not found");await t.provider.updateEmail({email:this.email}),Y.sendEvent({type:"track",event:"EMAIL_EDIT"}),j.replace("UpdateEmailPrimaryOtp",{email:this.initialEmail,newEmail:this.email})}catch(t){xe.showError(t),this.loading=!1}}};is.styles=kv;su([N()],is.prototype,"email",void 0);su([N()],is.prototype,"loading",void 0);is=su([k("w3m-update-email-wallet-view")],is);var Nv=function(n,e,t,i){var o=arguments.length,r=o<3?e:i===null?i=Object.getOwnPropertyDescriptor(e,t):i,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")r=Reflect.decorate(n,e,t,i);else for(var a=n.length-1;a>=0;a--)(s=n[a])&&(r=(o<3?s(r):o>3?s(e,t,r):s(e,t))||r);return o>3&&r&&Object.defineProperty(e,t,r),r};let Dd=class extends An{constructor(){var e;super(),this.email=(e=j.state.data)==null?void 0:e.email,this.onOtpSubmit=async t=>{try{this.emailConnector&&(await this.emailConnector.provider.updateEmailPrimaryOtp({otp:t}),Y.sendEvent({type:"track",event:"EMAIL_VERIFICATION_CODE_PASS"}),j.replace("UpdateEmailSecondaryOtp",j.state.data))}catch(i){throw Y.sendEvent({type:"track",event:"EMAIL_VERIFICATION_CODE_FAIL"}),i}},this.onStartOver=()=>{j.replace("UpdateEmailWallet",j.state.data)}}};Dd=Nv([k("w3m-update-email-primary-otp-view")],Dd);var Mv=function(n,e,t,i){var o=arguments.length,r=o<3?e:i===null?i=Object.getOwnPropertyDescriptor(e,t):i,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")r=Reflect.decorate(n,e,t,i);else for(var a=n.length-1;a>=0;a--)(s=n[a])&&(r=(o<3?s(r):o>3?s(e,t,r):s(e,t))||r);return o>3&&r&&Object.defineProperty(e,t,r),r};let Ud=class extends An{constructor(){var e;super(),this.email=(e=j.state.data)==null?void 0:e.newEmail,this.onOtpSubmit=async t=>{try{this.emailConnector&&(await this.emailConnector.provider.updateEmailSecondaryOtp({otp:t}),Y.sendEvent({type:"track",event:"EMAIL_VERIFICATION_CODE_PASS"}),j.reset("Account"))}catch(i){throw Y.sendEvent({type:"track",event:"EMAIL_VERIFICATION_CODE_FAIL"}),i}},this.onStartOver=()=>{j.replace("UpdateEmailWallet",j.state.data)}}};Ud=Mv([k("w3m-update-email-secondary-otp-view")],Ud);const Lv=be`
  :host > wui-flex {
    max-height: clamp(360px, 540px, 80vh);
    overflow: scroll;
    scrollbar-width: none;
  }

  :host > wui-flex::-webkit-scrollbar {
    display: none;
  }
`;var o1=function(n,e,t,i){var o=arguments.length,r=o<3?e:i===null?i=Object.getOwnPropertyDescriptor(e,t):i,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")r=Reflect.decorate(n,e,t,i);else for(var a=n.length-1;a>=0;a--)(s=n[a])&&(r=(o<3?s(r):o>3?s(e,t,r):s(e,t))||r);return o>3&&r&&Object.defineProperty(e,t,r),r};let fa=class extends X{constructor(){super(...arguments),this.disconecting=!1}render(){return A`
      <wui-flex class="container" flexDirection="column" gap="0">
        <wui-flex
          class="container"
          flexDirection="column"
          .padding=${["m","xl","xs","xl"]}
          alignItems="center"
          gap="xl"
        >
          <wui-text variant="small-400" color="fg-200" align="center">
            This app doesn’t support your current network. Switch to an available option following
            to continue.
          </wui-text>
        </wui-flex>

        <wui-flex flexDirection="column" padding="s" gap="xs">
          ${this.networksTemplate()}
        </wui-flex>

        <wui-separator text="or"></wui-separator>
        <wui-flex flexDirection="column" padding="s" gap="xs">
          <wui-list-item
            variant="icon"
            iconVariant="overlay"
            icon="disconnect"
            ?chevron=${!1}
            .loading=${this.disconecting}
            @click=${this.onDisconnect.bind(this)}
            data-testid="disconnect-button"
          >
            <wui-text variant="paragraph-500" color="fg-200">Disconnect</wui-text>
          </wui-list-item>
        </wui-flex>
      </wui-flex>
    `}networksTemplate(){const{approvedCaipNetworkIds:e,requestedCaipNetworks:t}=ge.state;return F.sortRequestedNetworks(e,t).map(o=>A`
        <wui-list-network
          imageSrc=${le(Se.getNetworkImage(o))}
          name=${o.name??"Unknown"}
          @click=${()=>this.onSwitchNetwork(o)}
        >
        </wui-list-network>
      `)}async onDisconnect(){try{this.disconecting=!0,await fe.disconnect(),Y.sendEvent({type:"track",event:"DISCONNECT_SUCCESS"}),he.close()}catch{Y.sendEvent({type:"track",event:"DISCONNECT_ERROR"}),xe.showError("Failed to disconnect")}finally{this.disconecting=!1}}async onSwitchNetwork(e){const{isConnected:t}=ne.state,{approvedCaipNetworkIds:i,supportsAllNetworks:o,caipNetwork:r}=ge.state,{data:s}=j.state;t&&(r==null?void 0:r.id)!==e.id?i!=null&&i.includes(e.id)?(await ge.switchActiveNetwork(e),kl.navigateAfterNetworkSwitch()):o&&j.push("SwitchNetwork",{...s,network:e}):t||(ge.setCaipNetwork(e),j.push("Connect"))}};fa.styles=Lv;o1([N()],fa.prototype,"disconecting",void 0);fa=o1([k("w3m-unsupported-chain-view")],fa);const Bv=be`
  wui-grid {
    max-height: clamp(360px, 400px, 80vh);
    overflow: scroll;
    scrollbar-width: none;
    grid-auto-rows: min-content;
    grid-template-columns: repeat(auto-fill, 76px);
  }

  @media (max-width: 435px) {
    wui-grid {
      grid-template-columns: repeat(auto-fill, 77px);
    }
  }

  wui-grid[data-scroll='false'] {
    overflow: hidden;
  }

  wui-grid::-webkit-scrollbar {
    display: none;
  }

  wui-loading-spinner {
    padding-top: var(--wui-spacing-l);
    padding-bottom: var(--wui-spacing-l);
    justify-content: center;
    grid-column: 1 / span 4;
  }
`;function s1(n){const{connectors:e}=Ee.state,t=e.filter(r=>r.type==="ANNOUNCED").reduce((r,s)=>{var a;return(a=s.info)!=null&&a.rdns&&(r[s.info.rdns]=!0),r},{});return n.map(r=>({...r,installed:!!r.rdns&&!!t[r.rdns??""]})).sort((r,s)=>Number(s.installed)-Number(r.installed))}var gs=function(n,e,t,i){var o=arguments.length,r=o<3?e:i===null?i=Object.getOwnPropertyDescriptor(e,t):i,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")r=Reflect.decorate(n,e,t,i);else for(var a=n.length-1;a>=0;a--)(s=n[a])&&(r=(o<3?s(r):o>3?s(e,t,r):s(e,t))||r);return o>3&&r&&Object.defineProperty(e,t,r),r};const Wd="local-paginator";let Wi=class extends X{constructor(){super(),this.unsubscribe=[],this.paginationObserver=void 0,this.initial=!ie.state.wallets.length,this.wallets=ie.state.wallets,this.recommended=ie.state.recommended,this.featured=ie.state.featured,this.unsubscribe.push(ie.subscribeKey("wallets",e=>this.wallets=e),ie.subscribeKey("recommended",e=>this.recommended=e),ie.subscribeKey("featured",e=>this.featured=e))}firstUpdated(){this.initialFetch(),this.createPaginationObserver()}disconnectedCallback(){var e;this.unsubscribe.forEach(t=>t()),(e=this.paginationObserver)==null||e.disconnect()}render(){return A`
      <wui-grid
        data-scroll=${!this.initial}
        .padding=${["0","s","s","s"]}
        columnGap="xxs"
        rowGap="l"
        justifyContent="space-between"
      >
        ${this.initial?this.shimmerTemplate(16):this.walletsTemplate()}
        ${this.paginationLoaderTemplate()}
      </wui-grid>
    `}async initialFetch(){var t;const e=(t=this.shadowRoot)==null?void 0:t.querySelector("wui-grid");this.initial&&e&&(await ie.fetchWallets({page:1}),await e.animate([{opacity:1},{opacity:0}],{duration:200,fill:"forwards",easing:"ease"}).finished,this.initial=!1,e.animate([{opacity:0},{opacity:1}],{duration:200,fill:"forwards",easing:"ease"}))}shimmerTemplate(e,t){return[...Array(e)].map(()=>A`
        <wui-card-select-loader type="wallet" id=${le(t)}></wui-card-select-loader>
      `)}walletsTemplate(){const e=[...this.featured,...this.recommended,...this.wallets];return s1(e).map(i=>A`
        <wui-card-select
          imageSrc=${le(Se.getWalletImage(i))}
          type="wallet"
          name=${i.name}
          @click=${()=>this.onConnectWallet(i)}
          .installed=${i.installed}
        ></wui-card-select>
      `)}paginationLoaderTemplate(){const{wallets:e,recommended:t,featured:i,count:o}=ie.state,r=window.innerWidth<352?3:4,s=e.length+t.length;let c=Math.ceil(s/r)*r-s+r;return c-=e.length?i.length%r:0,o===0&&i.length>0?null:o===0||[...i,...e,...t].length<o?this.shimmerTemplate(c,Wd):null}createPaginationObserver(){var t;const e=(t=this.shadowRoot)==null?void 0:t.querySelector(`#${Wd}`);e&&(this.paginationObserver=new IntersectionObserver(([i])=>{if(i!=null&&i.isIntersecting&&!this.initial){const{page:o,count:r,wallets:s}=ie.state;s.length<r&&ie.fetchWallets({page:o+1})}}),this.paginationObserver.observe(e))}onConnectWallet(e){const{connectors:t}=Ee.state,i=t.find(({explorerId:o})=>o===e.id);i?j.push("ConnectingExternal",{connector:i}):j.push("ConnectingWalletConnect",{wallet:e})}};Wi.styles=Bv;gs([N()],Wi.prototype,"initial",void 0);gs([N()],Wi.prototype,"wallets",void 0);gs([N()],Wi.prototype,"recommended",void 0);gs([N()],Wi.prototype,"featured",void 0);Wi=gs([k("w3m-all-wallets-list")],Wi);const jv=be`
  wui-grid,
  wui-loading-spinner,
  wui-flex {
    height: 360px;
  }

  wui-grid {
    overflow: scroll;
    scrollbar-width: none;
    grid-auto-rows: min-content;
  }

  wui-grid[data-scroll='false'] {
    overflow: hidden;
  }

  wui-grid::-webkit-scrollbar {
    display: none;
  }

  wui-loading-spinner {
    justify-content: center;
    align-items: center;
  }
`;var au=function(n,e,t,i){var o=arguments.length,r=o<3?e:i===null?i=Object.getOwnPropertyDescriptor(e,t):i,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")r=Reflect.decorate(n,e,t,i);else for(var a=n.length-1;a>=0;a--)(s=n[a])&&(r=(o<3?s(r):o>3?s(e,t,r):s(e,t))||r);return o>3&&r&&Object.defineProperty(e,t,r),r};let rs=class extends X{constructor(){super(...arguments),this.prevQuery="",this.loading=!0,this.query=""}render(){return this.onSearch(),this.loading?A`<wui-loading-spinner color="accent-100"></wui-loading-spinner>`:this.walletsTemplate()}async onSearch(){this.query!==this.prevQuery&&(this.prevQuery=this.query,this.loading=!0,await ie.searchWallet({search:this.query}),this.loading=!1)}walletsTemplate(){const{search:e}=ie.state,t=s1(e);return e.length?A`
      <wui-grid
        .padding=${["0","s","s","s"]}
        gridTemplateColumns="repeat(4, 1fr)"
        rowGap="l"
        columnGap="xs"
      >
        ${t.map(i=>A`
            <wui-card-select
              imageSrc=${le(Se.getWalletImage(i))}
              type="wallet"
              name=${i.name}
              @click=${()=>this.onConnectWallet(i)}
              .installed=${i.installed}
            ></wui-card-select>
          `)}
      </wui-grid>
    `:A`
        <wui-flex justifyContent="center" alignItems="center" gap="s" flexDirection="column">
          <wui-icon-box
            size="lg"
            iconColor="fg-200"
            backgroundColor="fg-300"
            icon="wallet"
            background="transparent"
          ></wui-icon-box>
          <wui-text color="fg-200" variant="paragraph-500">No Wallet found</wui-text>
        </wui-flex>
      `}onConnectWallet(e){const{connectors:t}=Ee.state,i=t.find(({explorerId:o})=>o===e.id);i?j.push("ConnectingExternal",{connector:i}):j.push("ConnectingWalletConnect",{wallet:e})}};rs.styles=jv;au([N()],rs.prototype,"loading",void 0);au([Ce()],rs.prototype,"query",void 0);rs=au([k("w3m-all-wallets-search")],rs);var Ka=function(n,e,t,i){var o=arguments.length,r=o<3?e:i===null?i=Object.getOwnPropertyDescriptor(e,t):i,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")r=Reflect.decorate(n,e,t,i);else for(var a=n.length-1;a>=0;a--)(s=n[a])&&(r=(o<3?s(r):o>3?s(e,t,r):s(e,t))||r);return o>3&&r&&Object.defineProperty(e,t,r),r};let os=class extends X{constructor(){super(),this.platformTabs=[],this.unsubscribe=[],this.platforms=[],this.onSelectPlatfrom=void 0,this.buffering=!1,this.unsubscribe.push(fe.subscribeKey("buffering",e=>this.buffering=e))}disconnectCallback(){this.unsubscribe.forEach(e=>e())}render(){const e=this.generateTabs();return A`
      <wui-flex justifyContent="center" .padding=${["l","0","0","0"]}>
        <wui-tabs
          ?disabled=${this.buffering}
          .tabs=${e}
          .onTabChange=${this.onTabChange.bind(this)}
        ></wui-tabs>
      </wui-flex>
    `}generateTabs(){const e=this.platforms.map(t=>t==="browser"?{label:"Browser",icon:"extension",platform:"browser"}:t==="mobile"?{label:"Mobile",icon:"mobile",platform:"mobile"}:t==="qrcode"?{label:"Mobile",icon:"mobile",platform:"qrcode"}:t==="web"?{label:"Webapp",icon:"browser",platform:"web"}:t==="desktop"?{label:"Desktop",icon:"desktop",platform:"desktop"}:{label:"Browser",icon:"extension",platform:"unsupported"});return this.platformTabs=e.map(({platform:t})=>t),e}onTabChange(e){var i;const t=this.platformTabs[e];t&&((i=this.onSelectPlatfrom)==null||i.call(this,t))}};Ka([Ce({type:Array})],os.prototype,"platforms",void 0);Ka([Ce()],os.prototype,"onSelectPlatfrom",void 0);Ka([N()],os.prototype,"buffering",void 0);os=Ka([k("w3m-connecting-header")],os);var Dv=function(n,e,t,i){var o=arguments.length,r=o<3?e:i===null?i=Object.getOwnPropertyDescriptor(e,t):i,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")r=Reflect.decorate(n,e,t,i);else for(var a=n.length-1;a>=0;a--)(s=n[a])&&(r=(o<3?s(r):o>3?s(e,t,r):s(e,t))||r);return o>3&&r&&Object.defineProperty(e,t,r),r};let zd=class extends lt{constructor(){if(super(),!this.wallet)throw new Error("w3m-connecting-wc-browser: No wallet provided");this.onConnect=this.onConnectProxy.bind(this),this.onAutoConnect=this.onConnectProxy.bind(this),Y.sendEvent({type:"track",event:"SELECT_WALLET",properties:{name:this.wallet.name,platform:"browser"}})}async onConnectProxy(){try{this.error=!1;const{connectors:e}=Ee.state,t=e.find(o=>{var r,s;return o.type==="ANNOUNCED"&&((r=o.info)==null?void 0:r.rdns)===((s=this.wallet)==null?void 0:s.rdns)}),i=e.find(o=>o.type==="INJECTED");t?await fe.connectExternal(t):i&&await fe.connectExternal(i),he.close(),Y.sendEvent({type:"track",event:"CONNECT_SUCCESS",properties:{method:"browser"}})}catch(e){Y.sendEvent({type:"track",event:"CONNECT_ERROR",properties:{message:(e==null?void 0:e.message)??"Unknown"}}),this.error=!0}}};zd=Dv([k("w3m-connecting-wc-browser")],zd);var Uv=function(n,e,t,i){var o=arguments.length,r=o<3?e:i===null?i=Object.getOwnPropertyDescriptor(e,t):i,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")r=Reflect.decorate(n,e,t,i);else for(var a=n.length-1;a>=0;a--)(s=n[a])&&(r=(o<3?s(r):o>3?s(e,t,r):s(e,t))||r);return o>3&&r&&Object.defineProperty(e,t,r),r};let Fd=class extends lt{constructor(){if(super(),!this.wallet)throw new Error("w3m-connecting-wc-desktop: No wallet provided");this.onConnect=this.onConnectProxy.bind(this),this.onRender=this.onRenderProxy.bind(this),Y.sendEvent({type:"track",event:"SELECT_WALLET",properties:{name:this.wallet.name,platform:"desktop"}})}onRenderProxy(){!this.ready&&this.uri&&(this.ready=!0,this.timeout=setTimeout(()=>{var e;(e=this.onConnect)==null||e.call(this)},200))}onConnectProxy(){var e;if((e=this.wallet)!=null&&e.desktop_link&&this.uri)try{this.error=!1;const{desktop_link:t,name:i}=this.wallet,{redirect:o,href:r}=F.formatNativeUrl(t,this.uri);fe.setWcLinking({name:i,href:r}),fe.setRecentWallet(this.wallet),F.openHref(o,"_blank")}catch{this.error=!0}}};Fd=Uv([k("w3m-connecting-wc-desktop")],Fd);var Wv=function(n,e,t,i){var o=arguments.length,r=o<3?e:i===null?i=Object.getOwnPropertyDescriptor(e,t):i,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")r=Reflect.decorate(n,e,t,i);else for(var a=n.length-1;a>=0;a--)(s=n[a])&&(r=(o<3?s(r):o>3?s(e,t,r):s(e,t))||r);return o>3&&r&&Object.defineProperty(e,t,r),r};let Hd=class extends lt{constructor(){if(super(),!this.wallet)throw new Error("w3m-connecting-wc-mobile: No wallet provided");this.onConnect=this.onConnectProxy.bind(this),this.onRender=this.onRenderProxy.bind(this),document.addEventListener("visibilitychange",this.onBuffering.bind(this)),Y.sendEvent({type:"track",event:"SELECT_WALLET",properties:{name:this.wallet.name,platform:"mobile"}})}disconnectedCallback(){super.disconnectedCallback(),document.removeEventListener("visibilitychange",this.onBuffering.bind(this))}onRenderProxy(){var e;!this.ready&&this.uri&&(this.ready=!0,(e=this.onConnect)==null||e.call(this))}onConnectProxy(){var e;if((e=this.wallet)!=null&&e.mobile_link&&this.uri)try{this.error=!1;const{mobile_link:t,name:i}=this.wallet,{redirect:o,href:r}=F.formatNativeUrl(t,this.uri);fe.setWcLinking({name:i,href:r}),fe.setRecentWallet(this.wallet),F.openHref(o,"_self")}catch{this.error=!0}}onBuffering(){const e=F.isIos();(document==null?void 0:document.visibilityState)==="visible"&&!this.error&&e&&(fe.setBuffering(!0),setTimeout(()=>{fe.setBuffering(!1)},5e3))}};Hd=Wv([k("w3m-connecting-wc-mobile")],Hd);const zv=be`
  @keyframes fadein {
    from {
      opacity: 0;
    }
    to {
      opacity: 1;
    }
  }

  wui-shimmer {
    width: 100%;
    aspect-ratio: 1 / 1;
    border-radius: clamp(0px, var(--wui-border-radius-l), 40px) !important;
  }

  wui-qr-code {
    opacity: 0;
    animation-duration: 200ms;
    animation-timing-function: ease;
    animation-name: fadein;
    animation-fill-mode: forwards;
  }
`;var Fv=function(n,e,t,i){var o=arguments.length,r=o<3?e:i===null?i=Object.getOwnPropertyDescriptor(e,t):i,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")r=Reflect.decorate(n,e,t,i);else for(var a=n.length-1;a>=0;a--)(s=n[a])&&(r=(o<3?s(r):o>3?s(e,t,r):s(e,t))||r);return o>3&&r&&Object.defineProperty(e,t,r),r};let pl=class extends lt{constructor(){var e;super(),this.forceUpdate=()=>{this.requestUpdate()},window.addEventListener("resize",this.forceUpdate),Y.sendEvent({type:"track",event:"SELECT_WALLET",properties:{name:((e=this.wallet)==null?void 0:e.name)??"WalletConnect",platform:"qrcode"}})}disconnectedCallback(){super.disconnectedCallback(),window.removeEventListener("resize",this.forceUpdate)}render(){return this.onRenderProxy(),A`
      <wui-flex padding="xl" flexDirection="column" gap="xl" alignItems="center">
        <wui-shimmer borderRadius="l" width="100%"> ${this.qrCodeTemplate()} </wui-shimmer>

        <wui-text variant="paragraph-500" color="fg-100">
          Scan this QR Code with your phone
        </wui-text>
        ${this.copyTemplate()}
      </wui-flex>

      <w3m-mobile-download-links .wallet=${this.wallet}></w3m-mobile-download-links>
    `}onRenderProxy(){!this.ready&&this.uri&&(this.timeout=setTimeout(()=>{this.ready=!0},200))}qrCodeTemplate(){if(!this.uri||!this.ready)return null;const e=this.getBoundingClientRect().width-40,t=this.wallet?this.wallet.name:void 0;return fe.setWcLinking(void 0),fe.setRecentWallet(this.wallet),A` <wui-qr-code
      size=${e}
      theme=${Fe.state.themeMode}
      uri=${this.uri}
      imageSrc=${le(Se.getWalletImage(this.wallet))}
      alt=${le(t)}
      data-testid="wui-qr-code"
    ></wui-qr-code>`}copyTemplate(){const e=!this.uri||!this.ready;return A`<wui-link
      .disabled=${e}
      @click=${this.onCopyUri}
      color="fg-200"
      data-testid="copy-wc2-uri"
    >
      <wui-icon size="xs" color="fg-200" slot="iconLeft" name="copy"></wui-icon>
      Copy link
    </wui-link>`}};pl.styles=zv;pl=Fv([k("w3m-connecting-wc-qrcode")],pl);const Hv=be`
  :host {
    display: flex;
    justify-content: center;
    gap: var(--wui-spacing-2xl);
  }

  wui-visual-thumbnail:nth-child(1) {
    z-index: 1;
  }
`;var Vv=function(n,e,t,i){var o=arguments.length,r=o<3?e:i===null?i=Object.getOwnPropertyDescriptor(e,t):i,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")r=Reflect.decorate(n,e,t,i);else for(var a=n.length-1;a>=0;a--)(s=n[a])&&(r=(o<3?s(r):o>3?s(e,t,r):s(e,t))||r);return o>3&&r&&Object.defineProperty(e,t,r),r};let fl=class extends X{constructor(){var e;super(...arguments),this.dappImageUrl=(e=ce.state.metadata)==null?void 0:e.icons,this.walletImageUrl=Ze.getConnectedWalletImageUrl()}firstUpdated(){var t;const e=(t=this.shadowRoot)==null?void 0:t.querySelectorAll("wui-visual-thumbnail");e!=null&&e[0]&&this.createAnimation(e[0],"translate(18px)"),e!=null&&e[1]&&this.createAnimation(e[1],"translate(-18px)")}render(){var e;return A`
      <wui-visual-thumbnail
        ?borderRadiusFull=${!0}
        .imageSrc=${(e=this.dappImageUrl)==null?void 0:e[0]}
      ></wui-visual-thumbnail>
      <wui-visual-thumbnail .imageSrc=${this.walletImageUrl}></wui-visual-thumbnail>
    `}createAnimation(e,t){e.animate([{transform:"translateX(0px)"},{transform:t}],{duration:1600,easing:"cubic-bezier(0.56, 0, 0.48, 1)",direction:"alternate",iterations:1/0})}};fl.styles=Hv;fl=Vv([k("w3m-connecting-siwe")],fl);var Zv=function(n,e,t,i){var o=arguments.length,r=o<3?e:i===null?i=Object.getOwnPropertyDescriptor(e,t):i,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")r=Reflect.decorate(n,e,t,i);else for(var a=n.length-1;a>=0;a--)(s=n[a])&&(r=(o<3?s(r):o>3?s(e,t,r):s(e,t))||r);return o>3&&r&&Object.defineProperty(e,t,r),r};let Vd=class extends X{constructor(){var e;if(super(),this.wallet=(e=j.state.data)==null?void 0:e.wallet,!this.wallet)throw new Error("w3m-connecting-wc-unsupported: No wallet provided");Y.sendEvent({type:"track",event:"SELECT_WALLET",properties:{name:this.wallet.name,platform:"browser"}})}render(){return A`
      <wui-flex
        flexDirection="column"
        alignItems="center"
        .padding=${["3xl","xl","xl","xl"]}
        gap="xl"
      >
        <wui-wallet-image
          size="lg"
          imageSrc=${le(Se.getWalletImage(this.wallet))}
        ></wui-wallet-image>

        <wui-text variant="paragraph-500" color="fg-100">Not Detected</wui-text>
      </wui-flex>

      <w3m-mobile-download-links .wallet=${this.wallet}></w3m-mobile-download-links>
    `}};Vd=Zv([k("w3m-connecting-wc-unsupported")],Vd);var qv=function(n,e,t,i){var o=arguments.length,r=o<3?e:i===null?i=Object.getOwnPropertyDescriptor(e,t):i,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")r=Reflect.decorate(n,e,t,i);else for(var a=n.length-1;a>=0;a--)(s=n[a])&&(r=(o<3?s(r):o>3?s(e,t,r):s(e,t))||r);return o>3&&r&&Object.defineProperty(e,t,r),r};let Zd=class extends lt{constructor(){if(super(),!this.wallet)throw new Error("w3m-connecting-wc-web: No wallet provided");this.onConnect=this.onConnectProxy.bind(this),this.secondaryBtnLabel="Open",this.secondaryLabel="Open and continue in a new browser tab",this.secondaryBtnIcon="externalLink",Y.sendEvent({type:"track",event:"SELECT_WALLET",properties:{name:this.wallet.name,platform:"web"}})}onConnectProxy(){var e;if((e=this.wallet)!=null&&e.webapp_link&&this.uri)try{this.error=!1;const{webapp_link:t,name:i}=this.wallet,{redirect:o,href:r}=F.formatUniversalUrl(t,this.uri);fe.setWcLinking({name:i,href:r}),fe.setRecentWallet(this.wallet),F.openHref(o,"_blank")}catch{this.error=!0}}};Zd=qv([k("w3m-connecting-wc-web")],Zd);const Gv=be`
  wui-icon-link[data-hidden='true'] {
    opacity: 0 !important;
    pointer-events: none;
  }
`;var Ja=function(n,e,t,i){var o=arguments.length,r=o<3?e:i===null?i=Object.getOwnPropertyDescriptor(e,t):i,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")r=Reflect.decorate(n,e,t,i);else for(var a=n.length-1;a>=0;a--)(s=n[a])&&(r=(o<3?s(r):o>3?s(e,t,r):s(e,t))||r);return o>3&&r&&Object.defineProperty(e,t,r),r};function qd(){var s,a,c,u,h,p,g;const n=(a=(s=j.state.data)==null?void 0:s.connector)==null?void 0:a.name,e=(u=(c=j.state.data)==null?void 0:c.wallet)==null?void 0:u.name,t=(p=(h=j.state.data)==null?void 0:h.network)==null?void 0:p.name,i=e??n,o=Ee.getConnectors();return{Connect:`Connect ${o.length===1&&((g=o[0])==null?void 0:g.id)==="w3m-email"?"Email":""} Wallet`,Account:void 0,AccountSettings:void 0,ConnectingExternal:i??"Connect Wallet",ConnectingWalletConnect:i??"WalletConnect",ConnectingSiwe:"Sign In",Networks:"Choose Network",SwitchNetwork:t??"Switch Network",AllWallets:"All Wallets",WhatIsANetwork:"What is a network?",WhatIsAWallet:"What is a wallet?",GetWallet:"Get a wallet",Downloads:i?`Get ${i}`:"Downloads",EmailVerifyOtp:"Confirm Email",EmailVerifyDevice:"Register Device",ApproveTransaction:"Approve Transaction",Transactions:"Activity",UpgradeEmailWallet:"Upgrade your Wallet",UpdateEmailWallet:"Edit Email",UpdateEmailPrimaryOtp:"Confirm Current Email",UpdateEmailSecondaryOtp:"Confirm New Email",UnsupportedChain:"Switch Network",OnRampProviders:"Choose Provider",OnRampActivity:"Activity",WhatIsABuy:"What is Buy?",BuyInProgress:"Buy",OnRampTokenSelect:"Select Token",OnRampFiatSelect:"Select Currency"}}let Br=class extends X{constructor(){super(),this.unsubscribe=[],this.heading=qd()[j.state.view],this.buffering=!1,this.showBack=!1,this.unsubscribe.push(j.subscribeKey("view",e=>{this.onViewChange(e),this.onHistoryChange()}),fe.subscribeKey("buffering",e=>this.buffering=e))}disconnectCallback(){this.unsubscribe.forEach(e=>e())}render(){return A`
      <wui-flex .padding=${this.getPadding()} justifyContent="space-between" alignItems="center">
        ${this.dynamicButtonTemplate()} ${this.titleTemplate()}
        <wui-icon-link
          ?disabled=${this.buffering}
          icon="close"
          @click=${this.onClose.bind(this)}
          data-testid="w3m-header-close"
        ></wui-icon-link>
      </wui-flex>
      ${this.separatorTemplate()}
    `}onWalletHelp(){Y.sendEvent({type:"track",event:"CLICK_WALLET_HELP"}),j.push("WhatIsAWallet")}async onClose(){Me.state.isSiweEnabled&&Me.state.status!=="success"&&await fe.disconnect(),he.close()}titleTemplate(){return A`<wui-text variant="paragraph-700" color="fg-100">${this.heading}</wui-text>`}dynamicButtonTemplate(){const{view:e}=j.state,t=e==="Connect",i=e==="ApproveTransaction";return this.showBack&&!i?A`<wui-icon-link
        id="dynamic"
        icon="chevronLeft"
        ?disabled=${this.buffering}
        @click=${this.onGoBack.bind(this)}
      ></wui-icon-link>`:A`<wui-icon-link
      data-hidden=${!t}
      id="dynamic"
      icon="helpCircle"
      @click=${this.onWalletHelp.bind(this)}
    ></wui-icon-link>`}separatorTemplate(){return this.heading?A`<wui-separator></wui-separator>`:null}getPadding(){return this.heading?["l","2l","l","2l"]:["l","2l","0","2l"]}async onViewChange(e){var i;const t=(i=this.shadowRoot)==null?void 0:i.querySelector("wui-text");if(t){const o=qd()[e];await t.animate([{opacity:1},{opacity:0}],{duration:200,fill:"forwards",easing:"ease"}).finished,this.heading=o,t.animate([{opacity:0},{opacity:1}],{duration:200,fill:"forwards",easing:"ease"})}}async onHistoryChange(){var i;const{history:e}=j.state,t=(i=this.shadowRoot)==null?void 0:i.querySelector("#dynamic");e.length>1&&!this.showBack&&t?(await t.animate([{opacity:1},{opacity:0}],{duration:200,fill:"forwards",easing:"ease"}).finished,this.showBack=!0,t.animate([{opacity:0},{opacity:1}],{duration:200,fill:"forwards",easing:"ease"})):e.length<=1&&this.showBack&&t&&(await t.animate([{opacity:1},{opacity:0}],{duration:200,fill:"forwards",easing:"ease"}).finished,this.showBack=!1,t.animate([{opacity:0},{opacity:1}],{duration:200,fill:"forwards",easing:"ease"}))}onGoBack(){j.state.view==="ConnectingSiwe"?j.push("Connect"):j.goBack()}};Br.styles=[Gv];Ja([N()],Br.prototype,"heading",void 0);Ja([N()],Br.prototype,"buffering",void 0);Ja([N()],Br.prototype,"showBack",void 0);Br=Ja([k("w3m-header")],Br);var a1=function(n,e,t,i){var o=arguments.length,r=o<3?e:i===null?i=Object.getOwnPropertyDescriptor(e,t):i,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")r=Reflect.decorate(n,e,t,i);else for(var a=n.length-1;a>=0;a--)(s=n[a])&&(r=(o<3?s(r):o>3?s(e,t,r):s(e,t))||r);return o>3&&r&&Object.defineProperty(e,t,r),r};let gl=class extends X{constructor(){super(...arguments),this.data=[]}render(){return A`
      <wui-flex flexDirection="column" alignItems="center" gap="l">
        ${this.data.map(e=>A`
            <wui-flex flexDirection="column" alignItems="center" gap="xl">
              <wui-flex flexDirection="row" justifyContent="center" gap="1xs">
                ${e.images.map(t=>A`<wui-visual name=${t}></wui-visual>`)}
              </wui-flex>
            </wui-flex>
            <wui-flex flexDirection="column" alignItems="center" gap="xxs">
              <wui-text variant="paragraph-500" color="fg-100" align="center">
                ${e.title}
              </wui-text>
              <wui-text variant="small-500" color="fg-200" align="center">${e.text}</wui-text>
            </wui-flex>
          `)}
      </wui-flex>
    `}};a1([Ce({type:Array})],gl.prototype,"data",void 0);gl=a1([k("w3m-help-widget")],gl);const Yv=be`
  :host {
    width: 100%;
  }

  wui-loading-spinner {
    position: absolute;
    top: 50%;
    right: 20px;
    transform: translateY(-50%);
  }

  .currency-container {
    position: absolute;
    top: 50%;
    transform: translateY(-50%);
    transition: all var(--wui-ease-in-power-2) var(--wui-duration-md);
    right: var(--wui-spacing-1xs);
    height: 40px;
    padding: var(--wui-spacing-xs) var(--wui-spacing-1xs) var(--wui-spacing-xs)
      var(--wui-spacing-xs);
    min-width: 95px;
    border-radius: var(--FULL, 1000px);
    border: 1px solid var(--wui-gray-glass-002);
    background: var(--wui-gray-glass-002);
    cursor: pointer;
  }

  .currency-container > wui-image {
    height: 24px;
    width: 24px;
    border-radius: 50%;
  }
`;var Gi=function(n,e,t,i){var o=arguments.length,r=o<3?e:i===null?i=Object.getOwnPropertyDescriptor(e,t):i,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")r=Reflect.decorate(n,e,t,i);else for(var a=n.length-1;a>=0;a--)(s=n[a])&&(r=(o<3?s(r):o>3?s(e,t,r):s(e,t))||r);return o>3&&r&&Object.defineProperty(e,t,r),r};let Sn=class extends X{constructor(){var e;super(),this.unsubscribe=[],this.type="Token",this.value=0,this.currencies=[],this.selectedCurrency=(e=this.currencies)==null?void 0:e[0],this.currencyImages=He.state.currencyImages,this.tokenImages=He.state.tokenImages,this.unsubscribe.push(ve.subscribeKey("purchaseCurrency",t=>{!t||this.type==="Fiat"||(this.selectedCurrency=this.formatPurchaseCurrency(t))}),ve.subscribeKey("paymentCurrency",t=>{!t||this.type==="Token"||(this.selectedCurrency=this.formatPaymentCurrency(t))}),ve.subscribe(t=>{this.type==="Fiat"?this.currencies=t.purchaseCurrencies.map(this.formatPurchaseCurrency):this.currencies=t.paymentCurrencies.map(this.formatPaymentCurrency)}),He.subscribe(t=>{this.currencyImages={...t.currencyImages},this.tokenImages={...t.tokenImages}}))}firstUpdated(){ve.getAvailableCurrencies()}disconnectedCallback(){this.unsubscribe.forEach(e=>e())}render(){var i;const e=((i=this.selectedCurrency)==null?void 0:i.symbol)||"",t=this.currencyImages[e]||this.tokenImages[e];return A` <wui-input-text type="number" size="lg" value=${this.value}>
      ${this.selectedCurrency?A` <wui-flex
            class="currency-container"
            justifyContent="space-between"
            alignItems="center"
            gap="xxs"
            @click=${()=>he.open({view:`OnRamp${this.type}Select`})}
          >
            <wui-image src=${le(t)}></wui-image>
            <wui-text color="fg-100"> ${this.selectedCurrency.symbol} </wui-text>
          </wui-flex>`:A`<wui-loading-spinner></wui-loading-spinner>`}
    </wui-input-text>`}formatPaymentCurrency(e){return{name:e.id,symbol:e.id}}formatPurchaseCurrency(e){return{name:e.name,symbol:e.symbol}}};Sn.styles=Yv;Gi([Ce({type:String})],Sn.prototype,"type",void 0);Gi([Ce({type:Number})],Sn.prototype,"value",void 0);Gi([N()],Sn.prototype,"currencies",void 0);Gi([N()],Sn.prototype,"selectedCurrency",void 0);Gi([N()],Sn.prototype,"currencyImages",void 0);Gi([N()],Sn.prototype,"tokenImages",void 0);Sn=Gi([k("w3m-swap-input")],Sn);const Kv=be`
  wui-flex {
    background-color: var(--wui-gray-glass-005);
  }

  a {
    text-decoration: none;
    color: var(--wui-color-fg-175);
    font-weight: 500;
  }
`;var Jv=function(n,e,t,i){var o=arguments.length,r=o<3?e:i===null?i=Object.getOwnPropertyDescriptor(e,t):i,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")r=Reflect.decorate(n,e,t,i);else for(var a=n.length-1;a>=0;a--)(s=n[a])&&(r=(o<3?s(r):o>3?s(e,t,r):s(e,t))||r);return o>3&&r&&Object.defineProperty(e,t,r),r};let ml=class extends X{render(){const{termsConditionsUrl:e,privacyPolicyUrl:t}=ce.state;return!e&&!t?null:A`
      <wui-flex .padding=${["m","s","s","s"]} justifyContent="center">
        <wui-text color="fg-250" variant="small-400" align="center">
          By connecting your wallet, you agree to our <br />
          ${this.termsTemplate()} ${this.andTemplate()} ${this.privacyTemplate()}
        </wui-text>
      </wui-flex>
    `}andTemplate(){const{termsConditionsUrl:e,privacyPolicyUrl:t}=ce.state;return e&&t?"and":""}termsTemplate(){const{termsConditionsUrl:e}=ce.state;return e?A`<a href=${e}>Terms of Service</a>`:null}privacyTemplate(){const{privacyPolicyUrl:e}=ce.state;return e?A`<a href=${e}>Privacy Policy</a>`:null}};ml.styles=[Kv];ml=Jv([k("w3m-legal-footer")],ml);const Qv=be`
  :host {
    display: block;
    padding: 0 var(--wui-spacing-xl) var(--wui-spacing-xl);
  }
`;var c1=function(n,e,t,i){var o=arguments.length,r=o<3?e:i===null?i=Object.getOwnPropertyDescriptor(e,t):i,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")r=Reflect.decorate(n,e,t,i);else for(var a=n.length-1;a>=0;a--)(s=n[a])&&(r=(o<3?s(r):o>3?s(e,t,r):s(e,t))||r);return o>3&&r&&Object.defineProperty(e,t,r),r};let ga=class extends X{constructor(){super(...arguments),this.wallet=void 0}render(){if(!this.wallet)return this.style.display="none",null;const{name:e,app_store:t,play_store:i,chrome_store:o,homepage:r}=this.wallet,s=F.isMobile(),a=F.isIos(),c=F.isAndroid(),u=[t,i,r,o].filter(Boolean).length>1,h=ye.getTruncateString({string:e,charsStart:12,charsEnd:0,truncate:"end"});return u&&!s?A`
        <wui-cta-button
          label=${`Don't have ${h}?`}
          buttonLabel="Get"
          @click=${()=>j.push("Downloads",{wallet:this.wallet})}
        ></wui-cta-button>
      `:!u&&r?A`
        <wui-cta-button
          label=${`Don't have ${h}?`}
          buttonLabel="Get"
          @click=${this.onHomePage.bind(this)}
        ></wui-cta-button>
      `:t&&a?A`
        <wui-cta-button
          label=${`Don't have ${h}?`}
          buttonLabel="Get"
          @click=${this.onAppStore.bind(this)}
        ></wui-cta-button>
      `:i&&c?A`
        <wui-cta-button
          label=${`Don't have ${h}?`}
          buttonLabel="Get"
          @click=${this.onPlayStore.bind(this)}
        ></wui-cta-button>
      `:(this.style.display="none",null)}onAppStore(){var e;(e=this.wallet)!=null&&e.app_store&&F.openHref(this.wallet.app_store,"_blank")}onPlayStore(){var e;(e=this.wallet)!=null&&e.play_store&&F.openHref(this.wallet.play_store,"_blank")}onHomePage(){var e;(e=this.wallet)!=null&&e.homepage&&F.openHref(this.wallet.homepage,"_blank")}};ga.styles=[Qv];c1([Ce({type:Object})],ga.prototype,"wallet",void 0);ga=c1([k("w3m-mobile-download-links")],ga);const Xv=be`
  wui-flex {
    border-top: 1px solid var(--wui-gray-glass-005);
  }

  a {
    text-decoration: none;
    color: var(--wui-color-fg-175);
    font-weight: 500;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: var(--wui-spacing-3xs);
  }
`;var ey=function(n,e,t,i){var o=arguments.length,r=o<3?e:i===null?i=Object.getOwnPropertyDescriptor(e,t):i,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")r=Reflect.decorate(n,e,t,i);else for(var a=n.length-1;a>=0;a--)(s=n[a])&&(r=(o<3?s(r):o>3?s(e,t,r):s(e,t))||r);return o>3&&r&&Object.defineProperty(e,t,r),r};let wl=class extends X{render(){const{termsConditionsUrl:e,privacyPolicyUrl:t}=ce.state;return!e&&!t?null:A`
      <wui-flex
        .padding=${["m","s","s","s"]}
        flexDirection="column"
        alignItems="center"
        justifyContent="center"
        gap="s"
      >
        <wui-text color="fg-250" variant="small-400" align="center">
          We work with the best providers to fit your buyer needs, region, and to get you the lowest
          fees
        </wui-text>

        ${this.whatIsBuyTemplate()}
      </wui-flex>
    `}whatIsBuyTemplate(){return A` <wui-link @click=${this.onWhatIsBuy.bind(this)}>
      <wui-icon size="xs" color="accent-100" slot="iconLeft" name="helpCircle"></wui-icon>
      What is Buy
    </wui-link>`}onWhatIsBuy(){j.push("WhatIsABuy")}};wl.styles=[Xv];wl=ey([k("w3m-onramp-providers-footer")],wl);const ty=be`
  :host {
    display: block;
    position: absolute;
    opacity: 0;
    pointer-events: none;
    top: 11px;
    left: 50%;
    width: max-content;
  }
`;var l1=function(n,e,t,i){var o=arguments.length,r=o<3?e:i===null?i=Object.getOwnPropertyDescriptor(e,t):i,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")r=Reflect.decorate(n,e,t,i);else for(var a=n.length-1;a>=0;a--)(s=n[a])&&(r=(o<3?s(r):o>3?s(e,t,r):s(e,t))||r);return o>3&&r&&Object.defineProperty(e,t,r),r};const ny={success:{backgroundColor:"success-100",iconColor:"success-100",icon:"checkmark"},error:{backgroundColor:"error-100",iconColor:"error-100",icon:"close"}};let ma=class extends X{constructor(){super(),this.unsubscribe=[],this.timeout=void 0,this.open=xe.state.open,this.unsubscribe.push(xe.subscribeKey("open",e=>{this.open=e,this.onOpen()}))}disconnectedCallback(){clearTimeout(this.timeout),this.unsubscribe.forEach(e=>e())}render(){const{message:e,variant:t}=xe.state,i=ny[t];return A`
      <wui-snackbar
        message=${e}
        backgroundColor=${i.backgroundColor}
        iconColor=${i.iconColor}
        icon=${i.icon}
      ></wui-snackbar>
    `}onOpen(){clearTimeout(this.timeout),this.open?(this.animate([{opacity:0,transform:"translateX(-50%) scale(0.85)"},{opacity:1,transform:"translateX(-50%) scale(1)"}],{duration:150,fill:"forwards",easing:"ease"}),this.timeout=setTimeout(()=>xe.hide(),2500)):this.animate([{opacity:1,transform:"translateX(-50%) scale(1)"},{opacity:0,transform:"translateX(-50%) scale(0.85)"}],{duration:150,fill:"forwards",easing:"ease"})}};ma.styles=ty;l1([N()],ma.prototype,"open",void 0);ma=l1([k("w3m-snackbar")],ma);const iy=be`
  wui-separator {
    margin: var(--wui-spacing-s) calc(var(--wui-spacing-s) * -1);
    width: calc(100% + var(--wui-spacing-s) * 2);
  }

  wui-email-input {
    width: 100%;
  }

  form {
    width: 100%;
    display: block;
    position: relative;
  }

  wui-icon-link,
  wui-loading-spinner {
    position: absolute;
    top: 21px;
    transform: translateY(-50%);
  }

  wui-icon-link {
    right: var(--wui-spacing-xs);
  }

  wui-loading-spinner {
    right: var(--wui-spacing-m);
  }

  .betaBanner {
    padding: 10px 12px 10px 10px;
    border-radius: var(--wui-border-radius-s);
    background: var(--wui-accent-glass-010);
    margin-bottom: var(--wui-spacing-s);
  }
`;var ms=function(n,e,t,i){var o=arguments.length,r=o<3?e:i===null?i=Object.getOwnPropertyDescriptor(e,t):i,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")r=Reflect.decorate(n,e,t,i);else for(var a=n.length-1;a>=0;a--)(s=n[a])&&(r=(o<3?s(r):o>3?s(e,t,r):s(e,t))||r);return o>3&&r&&Object.defineProperty(e,t,r),r};let zi=class extends X{constructor(){super(),this.unsubscribe=[],this.formRef=i1(),this.connectors=Ee.state.connectors,this.email="",this.loading=!1,this.error="",this.unsubscribe.push(Ee.subscribeKey("connectors",e=>this.connectors=e))}disconnectedCallback(){this.unsubscribe.forEach(e=>e())}firstUpdated(){var e;(e=this.formRef.value)==null||e.addEventListener("keydown",t=>{t.key==="Enter"&&this.onSubmitEmail(t)})}render(){const e=this.connectors.length>1;return this.connectors.find(i=>i.type==="EMAIL")?A`
      ${this.betaWarningTemplate()}
      <form ${r1(this.formRef)} @submit=${this.onSubmitEmail.bind(this)}>
        <wui-email-input
          @focus=${this.onFocusEvent.bind(this)}
          .disabled=${this.loading}
          @inputChange=${this.onEmailInputChange.bind(this)}
          .errorMessage=${this.error}
        >
        </wui-email-input>

        ${this.submitButtonTemplate()}${this.loadingTemplate()}
        <input type="submit" hidden />
      </form>

      ${e?A`<wui-separator text="or"></wui-separator>`:null}
    `:null}betaWarningTemplate(){return A`
          <wui-flex class="betaBanner" gap="xs" alignItems="center" justifyContent="center">
            <wui-text variant="small-400" color="accent-100">Email login is in beta</wui-text>
          </wui-flex>
        `}submitButtonTemplate(){return!this.loading&&this.email.length>3?A`
          <wui-icon-link
            size="sm"
            icon="chevronRight"
            iconcolor="accent-100"
            @click=${this.onSubmitEmail.bind(this)}
          >
          </wui-icon-link>
        `:null}loadingTemplate(){return this.loading?A`<wui-loading-spinner size="md" color="accent-100"></wui-loading-spinner>`:null}onEmailInputChange(e){this.email=e.detail,this.error=""}async onSubmitEmail(e){try{if(this.loading)return;this.loading=!0,e.preventDefault();const t=Ee.getEmailConnector();if(!t)throw new Error("w3m-email-login-widget: Email connector not found");const{action:i}=await t.provider.connectEmail({email:this.email});Y.sendEvent({type:"track",event:"EMAIL_SUBMITTED"}),i==="VERIFY_OTP"?(Y.sendEvent({type:"track",event:"EMAIL_VERIFICATION_CODE_SENT"}),j.push("EmailVerifyOtp",{email:this.email})):i==="VERIFY_DEVICE"&&j.push("EmailVerifyDevice",{email:this.email})}catch(t){const i=F.parseError(t);i!=null&&i.includes("Invalid email")?this.error="Invalid email. Try again.":xe.showError(t)}finally{this.loading=!1}}onFocusEvent(){Y.sendEvent({type:"track",event:"EMAIL_LOGIN_SELECTED"})}};zi.styles=iy;ms([N()],zi.prototype,"connectors",void 0);ms([N()],zi.prototype,"email",void 0);ms([N()],zi.prototype,"loading",void 0);ms([N()],zi.prototype,"error",void 0);zi=ms([k("w3m-email-login-widget")],zi);let Gd=!1;class ry{constructor(e){this.initPromise=void 0,this.setIsConnected=t=>{ne.setIsConnected(t)},this.setCaipAddress=t=>{ne.setCaipAddress(t)},this.setBalance=(t,i)=>{ne.setBalance(t,i)},this.setProfileName=t=>{ne.setProfileName(t)},this.setProfileImage=t=>{ne.setProfileImage(t)},this.resetAccount=()=>{ne.resetAccount()},this.setCaipNetwork=t=>{ge.setCaipNetwork(t)},this.getCaipNetwork=()=>ge.state.caipNetwork,this.setRequestedCaipNetworks=t=>{ge.setRequestedCaipNetworks(t)},this.getApprovedCaipNetworksData=()=>ge.getApprovedCaipNetworksData(),this.resetNetwork=()=>{ge.resetNetwork()},this.setConnectors=t=>{Ee.setConnectors(t)},this.addConnector=t=>{Ee.addConnector(t)},this.getConnectors=()=>Ee.getConnectors(),this.resetWcConnection=()=>{fe.resetWcConnection()},this.fetchIdentity=t=>mr.fetchIdentity(t),this.setAddressExplorerUrl=t=>{ne.setAddressExplorerUrl(t)},this.setSIWENonce=t=>{Me.setNonce(t)},this.setSIWESession=t=>{Me.setSession(t)},this.setSIWEStatus=t=>{Me.setStatus(t)},this.setSIWEMessage=t=>{Me.setMessage(t)},this.initControllers(e),this.initOrContinue()}async open(e){await this.initOrContinue(),he.open(e)}async close(){await this.initOrContinue(),he.close()}setLoading(e){he.setLoading(e)}getThemeMode(){return Fe.state.themeMode}getThemeVariables(){return Fe.state.themeVariables}setThemeMode(e){Fe.setThemeMode(e),jl(Fe.state.themeMode)}setThemeVariables(e){Fe.setThemeVariables(e),nh(Fe.state.themeVariables)}subscribeTheme(e){return Fe.subscribe(e)}getState(){return{...gr.state}}subscribeState(e){return gr.subscribe(e)}showErrorMessage(e){xe.showError(e)}showSuccessMessage(e){xe.showSuccess(e)}getEvent(){return{...Y.state}}subscribeEvents(e){return Y.subscribe(e)}subscribeSIWEState(e){return Me.subscribe(e)}initControllers(e){if(ge.setClient(e.networkControllerClient),ge.setDefaultCaipNetwork(e.defaultChain),ce.setProjectId(e.projectId),ce.setAllWallets(e.allWallets),ce.setIncludeWalletIds(e.includeWalletIds),ce.setExcludeWalletIds(e.excludeWalletIds),ce.setFeaturedWalletIds(e.featuredWalletIds),ce.setTokens(e.tokens),ce.setTermsConditionsUrl(e.termsConditionsUrl),ce.setPrivacyPolicyUrl(e.privacyPolicyUrl),ce.setCustomWallets(e.customWallets),ce.setEnableAnalytics(e.enableAnalytics),ce.setSdkVersion(e._sdkVersion),fe.setClient(e.connectionControllerClient),e.siweControllerClient){const t=e.siweControllerClient;Me.setSIWEClient(t)}e.metadata&&ce.setMetadata(e.metadata),e.themeMode&&Fe.setThemeMode(e.themeMode),e.themeVariables&&Fe.setThemeVariables(e.themeVariables),e.enableOnramp&&ce.setOnrampEnabled(!!e.enableOnramp)}async initOrContinue(){return!this.initPromise&&!Gd&&F.isClient()&&(Gd=!0,this.initPromise=new Promise(async e=>{await Promise.all([ho(()=>Promise.resolve().then(()=>x5),void 0,import.meta.url),ho(()=>Promise.resolve().then(()=>V5),void 0,import.meta.url)]);const t=document.createElement("w3m-modal");document.body.insertAdjacentElement("beforeend",t),e()})),this.initPromise}}const ae={WALLET_CONNECT_CONNECTOR_ID:"walletConnect",INJECTED_CONNECTOR_ID:"injected",COINBASE_CONNECTOR_ID:"coinbaseWallet",COINBASE_SDK_CONNECTOR_ID:"coinbaseWalletSDK",SAFE_CONNECTOR_ID:"safe",LEDGER_CONNECTOR_ID:"ledger",EIP6963_CONNECTOR_ID:"eip6963",EMAIL_CONNECTOR_ID:"w3mEmail",EIP155:"eip155",ADD_CHAIN_METHOD:"wallet_addEthereumChain",EIP6963_ANNOUNCE_EVENT:"eip6963:announceProvider",EIP6963_REQUEST_EVENT:"eip6963:requestProvider",VERSION:"4.0.10"},vn={ConnectorExplorerIds:{[ae.COINBASE_CONNECTOR_ID]:"fd20dc426fb37566d803205b19bbc1d4096b248ac04548e3cfb6b3a38bd033aa",[ae.SAFE_CONNECTOR_ID]:"225affb176778569276e484e1b92637ad061b01e13a048b35a9d280c3b58970f",[ae.LEDGER_CONNECTOR_ID]:"19177a98252e07ddfc9af2083ba8e07ef627cb6103467ffebb3f8f4205fd7927"},EIP155NetworkImageIds:{1:"692ed6ba-e569-459a-556a-776476829e00",42161:"3bff954d-5cb0-47a0-9a23-d20192e74600",43114:"30c46e53-e989-45fb-4549-be3bd4eb3b00",56:"93564157-2e8e-4ce7-81df-b264dbee9b00",250:"06b26297-fe0c-4733-5d6b-ffa5498aac00",10:"ab9c186a-c52f-464b-2906-ca59d760a400",137:"41d04d42-da3b-4453-8506-668cc0727900",100:"02b53f6a-e3d4-479e-1cb4-21178987d100",9001:"f926ff41-260d-4028-635e-91913fc28e00",324:"b310f07f-4ef7-49f3-7073-2a0a39685800",314:"5a73b3dd-af74-424e-cae0-0de859ee9400",4689:"34e68754-e536-40da-c153-6ef2e7188a00",1088:"3897a66d-40b9-4833-162f-a2c90531c900",1284:"161038da-44ae-4ec7-1208-0ea569454b00",1285:"f1d73bb6-5450-4e18-38f7-fb6484264a00",7777777:"845c60df-d429-4991-e687-91ae45791600",42220:"ab781bbc-ccc6-418d-d32d-789b15da1f00",8453:"7289c336-3981-4081-c5f4-efc26ac64a00",1313161554:"3ff73439-a619-4894-9262-4470c773a100",2020:"b8101fc0-9c19-4b6f-ec65-f6dfff106e00",2021:"b8101fc0-9c19-4b6f-ec65-f6dfff106e00"},ConnectorImageIds:{[ae.COINBASE_CONNECTOR_ID]:"0c2840c3-5b04-4c44-9661-fbd4b49e1800",[ae.COINBASE_SDK_CONNECTOR_ID]:"0c2840c3-5b04-4c44-9661-fbd4b49e1800",[ae.SAFE_CONNECTOR_ID]:"461db637-8616-43ce-035a-d89b8a1d5800",[ae.LEDGER_CONNECTOR_ID]:"54a1aa77-d202-4f8d-0fb2-5d2bb6db0300",[ae.WALLET_CONNECT_CONNECTOR_ID]:"ef1a1fcf-7fe8-4d69-bd6d-fda1345b4400",[ae.INJECTED_CONNECTOR_ID]:"07ba87ed-43aa-4adf-4540-9e6a2b9cae00"},ConnectorNamesMap:{[ae.INJECTED_CONNECTOR_ID]:"Browser Wallet",[ae.WALLET_CONNECT_CONNECTOR_ID]:"WalletConnect",[ae.COINBASE_CONNECTOR_ID]:"Coinbase",[ae.COINBASE_SDK_CONNECTOR_ID]:"Coinbase",[ae.LEDGER_CONNECTOR_ID]:"Ledger",[ae.SAFE_CONNECTOR_ID]:"Safe"},ConnectorTypesMap:{[ae.INJECTED_CONNECTOR_ID]:"INJECTED",[ae.WALLET_CONNECT_CONNECTOR_ID]:"WALLET_CONNECT",[ae.EIP6963_CONNECTOR_ID]:"ANNOUNCED",[ae.EMAIL_CONNECTOR_ID]:"EMAIL"},WalletConnectRpcChainIds:[1,5,11155111,10,420,42161,421613,137,80001,42220,1313161554,1313161555,56,97,43114,43113,100,8453,84531,7777777,999,324,280]},er={caipNetworkIdToNumber(n){return n?Number(n.split(":")[1]):void 0},getCaipTokens(n){if(!n)return;const e={};return Object.entries(n).forEach(([t,i])=>{e[`${ae.EIP155}:${t}`]=i}),e}};function oy(n){if(n)return{id:`${ae.EIP155}:${n.id}`,name:n.name,imageId:vn.EIP155NetworkImageIds[n.id]}}async function sy(n){var r,s,a,c;if(!n)throw new Error("networkControllerClient:getApprovedCaipNetworks - connector is undefined");const e=await(n==null?void 0:n.getProvider()),t=(s=(r=e==null?void 0:e.signer)==null?void 0:r.session)==null?void 0:s.namespaces,i=(a=t==null?void 0:t[ae.EIP155])==null?void 0:a.methods,o=(c=t==null?void 0:t[ae.EIP155])==null?void 0:c.chains;return{supportsAllNetworks:!!(i!=null&&i.includes(ae.ADD_CHAIN_METHOD)),approvedCaipNetworkIds:o}}function ay(){return{supportsAllNetworks:!1,approvedCaipNetworkIds:vn.WalletConnectRpcChainIds.map(n=>`${ae.EIP155}:${n}`)}}function cy({chainId:n,projectId:e}){const t=F.getBlockchainApiUrl();return vn.WalletConnectRpcChainIds.includes(n)?zu(`${t}/v1/?chainId=${ae.EIP155}:${n}&projectId=${e}`):zu()}class ly extends ry{constructor(e){const{wagmiConfig:t,siweConfig:i,defaultChain:o,tokens:r,_sdkVersion:s,...a}=e;if(!t)throw new Error("web3modal:constructor - wagmiConfig is undefined");if(!a.projectId)throw new Error("web3modal:constructor - projectId is undefined");const c={switchCaipNetwork:async h=>{const p=er.caipNetworkIdToNumber(h==null?void 0:h.id);p&&await em(this.wagmiConfig,{chainId:p})},getApprovedCaipNetworksData:async()=>new Promise(h=>{var b,_;const g=new Map(t.state.connections).get(t.state.current||"");if(((b=g==null?void 0:g.connector)==null?void 0:b.id)===ae.EMAIL_CONNECTOR_ID)h(ay());else if(((_=g==null?void 0:g.connector)==null?void 0:_.id)===ae.WALLET_CONNECT_CONNECTOR_ID){const x=t.connectors.find(C=>C.id===ae.WALLET_CONNECT_CONNECTOR_ID);h(sy(x))}h({approvedCaipNetworkIds:void 0,supportsAllNetworks:!0})})},u={connectWalletConnect:async h=>{var _;const p=t.connectors.find(x=>x.id===ae.WALLET_CONNECT_CONNECTOR_ID);if(!p)throw new Error("connectionControllerClient:getWalletConnectUri - connector is undefined");(await p.getProvider()).on("display_uri",x=>{h(x)});const b=er.caipNetworkIdToNumber((_=this.getCaipNetwork())==null?void 0:_.id);await qu(this.wagmiConfig,{connector:p,chainId:b})},connectExternal:async({id:h,provider:p,info:g})=>{var x,C;const b=t.connectors.find($=>$.id===h);if(!b)throw new Error("connectionControllerClient:connectExternal - connector is undefined");p&&g&&b.id===ae.EIP6963_CONNECTOR_ID&&((x=b.setEip6963Wallet)==null||x.call(b,{provider:p,info:g}));const _=er.caipNetworkIdToNumber((C=this.getCaipNetwork())==null?void 0:C.id);await qu(this.wagmiConfig,{connector:b,chainId:_})},checkInstalled:h=>{const p=this.getConnectors().find(g=>g.type==="INJECTED");return h?p&&window!=null&&window.ethereum?h.some(g=>{var b;return!!((b=window.ethereum)!=null&&b[String(g)])}):!1:!!window.ethereum},disconnect:async()=>{var h;await Hg(this.wagmiConfig),(h=i==null?void 0:i.options)!=null&&h.signOutOnDisconnect&&await i.signOut()},signMessage:async h=>Xg(this.wagmiConfig,{message:h})};super({networkControllerClient:c,connectionControllerClient:u,siweControllerClient:i,defaultChain:oy(o),tokens:er.getCaipTokens(r),_sdkVersion:s??`html-wagmi-${ae.VERSION}`,...a}),this.hasSyncedConnectedAccount=!1,this.options=void 0,this.options=e,this.wagmiConfig=t,this.syncRequestedNetworks([...t.chains]),this.syncConnectors([...t.connectors]),nm(this.wagmiConfig,{onChange:h=>this.syncConnectors(h)}),tm(this.wagmiConfig,{onChange:h=>this.syncAccount({...h})})}getState(){const e=super.getState();return{...e,selectedNetworkId:er.caipNetworkIdToNumber(e.selectedNetworkId)}}subscribeState(e){return super.subscribeState(t=>e({...t,selectedNetworkId:er.caipNetworkIdToNumber(t.selectedNetworkId)}))}syncRequestedNetworks(e){const t=e==null?void 0:e.map(i=>{var o,r;return{id:`${ae.EIP155}:${i.id}`,name:i.name,imageId:vn.EIP155NetworkImageIds[i.id],imageUrl:(r=(o=this.options)==null?void 0:o.chainImages)==null?void 0:r[i.id]}});this.setRequestedCaipNetworks(t??[])}async syncAccount({address:e,isConnected:t,chainId:i}){if(this.resetAccount(),this.syncNetwork(),t&&e&&i){const o=`${ae.EIP155}:${i}:${e}`;this.setIsConnected(t),this.setCaipAddress(o),await Promise.all([this.syncProfile(e,i),this.syncBalance(e,i),this.getApprovedCaipNetworksData()]),this.hasSyncedConnectedAccount=!0}else!t&&this.hasSyncedConnectedAccount&&(this.resetWcConnection(),this.resetNetwork())}async syncNetwork(){var r,s,a,c;const{address:e,isConnected:t,chainId:i}=Ds(this.wagmiConfig),o=this.wagmiConfig.chains.find(u=>u.id===i);if(o||i){const u=(o==null?void 0:o.name)??(i==null?void 0:i.toString()),h=Number((o==null?void 0:o.id)??i),p=`${ae.EIP155}:${h}`;if(this.setCaipNetwork({id:p,name:u,imageId:vn.EIP155NetworkImageIds[h],imageUrl:(s=(r=this.options)==null?void 0:r.chainImages)==null?void 0:s[h]}),t&&e&&i){const g=`${ae.EIP155}:${h}:${e}`;if(this.setCaipAddress(g),(c=(a=o==null?void 0:o.blockExplorers)==null?void 0:a.default)!=null&&c.url){const b=`${o.blockExplorers.default.url}/address/${e}`;this.setAddressExplorerUrl(b)}else this.setAddressExplorerUrl(void 0);this.hasSyncedConnectedAccount&&(await this.syncProfile(e,i),await this.syncBalance(e,i))}}}async syncProfile(e,t){if(t!==mg.id){this.setProfileName(null),this.setProfileImage(null);return}try{const{name:i,avatar:o}=await this.fetchIdentity({caipChainId:`${ae.EIP155}:${t}`,address:e});this.setProfileName(i),this.setProfileImage(o)}catch{const i=await Jg(this.wagmiConfig,{address:e,chainId:t});if(i){this.setProfileName(i);const o=await Kg(this.wagmiConfig,{name:i,chainId:t});o&&this.setProfileImage(o)}}}async syncBalance(e,t){var o,r,s;const i=this.wagmiConfig.chains.find(a=>a.id===t);if(i){const a=await Yg(this.wagmiConfig,{address:e,chainId:i.id,token:(s=(r=(o=this.options)==null?void 0:o.tokens)==null?void 0:r[i.id])==null?void 0:s.address});this.setBalance(a.formatted,a.symbol);return}this.setBalance(void 0,void 0)}syncConnectors(e){const t=new Set,i=e.filter(a=>!t.has(a.id)&&t.add(a.id)),o=[],r=ae.COINBASE_SDK_CONNECTOR_ID,s=i.find(a=>a.id===pt.CONNECTOR_RDNS_MAP[r]);i.forEach(({id:a,name:c,type:u,icon:h})=>{var g,b;s&&a===r||ae.EMAIL_CONNECTOR_ID===a||o.push({id:a,explorerId:vn.ConnectorExplorerIds[a],imageUrl:((b=(g=this.options)==null?void 0:g.connectorImages)==null?void 0:b[a])??h,name:vn.ConnectorNamesMap[a]??c,imageId:vn.ConnectorImageIds[a],type:vn.ConnectorTypesMap[u]??"EXTERNAL"})}),this.setConnectors(o),this.syncEmailConnector(i)}async syncEmailConnector(e){const t=e.find(({id:i})=>i===ae.EMAIL_CONNECTOR_ID);if(t){const i=await t.getProvider();this.addConnector({id:ae.EMAIL_CONNECTOR_ID,type:"EMAIL",name:"Email",provider:i}),this.listenEmailConnector(t),this.listenModal(t)}}async listenEmailConnector(e){if(typeof window<"u"&&e){super.setLoading(!0);const t=await e.getProvider(),i=t.getLoginEmailUsed();super.setLoading(i),i&&this.setIsConnected(!1),t.onRpcRequest(o=>{Ve.checkIfRequestExists(o)?Ve.checkIfRequestIsAllowed(o)||super.open({view:"ApproveTransaction"}):(super.open(),setTimeout(()=>{this.showErrorMessage("This RPC method is not supported")},300),t.rejectRpcRequest())}),t.onRpcResponse(()=>{super.close()}),t.onNotConnected(()=>{this.setIsConnected(!1),super.setLoading(!1)}),t.onIsConnected(()=>{this.setIsConnected(!0),super.setLoading(!1)})}}async listenModal(e){const t=await e.getProvider();this.subscribeState(i=>{i.open||t.rejectRpcRequest()})}}var u1={},Qa={};Qa.byteLength=hy;Qa.toByteArray=fy;Qa.fromByteArray=wy;var Xt=[],_t=[],uy=typeof Uint8Array<"u"?Uint8Array:Array,Tc="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";for(var tr=0,dy=Tc.length;tr<dy;++tr)Xt[tr]=Tc[tr],_t[Tc.charCodeAt(tr)]=tr;_t[45]=62;_t[95]=63;function d1(n){var e=n.length;if(e%4>0)throw new Error("Invalid string. Length must be a multiple of 4");var t=n.indexOf("=");t===-1&&(t=e);var i=t===e?0:4-t%4;return[t,i]}function hy(n){var e=d1(n),t=e[0],i=e[1];return(t+i)*3/4-i}function py(n,e,t){return(e+t)*3/4-t}function fy(n){var e,t=d1(n),i=t[0],o=t[1],r=new uy(py(n,i,o)),s=0,a=o>0?i-4:i,c;for(c=0;c<a;c+=4)e=_t[n.charCodeAt(c)]<<18|_t[n.charCodeAt(c+1)]<<12|_t[n.charCodeAt(c+2)]<<6|_t[n.charCodeAt(c+3)],r[s++]=e>>16&255,r[s++]=e>>8&255,r[s++]=e&255;return o===2&&(e=_t[n.charCodeAt(c)]<<2|_t[n.charCodeAt(c+1)]>>4,r[s++]=e&255),o===1&&(e=_t[n.charCodeAt(c)]<<10|_t[n.charCodeAt(c+1)]<<4|_t[n.charCodeAt(c+2)]>>2,r[s++]=e>>8&255,r[s++]=e&255),r}function gy(n){return Xt[n>>18&63]+Xt[n>>12&63]+Xt[n>>6&63]+Xt[n&63]}function my(n,e,t){for(var i,o=[],r=e;r<t;r+=3)i=(n[r]<<16&16711680)+(n[r+1]<<8&65280)+(n[r+2]&255),o.push(gy(i));return o.join("")}function wy(n){for(var e,t=n.length,i=t%3,o=[],r=16383,s=0,a=t-i;s<a;s+=r)o.push(my(n,s,s+r>a?a:s+r));return i===1?(e=n[t-1],o.push(Xt[e>>2]+Xt[e<<4&63]+"==")):i===2&&(e=(n[t-2]<<8)+n[t-1],o.push(Xt[e>>10]+Xt[e>>4&63]+Xt[e<<2&63]+"=")),o.join("")}var cu={};/*! ieee754. BSD-3-Clause License. Feross Aboukhadijeh <https://feross.org/opensource> */cu.read=function(n,e,t,i,o){var r,s,a=o*8-i-1,c=(1<<a)-1,u=c>>1,h=-7,p=t?o-1:0,g=t?-1:1,b=n[e+p];for(p+=g,r=b&(1<<-h)-1,b>>=-h,h+=a;h>0;r=r*256+n[e+p],p+=g,h-=8);for(s=r&(1<<-h)-1,r>>=-h,h+=i;h>0;s=s*256+n[e+p],p+=g,h-=8);if(r===0)r=1-u;else{if(r===c)return s?NaN:(b?-1:1)*(1/0);s=s+Math.pow(2,i),r=r-u}return(b?-1:1)*s*Math.pow(2,r-i)};cu.write=function(n,e,t,i,o,r){var s,a,c,u=r*8-o-1,h=(1<<u)-1,p=h>>1,g=o===23?Math.pow(2,-24)-Math.pow(2,-77):0,b=i?0:r-1,_=i?1:-1,x=e<0||e===0&&1/e<0?1:0;for(e=Math.abs(e),isNaN(e)||e===1/0?(a=isNaN(e)?1:0,s=h):(s=Math.floor(Math.log(e)/Math.LN2),e*(c=Math.pow(2,-s))<1&&(s--,c*=2),s+p>=1?e+=g/c:e+=g*Math.pow(2,1-p),e*c>=2&&(s++,c/=2),s+p>=h?(a=0,s=h):s+p>=1?(a=(e*c-1)*Math.pow(2,o),s=s+p):(a=e*Math.pow(2,p-1)*Math.pow(2,o),s=0));o>=8;n[t+b]=a&255,b+=_,a/=256,o-=8);for(s=s<<o|a,u+=o;u>0;n[t+b]=s&255,b+=_,s/=256,u-=8);n[t+b-_]|=x*128};/*!
 * The buffer module from node.js, for the browser.
 *
 * @author   Feross Aboukhadijeh <https://feross.org>
 * @license  MIT
 */(function(n){const e=Qa,t=cu,i=typeof Symbol=="function"&&typeof Symbol.for=="function"?Symbol.for("nodejs.util.inspect.custom"):null;n.Buffer=a,n.SlowBuffer=R,n.INSPECT_MAX_BYTES=50;const o=2147483647;n.kMaxLength=o,a.TYPED_ARRAY_SUPPORT=r(),!a.TYPED_ARRAY_SUPPORT&&typeof console<"u"&&typeof console.error=="function"&&console.error("This browser lacks typed array (Uint8Array) support which is required by `buffer` v5.x. Use `buffer` v4.x if you require old browser support.");function r(){try{const f=new Uint8Array(1),l={foo:function(){return 42}};return Object.setPrototypeOf(l,Uint8Array.prototype),Object.setPrototypeOf(f,l),f.foo()===42}catch{return!1}}Object.defineProperty(a.prototype,"parent",{enumerable:!0,get:function(){if(a.isBuffer(this))return this.buffer}}),Object.defineProperty(a.prototype,"offset",{enumerable:!0,get:function(){if(a.isBuffer(this))return this.byteOffset}});function s(f){if(f>o)throw new RangeError('The value "'+f+'" is invalid for option "size"');const l=new Uint8Array(f);return Object.setPrototypeOf(l,a.prototype),l}function a(f,l,d){if(typeof f=="number"){if(typeof l=="string")throw new TypeError('The "string" argument must be of type string. Received type number');return p(f)}return c(f,l,d)}a.poolSize=8192;function c(f,l,d){if(typeof f=="string")return g(f,l);if(ArrayBuffer.isView(f))return _(f);if(f==null)throw new TypeError("The first argument must be one of type string, Buffer, ArrayBuffer, Array, or Array-like Object. Received type "+typeof f);if(Zt(f,ArrayBuffer)||f&&Zt(f.buffer,ArrayBuffer)||typeof SharedArrayBuffer<"u"&&(Zt(f,SharedArrayBuffer)||f&&Zt(f.buffer,SharedArrayBuffer)))return x(f,l,d);if(typeof f=="number")throw new TypeError('The "value" argument must not be of type number. Received type number');const m=f.valueOf&&f.valueOf();if(m!=null&&m!==f)return a.from(m,l,d);const E=C(f);if(E)return E;if(typeof Symbol<"u"&&Symbol.toPrimitive!=null&&typeof f[Symbol.toPrimitive]=="function")return a.from(f[Symbol.toPrimitive]("string"),l,d);throw new TypeError("The first argument must be one of type string, Buffer, ArrayBuffer, Array, or Array-like Object. Received type "+typeof f)}a.from=function(f,l,d){return c(f,l,d)},Object.setPrototypeOf(a.prototype,Uint8Array.prototype),Object.setPrototypeOf(a,Uint8Array);function u(f){if(typeof f!="number")throw new TypeError('"size" argument must be of type number');if(f<0)throw new RangeError('The value "'+f+'" is invalid for option "size"')}function h(f,l,d){return u(f),f<=0?s(f):l!==void 0?typeof d=="string"?s(f).fill(l,d):s(f).fill(l):s(f)}a.alloc=function(f,l,d){return h(f,l,d)};function p(f){return u(f),s(f<0?0:$(f)|0)}a.allocUnsafe=function(f){return p(f)},a.allocUnsafeSlow=function(f){return p(f)};function g(f,l){if((typeof l!="string"||l==="")&&(l="utf8"),!a.isEncoding(l))throw new TypeError("Unknown encoding: "+l);const d=T(f,l)|0;let m=s(d);const E=m.write(f,l);return E!==d&&(m=m.slice(0,E)),m}function b(f){const l=f.length<0?0:$(f.length)|0,d=s(l);for(let m=0;m<l;m+=1)d[m]=f[m]&255;return d}function _(f){if(Zt(f,Uint8Array)){const l=new Uint8Array(f);return x(l.buffer,l.byteOffset,l.byteLength)}return b(f)}function x(f,l,d){if(l<0||f.byteLength<l)throw new RangeError('"offset" is outside of buffer bounds');if(f.byteLength<l+(d||0))throw new RangeError('"length" is outside of buffer bounds');let m;return l===void 0&&d===void 0?m=new Uint8Array(f):d===void 0?m=new Uint8Array(f,l):m=new Uint8Array(f,l,d),Object.setPrototypeOf(m,a.prototype),m}function C(f){if(a.isBuffer(f)){const l=$(f.length)|0,d=s(l);return d.length===0||f.copy(d,0,0,l),d}if(f.length!==void 0)return typeof f.length!="number"||tc(f.length)?s(0):b(f);if(f.type==="Buffer"&&Array.isArray(f.data))return b(f.data)}function $(f){if(f>=o)throw new RangeError("Attempt to allocate Buffer larger than maximum size: 0x"+o.toString(16)+" bytes");return f|0}function R(f){return+f!=f&&(f=0),a.alloc(+f)}a.isBuffer=function(l){return l!=null&&l._isBuffer===!0&&l!==a.prototype},a.compare=function(l,d){if(Zt(l,Uint8Array)&&(l=a.from(l,l.offset,l.byteLength)),Zt(d,Uint8Array)&&(d=a.from(d,d.offset,d.byteLength)),!a.isBuffer(l)||!a.isBuffer(d))throw new TypeError('The "buf1", "buf2" arguments must be one of type Buffer or Uint8Array');if(l===d)return 0;let m=l.length,E=d.length;for(let I=0,O=Math.min(m,E);I<O;++I)if(l[I]!==d[I]){m=l[I],E=d[I];break}return m<E?-1:E<m?1:0},a.isEncoding=function(l){switch(String(l).toLowerCase()){case"hex":case"utf8":case"utf-8":case"ascii":case"latin1":case"binary":case"base64":case"ucs2":case"ucs-2":case"utf16le":case"utf-16le":return!0;default:return!1}},a.concat=function(l,d){if(!Array.isArray(l))throw new TypeError('"list" argument must be an Array of Buffers');if(l.length===0)return a.alloc(0);let m;if(d===void 0)for(d=0,m=0;m<l.length;++m)d+=l[m].length;const E=a.allocUnsafe(d);let I=0;for(m=0;m<l.length;++m){let O=l[m];if(Zt(O,Uint8Array))I+O.length>E.length?(a.isBuffer(O)||(O=a.from(O)),O.copy(E,I)):Uint8Array.prototype.set.call(E,O,I);else if(a.isBuffer(O))O.copy(E,I);else throw new TypeError('"list" argument must be an Array of Buffers');I+=O.length}return E};function T(f,l){if(a.isBuffer(f))return f.length;if(ArrayBuffer.isView(f)||Zt(f,ArrayBuffer))return f.byteLength;if(typeof f!="string")throw new TypeError('The "string" argument must be one of type string, Buffer, or ArrayBuffer. Received type '+typeof f);const d=f.length,m=arguments.length>2&&arguments[2]===!0;if(!m&&d===0)return 0;let E=!1;for(;;)switch(l){case"ascii":case"latin1":case"binary":return d;case"utf8":case"utf-8":return ec(f).length;case"ucs2":case"ucs-2":case"utf16le":case"utf-16le":return d*2;case"hex":return d>>>1;case"base64":return bu(f).length;default:if(E)return m?-1:ec(f).length;l=(""+l).toLowerCase(),E=!0}}a.byteLength=T;function y(f,l,d){let m=!1;if((l===void 0||l<0)&&(l=0),l>this.length||((d===void 0||d>this.length)&&(d=this.length),d<=0)||(d>>>=0,l>>>=0,d<=l))return"";for(f||(f="utf8");;)switch(f){case"hex":return f1(this,l,d);case"utf8":case"utf-8":return gn(this,l,d);case"ascii":return h1(this,l,d);case"latin1":case"binary":return p1(this,l,d);case"base64":return me(this,l,d);case"ucs2":case"ucs-2":case"utf16le":case"utf-16le":return g1(this,l,d);default:if(m)throw new TypeError("Unknown encoding: "+f);f=(f+"").toLowerCase(),m=!0}}a.prototype._isBuffer=!0;function S(f,l,d){const m=f[l];f[l]=f[d],f[d]=m}a.prototype.swap16=function(){const l=this.length;if(l%2!==0)throw new RangeError("Buffer size must be a multiple of 16-bits");for(let d=0;d<l;d+=2)S(this,d,d+1);return this},a.prototype.swap32=function(){const l=this.length;if(l%4!==0)throw new RangeError("Buffer size must be a multiple of 32-bits");for(let d=0;d<l;d+=4)S(this,d,d+3),S(this,d+1,d+2);return this},a.prototype.swap64=function(){const l=this.length;if(l%8!==0)throw new RangeError("Buffer size must be a multiple of 64-bits");for(let d=0;d<l;d+=8)S(this,d,d+7),S(this,d+1,d+6),S(this,d+2,d+5),S(this,d+3,d+4);return this},a.prototype.toString=function(){const l=this.length;return l===0?"":arguments.length===0?gn(this,0,l):y.apply(this,arguments)},a.prototype.toLocaleString=a.prototype.toString,a.prototype.equals=function(l){if(!a.isBuffer(l))throw new TypeError("Argument must be a Buffer");return this===l?!0:a.compare(this,l)===0},a.prototype.inspect=function(){let l="";const d=n.INSPECT_MAX_BYTES;return l=this.toString("hex",0,d).replace(/(.{2})/g,"$1 ").trim(),this.length>d&&(l+=" ... "),"<Buffer "+l+">"},i&&(a.prototype[i]=a.prototype.inspect),a.prototype.compare=function(l,d,m,E,I){if(Zt(l,Uint8Array)&&(l=a.from(l,l.offset,l.byteLength)),!a.isBuffer(l))throw new TypeError('The "target" argument must be one of type Buffer or Uint8Array. Received type '+typeof l);if(d===void 0&&(d=0),m===void 0&&(m=l?l.length:0),E===void 0&&(E=0),I===void 0&&(I=this.length),d<0||m>l.length||E<0||I>this.length)throw new RangeError("out of range index");if(E>=I&&d>=m)return 0;if(E>=I)return-1;if(d>=m)return 1;if(d>>>=0,m>>>=0,E>>>=0,I>>>=0,this===l)return 0;let O=I-E,pe=m-d;const Te=Math.min(O,pe),Ae=this.slice(E,I),Pe=l.slice(d,m);for(let _e=0;_e<Te;++_e)if(Ae[_e]!==Pe[_e]){O=Ae[_e],pe=Pe[_e];break}return O<pe?-1:pe<O?1:0};function M(f,l,d,m,E){if(f.length===0)return-1;if(typeof d=="string"?(m=d,d=0):d>2147483647?d=2147483647:d<-2147483648&&(d=-2147483648),d=+d,tc(d)&&(d=E?0:f.length-1),d<0&&(d=f.length+d),d>=f.length){if(E)return-1;d=f.length-1}else if(d<0)if(E)d=0;else return-1;if(typeof l=="string"&&(l=a.from(l,m)),a.isBuffer(l))return l.length===0?-1:D(f,l,d,m,E);if(typeof l=="number")return l=l&255,typeof Uint8Array.prototype.indexOf=="function"?E?Uint8Array.prototype.indexOf.call(f,l,d):Uint8Array.prototype.lastIndexOf.call(f,l,d):D(f,[l],d,m,E);throw new TypeError("val must be string, number or Buffer")}function D(f,l,d,m,E){let I=1,O=f.length,pe=l.length;if(m!==void 0&&(m=String(m).toLowerCase(),m==="ucs2"||m==="ucs-2"||m==="utf16le"||m==="utf-16le")){if(f.length<2||l.length<2)return-1;I=2,O/=2,pe/=2,d/=2}function Te(Pe,_e){return I===1?Pe[_e]:Pe.readUInt16BE(_e*I)}let Ae;if(E){let Pe=-1;for(Ae=d;Ae<O;Ae++)if(Te(f,Ae)===Te(l,Pe===-1?0:Ae-Pe)){if(Pe===-1&&(Pe=Ae),Ae-Pe+1===pe)return Pe*I}else Pe!==-1&&(Ae-=Ae-Pe),Pe=-1}else for(d+pe>O&&(d=O-pe),Ae=d;Ae>=0;Ae--){let Pe=!0;for(let _e=0;_e<pe;_e++)if(Te(f,Ae+_e)!==Te(l,_e)){Pe=!1;break}if(Pe)return Ae}return-1}a.prototype.includes=function(l,d,m){return this.indexOf(l,d,m)!==-1},a.prototype.indexOf=function(l,d,m){return M(this,l,d,m,!0)},a.prototype.lastIndexOf=function(l,d,m){return M(this,l,d,m,!1)};function ee(f,l,d,m){d=Number(d)||0;const E=f.length-d;m?(m=Number(m),m>E&&(m=E)):m=E;const I=l.length;m>I/2&&(m=I/2);let O;for(O=0;O<m;++O){const pe=parseInt(l.substr(O*2,2),16);if(tc(pe))return O;f[d+O]=pe}return O}function K(f,l,d,m){return ws(ec(l,f.length-d),f,d,m)}function H(f,l,d,m){return ws(v1(l),f,d,m)}function V(f,l,d,m){return ws(bu(l),f,d,m)}function re(f,l,d,m){return ws(y1(l,f.length-d),f,d,m)}a.prototype.write=function(l,d,m,E){if(d===void 0)E="utf8",m=this.length,d=0;else if(m===void 0&&typeof d=="string")E=d,m=this.length,d=0;else if(isFinite(d))d=d>>>0,isFinite(m)?(m=m>>>0,E===void 0&&(E="utf8")):(E=m,m=void 0);else throw new Error("Buffer.write(string, encoding, offset[, length]) is no longer supported");const I=this.length-d;if((m===void 0||m>I)&&(m=I),l.length>0&&(m<0||d<0)||d>this.length)throw new RangeError("Attempt to write outside buffer bounds");E||(E="utf8");let O=!1;for(;;)switch(E){case"hex":return ee(this,l,d,m);case"utf8":case"utf-8":return K(this,l,d,m);case"ascii":case"latin1":case"binary":return H(this,l,d,m);case"base64":return V(this,l,d,m);case"ucs2":case"ucs-2":case"utf16le":case"utf-16le":return re(this,l,d,m);default:if(O)throw new TypeError("Unknown encoding: "+E);E=(""+E).toLowerCase(),O=!0}},a.prototype.toJSON=function(){return{type:"Buffer",data:Array.prototype.slice.call(this._arr||this,0)}};function me(f,l,d){return l===0&&d===f.length?e.fromByteArray(f):e.fromByteArray(f.slice(l,d))}function gn(f,l,d){d=Math.min(f.length,d);const m=[];let E=l;for(;E<d;){const I=f[E];let O=null,pe=I>239?4:I>223?3:I>191?2:1;if(E+pe<=d){let Te,Ae,Pe,_e;switch(pe){case 1:I<128&&(O=I);break;case 2:Te=f[E+1],(Te&192)===128&&(_e=(I&31)<<6|Te&63,_e>127&&(O=_e));break;case 3:Te=f[E+1],Ae=f[E+2],(Te&192)===128&&(Ae&192)===128&&(_e=(I&15)<<12|(Te&63)<<6|Ae&63,_e>2047&&(_e<55296||_e>57343)&&(O=_e));break;case 4:Te=f[E+1],Ae=f[E+2],Pe=f[E+3],(Te&192)===128&&(Ae&192)===128&&(Pe&192)===128&&(_e=(I&15)<<18|(Te&63)<<12|(Ae&63)<<6|Pe&63,_e>65535&&_e<1114112&&(O=_e))}}O===null?(O=65533,pe=1):O>65535&&(O-=65536,m.push(O>>>10&1023|55296),O=56320|O&1023),m.push(O),E+=pe}return Vt(m)}const mn=4096;function Vt(f){const l=f.length;if(l<=mn)return String.fromCharCode.apply(String,f);let d="",m=0;for(;m<l;)d+=String.fromCharCode.apply(String,f.slice(m,m+=mn));return d}function h1(f,l,d){let m="";d=Math.min(f.length,d);for(let E=l;E<d;++E)m+=String.fromCharCode(f[E]&127);return m}function p1(f,l,d){let m="";d=Math.min(f.length,d);for(let E=l;E<d;++E)m+=String.fromCharCode(f[E]);return m}function f1(f,l,d){const m=f.length;(!l||l<0)&&(l=0),(!d||d<0||d>m)&&(d=m);let E="";for(let I=l;I<d;++I)E+=x1[f[I]];return E}function g1(f,l,d){const m=f.slice(l,d);let E="";for(let I=0;I<m.length-1;I+=2)E+=String.fromCharCode(m[I]+m[I+1]*256);return E}a.prototype.slice=function(l,d){const m=this.length;l=~~l,d=d===void 0?m:~~d,l<0?(l+=m,l<0&&(l=0)):l>m&&(l=m),d<0?(d+=m,d<0&&(d=0)):d>m&&(d=m),d<l&&(d=l);const E=this.subarray(l,d);return Object.setPrototypeOf(E,a.prototype),E};function Ue(f,l,d){if(f%1!==0||f<0)throw new RangeError("offset is not uint");if(f+l>d)throw new RangeError("Trying to access beyond buffer length")}a.prototype.readUintLE=a.prototype.readUIntLE=function(l,d,m){l=l>>>0,d=d>>>0,m||Ue(l,d,this.length);let E=this[l],I=1,O=0;for(;++O<d&&(I*=256);)E+=this[l+O]*I;return E},a.prototype.readUintBE=a.prototype.readUIntBE=function(l,d,m){l=l>>>0,d=d>>>0,m||Ue(l,d,this.length);let E=this[l+--d],I=1;for(;d>0&&(I*=256);)E+=this[l+--d]*I;return E},a.prototype.readUint8=a.prototype.readUInt8=function(l,d){return l=l>>>0,d||Ue(l,1,this.length),this[l]},a.prototype.readUint16LE=a.prototype.readUInt16LE=function(l,d){return l=l>>>0,d||Ue(l,2,this.length),this[l]|this[l+1]<<8},a.prototype.readUint16BE=a.prototype.readUInt16BE=function(l,d){return l=l>>>0,d||Ue(l,2,this.length),this[l]<<8|this[l+1]},a.prototype.readUint32LE=a.prototype.readUInt32LE=function(l,d){return l=l>>>0,d||Ue(l,4,this.length),(this[l]|this[l+1]<<8|this[l+2]<<16)+this[l+3]*16777216},a.prototype.readUint32BE=a.prototype.readUInt32BE=function(l,d){return l=l>>>0,d||Ue(l,4,this.length),this[l]*16777216+(this[l+1]<<16|this[l+2]<<8|this[l+3])},a.prototype.readBigUInt64LE=Tn(function(l){l=l>>>0,Ki(l,"offset");const d=this[l],m=this[l+7];(d===void 0||m===void 0)&&Zr(l,this.length-8);const E=d+this[++l]*2**8+this[++l]*2**16+this[++l]*2**24,I=this[++l]+this[++l]*2**8+this[++l]*2**16+m*2**24;return BigInt(E)+(BigInt(I)<<BigInt(32))}),a.prototype.readBigUInt64BE=Tn(function(l){l=l>>>0,Ki(l,"offset");const d=this[l],m=this[l+7];(d===void 0||m===void 0)&&Zr(l,this.length-8);const E=d*2**24+this[++l]*2**16+this[++l]*2**8+this[++l],I=this[++l]*2**24+this[++l]*2**16+this[++l]*2**8+m;return(BigInt(E)<<BigInt(32))+BigInt(I)}),a.prototype.readIntLE=function(l,d,m){l=l>>>0,d=d>>>0,m||Ue(l,d,this.length);let E=this[l],I=1,O=0;for(;++O<d&&(I*=256);)E+=this[l+O]*I;return I*=128,E>=I&&(E-=Math.pow(2,8*d)),E},a.prototype.readIntBE=function(l,d,m){l=l>>>0,d=d>>>0,m||Ue(l,d,this.length);let E=d,I=1,O=this[l+--E];for(;E>0&&(I*=256);)O+=this[l+--E]*I;return I*=128,O>=I&&(O-=Math.pow(2,8*d)),O},a.prototype.readInt8=function(l,d){return l=l>>>0,d||Ue(l,1,this.length),this[l]&128?(255-this[l]+1)*-1:this[l]},a.prototype.readInt16LE=function(l,d){l=l>>>0,d||Ue(l,2,this.length);const m=this[l]|this[l+1]<<8;return m&32768?m|4294901760:m},a.prototype.readInt16BE=function(l,d){l=l>>>0,d||Ue(l,2,this.length);const m=this[l+1]|this[l]<<8;return m&32768?m|4294901760:m},a.prototype.readInt32LE=function(l,d){return l=l>>>0,d||Ue(l,4,this.length),this[l]|this[l+1]<<8|this[l+2]<<16|this[l+3]<<24},a.prototype.readInt32BE=function(l,d){return l=l>>>0,d||Ue(l,4,this.length),this[l]<<24|this[l+1]<<16|this[l+2]<<8|this[l+3]},a.prototype.readBigInt64LE=Tn(function(l){l=l>>>0,Ki(l,"offset");const d=this[l],m=this[l+7];(d===void 0||m===void 0)&&Zr(l,this.length-8);const E=this[l+4]+this[l+5]*2**8+this[l+6]*2**16+(m<<24);return(BigInt(E)<<BigInt(32))+BigInt(d+this[++l]*2**8+this[++l]*2**16+this[++l]*2**24)}),a.prototype.readBigInt64BE=Tn(function(l){l=l>>>0,Ki(l,"offset");const d=this[l],m=this[l+7];(d===void 0||m===void 0)&&Zr(l,this.length-8);const E=(d<<24)+this[++l]*2**16+this[++l]*2**8+this[++l];return(BigInt(E)<<BigInt(32))+BigInt(this[++l]*2**24+this[++l]*2**16+this[++l]*2**8+m)}),a.prototype.readFloatLE=function(l,d){return l=l>>>0,d||Ue(l,4,this.length),t.read(this,l,!0,23,4)},a.prototype.readFloatBE=function(l,d){return l=l>>>0,d||Ue(l,4,this.length),t.read(this,l,!1,23,4)},a.prototype.readDoubleLE=function(l,d){return l=l>>>0,d||Ue(l,8,this.length),t.read(this,l,!0,52,8)},a.prototype.readDoubleBE=function(l,d){return l=l>>>0,d||Ue(l,8,this.length),t.read(this,l,!1,52,8)};function nt(f,l,d,m,E,I){if(!a.isBuffer(f))throw new TypeError('"buffer" argument must be a Buffer instance');if(l>E||l<I)throw new RangeError('"value" argument is out of bounds');if(d+m>f.length)throw new RangeError("Index out of range")}a.prototype.writeUintLE=a.prototype.writeUIntLE=function(l,d,m,E){if(l=+l,d=d>>>0,m=m>>>0,!E){const pe=Math.pow(2,8*m)-1;nt(this,l,d,m,pe,0)}let I=1,O=0;for(this[d]=l&255;++O<m&&(I*=256);)this[d+O]=l/I&255;return d+m},a.prototype.writeUintBE=a.prototype.writeUIntBE=function(l,d,m,E){if(l=+l,d=d>>>0,m=m>>>0,!E){const pe=Math.pow(2,8*m)-1;nt(this,l,d,m,pe,0)}let I=m-1,O=1;for(this[d+I]=l&255;--I>=0&&(O*=256);)this[d+I]=l/O&255;return d+m},a.prototype.writeUint8=a.prototype.writeUInt8=function(l,d,m){return l=+l,d=d>>>0,m||nt(this,l,d,1,255,0),this[d]=l&255,d+1},a.prototype.writeUint16LE=a.prototype.writeUInt16LE=function(l,d,m){return l=+l,d=d>>>0,m||nt(this,l,d,2,65535,0),this[d]=l&255,this[d+1]=l>>>8,d+2},a.prototype.writeUint16BE=a.prototype.writeUInt16BE=function(l,d,m){return l=+l,d=d>>>0,m||nt(this,l,d,2,65535,0),this[d]=l>>>8,this[d+1]=l&255,d+2},a.prototype.writeUint32LE=a.prototype.writeUInt32LE=function(l,d,m){return l=+l,d=d>>>0,m||nt(this,l,d,4,4294967295,0),this[d+3]=l>>>24,this[d+2]=l>>>16,this[d+1]=l>>>8,this[d]=l&255,d+4},a.prototype.writeUint32BE=a.prototype.writeUInt32BE=function(l,d,m){return l=+l,d=d>>>0,m||nt(this,l,d,4,4294967295,0),this[d]=l>>>24,this[d+1]=l>>>16,this[d+2]=l>>>8,this[d+3]=l&255,d+4};function du(f,l,d,m,E){wu(l,m,E,f,d,7);let I=Number(l&BigInt(4294967295));f[d++]=I,I=I>>8,f[d++]=I,I=I>>8,f[d++]=I,I=I>>8,f[d++]=I;let O=Number(l>>BigInt(32)&BigInt(4294967295));return f[d++]=O,O=O>>8,f[d++]=O,O=O>>8,f[d++]=O,O=O>>8,f[d++]=O,d}function hu(f,l,d,m,E){wu(l,m,E,f,d,7);let I=Number(l&BigInt(4294967295));f[d+7]=I,I=I>>8,f[d+6]=I,I=I>>8,f[d+5]=I,I=I>>8,f[d+4]=I;let O=Number(l>>BigInt(32)&BigInt(4294967295));return f[d+3]=O,O=O>>8,f[d+2]=O,O=O>>8,f[d+1]=O,O=O>>8,f[d]=O,d+8}a.prototype.writeBigUInt64LE=Tn(function(l,d=0){return du(this,l,d,BigInt(0),BigInt("0xffffffffffffffff"))}),a.prototype.writeBigUInt64BE=Tn(function(l,d=0){return hu(this,l,d,BigInt(0),BigInt("0xffffffffffffffff"))}),a.prototype.writeIntLE=function(l,d,m,E){if(l=+l,d=d>>>0,!E){const Te=Math.pow(2,8*m-1);nt(this,l,d,m,Te-1,-Te)}let I=0,O=1,pe=0;for(this[d]=l&255;++I<m&&(O*=256);)l<0&&pe===0&&this[d+I-1]!==0&&(pe=1),this[d+I]=(l/O>>0)-pe&255;return d+m},a.prototype.writeIntBE=function(l,d,m,E){if(l=+l,d=d>>>0,!E){const Te=Math.pow(2,8*m-1);nt(this,l,d,m,Te-1,-Te)}let I=m-1,O=1,pe=0;for(this[d+I]=l&255;--I>=0&&(O*=256);)l<0&&pe===0&&this[d+I+1]!==0&&(pe=1),this[d+I]=(l/O>>0)-pe&255;return d+m},a.prototype.writeInt8=function(l,d,m){return l=+l,d=d>>>0,m||nt(this,l,d,1,127,-128),l<0&&(l=255+l+1),this[d]=l&255,d+1},a.prototype.writeInt16LE=function(l,d,m){return l=+l,d=d>>>0,m||nt(this,l,d,2,32767,-32768),this[d]=l&255,this[d+1]=l>>>8,d+2},a.prototype.writeInt16BE=function(l,d,m){return l=+l,d=d>>>0,m||nt(this,l,d,2,32767,-32768),this[d]=l>>>8,this[d+1]=l&255,d+2},a.prototype.writeInt32LE=function(l,d,m){return l=+l,d=d>>>0,m||nt(this,l,d,4,2147483647,-2147483648),this[d]=l&255,this[d+1]=l>>>8,this[d+2]=l>>>16,this[d+3]=l>>>24,d+4},a.prototype.writeInt32BE=function(l,d,m){return l=+l,d=d>>>0,m||nt(this,l,d,4,2147483647,-2147483648),l<0&&(l=4294967295+l+1),this[d]=l>>>24,this[d+1]=l>>>16,this[d+2]=l>>>8,this[d+3]=l&255,d+4},a.prototype.writeBigInt64LE=Tn(function(l,d=0){return du(this,l,d,-BigInt("0x8000000000000000"),BigInt("0x7fffffffffffffff"))}),a.prototype.writeBigInt64BE=Tn(function(l,d=0){return hu(this,l,d,-BigInt("0x8000000000000000"),BigInt("0x7fffffffffffffff"))});function pu(f,l,d,m,E,I){if(d+m>f.length)throw new RangeError("Index out of range");if(d<0)throw new RangeError("Index out of range")}function fu(f,l,d,m,E){return l=+l,d=d>>>0,E||pu(f,l,d,4),t.write(f,l,d,m,23,4),d+4}a.prototype.writeFloatLE=function(l,d,m){return fu(this,l,d,!0,m)},a.prototype.writeFloatBE=function(l,d,m){return fu(this,l,d,!1,m)};function gu(f,l,d,m,E){return l=+l,d=d>>>0,E||pu(f,l,d,8),t.write(f,l,d,m,52,8),d+8}a.prototype.writeDoubleLE=function(l,d,m){return gu(this,l,d,!0,m)},a.prototype.writeDoubleBE=function(l,d,m){return gu(this,l,d,!1,m)},a.prototype.copy=function(l,d,m,E){if(!a.isBuffer(l))throw new TypeError("argument should be a Buffer");if(m||(m=0),!E&&E!==0&&(E=this.length),d>=l.length&&(d=l.length),d||(d=0),E>0&&E<m&&(E=m),E===m||l.length===0||this.length===0)return 0;if(d<0)throw new RangeError("targetStart out of bounds");if(m<0||m>=this.length)throw new RangeError("Index out of range");if(E<0)throw new RangeError("sourceEnd out of bounds");E>this.length&&(E=this.length),l.length-d<E-m&&(E=l.length-d+m);const I=E-m;return this===l&&typeof Uint8Array.prototype.copyWithin=="function"?this.copyWithin(d,m,E):Uint8Array.prototype.set.call(l,this.subarray(m,E),d),I},a.prototype.fill=function(l,d,m,E){if(typeof l=="string"){if(typeof d=="string"?(E=d,d=0,m=this.length):typeof m=="string"&&(E=m,m=this.length),E!==void 0&&typeof E!="string")throw new TypeError("encoding must be a string");if(typeof E=="string"&&!a.isEncoding(E))throw new TypeError("Unknown encoding: "+E);if(l.length===1){const O=l.charCodeAt(0);(E==="utf8"&&O<128||E==="latin1")&&(l=O)}}else typeof l=="number"?l=l&255:typeof l=="boolean"&&(l=Number(l));if(d<0||this.length<d||this.length<m)throw new RangeError("Out of range index");if(m<=d)return this;d=d>>>0,m=m===void 0?this.length:m>>>0,l||(l=0);let I;if(typeof l=="number")for(I=d;I<m;++I)this[I]=l;else{const O=a.isBuffer(l)?l:a.from(l,E),pe=O.length;if(pe===0)throw new TypeError('The value "'+l+'" is invalid for argument "value"');for(I=0;I<m-d;++I)this[I+d]=O[I%pe]}return this};const Yi={};function Xa(f,l,d){Yi[f]=class extends d{constructor(){super(),Object.defineProperty(this,"message",{value:l.apply(this,arguments),writable:!0,configurable:!0}),this.name=`${this.name} [${f}]`,this.stack,delete this.name}get code(){return f}set code(E){Object.defineProperty(this,"code",{configurable:!0,enumerable:!0,value:E,writable:!0})}toString(){return`${this.name} [${f}]: ${this.message}`}}}Xa("ERR_BUFFER_OUT_OF_BOUNDS",function(f){return f?`${f} is outside of buffer bounds`:"Attempt to access memory outside buffer bounds"},RangeError),Xa("ERR_INVALID_ARG_TYPE",function(f,l){return`The "${f}" argument must be of type number. Received type ${typeof l}`},TypeError),Xa("ERR_OUT_OF_RANGE",function(f,l,d){let m=`The value of "${f}" is out of range.`,E=d;return Number.isInteger(d)&&Math.abs(d)>2**32?E=mu(String(d)):typeof d=="bigint"&&(E=String(d),(d>BigInt(2)**BigInt(32)||d<-(BigInt(2)**BigInt(32)))&&(E=mu(E)),E+="n"),m+=` It must be ${l}. Received ${E}`,m},RangeError);function mu(f){let l="",d=f.length;const m=f[0]==="-"?1:0;for(;d>=m+4;d-=3)l=`_${f.slice(d-3,d)}${l}`;return`${f.slice(0,d)}${l}`}function m1(f,l,d){Ki(l,"offset"),(f[l]===void 0||f[l+d]===void 0)&&Zr(l,f.length-(d+1))}function wu(f,l,d,m,E,I){if(f>d||f<l){const O=typeof l=="bigint"?"n":"";let pe;throw I>3?l===0||l===BigInt(0)?pe=`>= 0${O} and < 2${O} ** ${(I+1)*8}${O}`:pe=`>= -(2${O} ** ${(I+1)*8-1}${O}) and < 2 ** ${(I+1)*8-1}${O}`:pe=`>= ${l}${O} and <= ${d}${O}`,new Yi.ERR_OUT_OF_RANGE("value",pe,f)}m1(m,E,I)}function Ki(f,l){if(typeof f!="number")throw new Yi.ERR_INVALID_ARG_TYPE(l,"number",f)}function Zr(f,l,d){throw Math.floor(f)!==f?(Ki(f,d),new Yi.ERR_OUT_OF_RANGE(d||"offset","an integer",f)):l<0?new Yi.ERR_BUFFER_OUT_OF_BOUNDS:new Yi.ERR_OUT_OF_RANGE(d||"offset",`>= ${d?1:0} and <= ${l}`,f)}const w1=/[^+/0-9A-Za-z-_]/g;function b1(f){if(f=f.split("=")[0],f=f.trim().replace(w1,""),f.length<2)return"";for(;f.length%4!==0;)f=f+"=";return f}function ec(f,l){l=l||1/0;let d;const m=f.length;let E=null;const I=[];for(let O=0;O<m;++O){if(d=f.charCodeAt(O),d>55295&&d<57344){if(!E){if(d>56319){(l-=3)>-1&&I.push(239,191,189);continue}else if(O+1===m){(l-=3)>-1&&I.push(239,191,189);continue}E=d;continue}if(d<56320){(l-=3)>-1&&I.push(239,191,189),E=d;continue}d=(E-55296<<10|d-56320)+65536}else E&&(l-=3)>-1&&I.push(239,191,189);if(E=null,d<128){if((l-=1)<0)break;I.push(d)}else if(d<2048){if((l-=2)<0)break;I.push(d>>6|192,d&63|128)}else if(d<65536){if((l-=3)<0)break;I.push(d>>12|224,d>>6&63|128,d&63|128)}else if(d<1114112){if((l-=4)<0)break;I.push(d>>18|240,d>>12&63|128,d>>6&63|128,d&63|128)}else throw new Error("Invalid code point")}return I}function v1(f){const l=[];for(let d=0;d<f.length;++d)l.push(f.charCodeAt(d)&255);return l}function y1(f,l){let d,m,E;const I=[];for(let O=0;O<f.length&&!((l-=2)<0);++O)d=f.charCodeAt(O),m=d>>8,E=d%256,I.push(E),I.push(m);return I}function bu(f){return e.toByteArray(b1(f))}function ws(f,l,d,m){let E;for(E=0;E<m&&!(E+d>=l.length||E>=f.length);++E)l[E+d]=f[E];return E}function Zt(f,l){return f instanceof l||f!=null&&f.constructor!=null&&f.constructor.name!=null&&f.constructor.name===l.name}function tc(f){return f!==f}const x1=function(){const f="0123456789abcdef",l=new Array(256);for(let d=0;d<16;++d){const m=d*16;for(let E=0;E<16;++E)l[m+E]=f[d]+f[E]}return l}();function Tn(f){return typeof BigInt>"u"?C1:f}function C1(){throw new Error("BigInt not supported")}})(u1);var Jd;typeof window<"u"&&(window.Buffer||(window.Buffer=u1.Buffer),window.global||(window.global=window),window.process||(window.process={}),(Jd=window.process)!=null&&Jd.env||(window.process={env:{}}));lu.type="coinbaseWallet";function lu(n){let t,i;return o=>({id:"coinbaseWalletSDK",name:"Coinbase Wallet",type:lu.type,async connect({chainId:r}={}){try{const s=await this.getProvider(),a=(await s.request({method:"eth_requestAccounts"})).map(u=>Ot(u));s.on("accountsChanged",this.onAccountsChanged),s.on("chainChanged",this.onChainChanged),s.on("disconnect",this.onDisconnect.bind(this));let c=await this.getChainId();if(r&&c!==r){const u=await this.switchChain({chainId:r}).catch(h=>{if(h.code===De.code)throw h;return{id:c}});c=(u==null?void 0:u.id)??c}return{accounts:a,chainId:c}}catch(s){throw/(user closed modal|accounts received is empty|user denied account)/i.test(s.message)?new De(s):s}},async disconnect(){const r=await this.getProvider();r.removeListener("accountsChanged",this.onAccountsChanged),r.removeListener("chainChanged",this.onChainChanged),r.removeListener("disconnect",this.onDisconnect.bind(this)),r.disconnect(),r.close()},async getAccounts(){return(await(await this.getProvider()).request({method:"eth_accounts"})).map(s=>Ot(s))},async getChainId(){const s=await(await this.getProvider()).request({method:"eth_chainId"});return en(s)},async getProvider(){var r;if(!i){const{default:s}=await ho(()=>import("./index.CW5oB1DO.js").then(g=>g.i),__vite__mapDeps([7,4,3,2,5,8]),import.meta.url);let a;typeof s!="function"&&typeof s.default=="function"?a=s.default:a=s,t=new a({reloadOnDisconnect:!1,...n});const c=(r=t.walletExtension)==null?void 0:r.getChainId(),u=o.chains.find(g=>n.chainId?g.id===n.chainId:g.id===c)||o.chains[0],h=n.chainId||(u==null?void 0:u.id),p=n.jsonRpcUrl||(u==null?void 0:u.rpcUrls.default.http[0]);i=t.makeWeb3Provider(p,h)}return i},async isAuthorized(){try{return!!(await this.getAccounts()).length}catch{return!1}},async switchChain({chainId:r}){var u,h;const s=o.chains.find(p=>p.id===r);if(!s)throw new ft(new fr);const a=await this.getProvider(),c=Ne(s.id);try{return await a.request({method:"wallet_switchEthereumChain",params:[{chainId:c}]}),s}catch(p){if(p.code===4902)try{return await a.request({method:"wallet_addEthereumChain",params:[{chainId:c,chainName:s.name,nativeCurrency:s.nativeCurrency,rpcUrls:[((u=s.rpcUrls.default)==null?void 0:u.http[0])??""],blockExplorerUrls:[(h=s.blockExplorers)==null?void 0:h.default.url]}]}),s}catch(g){throw new De(g)}throw new ft(p)}},onAccountsChanged(r){r.length===0?o.emitter.emit("disconnect"):o.emitter.emit("change",{accounts:r.map(s=>Ot(s))})},onChainChanged(r){const s=en(r);o.emitter.emit("change",{chainId:s})},async onDisconnect(r){o.emitter.emit("disconnect");const s=await this.getProvider();s.removeListener("accountsChanged",this.onAccountsChanged),s.removeListener("chainChanged",this.onChainChanged),s.removeListener("disconnect",this.onDisconnect.bind(this))}})}uu.type="walletConnect";function uu(n){const e=n.isNewChainsStale??!0;let t,i;const o="eip155";return r=>({id:"walletConnect",name:"WalletConnect",type:uu.type,async setup(){const s=await this.getProvider().catch(()=>null);s&&(s.on("connect",this.onConnect.bind(this)),s.on("session_delete",this.onSessionDelete.bind(this)))},async connect({chainId:s,...a}={}){var c,u;try{const h=await this.getProvider();if(!h)throw new ui;h.on("display_uri",this.onDisplayUri);let p=s;if(!p){const x=await((c=r.storage)==null?void 0:c.getItem("state"))??{};r.chains.some($=>$.id===x.chainId)?p=x.chainId:p=(u=r.chains[0])==null?void 0:u.id}if(!p)throw new Error("No chains found on connector.");const g=await this.isChainsStale();if(h.session&&g&&await h.disconnect(),!h.session||g){const x=r.chains.filter(C=>C.id!==p).map(C=>C.id);await h.connect({optionalChains:[p,...x],..."pairingTopic"in a?{pairingTopic:a.pairingTopic}:{}}),this.setRequestedChainsIds(r.chains.map(C=>C.id))}const b=(await h.enable()).map(x=>Ot(x)),_=await this.getChainId();return h.removeListener("display_uri",this.onDisplayUri),h.removeListener("connect",this.onConnect.bind(this)),h.on("accountsChanged",this.onAccountsChanged.bind(this)),h.on("chainChanged",this.onChainChanged),h.on("disconnect",this.onDisconnect.bind(this)),h.on("session_delete",this.onSessionDelete.bind(this)),{accounts:b,chainId:_}}catch(h){throw/(user rejected|connection request reset)/i.test(h==null?void 0:h.message)?new De(h):h}},async disconnect(){const s=await this.getProvider();try{await(s==null?void 0:s.disconnect())}catch(a){if(!/No matching key/i.test(a.message))throw a}finally{s==null||s.removeListener("accountsChanged",this.onAccountsChanged.bind(this)),s==null||s.removeListener("chainChanged",this.onChainChanged),s==null||s.removeListener("disconnect",this.onDisconnect.bind(this)),s==null||s.removeListener("session_delete",this.onSessionDelete.bind(this)),s==null||s.on("connect",this.onConnect.bind(this)),this.setRequestedChainsIds([])}},async getAccounts(){return(await this.getProvider()).accounts.map(a=>Ot(a))},async getProvider({chainId:s}={}){var c;async function a(){const u=r.chains.map(p=>p.id);if(!u.length)return;const{EthereumProvider:h}=await ho(()=>import("./index.es.CIvunKIP.js"),__vite__mapDeps([9,10,8,4,3,2,5,11]),import.meta.url);return await h.init({...n,disableProviderPing:!0,optionalChains:u,projectId:n.projectId,rpcMap:Object.fromEntries(r.chains.map(p=>[p.id,p.rpcUrls.default.http[0]])),showQrModal:n.showQrModal??!0})}return t||(i||(i=a()),t=await i,t==null||t.events.setMaxListeners(1/0)),s&&await((c=this.switchChain)==null?void 0:c.call(this,{chainId:s})),t},async getChainId(){return(await this.getProvider()).chainId},async isAuthorized(){try{const[s,a]=await Promise.all([this.getAccounts(),this.getProvider()]);return s.length?await this.isChainsStale()&&a.session?(await a.disconnect().catch(()=>{}),!1):!0:!1}catch{return!1}},async switchChain({chainId:s}){var c;const a=r.chains.find(u=>u.id===s);if(!a)throw new ft(new fr);try{const u=await this.getProvider(),h=this.getNamespaceChainsIds(),p=this.getNamespaceMethods();if(!h.includes(s)&&p.includes("wallet_addEthereumChain")){await u.request({method:"wallet_addEthereumChain",params:[{chainId:Ne(a.id),blockExplorerUrls:[(c=a.blockExplorers)==null?void 0:c.default.url],chainName:a.name,nativeCurrency:a.nativeCurrency,rpcUrls:[...a.rpcUrls.default.http]}]});const b=await this.getRequestedChainsIds();this.setRequestedChainsIds([...b,s])}return await u.request({method:"wallet_switchEthereumChain",params:[{chainId:Ne(s)}]}),a}catch(u){const h=typeof u=="string"?u:u==null?void 0:u.message;throw/user rejected request/i.test(h)?new De(u):new ft(u)}},onAccountsChanged(s){s.length===0?this.onDisconnect():r.emitter.emit("change",{accounts:s.map(a=>Ot(a))})},onChainChanged(s){const a=en(s);r.emitter.emit("change",{chainId:a})},async onConnect(s){const a=en(s.chainId),c=await this.getAccounts();r.emitter.emit("connect",{accounts:c,chainId:a})},async onDisconnect(s){this.setRequestedChainsIds([]),r.emitter.emit("disconnect");const a=await this.getProvider();a.removeListener("accountsChanged",this.onAccountsChanged.bind(this)),a.removeListener("chainChanged",this.onChainChanged),a.removeListener("disconnect",this.onDisconnect.bind(this)),a.removeListener("session_delete",this.onSessionDelete.bind(this)),a.on("connect",this.onConnect.bind(this))},onDisplayUri(s){r.emitter.emit("message",{type:"display_uri",data:s})},onSessionDelete(){this.onDisconnect()},getNamespaceChainsIds(){var a,c,u;return t?((u=(c=(a=t.session)==null?void 0:a.namespaces[o])==null?void 0:c.chains)==null?void 0:u.map(h=>parseInt(h.split(":")[1]||"")))??[]:[]},getNamespaceMethods(){var a,c;return t?((c=(a=t.session)==null?void 0:a.namespaces[o])==null?void 0:c.methods)??[]:[]},async getRequestedChainsIds(){var s;return await((s=r.storage)==null?void 0:s.getItem(this.requestedChainsStorageKey))??[]},async isChainsStale(){if(this.getNamespaceMethods().includes("wallet_addEthereumChain")||!e)return!1;const a=r.chains.map(h=>h.id),c=this.getNamespaceChainsIds();if(c.length&&!c.some(h=>a.includes(h)))return!1;const u=await this.getRequestedChainsIds();return!a.every(h=>u.includes(h))},async setRequestedChainsIds(s){var a;await((a=r.storage)==null?void 0:a.setItem(this.requestedChainsStorageKey,s))},get requestedChainsStorageKey(){return`${this.id}.requestedChains`}})}function by(n){return e=>({id:ae.EMAIL_CONNECTOR_ID,name:"Web3Modal Email",type:"w3mEmail",async connect(t={}){const i=await this.getProvider(),{address:o,chainId:r}=await i.connect({chainId:t.chainId});return{accounts:[o],account:o,chainId:r,chain:{id:r,unsuported:!1}}},async disconnect(){await(await this.getProvider()).disconnect()},async getAccounts(){const t=await this.getProvider(),{address:i}=await t.connect();return[i]},async getProvider(){return this.provider||(this.provider=new bv(n.options.projectId)),Promise.resolve(this.provider)},async getChainId(){const t=await this.getProvider(),{chainId:i}=await t.getChainId();return i},async isAuthorized(){const t=await this.getProvider(),{isConnected:i}=await t.isConnected();return i},async switchChain({chainId:t}){try{const i=e.chains.find(r=>r.id===t);if(!i)throw new ft(new Error("chain not found on connector."));return await(await this.getProvider()).switchNetwork(t),e.emitter.emit("change",{chainId:en(t)}),i}catch(i){throw i instanceof Error?new ft(i):i}},onAccountsChanged(t){t.length===0?this.onDisconnect():e.emitter.emit("change",{accounts:t.map(Ot)})},onChainChanged(t){const i=en(t);e.emitter.emit("change",{chainId:i})},async onConnect(t){const i=en(t.chainId),o=await this.getAccounts();e.emitter.emit("connect",{accounts:o,chainId:i})},async onDisconnect(t){await(await this.getProvider()).disconnect()}})}function vy({projectId:n,chains:e,metadata:t,enableInjected:i,enableCoinbase:o,enableEmail:r,enableWalletConnect:s,enableEIP6963:a,...c}){const u=[],h=e.map(g=>[g.id,cy({chainId:g.id,projectId:n})]),p=Object.fromEntries(h);return s!==!1&&u.push(uu({projectId:n,metadata:t,showQrModal:!1})),i!==!1&&u.push($a({shimDisconnect:!0})),o!==!1&&u.push(lu({appName:(t==null?void 0:t.name)??"Unknown",appLogoUrl:(t==null?void 0:t.icons[0])??"Unknown",enableMobileWalletLink:!0})),r===!0&&u.push(by({chains:[...e],options:{projectId:n}})),Fg({chains:e,multiInjectedProviderDiscovery:a!==!1,transports:p,...c,connectors:u})}function yy(n){return new ly({...n,_sdkVersion:`html-wagmi-${ae.VERSION}`})}const xy={name:"Distributed Funds",description:"Peer to peer grant pools.",url:"",icons:[]},wa=vy({chains:[Z1],projectId:c0,metadata:xy});Qg(wa);yy({wagmiConfig:wa,projectId:c0,enableAnalytics:!0});function Cy(n){let e;const t=n[7].default,i=A1(t,n,n[10],null);return{c(){i&&i.c()},l(o){i&&i.l(o)},m(o,r){i&&i.m(o,r),e=!0},p(o,r){i&&i.p&&(!e||r&1024)&&S1(i,t,o,o[10],e?R1(t,o[10],r,null):I1(o[10]),null)},i(o){e||(Tt(i,o),e=!0)},o(o){Pt(i,o),e=!1},d(o){i&&i.d(o)}}}function _y(n){let e,t,i;function o(s){n[9](s)}let r={decimals:q1,symbol:G1,maxValue:Eu(n[12].amount_range.max),showMaxButton:!1};return n[0]!==void 0&&(r.value=n[0]),e=new Y1({props:r}),Qd.push(()=>n0(e,"value",o)),{c(){Yt(e.$$.fragment)},l(s){Kt(e.$$.fragment,s)},m(s,a){Jt(e,s,a),i=!0},p(s,a){const c={};a&4096&&(c.maxValue=Eu(s[12].amount_range.max)),!t&&a&1&&(t=!0,c.value=s[0],Xd(()=>t=!1)),e.$set(c)},i(s){i||(Tt(e.$$.fragment,s),i=!0)},o(s){Pt(e.$$.fragment,s),i=!1},d(s){Qt(e,s)}}}function Ey(n){let e;return{c(){e=Pc("w3m-button")},l(t){e=Oc(t,"W3M-BUTTON",{}),kc(e).forEach(ht)},m(t,i){Gt(t,e,i)},p:T1,d(t){t&&ht(e)}}}function $y(n){let e;return{c(){e=e0("Save Draft")},l(t){e=t0(t,"Save Draft")},m(t,i){Gt(t,e,i)},d(t){t&&ht(e)}}}function Ay(n){let e;return{c(){e=e0("Submit")},l(t){e=t0(t,"Submit")},m(t,i){Gt(t,e,i)},d(t){t&&ht(e)}}}function Sy(n){let e,t,i,o,r,s,a,c,u,h,p,g,b,_,x,C,$;e=new k1({props:{title:"Apply",replacements:{[n[4]]:n[12].name}}}),i=new N1({props:{class:"mb-8",$$slots:{default:[Cy]},$$scope:{ctx:n}}});function R(y){n[8](y)}let T={view:"render",formDefinition:JSON.parse(n[13].form_schema).formDefinition};return n[1]!==void 0&&(T.renderApi=n[1]),s=new M1({props:T}),Qd.push(()=>n0(s,"renderApi",R)),u=new _u({props:{label:"Funding Amount",class:"mb-8",$$slots:{default:[_y]},$$scope:{ctx:n}}}),p=new _u({props:{label:"Wallet",helper:"The wallet address that will recieve funds if grant is approved.",class:"mb-8",$$slots:{default:[Ey]},$$scope:{ctx:n}}}),_=new $u({props:{color:"alternative",$$slots:{default:[$y]},$$scope:{ctx:n}}}),_.$on("click",n[5]),C=new $u({props:{color:"green",disabled:!n[3],$$slots:{default:[Ay]},$$scope:{ctx:n}}}),C.$on("click",n[6]),{c(){Yt(e.$$.fragment),t=Ji(),Yt(i.$$.fragment),o=Ji(),r=Pc("div"),Yt(s.$$.fragment),c=Ji(),Yt(u.$$.fragment),h=Ji(),Yt(p.$$.fragment),g=Ji(),b=Pc("div"),Yt(_.$$.fragment),x=Ji(),Yt(C.$$.fragment),this.h()},l(y){Kt(e.$$.fragment,y),t=Qi(y),Kt(i.$$.fragment,y),o=Qi(y),r=Oc(y,"DIV",{class:!0});var S=kc(r);Kt(s.$$.fragment,S),S.forEach(ht),c=Qi(y),Kt(u.$$.fragment,y),h=Qi(y),Kt(p.$$.fragment,y),g=Qi(y),b=Oc(y,"DIV",{class:!0});var M=kc(b);Kt(_.$$.fragment,M),x=Qi(M),Kt(C.$$.fragment,M),M.forEach(ht),this.h()},h(){vu(r,"class","mb-8"),vu(b,"class","flex items-center justify-end space-x-8")},m(y,S){Jt(e,y,S),Gt(y,t,S),Jt(i,y,S),Gt(y,o,S),Gt(y,r,S),Jt(s,r,null),Gt(y,c,S),Jt(u,y,S),Gt(y,h,S),Jt(p,y,S),Gt(y,g,S),Gt(y,b,S),Jt(_,b,null),$1(b,x),Jt(C,b,null),$=!0},p(y,S){const M={};S&4112&&(M.replacements={[y[4]]:y[12].name}),e.$set(M);const D={};S&1024&&(D.$$scope={dirty:S,ctx:y}),i.$set(D);const ee={};S&8192&&(ee.formDefinition=JSON.parse(y[13].form_schema).formDefinition),!a&&S&2&&(a=!0,ee.renderApi=y[1],Xd(()=>a=!1)),s.$set(ee);const K={};S&5121&&(K.$$scope={dirty:S,ctx:y}),u.$set(K);const H={};S&1024&&(H.$$scope={dirty:S,ctx:y}),p.$set(H);const V={};S&1024&&(V.$$scope={dirty:S,ctx:y}),_.$set(V);const re={};S&8&&(re.disabled=!y[3]),S&1024&&(re.$$scope={dirty:S,ctx:y}),C.$set(re)},i(y){$||(Tt(e.$$.fragment,y),Tt(i.$$.fragment,y),Tt(s.$$.fragment,y),Tt(u.$$.fragment,y),Tt(p.$$.fragment,y),Tt(_.$$.fragment,y),Tt(C.$$.fragment,y),$=!0)},o(y){Pt(e.$$.fragment,y),Pt(i.$$.fragment,y),Pt(s.$$.fragment,y),Pt(u.$$.fragment,y),Pt(p.$$.fragment,y),Pt(_.$$.fragment,y),Pt(C.$$.fragment,y),$=!1},d(y){y&&(ht(t),ht(o),ht(r),ht(c),ht(h),ht(g),ht(b)),Qt(e,y),Qt(i,y),Qt(s),Qt(u,y),Qt(p,y),Qt(_),Qt(C)}}}function Iy(n){let e,t;return e=new i0({props:{callZomeRequest:{cap_secret:null,role_name:"grant_pools",zome_name:"grants",fn_name:"get_application_template",payload:n[12].application_template},$$slots:{default:[Sy,({entry:i})=>({13:i}),({entry:i})=>i?8192:0]},$$scope:{ctx:n}}}),{c(){Yt(e.$$.fragment)},l(i){Kt(e.$$.fragment,i)},m(i,o){Jt(e,i,o),t=!0},p(i,o){const r={};o&4096&&(r.callZomeRequest={cap_secret:null,role_name:"grant_pools",zome_name:"grants",fn_name:"get_application_template",payload:i[12].application_template}),o&13339&&(r.$$scope={dirty:o,ctx:i}),e.$set(r)},i(i){t||(Tt(e.$$.fragment,i),t=!0)},o(i){Pt(e.$$.fragment,i),t=!1},d(i){Qt(e,i)}}}function Ry(n){let e,t;return e=new i0({props:{callZomeRequest:{cap_secret:null,role_name:"grant_pools",zome_name:"grants",fn_name:"get_grant_pool",payload:n[2]},$$slots:{default:[Iy,({entry:i})=>({12:i}),({entry:i})=>i?4096:0]},$$scope:{ctx:n}}}),{c(){Yt(e.$$.fragment)},l(i){Kt(e.$$.fragment,i)},m(i,o){Jt(e,i,o),t=!0},p(i,[o]){const r={};o&4&&(r.callZomeRequest={cap_secret:null,role_name:"grant_pools",zome_name:"grants",fn_name:"get_grant_pool",payload:i[2]}),o&5147&&(r.$$scope={dirty:o,ctx:i}),e.$set(r)},i(i){t||(Tt(e.$$.fragment,i),t=!0)},o(i){Pt(e.$$.fragment,i),t=!1},d(i){Qt(e,i)}}}function Ty(n,e,t){let i,o,r;E1(n,B1,x=>t(11,r=x));let{$$slots:s={},$$scope:a}=e,{amount:c=void 0}=e,{renderApi:u=void 0}=e,{actionHash:h}=e;async function p(){const x=await(u==null?void 0:u.getData()),C={grant_pool:h,form_content:x,amount:Cu(c),status:{type:Su.Draft,content:void 0},evm_wallet:Ds(wa).address};try{const $=await r.client.callZome({cap_secret:null,role_name:"grant_pools",zome_name:"grants",fn_name:"create_application",payload:C});Au(`/applications/${nc($.signed_action.hashed.hash)}`)}catch($){yu.error(`Error saving the application: ${$}`)}}async function g(){const x=await(u==null?void 0:u.getData()),C={grant_pool:h,form_content:x,amount:Cu(c),status:{type:Su.Submitted,content:void 0},evm_wallet:Ds(wa).address};try{const $=await r.client.callZome({cap_secret:null,role_name:"grant_pools",zome_name:"grants",fn_name:"create_application",payload:C});Au(`/applications/${nc($.signed_action.hashed.hash)}`)}catch($){yu.error(`Error creating the application: ${$}`)}}function b(x){u=x,t(1,u)}function _(x){c=x,t(0,c)}return n.$$set=x=>{"amount"in x&&t(0,c=x.amount),"renderApi"in x&&t(1,u=x.renderApi),"actionHash"in x&&t(2,h=x.actionHash),"$$scope"in x&&t(10,a=x.$$scope)},n.$$.update=()=>{n.$$.dirty&4&&t(4,i=nc(h)),n.$$.dirty&1&&t(3,o=c!==void 0&&c>0n)},[c,u,h,o,i,p,g,s,b,_,a]}class s7 extends P1{constructor(e){super(),O1(this,e,Ty,Ry,_1,{amount:0,renderApi:1,actionHash:2})}}export{s7 as C,Rg as E,no as H,fo as I,H0 as a,fi as b,Mf as c,df as d,bi as e,zp as f,ls as g,u1 as h,zn as i,Ke as p,Lt as s};
function __vite__mapDeps(indexes) {
  if (!__vite__mapDeps.viteFileDeps) {
    __vite__mapDeps.viteFileDeps = ["./ccip.BDCkY7fA.js","./u256.B5SpBLfz.js","./scheduler.B-whawdI.js","./index.DKySoX1N.js","./holochainClient.jrRPnoXI.js","./entry.B2_ArKaw.js","./RecordDetail.yaTjB-DJ.js","./index.CW5oB1DO.js","./events.Cz4l13dd.js","./index.es.CIvunKIP.js","./preload-helper.BQ24v_F8.js","./tslib.es6.UDDzLUu6.js"]
  }
  return indexes.map((i) => __vite__mapDeps.viteFileDeps[i])
}
