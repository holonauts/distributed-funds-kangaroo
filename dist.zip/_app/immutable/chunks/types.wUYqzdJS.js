var i=(e=>(e.Single="Single",e.Weighted="Weighted",e))(i||{}),r=(e=>(e.Draft="Draft",e.Submitted="Submitted",e.Claimed="Claimed",e))(r||{});export{r as S,i as a};
